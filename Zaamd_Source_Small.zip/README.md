# 鋼王騎帝 -ツァームド- / Z_Armed v1.0 integrated prototype

This build consolidates the previous v0.6-v0.9 work instead of replacing it with disconnected samples.

Implemented in this package:
- Title -> Main Menu with BGM transition
- Main Menu: BATTLE / WATCH / TRAINING / DATABASE / RECORD / OPTION
- Existing Firebase room prototype kept for BATTLE
- TRAINING hub: TUTORIAL / PRACTICE
- 5x7 board with Z LINE and both Front Lines
- White/Silver vs Black/Gold orientation
- Official Lv1-Lv3 ranges for King/Knight/Emperor families included in the offline core
- Soldier cross movement and Front Line temporary Pu behavior
- Turn system, 15 minute clocks, 90 second turn timer, 3-timeout loss rule
- Move / melee / shooting / control / control destruction / merge / skill
- Mutual-range shooting clash blocks shooting
- Merge/control stack state borders
- Destruction, Lv growth on large-piece kills, battle log, victory condition (2 of leader/core set lost)
- Database, rules, record and option screens
- All currently supplied battle/result/deployment BGM assets bundled
- GitHub Actions APK workflow included

Still scaffolded rather than production-complete:
- Full online matchmaking/RATE/friends/watch synchronization
- Final deployment/RPS flow
- Storage/revival UI and full Master/Strasse special-rule runtime
- Final art/pilot cut-ins/SFX/animations
- Production Firebase config/security deployment

The source is intentionally kept as one integrated build so later work continues from this package.
