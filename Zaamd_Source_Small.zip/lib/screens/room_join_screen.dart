import 'package:flutter/material.dart';
import '../services/room_service.dart';
import 'room_lobby_screen.dart';

class RoomJoinScreen extends StatefulWidget {
  const RoomJoinScreen({super.key});

  @override
  State<RoomJoinScreen> createState() => _RoomJoinScreenState();
}

class _RoomJoinScreenState extends State<RoomJoinScreen> {
  final _name = TextEditingController(text: 'PLAYER 2');
  final _code = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _join() async {
    setState(() { _loading = true; _error = null; });
    try {
      final room = await roomService.joinRoom(_code.text, _name.text);
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => RoomLobbyScreen(roomCode: room.code, isHost: false)),
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('部屋に入る')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'プレイヤー名')),
            const SizedBox(height: 12),
            TextField(
              controller: _code,
              keyboardType: TextInputType.number,
              maxLength: 6,
              decoration: const InputDecoration(labelText: '6桁の部屋コード'),
            ),
            const SizedBox(height: 12),
            FilledButton(onPressed: _loading ? null : _join, child: Text(_loading ? '接続中…' : '参加')),
            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: const TextStyle(color: Colors.redAccent)),
            ],
          ],
        ),
      ),
    );
  }
}
