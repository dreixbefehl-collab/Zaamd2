import 'package:flutter/material.dart';
import '../services/room_service.dart';
import 'room_lobby_screen.dart';

class RoomCreateScreen extends StatefulWidget {
  const RoomCreateScreen({super.key});

  @override
  State<RoomCreateScreen> createState() => _RoomCreateScreenState();
}

class _RoomCreateScreenState extends State<RoomCreateScreen> {
  final _name = TextEditingController(text: 'PLAYER 1');
  bool _loading = false;
  String? _error;

  Future<void> _create() async {
    setState(() { _loading = true; _error = null; });
    try {
      final room = await roomService.createRoom(_name.text);
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => RoomLobbyScreen(roomCode: room.code, isHost: true)),
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('部屋を作る')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'プレイヤー名')),
            const SizedBox(height: 24),
            FilledButton(onPressed: _loading ? null : _create, child: Text(_loading ? '作成中…' : '作成')),
            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: const TextStyle(color: Colors.redAccent)),
            ],
          ],
        ),
      ),
    );
  }
}
