import 'package:flutter/material.dart';

void main() => runApp(const ZaamdApp());

class ZaamdApp extends StatelessWidget {
  const ZaamdApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '鋼王騎帝 -ツァームド-',
        theme: ThemeData.dark(useMaterial3: true),
        home: const TitleScreen(),
      );
}

class TitleScreen extends StatelessWidget {
  const TitleScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('鋼王騎帝', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              const Text('- ツァームド -', style: TextStyle(fontSize: 24)),
              const SizedBox(height: 42),
              FilledButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MainMenuScreen())),
                child: const Text('START'),
              ),
            ]),
          ),
        ),
      );
}

class MainMenuScreen extends StatelessWidget {
  const MainMenuScreen({super.key});

  static const items = [
    ('BATTLE', '作戦開始'),
    ('WATCH', 'リプレイ鑑賞'),
    ('TRAINING', '訓練'),
    ('DATABASE', 'データベース'),
    ('RECORD', '戦績'),
    ('OPTION', '各種設定'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('鋼王騎帝 -ツァームド-')),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final item in items) ...[
                    SizedBox(
                      width: 250,
                      child: TextButton(
                        onPressed: item.$1 == 'BATTLE'
                            ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BattleMenuScreen()))
                            : () => ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('${item.$1} は仮組み中')),
                                ),
                        child: Column(
                          children: [
                            Text(
                              item.$1,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w700, letterSpacing: 1.5),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              item.$2,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 12, color: Colors.white60),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

class BattleMenuScreen extends StatelessWidget {
  const BattleMenuScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('BATTLE')),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const JankenScreen())),
                    child: const Column(
                      children: [
                        Text('CPU BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('CPU戦', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('ONLINE BATTLE は COMING SOON')),
                    ),
                    child: const Column(
                      children: [
                        Text('ONLINE BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('オンライン対戦  /  COMING SOON', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}


class JankenScreen extends StatefulWidget {
  const JankenScreen({super.key});

  @override
  State<JankenScreen> createState() => _JankenScreenState();
}

class _JankenScreenState extends State<JankenScreen> {
  String? playerHand;
  String? cpuHand;
  String? result;

  static const hands = ['グー', 'チョキ', 'パー'];

  void play(String hand) {
    final cpu = hands[DateTime.now().microsecondsSinceEpoch % 3];
    String r;
    if (hand == cpu) {
      r = 'DRAW';
    } else if ((hand == 'グー' && cpu == 'チョキ') ||
        (hand == 'チョキ' && cpu == 'パー') ||
        (hand == 'パー' && cpu == 'グー')) {
      r = 'WIN';
    } else {
      r = 'LOSE';
    }
    setState(() {
      playerHand = hand;
      cpuHand = cpu;
      result = r;
    });
  }

  void _goNext() {
    final playerWon = result == 'WIN';
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => UnitSelectionScreen(playerWonJanken: playerWon),
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('CPU BATTLE')),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('INITIATIVE', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('じゃんけん', style: TextStyle(fontSize: 15, color: Colors.white60)),
                  const SizedBox(height: 34),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 12,
                    children: [
                      for (final hand in hands)
                        OutlinedButton(
                          onPressed: (result == null || result == 'DRAW') ? () => play(hand) : null,
                          child: Text(hand, style: const TextStyle(fontSize: 18)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 34),
                  if (result != null) ...[
                    Text('YOU  $playerHand   /   CPU  $cpuHand', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 12),
                    Text(result!, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800, letterSpacing: 3)),
                    const SizedBox(height: 28),
                    if (result == 'DRAW')
                      FilledButton(
                        onPressed: () => setState(() {
                          playerHand = null;
                          cpuHand = null;
                          result = null;
                        }),
                        child: const Text('もう一度'),
                      )
                    else
                      FilledButton(onPressed: _goNext, child: const Text('NEXT')),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

enum BattleUnit { king, knight, emperor }

extension BattleUnitInfo on BattleUnit {
  String get title => switch (this) {
        BattleUnit.king => 'KING',
        BattleUnit.knight => 'KNIGHT',
        BattleUnit.emperor => 'EMPEROR',
      };

  String get jp => switch (this) {
        BattleUnit.king => 'キング',
        BattleUnit.knight => 'ナイト',
        BattleUnit.emperor => 'エンペラー',
      };

  String representativeAsset(bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (this) {
      BattleUnit.king => 'assets/pieces/${side}_king.png',
      BattleUnit.knight => 'assets/pieces/${side}_knight.png',
      BattleUnit.emperor => 'assets/pieces/${side}_emperor.png',
    };
  }
}

class UnitSelectionScreen extends StatefulWidget {
  final bool playerWonJanken;
  const UnitSelectionScreen({
    super.key,
    required this.playerWonJanken,
  });

  @override
  State<UnitSelectionScreen> createState() => _UnitSelectionScreenState();
}

class _UnitSelectionScreenState extends State<UnitSelectionScreen> {
  BattleUnit? selected;
  BattleUnit? playerUnit;
  BattleUnit? cpuUnit;
  int step = 0;

  bool get selectingPlayer =>
      widget.playerWonJanken ? step == 0 : step == 1;

  String get selectingName => selectingPlayer ? 'YOU' : 'CPU';

  void _confirm() {
    if (selected == null) return;

    setState(() {
      if (selectingPlayer) {
        playerUnit = selected;
      } else {
        cpuUnit = selected;
      }

      if (step == 0) {
        step = 1;
        selected = null;
        return;
      }
    });

    if (playerUnit == null || cpuUnit == null) return;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitiativeChoiceScreen(
        playerWonJanken: widget.playerWonJanken,
        playerUnit: playerUnit!,
        cpuUnit: cpuUnit!,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final winnerName = widget.playerWonJanken ? 'YOU' : 'CPU';
    final loserName = widget.playerWonJanken ? 'CPU' : 'YOU';
    final instruction = step == 0
        ? 'じゃんけん勝者：$winnerName － 先にユニットを選択'
        : 'じゃんけん敗者：$loserName － 次にユニットを選択';

    return Scaffold(
      appBar: AppBar(title: const Text('UNIT SELECT')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          child: Column(
            children: [
              Text(
                instruction,
                style: const TextStyle(fontSize: 15, color: Colors.white70),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                '現在：$selectingName のユニットを選択',
                style: const TextStyle(fontSize: 14, color: Colors.white60),
              ),
              const SizedBox(height: 18),
              Expanded(
                child: ListView.separated(
                  itemCount: BattleUnit.values.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    final unit = BattleUnit.values[i];
                    final active = selected == unit;
                    return InkWell(
                      onTap: () => setState(() => selected = unit),
                      borderRadius: BorderRadius.circular(14),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 120),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: active ? Colors.cyanAccent : Colors.white24,
                            width: active ? 2 : 1,
                          ),
                          color: active ? Colors.cyanAccent.withOpacity(.08) : Colors.white.withOpacity(.02),
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 78,
                              height: 78,
                              child: Image.asset(unit.representativeAsset(true), fit: BoxFit.contain),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(unit.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                                  const SizedBox(height: 2),
                                  Text(unit.jp, style: const TextStyle(color: Colors.white60)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: selected == null ? null : _confirm,
                  child: Text(step == 0 ? '決定して次へ' : '決定'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class InitiativeChoiceScreen extends StatefulWidget {
  final bool playerWonJanken;
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  const InitiativeChoiceScreen({
    super.key,
    required this.playerWonJanken,
    required this.playerUnit,
    required this.cpuUnit,
  });

  @override
  State<InitiativeChoiceScreen> createState() => _InitiativeChoiceScreenState();
}

class _InitiativeChoiceScreenState extends State<InitiativeChoiceScreen> {
  void _startSetup(bool winnerChoosesFirst) {
    // 勝者が先攻を選んだ場合：勝者が白。後攻なら勝者が黒。
    // YOU がじゃんけん勝者かどうかを加味して YOU の色を決める。
    final playerIsWhite = widget.playerWonJanken
        ? winnerChoosesFirst
        : !winnerChoosesFirst;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitialPlacementScreen(
        playerUnit: widget.playerUnit,
        cpuUnit: widget.cpuUnit,
        playerIsWhite: playerIsWhite,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final winnerName = widget.playerWonJanken ? 'YOU' : 'CPU';
    return Scaffold(
      appBar: AppBar(title: const Text('INITIATIVE')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('先攻・後攻選択', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Text(
                  'じゃんけん勝者：$winnerName が選択',
                  style: const TextStyle(color: Colors.white60),
                ),
                const SizedBox(height: 34),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: () => _startSetup(true),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('先攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('白枠 / 銀', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: () => _startSetup(false),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('後攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('黒枠 / 金', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class InitialPlacementScreen extends StatefulWidget {
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  final bool playerIsWhite;
  const InitialPlacementScreen({
    super.key,
    required this.playerUnit,
    required this.cpuUnit,
    required this.playerIsWhite,
  });

  @override
  State<InitialPlacementScreen> createState() => _InitialPlacementScreenState();
}

class _InitialPlacementScreenState extends State<InitialPlacementScreen> {
  late bool placingWhite;
  int whiteCoreType = 2;
  int blackCoreType = 2;
  final Map<int, Piece> whiteMajors = {};
  final Map<int, Piece> blackMajors = {};
  Piece? selectedMajor;
  bool whiteDone = false;
  bool blackDone = false;

  static const whiteSlots = <int>[27, 31, 32, 33];
  static const blackSlots = <int>[1, 2, 3, 7];

  @override
  void initState() {
    super.initState();
    // 初期配置は先攻（白/銀）→後攻（黒/金）の順に、
    // テスト端末上で両者とも手動配置する。
    placingWhite = true;
  }

  bool _isHumanSide(bool isWhite) => true;

  BattleUnit _unitForSide(bool isWhite) =>
      isWhite == widget.playerIsWhite ? widget.playerUnit : widget.cpuUnit;

  List<Piece> _rosterFor(BattleUnit unit, bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (unit) {
      BattleUnit.knight => [
          Piece('assets/pieces/${side}_knight.png', '騎', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_scholar.png', '博', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_general.png', '将', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_officer.png', '官', major: true, isWhite: isWhite),
        ],
      BattleUnit.king => [
          Piece('assets/pieces/${side}_king.png', '王', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_servant.png', '仕', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_guard.png', '護', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_fighter.png', '闘', major: true, isWhite: isWhite),
        ],
      BattleUnit.emperor => [
          Piece('assets/pieces/${side}_emperor.png', '帝', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_cannon.png', '砲', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_sword.png', '剣', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_shield.png', '盾', major: true, isWhite: isWhite),
        ],
    };
  }

  void _autoPlaceSide(bool isWhite) {
    final slots = isWhite ? whiteSlots : blackSlots;
    final target = isWhite ? whiteMajors : blackMajors;
    final roster = _rosterFor(_unitForSide(isWhite), isWhite);
    for (var i = 0; i < slots.length; i++) {
      target[slots[i]] = roster[i];
    }
  }

  String _coreAsset(bool isWhite) {
    final type = isWhite ? whiteCoreType : blackCoreType;
    return 'assets/pieces/${isWhite ? 'white' : 'black'}_core_$type.png';
  }

  Map<int, Piece> _fixedFor(bool isWhite) {
    if (isWhite) {
      return {
        25: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        26: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        28: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        29: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        30: Piece(_coreAsset(true), '核', isWhite: true),
        34: Piece(_coreAsset(true), '核', isWhite: true),
      };
    }
    return {
      0: Piece(_coreAsset(false), '核', isWhite: false),
      4: Piece(_coreAsset(false), '核', isWhite: false),
      5: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      6: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      8: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      9: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
    };
  }

  Map<int, Piece> _previewPieces() {
    final map = <int, Piece>{};
    map.addAll(_fixedFor(true));
    map.addAll(_fixedFor(false));
    map.addAll(whiteMajors);
    map.addAll(blackMajors);
    return map;
  }

  void _toggleCore(bool isWhite) {
    if (!_isHumanSide(isWhite) || placingWhite != isWhite) return;
    setState(() {
      if (isWhite) {
        whiteCoreType = whiteCoreType == 2 ? 1 : 2;
      } else {
        blackCoreType = blackCoreType == 2 ? 1 : 2;
      }
    });
  }

  void _tapPlacementCell(int index) {
    final isWhite = placingWhite;
    if (!_isHumanSide(isWhite)) return;
    final slots = isWhite ? whiteSlots : blackSlots;
    if (!slots.contains(index)) return;
    final target = isWhite ? whiteMajors : blackMajors;

    if (selectedMajor != null) {
      setState(() {
        final existingIndex = target.entries
            .where((e) => e.value.label == selectedMajor!.label)
            .map((e) => e.key)
            .cast<int?>()
            .firstWhere((_) => true, orElse: () => null);
        final displaced = target[index];
        if (existingIndex != null) {
          target.remove(existingIndex);
        }
        target[index] = selectedMajor!;
        if (displaced != null && existingIndex != null) {
          target[existingIndex] = displaced;
        }
        selectedMajor = null;
      });
      return;
    }

    final placed = target[index];
    if (placed != null) {
      setState(() => selectedMajor = placed);
    }
  }

  bool _sideComplete(bool isWhite) => (isWhite ? whiteMajors : blackMajors).length == 4;

  void _completeCurrentSide() {
    final side = placingWhite;
    if (!_sideComplete(side)) return;
    if (side) {
      whiteDone = true;
      setState(() {
        placingWhite = false;
        selectedMajor = null;
      });
    } else {
      blackDone = true;
      setState(() => selectedMajor = null);
    }

    if (whiteDone && blackDone) {
      final all = <int, Piece>{}
        ..addAll(_fixedFor(true))
        ..addAll(_fixedFor(false))
        ..addAll(whiteMajors)
        ..addAll(blackMajors);
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => BoardScreen(initialPieces: all, playerIsWhite: widget.playerIsWhite),
      ));
    }
  }

  Widget _pieceVisual(
    Piece piece, {
    bool playerPerspective = false,
    bool forceUpright = false,
  }) {
    if (piece.asset.isEmpty) {
      return Center(
        child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      );
    }
    final upright = forceUpright
        ? true
        : playerPerspective
            ? piece.isWhite == widget.playerIsWhite
            : piece.isWhite;
    return Transform.rotate(
      angle: upright ? 0 : 3.141592653589793,
      child: Image.asset(piece.asset, fit: BoxFit.contain),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pieces = _previewPieces();
    final humanTurn = _isHumanSide(placingWhite);
    final currentUnit = _unitForSide(placingWhite);
    final currentRoster = _rosterFor(currentUnit, placingWhite);
    final currentPlaced = placingWhite ? whiteMajors : blackMajors;

    return Scaffold(
      appBar: AppBar(title: const Text('INITIAL DEPLOYMENT')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Column(
                children: [
                  Text(
                    placingWhite ? '先攻  WHITE / SILVER  初期配置' : '後攻  BLACK / GOLD  初期配置',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: .8),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    humanTurn ? '核をタップで絵柄切替・大駒を選んで配置' : 'CPU 配置中',
                    style: const TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 5,
                      childAspectRatio: 1,
                    ),
                    itemCount: 35,
                    itemBuilder: (_, visualIndex) {
                      // 初期配置中も YOU は常に画面下側に表示する。
                      final i = widget.playerIsWhite ? visualIndex : 34 - visualIndex;
                      final piece = pieces[i];
                      final isCurrentSlot = (placingWhite ? whiteSlots : blackSlots).contains(i);
                      final isCurrentCore = placingWhite ? (i == 30 || i == 34) : (i == 0 || i == 4);
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (isCurrentCore) {
                            _toggleCore(placingWhite);
                          } else if (isCurrentSlot) {
                            _tapPlacementCell(i);
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.8) : Colors.white30,
                              width: isCurrentSlot && humanTurn ? 1.4 : .7,
                            ),
                            color: isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.05) : Colors.transparent,
                          ),
                          child: piece == null
                              ? null
                              : Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(3, 3, 3, 17),
                                      child: _pieceVisual(piece, playerPerspective: true),
                                    ),
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        width: double.infinity,
                                        color: Colors.black54,
                                        child: Text(piece.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            if (humanTurn) ...[
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: currentRoster.map((piece) {
                    final isPlaced = currentPlaced.values.any((p) => p.label == piece.label);
                    final active = selectedMajor?.label == piece.label;
                    return GestureDetector(
                      onTap: () => setState(() => selectedMajor = piece),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 100),
                        width: 72,
                        height: 88,
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          border: Border.all(color: active ? Colors.cyanAccent : Colors.white24, width: active ? 2 : 1),
                          borderRadius: BorderRadius.circular(8),
                          color: isPlaced ? Colors.white.withOpacity(.03) : Colors.white.withOpacity(.07),
                        ),
                        child: Column(
                          children: [
                            Expanded(child: _pieceVisual(piece, forceUpright: true)),
                            Text(piece.label, style: TextStyle(fontWeight: FontWeight.w800, color: isPlaced ? Colors.white54 : Colors.white)),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 6, 18, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _sideComplete(placingWhite) ? _completeCurrentSide : null,
                    child: Text(placingWhite ? '先攻側 配置完了' : '後攻側 配置完了'),
                  ),
                ),
              ),
            ] else
              Padding(
                padding: const EdgeInsets.all(18),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _completeCurrentSide,
                    child: const Text('CPU 配置完了'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class CrownBadge extends StatelessWidget {
  final Color color;
  final String value;
  final bool darkCrown;
  const CrownBadge({
    super.key,
    required this.color,
    required this.value,
    this.darkCrown = false,
  });

  @override
  Widget build(BuildContext context) {
    final light = Color.lerp(color, Colors.white, .42)!;
    final dark = Color.lerp(color, Colors.black, .45)!;
    final outline = darkCrown ? const Color(0xFFE7EBEF) : light;
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [light, color, dark],
          stops: const [0.0, .46, 1.0],
        ),
        border: Border.all(color: outline, width: 1.0),
        boxShadow: [
          BoxShadow(color: outline.withOpacity(.24), blurRadius: 3.2, spreadRadius: .1),
        ],
      ),
      child: Container(
        margin: const EdgeInsets.all(1.5),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xCC101318),
          border: Border.all(color: Colors.white.withOpacity(.12), width: .5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 13,
              height: 7.5,
              child: CustomPaint(
                painter: _CrownPainter(
                  fill: light,
                  stroke: darkCrown ? Colors.white : light,
                ),
              ),
            ),
            const SizedBox(height: .5),
            Text(
              value,
              style: const TextStyle(
                fontSize: 6.6,
                fontWeight: FontWeight.w900,
                height: .9,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CrownScoreDisplay extends StatelessWidget {
  final String label;
  final String value;
  const CrownScoreDisplay({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.045),
        border: Border.all(color: Colors.white24, width: .7),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: .7)),
          const SizedBox(width: 5),
          SizedBox(
            width: 13,
            height: 10,
            child: CustomPaint(
              painter: const _CrownPainter(fill: Color(0xFFD7DCE2), stroke: Colors.white),
            ),
          ),
          const SizedBox(width: 4),
          Text('$value / 3', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _CrownPainter extends CustomPainter {
  final Color fill;
  final Color stroke;
  const _CrownPainter({required this.fill, required this.stroke});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(w * .08, h * .25)
      ..lineTo(w * .28, h * .58)
      ..lineTo(w * .48, h * .18)
      ..lineTo(w * .68, h * .58)
      ..lineTo(w * .92, h * .25)
      ..lineTo(w * .82, h * .82)
      ..lineTo(w * .18, h * .82)
      ..close();
    canvas.drawPath(path, Paint()..color = fill..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()..color = stroke..style = PaintingStyle.stroke..strokeWidth = 1.0);
    canvas.drawLine(
      Offset(w * .17, h * .88),
      Offset(w * .83, h * .88),
      Paint()..color = stroke..strokeWidth = 1.1,
    );
  }

  @override
  bool shouldRepaint(covariant _CrownPainter oldDelegate) =>
      oldDelegate.fill != fill || oldDelegate.stroke != stroke;
}

class BattleResultScreen extends StatelessWidget {
  final bool playerWon;
  const BattleResultScreen({super.key, required this.playerWon});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    playerWon ? 'VICTORY' : 'DEFEAT',
                    style: const TextStyle(
                      fontSize: 44,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('♛ × 3', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 34),
                  FilledButton(
                    onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
                    child: const Text('TITLE'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class Piece {
  final String asset;
  final String label;
  final bool major;
  final bool isWhite;
  final int level;
  const Piece(
    this.asset,
    this.label, {
    this.major = false,
    required this.isWhite,
    this.level = 1,
  });

  Piece copyWith({
    String? asset,
    String? label,
    bool? major,
    bool? isWhite,
    int? level,
  }) {
    return Piece(
      asset ?? this.asset,
      label ?? this.label,
      major: major ?? this.major,
      isWhite: isWhite ?? this.isWhite,
      level: level ?? this.level,
    );
  }
}

class BoardScreen extends StatefulWidget {
  final Map<int, Piece> initialPieces;
  final bool playerIsWhite;
  const BoardScreen({
    super.key,
    required this.initialPieces,
    required this.playerIsWhite,
  });

  @override
  State<BoardScreen> createState() => _BoardScreenState();
}

class _BoardScreenState extends State<BoardScreen> with SingleTickerProviderStateMixin {
  int? selectedIndex;
  bool whiteTurn = true;
  // 帝「加速」：1回目を選んだ後、2回目の移動が可能なら強制する。
  // 現在は同一端末テスト版。対戦相手への移動経路秘匿・カットインは
  // オンライン同期時に2回目の成否だけ送る形で実装する。
  int _accelerationStep = 0; // 0=通常、1=最初の移動、2=2回目の移動
  int _rapidFireStep = 0; // 王「連射」：0=通常、1=1発目、2=2発目
  final List<Piece> _whiteDestroyedMajors = <Piece>[];
  final List<Piece> _blackDestroyedMajors = <Piece>[];
  Piece? _pendingRevivalPiece;
  Set<int> _pendingRevivalTargets = <int>{};
  final Set<int> lowerInfoCells = <int>{};
  late final AnimationController _mergeBlinkController;

  @override
  void initState() {
    super.initState();
    _mergeBlinkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..repeat(reverse: true);
    cells = {
      for (final entry in widget.initialPieces.entries) entry.key: [entry.value],
    };
    _whiteBattleUnit = _unitFromInitialPieces(true);
    _blackBattleUnit = _unitFromInitialPieces(false);
  }

  @override
  void dispose() {
    _mergeBlinkController.dispose();
    super.dispose();
  }

  late final Map<int, List<Piece>> cells;
  late final BattleUnit _whiteBattleUnit;
  late final BattleUnit _blackBattleUnit;

  // 格闘後などで、敵駒の上に乗って制圧しているマス。
  final Set<int> suppressedCells = <int>{};

  Piece? _topPieceAt(int index) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return null;
    return stack.last;
  }

  bool _isMergedCell(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    return stack.every((piece) => piece.isWhite == stack.first.isWhite);
  }

  bool _isSuppressedCell(int index) => suppressedCells.contains(index);

  BattleUnit _unitFromInitialPieces(bool isWhite) {
    final labels = widget.initialPieces.values
        .where((piece) => piece.isWhite == isWhite)
        .map((piece) => piece.label)
        .toSet();
    if (labels.contains('王')) return BattleUnit.king;
    if (labels.contains('帝')) return BattleUnit.emperor;
    return BattleUnit.knight;
  }

  BattleUnit _unitForPiece(Piece piece) =>
      piece.isWhite ? _whiteBattleUnit : _blackBattleUnit;

  bool _isLeaderPiece(Piece piece) {
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => piece.label == '王',
      BattleUnit.knight => piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式',
      BattleUnit.emperor => piece.label == '帝',
    };
  }

  double? _crownValueForPiece(Piece piece) {
    if (piece.label == '核' || _isLeaderPiece(piece)) return 1.5;
    return null;
  }

  Color _crownColorForPiece(Piece piece) {
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => const Color(0xFFFFD740),
      BattleUnit.knight => const Color(0xFF42A5F5),
      BattleUnit.emperor => const Color(0xFFFF5252),
    };
  }

  String? _crownAssetForPiece(Piece piece) {
    if (_crownValueForPiece(piece) != 1.5) return null;
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => 'assets/pieces/crown_king_1_5.webp',
      BattleUnit.knight => 'assets/pieces/crown_knight_1_5.webp',
      BattleUnit.emperor => 'assets/pieces/crown_emperor_1_5.webp',
    };
  }

  String _crownValueText(double value) => value == value.roundToDouble()
      ? value.toInt().toString()
      : value.toStringAsFixed(1);

  double _lostCrownPoints(bool isWhite) {
    final unit = isWhite ? _whiteBattleUnit : _blackBattleUnit;
    var coresAlive = 0;
    var leaderAlive = false;
    for (final stack in cells.values) {
      for (final piece in stack) {
        if (piece.isWhite != isWhite) continue;
        if (piece.label == '核') coresAlive++;
        final isLeader = switch (unit) {
          BattleUnit.king => piece.label == '王',
          BattleUnit.knight => piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式',
          BattleUnit.emperor => piece.label == '帝',
        };
        if (isLeader) leaderAlive = true;
      }
    }
    final missingCores = 2 - coresAlive.clamp(0, 2).toInt();
    final missingLeader = leaderAlive ? 0 : 1;
    return (missingCores + missingLeader) * 1.5;
  }

  bool _maybeFinishBattle() {
    final whiteDefeated = _lostCrownPoints(true) >= 3.0;
    final blackDefeated = _lostCrownPoints(false) >= 3.0;
    if (!whiteDefeated && !blackDefeated) return false;

    final winnerIsWhite = blackDefeated && !whiteDefeated;
    final playerWon = winnerIsWhite == widget.playerIsWhite;
    _accelerationStep = 0;
    _rapidFireStep = 0;
    selectedIndex = null;
    if (!mounted) return true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => BattleResultScreen(playerWon: playerWon)),
    );
    return true;
  }

  // 上方向を「前」とした白側用の相対座標。
  // 2026-09-22確定版：KNIGHT / KING / EMPEROR 全12大駒＋兵系。
  static const Map<String, List<List<int>>> lv1MoveOffsets = {
    '兵': [
      [-1, 0], [1, 0], [0, -1], [0, 1],
    ],
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '護': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '帝': [
      [-2, 0],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv2MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, 0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv3MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [0, -2], [0, 2],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, -1], [0, 1], [0, 2],
      [1, 0],
    ],
    '王': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -2], [0, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '核': <List<int>>[],
  };

  static const List<List<int>> mergedSoldierOffsets = [
    [-2, 0], [-1, 0],
    [0, -2], [0, -1], [0, 1], [0, 2],
    [1, 0], [2, 0],
  ];

  static const List<List<int>> frontlineSoldierOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  // 騎の変形形態はLv/Puの影響を受けない固定行動範囲。
  static const List<List<int>> knightSecondOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  static const List<List<int>> knightThirdOffsets = [
    [-2, -1], [-2, 1],
    [-1, -2], [-1, -1], [-1, 1], [-1, 2],
    [1, -1], [1, 1],
  ];

  bool _isKnightForm(Piece piece) =>
      piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式';

  bool _isFixedKnightForm(Piece piece) =>
      piece.label == '騎弐式' || piece.label == '騎参式';

  bool _isFrontlineForPiece(int index, Piece piece) {
    final row = index ~/ 5;
    // 白は下側から上へ進軍、黒は上側から下へ進軍。
    // 相手側3列に入ったら前線パンプ +1。
    return piece.isWhite ? row <= 2 : row >= 4;
  }

  bool _hasFrontlineMergeForSide(bool isWhite) {
    for (final entry in cells.entries) {
      final index = entry.key;
      if (!_isMergedCell(index)) continue;
      final top = _topPieceAt(index);
      if (top == null || top.isWhite != isWhite) continue;
      if (_isFrontlineForPiece(index, top)) return true;
    }
    return false;
  }

  int _pumpForPieceAt(int index, Piece piece, {bool? mergedOverride}) {
    if (!piece.major || _isFixedKnightForm(piece) || piece.level >= 3) return 0;

    final roomToLevel3 = 3 - piece.level;

    // 味方のどこかで「前線＋合流」が成立している間は、
    // 味方大駒全体を最大（実効Lv3）までパンプする。
    if (_hasFrontlineMergeForSide(piece.isWhite)) return roomToLevel3;

    final merged = mergedOverride ?? _isMergedCell(index);
    var pump = 0;
    if (merged) pump++;
    if (_isFrontlineForPiece(index, piece)) pump++;
    return pump > roomToLevel3 ? roomToLevel3 : pump;
  }

  int _effectiveLevelForPieceAt(int index, Piece piece, {bool? mergedOverride}) {
    if (!piece.major || _isFixedKnightForm(piece)) return piece.level;
    final pump = _pumpForPieceAt(index, piece, mergedOverride: mergedOverride);
    final effective = piece.level + pump;
    return effective > 3 ? 3 : effective;
  }

  List<List<int>> _levelOffsetsFor(String label, int level) {
    if (level >= 3) {
      return lv3MoveOffsets[label] ?? lv2MoveOffsets[label] ?? lv1MoveOffsets[label] ?? const <List<int>>[];
    }
    if (level == 2) {
      return lv2MoveOffsets[label] ?? lv1MoveOffsets[label] ?? const <List<int>>[];
    }
    return lv1MoveOffsets[label] ?? const <List<int>>[];
  }

  List<List<int>> _moveOffsetsFor(int index, Piece piece, {bool? mergedOverride}) {
    if (piece.label == '騎弐式') return knightSecondOffsets;
    if (piece.label == '騎参式') return knightThirdOffsets;

    final merged = mergedOverride ?? _isMergedCell(index);
    final frontline = _isFrontlineForPiece(index, piece);

    if (piece.label == '兵') {
      // 兵はLv成長なし。
      // 前線効果（または味方の前線合流による全体パンプ）= 3x3、
      // 合流効果 = 十字2。両方ある場合は効果を合成する。
      final teamMaxPump = _hasFrontlineMergeForSide(piece.isWhite);
      final hasFrontlineEffect = frontline || teamMaxPump;

      if (hasFrontlineEffect && merged) {
        final combined = <String, List<int>>{};
        for (final offset in frontlineSoldierOffsets) {
          combined['${offset[0]},${offset[1]}'] = offset;
        }
        for (final offset in mergedSoldierOffsets) {
          combined['${offset[0]},${offset[1]}'] = offset;
        }
        return combined.values.toList(growable: false);
      }
      if (hasFrontlineEffect) return frontlineSoldierOffsets;
      if (merged) return mergedSoldierOffsets;
      return lv1MoveOffsets['兵'] ?? const <List<int>>[];
    }

    final effectiveLevel = _effectiveLevelForPieceAt(index, piece, mergedOverride: merged);
    return _levelOffsetsFor(piece.label, effectiveLevel);
  }

  Set<int> _actionSquaresFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Set<int> _enemyTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    return _actionSquaresFor(index).where((target) {
      final targetPiece = _topPieceAt(target);
      return targetPiece != null && targetPiece.isWhite != piece.isWhite;
    }).toSet();
  }

  bool _isContested(int attackerIndex, int targetIndex) {
    return _actionSquaresFor(targetIndex).contains(attackerIndex);
  }

  Set<int> _actionSquaresForPieceAt(int index, Piece piece, {bool merged = false}) {
    final offsets = _moveOffsetsFor(index, piece, mergedOverride: merged);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};
    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Piece _pieceAfterKillLevelUp(Piece piece) {
    if (!piece.major || piece.level >= 3) return piece;
    return piece.copyWith(level: piece.level + 1);
  }

  void _recordDestroyedPiece(Piece piece) {
    if (!piece.major) return;
    (piece.isWhite ? _whiteDestroyedMajors : _blackDestroyedMajors).add(piece);
  }

  List<Piece> _destroyedMajorsFor(bool isWhite) =>
      isWhite ? _whiteDestroyedMajors : _blackDestroyedMajors;

  Set<int> _revivalTargetsFor(bool isWhite) {
    final result = <int>{};
    for (var i = 0; i < 35; i++) {
      final row = i ~/ 5;
      final inOwnFourRows = isWhite ? row >= 3 : row <= 3;
      if (!inOwnFourRows) continue;
      final stack = cells[i];
      if (stack == null || stack.isEmpty) {
        result.add(i);
        continue;
      }
      if (stack.length < 2 && stack.last.isWhite == isWhite) {
        result.add(i);
      }
    }
    return result;
  }

  List<MapEntry<int, Piece>> _lv3Candidates(bool isWhite) {
    final result = <MapEntry<int, Piece>>[];
    for (final entry in cells.entries) {
      final stack = entry.value;
      if (stack.isEmpty) continue;
      for (final piece in stack) {
        if (piece.isWhite == isWhite && piece.major && piece.level < 3) {
          result.add(MapEntry(entry.key, piece));
        }
      }
    }
    return result;
  }

  bool _canActivateCoreAt(int index) {
    if (_accelerationStep != 0 || _rapidFireStep != 0 || _pendingRevivalPiece != null) return false;
    final stack = cells[index];
    if (stack == null || stack.length != 1) return false;
    final core = stack.single;
    if (core.label != '核' || core.isWhite != whiteTurn) return false;
    if (_lostCrownPoints(core.isWhite) + 1.5 >= 3.0) return false;
    final canRevive = _destroyedMajorsFor(core.isWhite).isNotEmpty && _revivalTargetsFor(core.isWhite).isNotEmpty;
    final canLv3 = _lv3Candidates(core.isWhite).isNotEmpty;
    return canRevive || canLv3;
  }

  void _consumeCore(int index) {
    final stack = cells[index];
    if (stack == null || stack.length != 1 || stack.single.label != '核') return;
    cells.remove(index);
    lowerInfoCells.remove(index);
    selectedIndex = null;
  }

  void _startRevival(int coreIndex, Piece piece) {
    final targets = _revivalTargetsFor(piece.isWhite);
    if (targets.isEmpty) return;
    setState(() {
      _consumeCore(coreIndex);
      _pendingRevivalPiece = piece;
      _pendingRevivalTargets = targets;
    });
  }

  void _placeRevivedPiece(int index) {
    final piece = _pendingRevivalPiece;
    if (piece == null || !_pendingRevivalTargets.contains(index)) return;
    setState(() {
      final stack = cells[index];
      if (stack == null || stack.isEmpty) {
        cells[index] = [piece];
      } else {
        stack.add(piece);
        cells[index] = stack;
      }
      _destroyedMajorsFor(piece.isWhite).remove(piece);
      _pendingRevivalPiece = null;
      _pendingRevivalTargets = <int>{};
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('核発動・復活')));
  }

  void _applyInstantLv3(int coreIndex, int targetIndex, Piece targetPiece) {
    setState(() {
      _consumeCore(coreIndex);
      final stack = cells[targetIndex];
      if (stack != null) {
        final pos = stack.indexWhere((p) => identical(p, targetPiece));
        if (pos >= 0) stack[pos] = targetPiece.copyWith(level: 3);
        cells[targetIndex] = stack;
      }
      whiteTurn = !whiteTurn;
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('核発動・Lv3')));
  }

  void _showCoreActivationMenu(int index) {
    if (!_canActivateCoreAt(index)) return;
    final core = cells[index]!.single;
    final destroyed = List<Piece>.from(_destroyedMajorsFor(core.isWhite));
    final canRevive = destroyed.isNotEmpty && _revivalTargetsFor(core.isWhite).isNotEmpty;
    final lv3 = _lv3Candidates(core.isWhite);
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('核発動', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: canRevive ? () {
                    Navigator.of(sheetContext).pop();
                    _showRevivePieceMenu(index, destroyed);
                  } : null,
                  child: const Text('大駒を復活', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: lv3.isNotEmpty ? () {
                    Navigator.of(sheetContext).pop();
                    _showLv3TargetMenu(index, lv3);
                  } : null,
                  child: const Text('大駒を即Lv3', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRevivePieceMenu(int coreIndex, List<Piece> pieces) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('復活する大駒を選択', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final piece in pieces) ...[
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _startRevival(coreIndex, piece);
                    },
                    child: Text('${piece.label}  Lv${piece.level}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _showLv3TargetMenu(int coreIndex, List<MapEntry<int, Piece>> targets) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Lv3にする大駒を選択', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final entry in targets) ...[
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _applyInstantLv3(coreIndex, entry.key, entry.value);
                    },
                    child: Text('${entry.value.label}  Lv${entry.value.level} → Lv3', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Set<int> _legalRangedTargetsFor(
    int attackerIndex, {
    int? afterRemovingTopAt,
    Piece? attackerOverride,
  }) {
    final attacker = attackerOverride ?? _topPieceAt(attackerIndex);
    if (attacker == null) return const <int>{};
    final attackerMerged = _isMergedCell(attackerIndex);
    final inRange = _actionSquaresForPieceAt(attackerIndex, attacker, merged: attackerMerged);
    final result = <int>{};
    for (final target in inRange) {
      Piece? targetPiece;
      bool targetMerged = false;
      if (target == afterRemovingTopAt) {
        final stack = cells[target];
        if (stack != null && stack.length >= 2) {
          targetPiece = stack[stack.length - 2];
          targetMerged = false;
        }
      } else {
        targetPiece = _topPieceAt(target);
        targetMerged = _isMergedCell(target);
      }
      if (targetPiece == null || targetPiece.isWhite == attacker.isWhite) continue;
      final counterRange = _actionSquaresForPieceAt(target, targetPiece, merged: targetMerged);
      if (counterRange.contains(attackerIndex)) continue;
      result.add(target);
    }
    return result;
  }

  Set<int> _rapidFireFirstTargetsFor(int attackerIndex) {
    final attacker = _topPieceAt(attackerIndex);
    if (attacker == null) return const <int>{};
    final current = _legalRangedTargetsFor(attackerIndex);
    final leveledAfterFirst = _pieceAfterKillLevelUp(attacker);
    return current.where((first) =>
      _legalRangedTargetsFor(
        attackerIndex,
        afterRemovingTopAt: first,
        attackerOverride: leveledAfterFirst,
      ).isNotEmpty
    ).toSet();
  }

  bool _canUseRapidFire(int attackerIndex) => _rapidFireFirstTargetsFor(attackerIndex).isNotEmpty;

  void _executeMelee(int attackerIndex, int targetIndex) {
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasMerged = _isMergedCell(targetIndex);
    final targetWasSuppressed = _isSuppressedCell(targetIndex);

    setState(() {
      // 攻撃側は現在いるマスから上の駒だけが格闘に出る。
      var attacker = attackerStack.removeLast();
      attacker = _pieceAfterKillLevelUp(attacker);
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      } else if (_isSuppressedCell(attackerIndex)) {
        // 制圧していた上の駒が離れたので、下の駒は制圧解除。
        suppressedCells.remove(attackerIndex);
      }

      // 敵の上の駒を破壊。
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();

      if (targetWasSuppressed && targetStack.isNotEmpty) {
        // 制圧中の上側を格闘で破壊。下の駒は絶対に消さない。
        // 格闘した駒はそのマスへ移動するため、残った下の駒の上へ入る。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.remove(targetIndex);
      } else if (targetWasMerged && targetStack.isNotEmpty) {
        // 合流中の敵への格闘：上だけ破壊し、残った下を制圧。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.add(targetIndex);
      } else {
        // 通常格闘：敵を破壊し、その敵がいたマスへ移動。
        cells[targetIndex] = [attacker];
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    if (_maybeFinishBattle()) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(targetWasMerged ? '格闘成功・制圧' : '格闘成功')),
    );
  }

  void _executeRanged(int attackerIndex, int targetIndex) {
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasSuppressed = _isSuppressedCell(targetIndex);

    setState(() {
      // 射撃は攻撃側がその場に残り、敵の上の駒だけを破壊する。
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();
      attackerStack[attackerStack.length - 1] =
          _pieceAfterKillLevelUp(attackerStack.last);

      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        // 合流中・制圧中とも、下の駒は残す。
        cells[targetIndex] = targetStack;
      }

      // 制圧中の上側が射撃で破壊された場合、下の駒は制圧解除。
      if (targetWasSuppressed) {
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    if (_maybeFinishBattle()) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('射撃成功')),
    );
  }

  void _executeSuppression(int attackerIndex, int targetIndex) {
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;
    if (_isMergedCell(targetIndex) || _isSuppressedCell(targetIndex)) return;

    setState(() {
      // 制圧側は上の駒だけが対象マスへ移動する。
      final attacker = attackerStack.removeLast();
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      } else if (_isSuppressedCell(attackerIndex)) {
        // 制圧していた駒が離れた場合、下の駒は制圧解除。
        suppressedCells.remove(attackerIndex);
      }

      // 敵駒は破壊せず下に残し、その上へ攻撃側を重ねる。
      targetStack.add(attacker);
      cells[targetIndex] = targetStack;
      suppressedCells.add(targetIndex);

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('制圧成功')),
    );
  }


  void _executeSuppressionDestroy(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    setState(() {
      // 制圧破壊：下にいる敵駒だけを破壊し、制圧側の上駒はその場に残る。
      _recordDestroyedPiece(stack.first);
      stack.removeAt(0);
      stack[stack.length - 1] = _pieceAfterKillLevelUp(stack.last);
      cells[index] = stack;
      suppressedCells.remove(index);

      lowerInfoCells.remove(index);
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    if (_maybeFinishBattle()) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('制圧破壊')),
    );
  }

  void _showSuppressionDestroyMenu(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SUPPRESSION  ${bottomPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _executeSuppressionDestroy(index);
                    },
                    child: const Text(
                      '制圧破壊',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showActionMenu(int attackerIndex, int targetIndex) {
    final targetPiece = _topPieceAt(targetIndex);
    if (targetPiece == null) return;
    final contested = _isContested(attackerIndex, targetIndex);
    final targetMerged = _isMergedCell(targetIndex);
    final targetSuppressed = _isSuppressedCell(targetIndex);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        Widget actionButton(
          String label, {
          bool enabled = true,
          VoidCallback? onPressed,
        }) {
          return SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: enabled
                  ? (onPressed ??
                      () {
                        Navigator.of(sheetContext).pop();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('$label は次で実装')),
                        );
                      })
                  : null,
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: enabled ? null : Colors.white38,
                ),
              ),
            ),
          );
        }

        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'TARGET  ${targetPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                actionButton(
                  '格闘',
                  onPressed: () {
                    Navigator.of(sheetContext).pop();
                    _executeMelee(attackerIndex, targetIndex);
                  },
                ),
                const SizedBox(height: 8),
                actionButton(
                  contested ? '拮抗' : '射撃',
                  enabled: !contested,
                  onPressed: contested
                      ? null
                      : () {
                          Navigator.of(sheetContext).pop();
                          _executeRanged(attackerIndex, targetIndex);
                        },
                ),
                const SizedBox(height: 8),
                actionButton(
                  '制圧',
                  enabled: !targetMerged && !targetSuppressed,
                  onPressed: (targetMerged || targetSuppressed)
                      ? null
                      : () {
                          Navigator.of(sheetContext).pop();
                          _executeSuppression(attackerIndex, targetIndex);
                        },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Set<int> _moveTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      if (cells.containsKey(target)) continue;
      targets.add(target);
    }
    return targets;
  }

  Set<int> _mergeTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      final targetStack = cells[target];
      if (targetStack == null || targetStack.isEmpty) continue;
      final targetTop = targetStack.last;
      if (targetTop.isWhite != piece.isWhite) continue;
      if (targetStack.length >= 2) continue;
      targets.add(target);
    }
    return targets;
  }

  void _moveTopPiece({required int from, required int to, required bool merge}) {
    final sourceStack = cells[from];
    if (sourceStack == null || sourceStack.isEmpty) return;
    final wasSuppressed = _isSuppressedCell(from);
    final movingPiece = sourceStack.removeLast();
    if (sourceStack.isEmpty) {
      cells.remove(from);
    }
    if (wasSuppressed) {
      // 上の制圧側が離れたら、下の駒は行動可能に戻る。
      suppressedCells.remove(from);
    }

    lowerInfoCells.remove(from);
    lowerInfoCells.remove(to);

    if (merge) {
      final targetStack = cells[to] ?? <Piece>[];
      targetStack.add(movingPiece);
      cells[to] = targetStack;
    } else {
      cells[to] = [movingPiece];
    }
  }

  Piece _knightFormPiece(Piece current, String formLabel) {
    final side = current.isWhite ? 'white' : 'black';
    final asset = switch (formLabel) {
      '騎弐式' => 'assets/pieces/${side}_knight_2.png',
      '騎参式' => 'assets/pieces/${side}_knight_3.png',
      _ => 'assets/pieces/${side}_knight.png',
    };
    return Piece(
      asset,
      formLabel,
      major: true,
      isWhite: current.isWhite,
      level: current.level,
    );
  }

  void _executeKnightTransform(int index, String formLabel) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return;
    final current = stack.last;
    if (!_isKnightForm(current) || current.isWhite != whiteTurn) return;

    setState(() {
      stack[stack.length - 1] = _knightFormPiece(current, formLabel);
      cells[index] = stack;
      selectedIndex = null;
      lowerInfoCells.remove(index);
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${current.label} → $formLabel')),
    );
  }

  void _showKnightSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isKnightForm(piece)) return;
    if (piece.isWhite != whiteTurn) return;

    final forms = <String>['騎', '騎弐式', '騎参式']
        .where((form) => form != piece.label)
        .toList();

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SKILL  ${piece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                for (var n = 0; n < forms.length; n++) ...[
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.of(sheetContext).pop();
                        _executeKnightTransform(index, forms[n]);
                      },
                      child: Text(
                        '${forms[n]}へ変形',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  if (n != forms.length - 1) const SizedBox(height: 8),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  void _startKingRapidFire(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '王' || piece.isWhite != whiteTurn) return;
    if (!_canUseRapidFire(index)) return;
    setState(() {
      selectedIndex = index;
      lowerInfoCells.remove(index);
      _rapidFireStep = 1;
    });
  }

  void _showKingSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '王' || piece.isWhite != whiteTurn) return;
    final canRapid = _canUseRapidFire(index);
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  王', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: canRapid ? () {
                    Navigator.of(sheetContext).pop();
                    _startKingRapidFire(index);
                  } : null,
                  child: Text('連射', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canRapid ? null : Colors.white38)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _executeRapidFireShot(int attackerIndex, int targetIndex) {
    final targetStack = cells[targetIndex];
    if (targetStack == null || targetStack.isEmpty) return;
    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    setState(() {
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();
      final attackerStack = cells[attackerIndex];
      if (attackerStack != null && attackerStack.isNotEmpty) {
        attackerStack[attackerStack.length - 1] =
            _pieceAfterKillLevelUp(attackerStack.last);
        cells[attackerIndex] = attackerStack;
      }
      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        cells[targetIndex] = targetStack;
      }
      if (targetWasSuppressed) suppressedCells.remove(targetIndex);
      lowerInfoCells.clear();

      if (_rapidFireStep == 1) {
        selectedIndex = attackerIndex;
        _rapidFireStep = 2;
      } else {
        selectedIndex = null;
        _rapidFireStep = 0;
        whiteTurn = !whiteTurn;
      }
    });
    _maybeFinishBattle();
  }

  void _startEmperorAcceleration(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '帝' || piece.isWhite != whiteTurn) return;
    if (_moveTargetsFor(index).isEmpty) return;
    setState(() {
      selectedIndex = index;
      lowerInfoCells.remove(index);
      _accelerationStep = 1;
    });
  }

  void _showEmperorSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '帝' || piece.isWhite != whiteTurn) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  帝', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: _moveTargetsFor(index).isEmpty ? null : () {
                    Navigator.of(sheetContext).pop();
                    _startEmperorAcceleration(index);
                  },
                  child: const Text('加速', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleTap(int index) {
    if (_pendingRevivalPiece != null) {
      if (_pendingRevivalTargets.contains(index)) _placeRevivedPiece(index);
      return;
    }

    // 連射発動後は、合法な射撃対象以外の操作を受け付けない。
    if (_rapidFireStep != 0) {
      final attackerIndex = selectedIndex;
      if (attackerIndex == null) return;
      final legalTargets = _rapidFireStep == 1
          ? _rapidFireFirstTargetsFor(attackerIndex)
          : _legalRangedTargetsFor(attackerIndex);
      if (!legalTargets.contains(index)) return;
      _executeRapidFireShot(attackerIndex, index);
      return;
    }

    // 加速発動後は帝の移動先以外の操作を受け付けない。
    if (_accelerationStep != 0) {
      final from = selectedIndex;
      if (from == null || !_moveTargetsFor(from).contains(index)) return;
      final wasFirstMove = _accelerationStep == 1;
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        if (wasFirstMove && _moveTargetsFor(index).isNotEmpty) {
          selectedIndex = index;
          _accelerationStep = 2;
        } else {
          // 2回目が不可能なら通常移動と同じ結果でターン終了。
          selectedIndex = null;
          _accelerationStep = 0;
          whiteTurn = !whiteTurn;
        }
      });
      return;
    }
    final piece = _topPieceAt(index);
    final moveTargets = selectedIndex == null ? const <int>{} : _moveTargetsFor(selectedIndex!);
    final mergeTargets = selectedIndex == null ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final enemyTargets = selectedIndex == null ? const <int>{} : _enemyTargetsFor(selectedIndex!);
    final isCurrentSidePiece = piece != null &&
        piece.isWhite == whiteTurn;

    if (selectedIndex != null && enemyTargets.contains(index)) {
      _showActionMenu(selectedIndex!, index);
      return;
    }

    setState(() {
      if (selectedIndex != null && moveTargets.contains(index)) {
        _moveTopPiece(from: selectedIndex!, to: index, merge: false);
        whiteTurn = !whiteTurn;
        selectedIndex = null;
        return;
      }

      if (selectedIndex != null && mergeTargets.contains(index)) {
        _moveTopPiece(from: selectedIndex!, to: index, merge: true);
        whiteTurn = !whiteTurn;
        selectedIndex = null;
        return;
      }

      if (isCurrentSidePiece) {
        final stack = cells[index];
        final isStacked = stack != null && stack.length > 1;
        if (selectedIndex == index && isStacked) {
          // 重なり中の同じマスをもう一度タップすると、情報欄だけ上↔下を切り替える。
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
        selectedIndex = selectedIndex == index ? null : index;
        lowerInfoCells.remove(index);
        return;
      }

      // 未選択時なら、敵の重なりマスも情報だけ確認できる。
      if (selectedIndex == null && piece != null) {
        final stack = cells[index];
        if (stack != null && stack.length > 1) {
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
      }

      if (piece == null) {
        selectedIndex = null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final moveTargets = (_rapidFireStep != 0 || selectedIndex == null) ? const <int>{} : _moveTargetsFor(selectedIndex!);
    final mergeTargets = (_accelerationStep != 0 || _rapidFireStep != 0 || selectedIndex == null) ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final enemyTargets = _rapidFireStep != 0 && selectedIndex != null
        ? (_rapidFireStep == 1 ? _rapidFireFirstTargetsFor(selectedIndex!) : _legalRangedTargetsFor(selectedIndex!))
        : (_accelerationStep != 0 || selectedIndex == null ? const <int>{} : _enemyTargetsFor(selectedIndex!));
    final selectedPiece = selectedIndex == null ? null : _topPieceAt(selectedIndex!);
    final canUseCore = selectedIndex != null && _canActivateCoreAt(selectedIndex!);
    final canShowKingSkill = _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null && selectedPiece.label == '王' && selectedPiece.isWhite == whiteTurn;
    final canUseKingSkill = canShowKingSkill && _canUseRapidFire(selectedIndex!);
    final canUseEmperorSkill = _accelerationStep == 0 && _rapidFireStep == 0 &&
        selectedIndex != null &&
        selectedPiece != null &&
        selectedPiece.label == '帝' &&
        selectedPiece.isWhite == whiteTurn;
    final canUseKnightSkill = _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null &&
        _isKnightForm(selectedPiece) &&
        selectedPiece.isWhite == whiteTurn;
    final whiteCapturedCrowns = _lostCrownPoints(false);
    final blackCapturedCrowns = _lostCrownPoints(true);

    return Scaffold(
      appBar: AppBar(title: const Text('鋼王騎帝 -ツァームド-')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 6),
              child: Text(
                _pendingRevivalPiece != null
                    ? '復活位置を選択'
                    : (_rapidFireStep != 0
                        ? '連射  SHOT $_rapidFireStep / 2'
                        : (_accelerationStep == 0 ? (whiteTurn ? 'WHITE TURN' : 'BLACK TURN') : '加速  MOVE $_accelerationStep / 2')),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.8,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CrownScoreDisplay(label: 'WHITE', value: _crownValueText(whiteCapturedCrowns)),
                  const SizedBox(width: 8),
                  CrownScoreDisplay(label: 'BLACK', value: _crownValueText(blackCapturedCrowns)),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5,
              childAspectRatio: 1,
            ),
            itemCount: 35,
            itemBuilder: (_, visualIndex) {
              // YOU は常に画面下側。YOU が黒/金なら盤面表示だけ180度反転する。
              final i = widget.playerIsWhite ? visualIndex : 34 - visualIndex;
              final r = visualIndex ~/ 5, c = visualIndex % 5;
              final cellStack = cells[i];
              final piece = _topPieceAt(i);
              final basePiece = (cellStack != null && cellStack.length > 1) ? cellStack.first : null;
              final isSelected = selectedIndex == i;
              final isMoveTarget = moveTargets.contains(i);
              final isMergeTarget = mergeTargets.contains(i);
              final isEnemyTarget = enemyTargets.contains(i);
              final isMergedCell = _isMergedCell(i);
              final isSuppressedCell = _isSuppressedCell(i);
              final isStackedCell = cellStack != null && cellStack.length > 1;
              final showingLowerInfo = isStackedCell && lowerInfoCells.contains(i);
              final infoPiece = showingLowerInfo ? cellStack!.first : piece;
              final infoPump = infoPiece == null
                  ? 0
                  : _pumpForPieceAt(i, infoPiece, mergedOverride: isMergedCell);
              final showInfoPu = infoPiece != null &&
                  infoPiece.major &&
                  infoPiece.level < 3 &&
                  !_isFixedKnightForm(infoPiece);

              final isRevivalTarget = _pendingRevivalTargets.contains(i);

              Color borderColor;
              double borderWidth;
              List<BoxShadow>? glow;
              Color fillColor;

              if (isRevivalTarget) {
                borderColor = Colors.greenAccent;
                borderWidth = 3.0;
                glow = const [
                  BoxShadow(color: Colors.greenAccent, blurRadius: 10, spreadRadius: 1),
                ];
                fillColor = Colors.greenAccent.withOpacity(.20);
              } else if (isSelected) {
                borderColor = Colors.lightBlueAccent;
                borderWidth = 2.4;
                glow = const [
                  BoxShadow(
                    color: Colors.lightBlueAccent,
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ];
                fillColor = Colors.lightBlueAccent.withOpacity(.12);
              } else if (isMergeTarget) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.0;
                glow = const [
                  BoxShadow(
                    color: Colors.greenAccent,
                    blurRadius: 8,
                    spreadRadius: .6,
                  ),
                ];
                fillColor = Colors.greenAccent.withOpacity(.16);
              } else if (isMoveTarget) {
                borderColor = Colors.cyanAccent;
                borderWidth = 2.0;
                glow = const [
                  BoxShadow(
                    color: Colors.cyanAccent,
                    blurRadius: 7,
                    spreadRadius: .5,
                  ),
                ];
                fillColor = Colors.cyanAccent.withOpacity(.18);
              } else if (isEnemyTarget) {
                borderColor = Colors.redAccent;
                borderWidth = 2.2;
                glow = const [
                  BoxShadow(
                    color: Colors.redAccent,
                    blurRadius: 8,
                    spreadRadius: .6,
                  ),
                ];
                fillColor = Colors.redAccent.withOpacity(.16);
              } else if (isSuppressedCell) {
                borderColor = Colors.redAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.redAccent.withOpacity(.04);
              } else if (isMergedCell) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.greenAccent.withOpacity(.04);
              } else {
                borderColor = Colors.white38;
                borderWidth = .7;
                glow = null;
                fillColor = (r + c).isEven ? Colors.white10 : Colors.black12;
              }

              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _handleTap(i),
                onLongPress: () {
                  final top = _topPieceAt(i);
                  if (_accelerationStep == 0 && _rapidFireStep == 0 && top != null &&
                      top.isWhite == whiteTurn &&
                      _isSuppressedCell(i)) {
                    _showSuppressionDestroyMenu(i);
                  }
                },
                child: AnimatedBuilder(
                  animation: _mergeBlinkController,
                  builder: (context, child) {
                    final blink = 0.25 + (_mergeBlinkController.value * 0.75);
                    final showSuppressionBlink = isSuppressedCell && !isSelected && !isMergeTarget && !isEnemyTarget;
                    final showMergeBlink = isMergedCell && !isSelected && !isMergeTarget && !isEnemyTarget;
                    final blinkColor = showSuppressionBlink ? Colors.redAccent : Colors.greenAccent;
                    final showStateBlink = showSuppressionBlink || showMergeBlink;
                    final effectiveBorderColor = showStateBlink
                        ? blinkColor.withOpacity(blink)
                        : borderColor;
                    final effectiveBorderWidth = showStateBlink ? 2.2 : borderWidth;
                    final effectiveGlow = showStateBlink
                        ? [
                            BoxShadow(
                              color: blinkColor.withOpacity(blink * 0.85),
                              blurRadius: 4 + (7 * _mergeBlinkController.value),
                              spreadRadius: .2 + (.8 * _mergeBlinkController.value),
                            ),
                          ]
                        : glow;

                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 90),
                      decoration: BoxDecoration(
                        border: Border.all(color: effectiveBorderColor, width: effectiveBorderWidth),
                        boxShadow: effectiveGlow,
                        color: fillColor,
                      ),
                  child: piece == null
                      ? null
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            if (basePiece != null)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(8, 6, 10, 22),
                                child: Opacity(
                                  opacity: 0.55,
                                  child: Transform.translate(
                                    offset: const Offset(-6, -4),
                                    child: Transform.rotate(
                                      angle: basePiece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                      child: basePiece.asset.isEmpty
                                          ? Center(child: Text(basePiece.label, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)))
                                          : Image.asset(basePiece.asset, fit: BoxFit.contain),
                                    ),
                                  ),
                                ),
                              ),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                              child: Transform.rotate(
                                angle: piece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                child: piece.asset.isEmpty
                                    ? Center(child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))
                                    : Image.asset(piece.asset, fit: BoxFit.contain),
                              ),
                            ),
                            if (isMergedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.greenAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.greenAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '合流',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            if (isSuppressedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.redAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.redAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '制圧',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
                                color: Colors.black54,
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      if (infoPiece != null && _crownAssetForPiece(infoPiece) != null) ...[
                                        SizedBox(
                                          width: 20,
                                          height: 15,
                                          child: Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              Image.asset(
                                                _crownAssetForPiece(infoPiece)!,
                                                width: 20,
                                                height: 15,
                                                fit: BoxFit.contain,
                                              ),
                                              Positioned(
                                                left: 5.2,
                                                right: 5.2,
                                                bottom: 1.7,
                                                child: Container(
                                                  height: 5.6,
                                                  alignment: Alignment.center,
                                                  decoration: BoxDecoration(
                                                    color: const Color(0xFF111318).withOpacity(.96),
                                                    borderRadius: BorderRadius.circular(1.2),
                                                  ),
                                                  child: Text(
                                                    _crownValueText(_crownValueForPiece(infoPiece)!),
                                                    maxLines: 1,
                                                    textAlign: TextAlign.center,
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 6.2,
                                                      fontWeight: FontWeight.w900,
                                                      height: .82,
                                                      letterSpacing: -.35,
                                                      shadows: [
                                                        Shadow(
                                                          color: Colors.black,
                                                          blurRadius: 1.2,
                                                          offset: Offset(0, .4),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 2),
                                      ],
                                      Text(
                                        infoPiece == null
                                            ? ''
                                            : '${isStackedCell ? (showingLowerInfo ? '下：' : '上：') : ''}${infoPiece.major ? '${infoPiece.label}  Lv${infoPiece.level}${showInfoPu ? '/Pu$infoPump' : ''}' : infoPiece.label}',
                                        maxLines: 1,
                                        style: const TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          height: 1.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                    );
                  },
                ),
              );
                    },
                  ),
                ),
              ),
            ),
            if (canUseCore)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonal(
                    onPressed: () => _showCoreActivationMenu(selectedIndex!),
                    child: const Text('核発動', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.6)),
                  ),
                ),
              )
            else if (canUseKnightSkill || canUseEmperorSkill || canShowKingSkill)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonal(
                    onPressed: canShowKingSkill
                        ? (canUseKingSkill ? () => _showKingSkillMenu(selectedIndex!) : null)
                        : () => canUseKnightSkill ? _showKnightSkillMenu(selectedIndex!) : _showEmperorSkillMenu(selectedIndex!),
                    child: Text(
                      'SKILL',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.6,
                        color: canShowKingSkill && !canUseKingSkill ? Colors.white38 : null,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
