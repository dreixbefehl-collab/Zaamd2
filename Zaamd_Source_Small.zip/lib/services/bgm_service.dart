/// Temporary no-audio BGM controller for the first cloud APK build.
/// The final project keeps the same public API so audio can be restored later.
class BgmService {
  BgmService._();
  static final BgmService instance = BgmService._();

  Future<void> playLoop(
    String assetPath, {
    Duration fadeIn = const Duration(milliseconds: 900),
    double targetVolume = 0.82,
  }) async {}

  Future<void> fadeOut({
    Duration duration = const Duration(milliseconds: 650),
  }) async {}
}
