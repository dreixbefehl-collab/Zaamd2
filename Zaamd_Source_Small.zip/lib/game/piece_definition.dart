enum PieceClass { standard, master, hidden }

class PieceDefinition {
  const PieceDefinition({
    required this.id,
    required this.displayName,
    required this.pieceClass,
    this.machineName,
    this.pilotName,
    this.note,
  });

  final String id;
  final String displayName;
  final PieceClass pieceClass;
  final String? machineName;
  final String? pilotName;
  final String? note;
}

/// 現時点で会話上、正式名称として確認できている駒だけを登録。
/// 未確定の駒・初期配置・性能は勝手に補完しない。
const confirmedPieceCatalog = <PieceDefinition>[
  PieceDefinition(id: 'kan', displayName: '官', pieceClass: PieceClass.standard),
  PieceDefinition(id: 'sho', displayName: '将', pieceClass: PieceClass.standard),
  PieceDefinition(id: 'haku', displayName: '博', pieceClass: PieceClass.standard),
  PieceDefinition(
    id: 'master_king',
    displayName: '王',
    pieceClass: PieceClass.master,
    machineName: '立神 / TACHIGAMI',
    pilotName: 'アーキン',
    note: 'Master',
  ),
  PieceDefinition(
    id: 'master_emperor',
    displayName: '帝',
    pieceClass: PieceClass.master,
    machineName: '帝 / MIKADO',
    pilotName: '皇帝',
    note: 'Master',
  ),
  PieceDefinition(
    id: 'master_knight_1',
    displayName: '騎',
    pieceClass: PieceClass.master,
    machineName: '三俣 / MITSUMATA',
    pilotName: 'ブル',
    note: 'Master・壱式',
  ),
  PieceDefinition(
    id: 'master_knight_2',
    displayName: '騎弐式',
    pieceClass: PieceClass.master,
    machineName: '三俣 / MITSUMATA 弐式',
    pilotName: 'ブル',
    note: 'Master',
  ),
  PieceDefinition(
    id: 'master_knight_3',
    displayName: '騎参式',
    pieceClass: PieceClass.master,
    machineName: '三俣 / MITSUMATA 参式',
    pilotName: 'ブル',
    note: 'Master',
  ),
];
