import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'screens/title_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    debugPrint('Firebase is not configured yet: $e');
  }
  runApp(const ZaamdApp());
}

class ZaamdApp extends StatelessWidget {
  const ZaamdApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '鋼王騎帝 -ツァームド-',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF070A0C),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF78909C),
          brightness: Brightness.dark,
        ),
      ),
      home: const TitleScreen(),
    );
  }
}
