import 'package:flutter/material.dart';
import '../models/room.dart';
import '../services/room_service.dart';
import 'sync_board_screen.dart';

class RoomLobbyScreen extends StatefulWidget {
  const RoomLobbyScreen({super.key, required this.roomCode, required this.isHost});
  final String roomCode;
  final bool isHost;

  @override
  State<RoomLobbyScreen> createState() => _RoomLobbyScreenState();
}

class _RoomLobbyScreenState extends State<RoomLobbyScreen> {
  bool _navigated = false;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Room?>(
      stream: roomService.watchRoom(widget.roomCode),
      builder: (context, snapshot) {
        final room = snapshot.data;
        if (room == null) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        if (room.status == 'playing' && !_navigated) {
          _navigated = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => SyncBoardScreen(roomCode: room.code, isHost: widget.isHost),
              ),
            );
          });
        }

        final myReady = widget.isHost ? room.hostReady : room.guestReady;
        return Scaffold(
          appBar: AppBar(title: const Text('対戦ロビー')),
          body: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('ROOM CODE', textAlign: TextAlign.center),
                const SizedBox(height: 8),
                Text(room.code, textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold, letterSpacing: 8)),
                const SizedBox(height: 32),
                _PlayerRow(label: 'HOST', name: room.hostName, ready: room.hostReady),
                const SizedBox(height: 12),
                _PlayerRow(label: 'GUEST', name: room.guestName ?? '接続待ち…', ready: room.guestReady),
                const Spacer(),
                FilledButton(
                  onPressed: room.guestId == null
                      ? null
                      : () async {
                          await roomService.setReady(room.code, isHost: widget.isHost, ready: !myReady);
                          await roomService.startMatchIfReady(room.code);
                        },
                  child: Text(myReady ? 'READY ✓' : 'READY'),
                ),
                const SizedBox(height: 12),
                const Text('両者READYで通信テスト盤面へ', textAlign: TextAlign.center),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _PlayerRow extends StatelessWidget {
  const _PlayerRow({required this.label, required this.name, required this.ready});
  final String label;
  final String name;
  final bool ready;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          SizedBox(width: 72, child: Text(label)),
          Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.bold))),
          Text(ready ? 'READY' : 'WAIT'),
        ],
      ),
    );
  }
}
