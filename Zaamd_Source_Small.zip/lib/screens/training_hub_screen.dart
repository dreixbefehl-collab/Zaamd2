import 'package:flutter/material.dart';
import 'training_battle_screen.dart';

class TrainingHubScreen extends StatelessWidget {
  const TrainingHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('TRAINING')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _tile(context, 'TUTORIAL', '基本操作を順番に確認', true),
          const SizedBox(height: 12),
          _tile(context, 'PRACTICE', '時間制限・RATE変動なし', false),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, String title, String sub, bool tutorial) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.all(18),
        title: Text(title, style: const TextStyle(letterSpacing: 2, fontSize: 20)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => TrainingBattleScreen(tutorialMode: tutorial)),
        ),
      ),
    );
  }
}
