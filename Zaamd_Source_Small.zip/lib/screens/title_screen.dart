import 'package:flutter/material.dart';

import '../services/bgm_service.dart';
import 'main_menu_screen.dart';

class TitleScreen extends StatefulWidget {
  const TitleScreen({super.key});

  @override
  State<TitleScreen> createState() => _TitleScreenState();
}

class _TitleScreenState extends State<TitleScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  late final Animation<double> _pulse;
  bool _leaving = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: .42, end: 1).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      BgmService.instance.playLoop(
        'audio/dawn_after_the_war.mp3',
        fadeIn: const Duration(milliseconds: 1100),
      );
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _enter() async {
    if (_leaving) return;
    setState(() => _leaving = true);

    await BgmService.instance.fadeOut(
      duration: const Duration(milliseconds: 650),
    );

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 750),
        pageBuilder: (_, animation, __) => FadeTransition(
          opacity: animation,
          child: const MainMenuScreen(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _enter,
        child: AnimatedOpacity(
          opacity: _leaving ? 0 : 1,
          duration: const Duration(milliseconds: 650),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                'assets/images/title_zaarmed.png',
                fit: BoxFit.cover,
                alignment: Alignment.center,
              ),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.transparent,
                      Color(0x26000000),
                      Color(0x8A000000),
                    ],
                    stops: [0, .56, .76, 1],
                  ),
                ),
              ),
              SafeArea(
                child: Align(
                  alignment: const Alignment(0, .88),
                  child: FadeTransition(
                    opacity: _pulse,
                    child: const Text(
                      'TOUCH TO START',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        letterSpacing: 4,
                        fontWeight: FontWeight.w600,
                        shadows: [
                          Shadow(color: Colors.black87, blurRadius: 8),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
