import 'package:flutter/material.dart';

class DatabaseScreen extends StatelessWidget {
  const DatabaseScreen({super.key});

  static const unitData = {
    'KING': ['王', '仕', '護', '闘'],
    'KNIGHT': ['騎', '博', '将', '官'],
    'EMPEROR': ['帝', '砲', '剣', '盾'],
  };

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('DATABASE'),
          bottom: const TabBar(tabs: [Tab(text: 'UNITS'), Tab(text: 'PILOTS'), Tab(text: 'MECHS'), Tab(text: 'RULES')]),
        ),
        body: TabBarView(children: [
          ListView(padding: const EdgeInsets.all(16), children: unitData.entries.map((e) => Card(child: ListTile(title: Text(e.key), subtitle: Text(e.value.join(' / ')))).toList()),
          const _Simple(items: ['皇帝', 'アーキン', 'アーツ', 'ジェイク', 'レイ', 'ブル', 'ファン', 'ギル', 'オース']),
          const _Simple(items: ['キングユニット', 'ナイトユニット', 'エンペラーユニット', '兵 / 量産機', '核']),
          const _Rules(),
        ]),
      ),
    );
  }
}

class _Simple extends StatelessWidget {
  const _Simple({required this.items});
  final List<String> items;
  @override
  Widget build(BuildContext context) => ListView.separated(
    padding: const EdgeInsets.all(16), itemCount: items.length,
    separatorBuilder: (_, __) => const Divider(height: 1),
    itemBuilder: (_, i) => ListTile(title: Text(items[i])),
  );
}

class _Rules extends StatelessWidget {
  const _Rules();
  @override
  Widget build(BuildContext context) {
    const data = {
      'TURN': '1ターン1行動。移動後攻撃は不可。',
      'SHOOT': '射程内へ射撃。相互射程なら拮抗し射撃不可。成立時は即破壊。',
      'MERGE': '同マスへ合流。合流中は通常ユニットは一緒に移動不可。',
      'CONTROL': '敵の上に乗って制圧。制圧中の下駒は行動不能。制圧破壊あり。',
      'FRONT LINE': '敵陣側Front Lineで一時的にPu。Z LINEはFront Lineではない。',
      'LEVEL': 'Lv1〜3は恒久成長。Puは一時強化。',
      'TIME': '持ち時間15分、1ターン90秒。3回目の90秒超過で敗北。',
      '30 ROUND': '30往復で駒増減なしなら損失が多い側が敗北。同数は後攻勝ち。',
    };
    return ListView(padding: const EdgeInsets.all(12), children: data.entries.map((e) => ExpansionTile(title: Text(e.key), children: [Padding(padding: const EdgeInsets.all(16), child: Text(e.value))])).toList());
  }
}
