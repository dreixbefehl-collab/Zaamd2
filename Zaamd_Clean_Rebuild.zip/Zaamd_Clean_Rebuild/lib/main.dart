import 'package:flutter/material.dart';

void main() => runApp(const ZaamdApp());

class ZaamdApp extends StatelessWidget {
  const ZaamdApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '鋼王騎帝 -ツァームド-',
        theme: ThemeData.dark(useMaterial3: true),
        home: const TitleScreen(),
      );
}

class TitleScreen extends StatelessWidget {
  const TitleScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('鋼王騎帝', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              const Text('- ツァームド -', style: TextStyle(fontSize: 24)),
              const SizedBox(height: 42),
              FilledButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MainMenuScreen())),
                child: const Text('START'),
              ),
            ]),
          ),
        ),
      );
}

class MainMenuScreen extends StatelessWidget {
  const MainMenuScreen({super.key});

  static const items = [
    ('BATTLE', '作戦開始'),
    ('WATCH', 'リプレイ鑑賞'),
    ('TRAINING', '訓練'),
    ('DATABASE', 'データベース'),
    ('RECORD', '戦績'),
    ('OPTION', '各種設定'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('鋼王騎帝 -ツァームド-')),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final item in items) ...[
                    SizedBox(
                      width: 250,
                      child: TextButton(
                        onPressed: item.$1 == 'BATTLE'
                            ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BattleMenuScreen()))
                            : () => ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('${item.$1} は仮組み中')),
                                ),
                        child: Column(
                          children: [
                            Text(
                              item.$1,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w700, letterSpacing: 1.5),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              item.$2,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 12, color: Colors.white60),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

class BattleMenuScreen extends StatelessWidget {
  const BattleMenuScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('BATTLE')),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const JankenScreen())),
                    child: const Column(
                      children: [
                        Text('CPU BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('CPU戦', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('ONLINE BATTLE は COMING SOON')),
                    ),
                    child: const Column(
                      children: [
                        Text('ONLINE BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('オンライン対戦  /  COMING SOON', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}


class JankenScreen extends StatefulWidget {
  const JankenScreen({super.key});

  @override
  State<JankenScreen> createState() => _JankenScreenState();
}

class _JankenScreenState extends State<JankenScreen> {
  String? playerHand;
  String? cpuHand;
  String? result;

  static const hands = ['グー', 'チョキ', 'パー'];

  void play(String hand) {
    final cpu = hands[DateTime.now().microsecondsSinceEpoch % 3];
    String r;
    if (hand == cpu) {
      r = 'DRAW';
    } else if ((hand == 'グー' && cpu == 'チョキ') ||
        (hand == 'チョキ' && cpu == 'パー') ||
        (hand == 'パー' && cpu == 'グー')) {
      r = 'WIN';
    } else {
      r = 'LOSE';
    }
    setState(() {
      playerHand = hand;
      cpuHand = cpu;
      result = r;
    });
  }

  void _goNext() {
    final playerWon = result == 'WIN';
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => UnitSelectionScreen(playerWonJanken: playerWon),
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('CPU BATTLE')),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('INITIATIVE', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('じゃんけん', style: TextStyle(fontSize: 15, color: Colors.white60)),
                  const SizedBox(height: 34),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 12,
                    children: [
                      for (final hand in hands)
                        OutlinedButton(
                          onPressed: (result == null || result == 'DRAW') ? () => play(hand) : null,
                          child: Text(hand, style: const TextStyle(fontSize: 18)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 34),
                  if (result != null) ...[
                    Text('YOU  $playerHand   /   CPU  $cpuHand', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 12),
                    Text(result!, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800, letterSpacing: 3)),
                    const SizedBox(height: 28),
                    if (result == 'DRAW')
                      FilledButton(
                        onPressed: () => setState(() {
                          playerHand = null;
                          cpuHand = null;
                          result = null;
                        }),
                        child: const Text('もう一度'),
                      )
                    else
                      FilledButton(onPressed: _goNext, child: const Text('NEXT')),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

enum BattleUnit { king, knight, emperor }

extension BattleUnitInfo on BattleUnit {
  String get title => switch (this) {
        BattleUnit.king => 'KING',
        BattleUnit.knight => 'KNIGHT',
        BattleUnit.emperor => 'EMPEROR',
      };

  String get jp => switch (this) {
        BattleUnit.king => 'キング',
        BattleUnit.knight => 'ナイト',
        BattleUnit.emperor => 'エンペラー',
      };

  String representativeAsset(bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (this) {
      BattleUnit.king => 'assets/pieces/${side}_king.png',
      BattleUnit.knight => 'assets/pieces/${side}_knight.png',
      BattleUnit.emperor => 'assets/pieces/${side}_emperor.png',
    };
  }
}

class UnitSelectionScreen extends StatefulWidget {
  final bool playerWonJanken;
  const UnitSelectionScreen({
    super.key,
    required this.playerWonJanken,
  });

  @override
  State<UnitSelectionScreen> createState() => _UnitSelectionScreenState();
}

class _UnitSelectionScreenState extends State<UnitSelectionScreen> {
  BattleUnit? selected;
  BattleUnit? playerUnit;
  BattleUnit? cpuUnit;
  int step = 0;

  bool get selectingPlayer =>
      widget.playerWonJanken ? step == 0 : step == 1;

  String get selectingName => selectingPlayer ? 'YOU' : 'CPU';

  void _confirm() {
    if (selected == null) return;

    setState(() {
      if (selectingPlayer) {
        playerUnit = selected;
      } else {
        cpuUnit = selected;
      }

      if (step == 0) {
        step = 1;
        selected = null;
        return;
      }
    });

    if (playerUnit == null || cpuUnit == null) return;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitiativeChoiceScreen(
        playerWonJanken: widget.playerWonJanken,
        playerUnit: playerUnit!,
        cpuUnit: cpuUnit!,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final winnerName = widget.playerWonJanken ? 'YOU' : 'CPU';
    final loserName = widget.playerWonJanken ? 'CPU' : 'YOU';
    final instruction = step == 0
        ? 'じゃんけん勝者：$winnerName － 先にユニットを選択'
        : 'じゃんけん敗者：$loserName － 次にユニットを選択';

    return Scaffold(
      appBar: AppBar(title: const Text('UNIT SELECT')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          child: Column(
            children: [
              Text(
                instruction,
                style: const TextStyle(fontSize: 15, color: Colors.white70),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                '現在：$selectingName のユニットを選択',
                style: const TextStyle(fontSize: 14, color: Colors.white60),
              ),
              const SizedBox(height: 18),
              Expanded(
                child: ListView.separated(
                  itemCount: BattleUnit.values.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    final unit = BattleUnit.values[i];
                    final active = selected == unit;
                    return InkWell(
                      onTap: () => setState(() => selected = unit),
                      borderRadius: BorderRadius.circular(14),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 120),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: active ? Colors.cyanAccent : Colors.white24,
                            width: active ? 2 : 1,
                          ),
                          color: active ? Colors.cyanAccent.withOpacity(.08) : Colors.white.withOpacity(.02),
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 78,
                              height: 78,
                              child: Image.asset(unit.representativeAsset(true), fit: BoxFit.contain),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(unit.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                                  const SizedBox(height: 2),
                                  Text(unit.jp, style: const TextStyle(color: Colors.white60)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: selected == null ? null : _confirm,
                  child: Text(step == 0 ? '決定して次へ' : '決定'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class InitiativeChoiceScreen extends StatefulWidget {
  final bool playerWonJanken;
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  const InitiativeChoiceScreen({
    super.key,
    required this.playerWonJanken,
    required this.playerUnit,
    required this.cpuUnit,
  });

  @override
  State<InitiativeChoiceScreen> createState() => _InitiativeChoiceScreenState();
}

class _InitiativeChoiceScreenState extends State<InitiativeChoiceScreen> {
  void _startSetup(bool winnerChoosesFirst) {
    // 勝者が先攻を選んだ場合：勝者が白。後攻なら勝者が黒。
    // YOU がじゃんけん勝者かどうかを加味して YOU の色を決める。
    final playerIsWhite = widget.playerWonJanken
        ? winnerChoosesFirst
        : !winnerChoosesFirst;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitialPlacementScreen(
        playerUnit: widget.playerUnit,
        cpuUnit: widget.cpuUnit,
        playerIsWhite: playerIsWhite,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final winnerName = widget.playerWonJanken ? 'YOU' : 'CPU';
    return Scaffold(
      appBar: AppBar(title: const Text('INITIATIVE')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('先攻・後攻選択', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Text(
                  'じゃんけん勝者：$winnerName が選択',
                  style: const TextStyle(color: Colors.white60),
                ),
                const SizedBox(height: 34),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: () => _startSetup(true),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('先攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('白枠 / 銀', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: () => _startSetup(false),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('後攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('黒枠 / 金', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class InitialPlacementScreen extends StatefulWidget {
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  final bool playerIsWhite;
  const InitialPlacementScreen({
    super.key,
    required this.playerUnit,
    required this.cpuUnit,
    required this.playerIsWhite,
  });

  @override
  State<InitialPlacementScreen> createState() => _InitialPlacementScreenState();
}

class _InitialPlacementScreenState extends State<InitialPlacementScreen> {
  late bool placingWhite;
  int whiteCoreType = 2;
  int blackCoreType = 2;
  final Map<int, Piece> whiteMajors = {};
  final Map<int, Piece> blackMajors = {};
  Piece? selectedMajor;
  bool whiteDone = false;
  bool blackDone = false;

  static const whiteSlots = <int>[27, 31, 32, 33];
  static const blackSlots = <int>[1, 2, 3, 7];

  @override
  void initState() {
    super.initState();
    // 初期配置は先攻（白/銀）→後攻（黒/金）の順に、
    // テスト端末上で両者とも手動配置する。
    placingWhite = true;
  }

  bool _isHumanSide(bool isWhite) => true;

  BattleUnit _unitForSide(bool isWhite) =>
      isWhite == widget.playerIsWhite ? widget.playerUnit : widget.cpuUnit;

  List<Piece> _rosterFor(BattleUnit unit, bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (unit) {
      BattleUnit.knight => [
          Piece('assets/pieces/${side}_knight.png', '騎', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_scholar.png', '博', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_general.png', '将', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_officer.png', '官', major: true, isWhite: isWhite),
        ],
      BattleUnit.king => [
          Piece('assets/pieces/${side}_king.png', '王', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_servant.png', '仕', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_guard.png', '護', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_fighter.png', '闘', major: true, isWhite: isWhite),
        ],
      BattleUnit.emperor => [
          Piece('assets/pieces/${side}_emperor.png', '帝', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_cannon.png', '砲', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_sword.png', '剣', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_shield.png', '盾', major: true, isWhite: isWhite),
        ],
    };
  }

  void _autoPlaceSide(bool isWhite) {
    final slots = isWhite ? whiteSlots : blackSlots;
    final target = isWhite ? whiteMajors : blackMajors;
    final roster = _rosterFor(_unitForSide(isWhite), isWhite);
    for (var i = 0; i < slots.length; i++) {
      target[slots[i]] = roster[i];
    }
  }

  String _coreAsset(bool isWhite) {
    final type = isWhite ? whiteCoreType : blackCoreType;
    return 'assets/pieces/${isWhite ? 'white' : 'black'}_core_$type.png';
  }

  Map<int, Piece> _fixedFor(bool isWhite) {
    if (isWhite) {
      return {
        25: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        26: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        28: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        29: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        30: Piece(_coreAsset(true), '核', isWhite: true),
        34: Piece(_coreAsset(true), '核', isWhite: true),
      };
    }
    return {
      0: Piece(_coreAsset(false), '核', isWhite: false),
      4: Piece(_coreAsset(false), '核', isWhite: false),
      5: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      6: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      8: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      9: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
    };
  }

  Map<int, Piece> _previewPieces() {
    final map = <int, Piece>{};
    map.addAll(_fixedFor(true));
    map.addAll(_fixedFor(false));
    map.addAll(whiteMajors);
    map.addAll(blackMajors);
    return map;
  }

  void _toggleCore(bool isWhite) {
    if (!_isHumanSide(isWhite) || placingWhite != isWhite) return;
    setState(() {
      if (isWhite) {
        whiteCoreType = whiteCoreType == 2 ? 1 : 2;
      } else {
        blackCoreType = blackCoreType == 2 ? 1 : 2;
      }
    });
  }

  void _tapPlacementCell(int index) {
    final isWhite = placingWhite;
    if (!_isHumanSide(isWhite)) return;
    final slots = isWhite ? whiteSlots : blackSlots;
    if (!slots.contains(index)) return;
    final target = isWhite ? whiteMajors : blackMajors;

    if (selectedMajor != null) {
      setState(() {
        final existingIndex = target.entries
            .where((e) => e.value.label == selectedMajor!.label)
            .map((e) => e.key)
            .cast<int?>()
            .firstWhere((_) => true, orElse: () => null);
        final displaced = target[index];
        if (existingIndex != null) {
          target.remove(existingIndex);
        }
        target[index] = selectedMajor!;
        if (displaced != null && existingIndex != null) {
          target[existingIndex] = displaced;
        }
        selectedMajor = null;
      });
      return;
    }

    final placed = target[index];
    if (placed != null) {
      setState(() => selectedMajor = placed);
    }
  }

  bool _sideComplete(bool isWhite) => (isWhite ? whiteMajors : blackMajors).length == 4;

  void _completeCurrentSide() {
    final side = placingWhite;
    if (!_sideComplete(side)) return;
    if (side) {
      whiteDone = true;
      setState(() {
        placingWhite = false;
        selectedMajor = null;
      });
    } else {
      blackDone = true;
      setState(() => selectedMajor = null);
    }

    if (whiteDone && blackDone) {
      final all = <int, Piece>{}
        ..addAll(_fixedFor(true))
        ..addAll(_fixedFor(false))
        ..addAll(whiteMajors)
        ..addAll(blackMajors);
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => BoardScreen(initialPieces: all, playerIsWhite: widget.playerIsWhite),
      ));
    }
  }

  Widget _pieceVisual(
    Piece piece, {
    bool playerPerspective = false,
    bool forceUpright = false,
  }) {
    if (piece.asset.isEmpty) {
      return Center(
        child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      );
    }
    final upright = forceUpright
        ? true
        : playerPerspective
            ? piece.isWhite == widget.playerIsWhite
            : piece.isWhite;
    return Transform.rotate(
      angle: upright ? 0 : 3.141592653589793,
      child: Image.asset(piece.asset, fit: BoxFit.contain),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pieces = _previewPieces();
    final humanTurn = _isHumanSide(placingWhite);
    final currentUnit = _unitForSide(placingWhite);
    final currentRoster = _rosterFor(currentUnit, placingWhite);
    final currentPlaced = placingWhite ? whiteMajors : blackMajors;

    return Scaffold(
      appBar: AppBar(title: const Text('INITIAL DEPLOYMENT')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Column(
                children: [
                  Text(
                    placingWhite ? '先攻  WHITE / SILVER  初期配置' : '後攻  BLACK / GOLD  初期配置',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: .8),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    humanTurn ? '核をタップで絵柄切替・大駒を選んで配置' : 'CPU 配置中',
                    style: const TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 5,
                      childAspectRatio: 1,
                    ),
                    itemCount: 35,
                    itemBuilder: (_, visualIndex) {
                      // 初期配置中も YOU は常に画面下側に表示する。
                      final i = widget.playerIsWhite ? visualIndex : 34 - visualIndex;
                      final piece = pieces[i];
                      final isCurrentSlot = (placingWhite ? whiteSlots : blackSlots).contains(i);
                      final isCurrentCore = placingWhite ? (i == 30 || i == 34) : (i == 0 || i == 4);
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (isCurrentCore) {
                            _toggleCore(placingWhite);
                          } else if (isCurrentSlot) {
                            _tapPlacementCell(i);
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.8) : Colors.white30,
                              width: isCurrentSlot && humanTurn ? 1.4 : .7,
                            ),
                            color: isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.05) : Colors.transparent,
                          ),
                          child: piece == null
                              ? null
                              : Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(3, 3, 3, 17),
                                      child: _pieceVisual(piece, playerPerspective: true),
                                    ),
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        width: double.infinity,
                                        color: Colors.black54,
                                        child: Text(piece.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            if (humanTurn) ...[
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: currentRoster.map((piece) {
                    final isPlaced = currentPlaced.values.any((p) => p.label == piece.label);
                    final active = selectedMajor?.label == piece.label;
                    return GestureDetector(
                      onTap: () => setState(() => selectedMajor = piece),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 100),
                        width: 72,
                        height: 88,
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          border: Border.all(color: active ? Colors.cyanAccent : Colors.white24, width: active ? 2 : 1),
                          borderRadius: BorderRadius.circular(8),
                          color: isPlaced ? Colors.white.withOpacity(.03) : Colors.white.withOpacity(.07),
                        ),
                        child: Column(
                          children: [
                            Expanded(child: _pieceVisual(piece, forceUpright: true)),
                            Text(piece.label, style: TextStyle(fontWeight: FontWeight.w800, color: isPlaced ? Colors.white54 : Colors.white)),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 6, 18, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _sideComplete(placingWhite) ? _completeCurrentSide : null,
                    child: Text(placingWhite ? '先攻側 配置完了' : '後攻側 配置完了'),
                  ),
                ),
              ),
            ] else
              Padding(
                padding: const EdgeInsets.all(18),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _completeCurrentSide,
                    child: const Text('CPU 配置完了'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class Piece {
  final String asset;
  final String label;
  final bool major;
  final bool isWhite;
  const Piece(this.asset, this.label, {this.major = false, required this.isWhite});
}

class BoardScreen extends StatefulWidget {
  final Map<int, Piece> initialPieces;
  final bool playerIsWhite;
  const BoardScreen({
    super.key,
    required this.initialPieces,
    required this.playerIsWhite,
  });

  @override
  State<BoardScreen> createState() => _BoardScreenState();
}

class _BoardScreenState extends State<BoardScreen> with SingleTickerProviderStateMixin {
  int? selectedIndex;
  bool whiteTurn = true;
  final Set<int> lowerInfoCells = <int>{};
  late final AnimationController _mergeBlinkController;

  @override
  void initState() {
    super.initState();
    _mergeBlinkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..repeat(reverse: true);
    cells = {
      for (final entry in widget.initialPieces.entries) entry.key: [entry.value],
    };
  }

  @override
  void dispose() {
    _mergeBlinkController.dispose();
    super.dispose();
  }

  late final Map<int, List<Piece>> cells;

  // 格闘後などで、敵駒の上に乗って制圧しているマス。
  final Set<int> suppressedCells = <int>{};

  Piece? _topPieceAt(int index) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return null;
    return stack.last;
  }

  bool _isMergedCell(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    return stack.every((piece) => piece.isWhite == stack.first.isWhite);
  }

  bool _isSuppressedCell(int index) => suppressedCells.contains(index);

  // 上方向を「前」とした白側用の相対座標。
  // 2026-09-22確定版：KNIGHT / KING / EMPEROR 全12大駒＋兵系。
  static const Map<String, List<List<int>>> lv1MoveOffsets = {
    '兵': [
      [-1, 0], [1, 0], [0, -1], [0, 1],
    ],
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '護': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '帝': [
      [-2, 0],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv2MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, 0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv3MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [0, -2], [0, 2],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, -1], [0, 1], [0, 2],
      [1, 0],
    ],
    '王': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -2], [0, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '核': <List<int>>[],
  };

  static const List<List<int>> mergedSoldierOffsets = [
    [-2, 0], [-1, 0],
    [0, -2], [0, -1], [0, 1], [0, 2],
    [1, 0], [2, 0],
  ];

  static const List<List<int>> frontlineSoldierOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  // 騎の変形形態はLv/Puの影響を受けない固定行動範囲。
  static const List<List<int>> knightSecondOffsets = [
    [-2, -1], [-2, 1],
    [-1, -2], [-1, -1], [-1, 1], [-1, 2],
    [1, -1], [1, 1],
  ];

  static const List<List<int>> knightThirdOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  bool _isKnightForm(Piece piece) =>
      piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式';

  List<List<int>> _moveOffsetsFor(int index, Piece piece) {
    if (piece.label == '騎弐式') return knightSecondOffsets;
    if (piece.label == '騎参式') return knightThirdOffsets;
    if (_isMergedCell(index)) {
      if (piece.label == '兵') return mergedSoldierOffsets;
      return lv2MoveOffsets[piece.label] ?? lv1MoveOffsets[piece.label] ?? const <List<int>>[];
    }
    return lv1MoveOffsets[piece.label] ?? const <List<int>>[];
  }

  Set<int> _actionSquaresFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Set<int> _enemyTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    return _actionSquaresFor(index).where((target) {
      final targetPiece = _topPieceAt(target);
      return targetPiece != null && targetPiece.isWhite != piece.isWhite;
    }).toSet();
  }

  bool _isContested(int attackerIndex, int targetIndex) {
    return _actionSquaresFor(targetIndex).contains(attackerIndex);
  }


  void _executeMelee(int attackerIndex, int targetIndex) {
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasMerged = _isMergedCell(targetIndex);
    final targetWasSuppressed = _isSuppressedCell(targetIndex);

    setState(() {
      // 攻撃側は現在いるマスから上の駒だけが格闘に出る。
      final attacker = attackerStack.removeLast();
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      } else if (_isSuppressedCell(attackerIndex)) {
        // 制圧していた上の駒が離れたので、下の駒は制圧解除。
        suppressedCells.remove(attackerIndex);
      }

      // 敵の上の駒を破壊。
      targetStack.removeLast();

      if (targetWasSuppressed && targetStack.isNotEmpty) {
        // 制圧中の上側を格闘で破壊。下の駒は絶対に消さない。
        // 格闘した駒はそのマスへ移動するため、残った下の駒の上へ入る。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.remove(targetIndex);
      } else if (targetWasMerged && targetStack.isNotEmpty) {
        // 合流中の敵への格闘：上だけ破壊し、残った下を制圧。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.add(targetIndex);
      } else {
        // 通常格闘：敵を破壊し、その敵がいたマスへ移動。
        cells[targetIndex] = [attacker];
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(targetWasMerged ? '格闘成功・制圧' : '格闘成功')),
    );
  }

  void _executeRanged(int attackerIndex, int targetIndex) {
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasSuppressed = _isSuppressedCell(targetIndex);

    setState(() {
      // 射撃は攻撃側がその場に残り、敵の上の駒だけを破壊する。
      targetStack.removeLast();

      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        // 合流中・制圧中とも、下の駒は残す。
        cells[targetIndex] = targetStack;
      }

      // 制圧中の上側が射撃で破壊された場合、下の駒は制圧解除。
      if (targetWasSuppressed) {
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('射撃成功')),
    );
  }

  void _executeSuppression(int attackerIndex, int targetIndex) {
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;
    if (_isMergedCell(targetIndex) || _isSuppressedCell(targetIndex)) return;

    setState(() {
      // 制圧側は上の駒だけが対象マスへ移動する。
      final attacker = attackerStack.removeLast();
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      } else if (_isSuppressedCell(attackerIndex)) {
        // 制圧していた駒が離れた場合、下の駒は制圧解除。
        suppressedCells.remove(attackerIndex);
      }

      // 敵駒は破壊せず下に残し、その上へ攻撃側を重ねる。
      targetStack.add(attacker);
      cells[targetIndex] = targetStack;
      suppressedCells.add(targetIndex);

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('制圧成功')),
    );
  }


  void _executeSuppressionDestroy(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    setState(() {
      // 制圧破壊：下にいる敵駒だけを破壊し、制圧側の上駒はその場に残る。
      stack.removeAt(0);
      cells[index] = stack;
      suppressedCells.remove(index);

      lowerInfoCells.remove(index);
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('制圧破壊')),
    );
  }

  void _showSuppressionDestroyMenu(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SUPPRESSION  ${bottomPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _executeSuppressionDestroy(index);
                    },
                    child: const Text(
                      '制圧破壊',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showActionMenu(int attackerIndex, int targetIndex) {
    final targetPiece = _topPieceAt(targetIndex);
    if (targetPiece == null) return;
    final contested = _isContested(attackerIndex, targetIndex);
    final targetMerged = _isMergedCell(targetIndex);
    final targetSuppressed = _isSuppressedCell(targetIndex);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        Widget actionButton(
          String label, {
          bool enabled = true,
          VoidCallback? onPressed,
        }) {
          return SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: enabled
                  ? (onPressed ??
                      () {
                        Navigator.of(sheetContext).pop();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('$label は次で実装')),
                        );
                      })
                  : null,
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: enabled ? null : Colors.white38,
                ),
              ),
            ),
          );
        }

        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'TARGET  ${targetPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                actionButton(
                  '格闘',
                  onPressed: () {
                    Navigator.of(sheetContext).pop();
                    _executeMelee(attackerIndex, targetIndex);
                  },
                ),
                const SizedBox(height: 8),
                actionButton(
                  contested ? '拮抗' : '射撃',
                  enabled: !contested,
                  onPressed: contested
                      ? null
                      : () {
                          Navigator.of(sheetContext).pop();
                          _executeRanged(attackerIndex, targetIndex);
                        },
                ),
                const SizedBox(height: 8),
                actionButton(
                  '制圧',
                  enabled: !targetMerged && !targetSuppressed,
                  onPressed: (targetMerged || targetSuppressed)
                      ? null
                      : () {
                          Navigator.of(sheetContext).pop();
                          _executeSuppression(attackerIndex, targetIndex);
                        },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Set<int> _moveTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      if (cells.containsKey(target)) continue;
      targets.add(target);
    }
    return targets;
  }

  Set<int> _mergeTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      final targetStack = cells[target];
      if (targetStack == null || targetStack.isEmpty) continue;
      final targetTop = targetStack.last;
      if (targetTop.isWhite != piece.isWhite) continue;
      if (targetStack.length >= 2) continue;
      targets.add(target);
    }
    return targets;
  }

  void _moveTopPiece({required int from, required int to, required bool merge}) {
    final sourceStack = cells[from];
    if (sourceStack == null || sourceStack.isEmpty) return;
    final wasSuppressed = _isSuppressedCell(from);
    final movingPiece = sourceStack.removeLast();
    if (sourceStack.isEmpty) {
      cells.remove(from);
    }
    if (wasSuppressed) {
      // 上の制圧側が離れたら、下の駒は行動可能に戻る。
      suppressedCells.remove(from);
    }

    lowerInfoCells.remove(from);
    lowerInfoCells.remove(to);

    if (merge) {
      final targetStack = cells[to] ?? <Piece>[];
      targetStack.add(movingPiece);
      cells[to] = targetStack;
    } else {
      cells[to] = [movingPiece];
    }
  }

  Piece _knightFormPiece(Piece current, String formLabel) {
    final side = current.isWhite ? 'white' : 'black';
    final asset = switch (formLabel) {
      '騎弐式' => 'assets/pieces/${side}_knight_2.png',
      '騎参式' => 'assets/pieces/${side}_knight_3.png',
      _ => 'assets/pieces/${side}_knight.png',
    };
    return Piece(asset, formLabel, major: true, isWhite: current.isWhite);
  }

  void _executeKnightTransform(int index, String formLabel) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return;
    final current = stack.last;
    if (!_isKnightForm(current) || current.isWhite != whiteTurn) return;

    setState(() {
      stack[stack.length - 1] = _knightFormPiece(current, formLabel);
      cells[index] = stack;
      selectedIndex = null;
      lowerInfoCells.remove(index);
      whiteTurn = !whiteTurn;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${current.label} → $formLabel')),
    );
  }

  void _showKnightSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isKnightForm(piece)) return;
    if (piece.isWhite != whiteTurn) return;

    final forms = <String>['騎', '騎弐式', '騎参式']
        .where((form) => form != piece.label)
        .toList();

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SKILL  ${piece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                for (var n = 0; n < forms.length; n++) ...[
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.of(sheetContext).pop();
                        _executeKnightTransform(index, forms[n]);
                      },
                      child: Text(
                        '${forms[n]}へ変形',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  if (n != forms.length - 1) const SizedBox(height: 8),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  void _handleTap(int index) {
    final piece = _topPieceAt(index);
    final moveTargets = selectedIndex == null ? const <int>{} : _moveTargetsFor(selectedIndex!);
    final mergeTargets = selectedIndex == null ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final enemyTargets = selectedIndex == null ? const <int>{} : _enemyTargetsFor(selectedIndex!);
    final isCurrentSidePiece = piece != null &&
        piece.isWhite == whiteTurn;

    if (selectedIndex != null && enemyTargets.contains(index)) {
      _showActionMenu(selectedIndex!, index);
      return;
    }

    setState(() {
      if (selectedIndex != null && moveTargets.contains(index)) {
        _moveTopPiece(from: selectedIndex!, to: index, merge: false);
        whiteTurn = !whiteTurn;
        selectedIndex = null;
        return;
      }

      if (selectedIndex != null && mergeTargets.contains(index)) {
        _moveTopPiece(from: selectedIndex!, to: index, merge: true);
        whiteTurn = !whiteTurn;
        selectedIndex = null;
        return;
      }

      if (isCurrentSidePiece) {
        final stack = cells[index];
        final isStacked = stack != null && stack.length > 1;
        if (selectedIndex == index && isStacked) {
          // 重なり中の同じマスをもう一度タップすると、情報欄だけ上↔下を切り替える。
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
        selectedIndex = selectedIndex == index ? null : index;
        lowerInfoCells.remove(index);
        return;
      }

      // 未選択時なら、敵の重なりマスも情報だけ確認できる。
      if (selectedIndex == null && piece != null) {
        final stack = cells[index];
        if (stack != null && stack.length > 1) {
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
      }

      if (piece == null) {
        selectedIndex = null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final moveTargets = selectedIndex == null ? const <int>{} : _moveTargetsFor(selectedIndex!);
    final mergeTargets = selectedIndex == null ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final enemyTargets = selectedIndex == null ? const <int>{} : _enemyTargetsFor(selectedIndex!);
    final selectedPiece = selectedIndex == null ? null : _topPieceAt(selectedIndex!);
    final canUseKnightSkill = selectedIndex != null &&
        selectedPiece != null &&
        _isKnightForm(selectedPiece) &&
        selectedPiece.isWhite == whiteTurn;

    return Scaffold(
      appBar: AppBar(title: const Text('鋼王騎帝 -ツァームド-')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 8),
              child: Text(
                whiteTurn ? 'WHITE TURN' : 'BLACK TURN',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.8,
                ),
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5,
              childAspectRatio: 1,
            ),
            itemCount: 35,
            itemBuilder: (_, visualIndex) {
              // YOU は常に画面下側。YOU が黒/金なら盤面表示だけ180度反転する。
              final i = widget.playerIsWhite ? visualIndex : 34 - visualIndex;
              final r = visualIndex ~/ 5, c = visualIndex % 5;
              final cellStack = cells[i];
              final piece = _topPieceAt(i);
              final basePiece = (cellStack != null && cellStack.length > 1) ? cellStack.first : null;
              final isSelected = selectedIndex == i;
              final isMoveTarget = moveTargets.contains(i);
              final isMergeTarget = mergeTargets.contains(i);
              final isEnemyTarget = enemyTargets.contains(i);
              final isMergedCell = _isMergedCell(i);
              final isSuppressedCell = _isSuppressedCell(i);
              final isStackedCell = cellStack != null && cellStack.length > 1;
              final showingLowerInfo = isStackedCell && lowerInfoCells.contains(i);
              final infoPiece = showingLowerInfo ? cellStack!.first : piece;

              Color borderColor;
              double borderWidth;
              List<BoxShadow>? glow;
              Color fillColor;

              if (isSelected) {
                borderColor = Colors.lightBlueAccent;
                borderWidth = 2.4;
                glow = const [
                  BoxShadow(
                    color: Colors.lightBlueAccent,
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ];
                fillColor = Colors.lightBlueAccent.withOpacity(.12);
              } else if (isMergeTarget) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.0;
                glow = const [
                  BoxShadow(
                    color: Colors.greenAccent,
                    blurRadius: 8,
                    spreadRadius: .6,
                  ),
                ];
                fillColor = Colors.greenAccent.withOpacity(.16);
              } else if (isMoveTarget) {
                borderColor = Colors.cyanAccent;
                borderWidth = 2.0;
                glow = const [
                  BoxShadow(
                    color: Colors.cyanAccent,
                    blurRadius: 7,
                    spreadRadius: .5,
                  ),
                ];
                fillColor = Colors.cyanAccent.withOpacity(.18);
              } else if (isEnemyTarget) {
                borderColor = Colors.redAccent;
                borderWidth = 2.2;
                glow = const [
                  BoxShadow(
                    color: Colors.redAccent,
                    blurRadius: 8,
                    spreadRadius: .6,
                  ),
                ];
                fillColor = Colors.redAccent.withOpacity(.16);
              } else if (isSuppressedCell) {
                borderColor = Colors.redAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.redAccent.withOpacity(.04);
              } else if (isMergedCell) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.greenAccent.withOpacity(.04);
              } else {
                borderColor = Colors.white38;
                borderWidth = .7;
                glow = null;
                fillColor = (r + c).isEven ? Colors.white10 : Colors.black12;
              }

              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _handleTap(i),
                onLongPress: () {
                  final top = _topPieceAt(i);
                  if (top != null &&
                      top.isWhite == whiteTurn &&
                      _isSuppressedCell(i)) {
                    _showSuppressionDestroyMenu(i);
                  }
                },
                child: AnimatedBuilder(
                  animation: _mergeBlinkController,
                  builder: (context, child) {
                    final blink = 0.25 + (_mergeBlinkController.value * 0.75);
                    final showSuppressionBlink = isSuppressedCell && !isSelected && !isMergeTarget && !isEnemyTarget;
                    final showMergeBlink = isMergedCell && !isSelected && !isMergeTarget && !isEnemyTarget;
                    final blinkColor = showSuppressionBlink ? Colors.redAccent : Colors.greenAccent;
                    final showStateBlink = showSuppressionBlink || showMergeBlink;
                    final effectiveBorderColor = showStateBlink
                        ? blinkColor.withOpacity(blink)
                        : borderColor;
                    final effectiveBorderWidth = showStateBlink ? 2.2 : borderWidth;
                    final effectiveGlow = showStateBlink
                        ? [
                            BoxShadow(
                              color: blinkColor.withOpacity(blink * 0.85),
                              blurRadius: 4 + (7 * _mergeBlinkController.value),
                              spreadRadius: .2 + (.8 * _mergeBlinkController.value),
                            ),
                          ]
                        : glow;

                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 90),
                      decoration: BoxDecoration(
                        border: Border.all(color: effectiveBorderColor, width: effectiveBorderWidth),
                        boxShadow: effectiveGlow,
                        color: fillColor,
                      ),
                  child: piece == null
                      ? null
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            if (basePiece != null)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(8, 6, 10, 22),
                                child: Opacity(
                                  opacity: 0.55,
                                  child: Transform.translate(
                                    offset: const Offset(-6, -4),
                                    child: Transform.rotate(
                                      angle: basePiece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                      child: basePiece.asset.isEmpty
                                          ? Center(child: Text(basePiece.label, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)))
                                          : Image.asset(basePiece.asset, fit: BoxFit.contain),
                                    ),
                                  ),
                                ),
                              ),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                              child: Transform.rotate(
                                angle: piece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                child: piece.asset.isEmpty
                                    ? Center(child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))
                                    : Image.asset(piece.asset, fit: BoxFit.contain),
                              ),
                            ),
                            if (isMergedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.greenAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.greenAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '合流',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
                                color: Colors.black54,
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Text(
                                    infoPiece == null
                                        ? ''
                                        : '${isStackedCell ? (showingLowerInfo ? '下：' : '上：') : ''}${infoPiece.major ? '${infoPiece.label}  Lv1/${(!showingLowerInfo && isMergedCell) ? 'Pu2' : 'Pu1'}' : infoPiece.label}',
                                    maxLines: 1,
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                    );
                  },
                ),
              );
                    },
                  ),
                ),
              ),
            ),
            if (canUseKnightSkill)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonal(
                    onPressed: () => _showKnightSkillMenu(selectedIndex!),
                    child: const Text(
                      'SKILL',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.6,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
