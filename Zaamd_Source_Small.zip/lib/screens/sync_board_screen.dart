import 'package:flutter/material.dart';
import '../game/piece_definition.dart';
import '../services/room_service.dart';

class SyncBoardScreen extends StatefulWidget {
  const SyncBoardScreen({super.key, required this.roomCode, required this.isHost});
  final String roomCode;
  final bool isHost;

  @override
  State<SyncBoardScreen> createState() => _SyncBoardScreenState();
}

class _SyncBoardScreenState extends State<SyncBoardScreen> {
  PieceDefinition? selected;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('鋼王騎帝 -ツァームド-'),
        actions: [
          IconButton(
            tooltip: '確認済み駒',
            onPressed: () => _showCatalog(context),
            icon: const Icon(Icons.view_module_outlined),
          ),
        ],
      ),
      body: StreamBuilder<Map<String, dynamic>?>(
        stream: roomService.watchRawRoom(widget.roomCode),
        builder: (context, snapshot) {
          final data = snapshot.data;
          if (data == null) return const Center(child: CircularProgressIndicator());
          final markerRow = data['testPieceRow'] as int? ?? 2;
          final markerCol = data['testPieceCol'] as int? ?? 3;

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(
                children: [
                  Row(
                    children: [
                      _sideBadge(widget.isHost ? 'HOST' : 'GUEST'),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'ROOM ${widget.roomCode}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1.5),
                        ),
                      ),
                      _sideBadge('5×7'),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: Center(
                      child: AspectRatio(
                        aspectRatio: 5 / 7,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.white54, width: 1.4),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: GridView.builder(
                            padding: EdgeInsets.zero,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 5,
                              childAspectRatio: 1,
                            ),
                            itemCount: 35,
                            itemBuilder: (context, index) {
                              final row = index ~/ 5;
                              final col = index % 5;
                              final hasMarker = row == markerRow && col == markerCol;
                              final dark = (row + col).isOdd;
                              return InkWell(
                                onTap: () => roomService.moveTestPiece(widget.roomCode, row, col),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: dark ? Colors.white.withValues(alpha: .035) : Colors.transparent,
                                    border: Border.all(color: Colors.white12, width: .5),
                                  ),
                                  child: Center(
                                    child: hasMarker
                                        ? Container(
                                            width: 34,
                                            height: 34,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              border: Border.all(color: Colors.white70, width: 2),
                                            ),
                                            child: const Center(child: Text('SYNC', style: TextStyle(fontSize: 8))),
                                          )
                                        : null,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white24),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      '正式5×7盤面。いまのSYNCマーカーは通信確認専用。初期配置・移動・格闘・射撃などの正式ルールは、確定済みデータだけを順に実装する。',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _sideBadge(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white24),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
      );

  void _showCatalog(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          itemCount: confirmedPieceCatalog.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, index) {
            final p = confirmedPieceCatalog[index];
            final detail = [p.machineName, p.pilotName].whereType<String>().join(' / ');
            return ListTile(
              title: Text(p.displayName, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: detail.isEmpty ? const Text('名称確認済み・性能未実装') : Text(detail),
              trailing: Text(p.pieceClass == PieceClass.master ? 'MASTER' : 'UNIT'),
            );
          },
        );
      },
    );
  }
}
