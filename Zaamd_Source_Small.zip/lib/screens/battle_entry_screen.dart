import 'package:flutter/material.dart';
import 'room_create_screen.dart';
import 'room_join_screen.dart';

class BattleEntryScreen extends StatelessWidget {
  const BattleEntryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('BATTLE')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Text(
                'ONLINE MATCH TEST',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, letterSpacing: 3, color: Colors.white54),
              ),
              const SizedBox(height: 16),
              const Text(
                '現在は既存のFirebase通信テストをここから起動します。',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60),
              ),
              const Spacer(),
              FilledButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RoomCreateScreen()),
                ),
                child: const Text('部屋を作る'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RoomJoinScreen()),
                ),
                child: const Text('部屋に入る'),
              ),
              const SizedBox(height: 12),
              const Text(
                '次段階で SEARCHING → じゃんけん → UNIT SELECT に置き換える。',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.white38),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
