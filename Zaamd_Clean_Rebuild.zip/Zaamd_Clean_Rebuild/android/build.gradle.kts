allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}

subprojects {
    project.evaluationDependsOn(":app")
}

// Work around an Android Lint crash in video_player_android's HttpVideoAsset.java.
// Only this plugin's release lint analysis is disabled; all other lint tasks remain intact.
subprojects {
    if (name == "video_player_android") {
        tasks.configureEach {
            if (name == "lintVitalAnalyzeRelease") {
                enabled = false
            }
        }
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
