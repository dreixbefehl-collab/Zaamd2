import 'package:flutter/material.dart';
class WatchScreen extends StatelessWidget { const WatchScreen({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('WATCH')),body:const Center(child:Text('NO LIVE MATCHES',style:TextStyle(letterSpacing:2,color:Colors.white54)))); }
