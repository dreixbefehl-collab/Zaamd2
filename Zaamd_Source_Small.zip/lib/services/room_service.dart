import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/room.dart';

class RoomService {
  RoomService({FirebaseFirestore? db, FirebaseAuth? auth})
      : _db = db ?? FirebaseFirestore.instance,
        _auth = auth ?? FirebaseAuth.instance;

  final FirebaseFirestore _db;
  final FirebaseAuth _auth;
  final Random _random = Random.secure();

  CollectionReference<Map<String, dynamic>> get _rooms => _db.collection('rooms');

  String get playerId => _auth.currentUser!.uid;

  Future<void> ensureSignedIn() async {
    if (_auth.currentUser == null) {
      await _auth.signInAnonymously();
    }
  }

  Future<Room> createRoom(String playerName) async {
    await ensureSignedIn();

    for (var attempt = 0; attempt < 12; attempt++) {
      final code = (_random.nextInt(900000) + 100000).toString();
      final ref = _rooms.doc(code);

      try {
        await _db.runTransaction((tx) async {
          final snap = await tx.get(ref);
          if (snap.exists) throw StateError('collision');
          tx.set(ref, {
            'hostId': playerId,
            'hostName': playerName.trim().isEmpty ? 'HOST' : playerName.trim(),
            'guestId': null,
            'guestName': null,
            'hostReady': false,
            'guestReady': false,
            'status': 'lobby',
            'testPieceRow': 2,
            'testPieceCol': 3,
            'testPieceMovedBy': null,
            'createdAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
        });
        final snap = await ref.get();
        return Room.fromMap(code, snap.data()!);
      } on StateError {
        continue;
      }
    }

    throw StateError('部屋コードを作れませんでした。もう一度試してください。');
  }

  Future<Room> joinRoom(String roomCode, String playerName) async {
    await ensureSignedIn();
    final code = roomCode.trim();
    final ref = _rooms.doc(code);

    await _db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw StateError('部屋が見つかりません。');
      final data = snap.data()!;
      if (data['guestId'] != null && data['guestId'] != playerId) {
        throw StateError('この部屋は満員です。');
      }
      if (data['hostId'] == playerId) return;
      tx.update(ref, {
        'guestId': playerId,
        'guestName': playerName.trim().isEmpty ? 'GUEST' : playerName.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });

    final snap = await ref.get();
    return Room.fromMap(code, snap.data()!);
  }

  Stream<Room?> watchRoom(String code) {
    return _rooms.doc(code).snapshots().map((snap) {
      final data = snap.data();
      return data == null ? null : Room.fromMap(code, data);
    });
  }

  Future<void> setReady(String code, {required bool isHost, required bool ready}) async {
    await _rooms.doc(code).update({
      isHost ? 'hostReady' : 'guestReady': ready,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> startMatchIfReady(String code) async {
    final ref = _rooms.doc(code);
    await _db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) return;
      final data = snap.data()!;
      final ready = data['hostReady'] == true && data['guestReady'] == true && data['guestId'] != null;
      if (ready && data['status'] != 'playing') {
        tx.update(ref, {
          'status': 'playing',
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
    });
  }

  Stream<Map<String, dynamic>?> watchRawRoom(String code) {
    return _rooms.doc(code).snapshots().map((s) => s.data());
  }

  Future<void> moveTestPiece(String code, int row, int col) async {
    await _rooms.doc(code).update({
      'testPieceRow': row,
      'testPieceCol': col,
      'testPieceMovedBy': playerId,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}

final roomService = RoomService();
