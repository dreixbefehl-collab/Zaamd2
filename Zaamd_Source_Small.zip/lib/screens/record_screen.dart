import 'package:flutter/material.dart';
class RecordScreen extends StatelessWidget {
  const RecordScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('RECORD')),
    body: const Padding(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('RATE 1500', style: TextStyle(fontSize: 28, letterSpacing: 2)), SizedBox(height: 20),
      Text('MATCHES   0'), Text('WINS      0'), Text('LOSSES    0'), Text('WIN RATE  --'), SizedBox(height: 20),
      Text('MOST USED UNIT  --'), Text('KILLS           0'),
    ])),
  );
}
