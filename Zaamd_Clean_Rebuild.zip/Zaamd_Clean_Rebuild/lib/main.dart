import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const ZaamdApp());

class _StablePilotTypewriter extends StatefulWidget {
  const _StablePilotTypewriter({
    super.key,
    required this.text,
    required this.duration,
    required this.childBuilder,
    this.completed = false,
  });
  final String text;
  final Duration duration;
  final bool completed;
  final Widget Function(BuildContext, String) childBuilder;
  @override
  State<_StablePilotTypewriter> createState() => _StablePilotTypewriterState();
}

class _StablePilotTypewriterState extends State<_StablePilotTypewriter>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration)
      ..addListener(() { if (mounted) setState(() {}); })
      ..forward();
  }
  @override
  void didUpdateWidget(covariant _StablePilotTypewriter oldWidget) {
    super.didUpdateWidget(oldWidget);
    // CPU preview/action rebuilds must never restart the same dialogue.
    if (oldWidget.duration != widget.duration) _controller.duration = widget.duration;
    if (widget.completed && !oldWidget.completed) {
      _controller.stop();
      _controller.value = 1.0;
    }
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final count = widget.completed
        ? widget.text.length
        : (widget.text.length * _controller.value).ceil().clamp(0, widget.text.length);
    return widget.childBuilder(context, widget.text.substring(0, count));
  }
}

class ZaamdApp extends StatelessWidget {
  const ZaamdApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '鋼王騎帝 -ツァームド-',
        theme: ThemeData.dark(useMaterial3: true),
        home: const TitleScreen(),
      );
}

class TitleScreen extends StatelessWidget {
  const TitleScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('鋼王騎帝', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              const Text('- ツァームド -', style: TextStyle(fontSize: 24)),
              const SizedBox(height: 42),
              FilledButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MainMenuScreen())),
                child: const Text('START'),
              ),
            ]),
          ),
        ),
      );
}

class MainMenuScreen extends StatelessWidget {
  const MainMenuScreen({super.key});

  static const items = [
    ('BATTLE', '作戦開始'),
    ('WATCH', 'リプレイ鑑賞'),
    ('TRAINING', '訓練'),
    ('DATABASE', 'データベース'),
    ('RECORD', '戦績'),
    ('OPTION', '各種設定'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('鋼王騎帝 -ツァームド-')),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final item in items) ...[
                    SizedBox(
                      width: 250,
                      child: TextButton(
                        onPressed: item.$1 == 'BATTLE'
                            ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BattleMenuScreen()))
                            : () => ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('${item.$1} は仮組み中')),
                                ),
                        child: Column(
                          children: [
                            Text(
                              item.$1,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w700, letterSpacing: 1.5),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              item.$2,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 12, color: Colors.white60),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

class BattleMenuScreen extends StatelessWidget {
  const BattleMenuScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('BATTLE')),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const JankenScreen())),
                    child: const Column(
                      children: [
                        Text('CPU BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('CPU戦', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('ONLINE BATTLE は COMING SOON')),
                    ),
                    child: const Column(
                      children: [
                        Text('ONLINE BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('オンライン対戦  /  COMING SOON', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}


class JankenScreen extends StatefulWidget {
  const JankenScreen({super.key});

  @override
  State<JankenScreen> createState() => _JankenScreenState();
}

class _JankenScreenState extends State<JankenScreen> {
  String? playerHand;
  String? cpuHand;
  String? result;

  static const hands = ['グー', 'チョキ', 'パー'];

  void play(String hand) {
    final cpu = hands[DateTime.now().microsecondsSinceEpoch % 3];
    String r;
    if (hand == cpu) {
      r = 'DRAW';
    } else if ((hand == 'グー' && cpu == 'チョキ') ||
        (hand == 'チョキ' && cpu == 'パー') ||
        (hand == 'パー' && cpu == 'グー')) {
      r = 'WIN';
    } else {
      r = 'LOSE';
    }
    setState(() {
      playerHand = hand;
      cpuHand = cpu;
      result = r;
    });
  }

  void _goNext() {
    final playerWon = result == 'WIN';
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => UnitSelectionScreen(playerWonJanken: playerWon),
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('CPU BATTLE')),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('INITIATIVE', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('じゃんけん', style: TextStyle(fontSize: 15, color: Colors.white60)),
                  const SizedBox(height: 34),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 12,
                    children: [
                      for (final hand in hands)
                        OutlinedButton(
                          onPressed: (result == null || result == 'DRAW') ? () => play(hand) : null,
                          child: Text(hand, style: const TextStyle(fontSize: 18)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 34),
                  if (result != null) ...[
                    Text('YOU  $playerHand   /   CPU  $cpuHand', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 12),
                    Text(result!, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800, letterSpacing: 3)),
                    const SizedBox(height: 28),
                    if (result == 'DRAW')
                      FilledButton(
                        onPressed: () => setState(() {
                          playerHand = null;
                          cpuHand = null;
                          result = null;
                        }),
                        child: const Text('もう一度'),
                      )
                    else
                      FilledButton(onPressed: _goNext, child: const Text('NEXT')),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
}

enum BattleUnit { king, knight, emperor, strasse }

extension BattleUnitInfo on BattleUnit {
  String get title => switch (this) {
        BattleUnit.king => 'KING',
        BattleUnit.knight => 'KNIGHT',
        BattleUnit.emperor => 'EMPEROR',
        BattleUnit.strasse => 'STRASSE',
      };

  String get jp => switch (this) {
        BattleUnit.king => 'キング',
        BattleUnit.knight => 'ナイト',
        BattleUnit.emperor => 'エンペラー',
        BattleUnit.strasse => 'シュトラーセ',
      };

  String representativeAsset(bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (this) {
      BattleUnit.king => 'assets/pieces/${side}_king.png',
      BattleUnit.knight => 'assets/pieces/${side}_knight.png',
      BattleUnit.emperor => 'assets/pieces/${side}_emperor.png',
      BattleUnit.strasse => 'assets/pieces/${side}_strasse_spear.png',
    };
  }
}

class UnitSelectionScreen extends StatefulWidget {
  final bool playerWonJanken;
  const UnitSelectionScreen({
    super.key,
    required this.playerWonJanken,
  });

  @override
  State<UnitSelectionScreen> createState() => _UnitSelectionScreenState();
}

class _UnitSelectionScreenState extends State<UnitSelectionScreen> {
  BattleUnit? selected;
  BattleUnit? playerUnit;
  BattleUnit? cpuUnit;
  int step = 0;
  bool _cpuUnitSelectionScheduled = false;
  bool _unitSelectionFinished = false;

  bool get selectingPlayer =>
      widget.playerWonJanken ? step == 0 : step == 1;

  String get selectingName => selectingPlayer ? 'YOU' : 'CPU';

  void _scheduleCpuUnitSelectionIfNeeded() {
    if (_unitSelectionFinished || selectingPlayer || _cpuUnitSelectionScheduled) return;
    _cpuUnitSelectionScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (!mounted || _unitSelectionFinished || selectingPlayer) return;
        final units = BattleUnit.values;
        selected = units[DateTime.now().microsecondsSinceEpoch % units.length];
        _cpuUnitSelectionScheduled = false;
        _confirm();
      });
    });
  }

  void _confirm() {
    if (selected == null) return;

    setState(() {
      if (selectingPlayer) {
        playerUnit = selected;
      } else {
        cpuUnit = selected;
      }

      if (step == 0) {
        step = 1;
        selected = null;
        return;
      }
    });

    if (playerUnit == null || cpuUnit == null || _unitSelectionFinished) return;
    _unitSelectionFinished = true;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitiativeChoiceScreen(
        playerWonJanken: widget.playerWonJanken,
        playerUnit: playerUnit!,
        cpuUnit: cpuUnit!,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    _scheduleCpuUnitSelectionIfNeeded();
    final winnerName = widget.playerWonJanken ? 'YOU' : 'CPU';
    final loserName = widget.playerWonJanken ? 'CPU' : 'YOU';
    final instruction = step == 0
        ? 'じゃんけん勝者：$winnerName － 先にユニットを選択'
        : 'じゃんけん敗者：$loserName － 次にユニットを選択';

    return Scaffold(
      appBar: AppBar(title: const Text('UNIT SELECT')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          child: Column(
            children: [
              Text(
                instruction,
                style: const TextStyle(fontSize: 15, color: Colors.white70),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                '現在：$selectingName のユニットを選択',
                style: const TextStyle(fontSize: 14, color: Colors.white60),
              ),
              const SizedBox(height: 18),
              Expanded(
                child: ListView.separated(
                  itemCount: BattleUnit.values.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    final unit = BattleUnit.values[i];
                    final active = selected == unit;
                    return InkWell(
                      onTap: selectingPlayer ? () => setState(() => selected = unit) : null,
                      borderRadius: BorderRadius.circular(14),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 120),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: active ? Colors.cyanAccent : Colors.white24,
                            width: active ? 2 : 1,
                          ),
                          color: active ? Colors.cyanAccent.withOpacity(.08) : Colors.white.withOpacity(.02),
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 78,
                              height: 78,
                              child: Image.asset(unit.representativeAsset(true), fit: BoxFit.contain),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(unit.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                                  const SizedBox(height: 2),
                                  Text(unit.jp, style: const TextStyle(color: Colors.white60)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: !selectingPlayer || selected == null ? null : _confirm,
                  child: Text(step == 0 ? '決定して次へ' : '決定'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class InitiativeChoiceScreen extends StatefulWidget {
  final bool playerWonJanken;
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  const InitiativeChoiceScreen({
    super.key,
    required this.playerWonJanken,
    required this.playerUnit,
    required this.cpuUnit,
  });

  @override
  State<InitiativeChoiceScreen> createState() => _InitiativeChoiceScreenState();
}

class _InitiativeChoiceScreenState extends State<InitiativeChoiceScreen> {
  bool _cpuInitiativeScheduled = false;
  bool _initiativeNavigationStarted = false;

  void _scheduleCpuInitiativeIfNeeded() {
    if (widget.playerWonJanken || _cpuInitiativeScheduled || _initiativeNavigationStarted) return;
    _cpuInitiativeScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (!mounted || _initiativeNavigationStarted) return;
        final chooseFirst = DateTime.now().microsecondsSinceEpoch.isEven;
        _startSetup(chooseFirst);
      });
    });
  }

  void _startSetup(bool winnerChoosesFirst) {
    if (_initiativeNavigationStarted) return;
    _initiativeNavigationStarted = true;
    // 勝者が先攻を選んだ場合：勝者が白。後攻なら勝者が黒。
    // YOU がじゃんけん勝者かどうかを加味して YOU の色を決める。
    final playerIsWhite = widget.playerWonJanken
        ? winnerChoosesFirst
        : !winnerChoosesFirst;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitialPlacementScreen(
        playerUnit: widget.playerUnit,
        cpuUnit: widget.cpuUnit,
        playerIsWhite: playerIsWhite,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    _scheduleCpuInitiativeIfNeeded();
    final winnerName = widget.playerWonJanken ? 'YOU' : 'CPU';
    return Scaffold(
      appBar: AppBar(title: const Text('INITIATIVE')),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('先攻・後攻選択', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Text(
                  'じゃんけん勝者：$winnerName が選択',
                  style: const TextStyle(color: Colors.white60),
                ),
                const SizedBox(height: 34),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: widget.playerWonJanken ? () => _startSetup(true) : null,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('先攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('白', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: widget.playerWonJanken ? () => _startSetup(false) : null,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('後攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('黒', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class InitialPlacementScreen extends StatefulWidget {
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  final bool playerIsWhite;
  const InitialPlacementScreen({
    super.key,
    required this.playerUnit,
    required this.cpuUnit,
    required this.playerIsWhite,
  });

  @override
  State<InitialPlacementScreen> createState() => _InitialPlacementScreenState();
}

class _InitialPlacementScreenState extends State<InitialPlacementScreen> {
  late bool placingWhite;
  int whiteCoreType = 2;
  int blackCoreType = 2;
  final Map<int, Piece> whiteMajors = {};
  final Map<int, Piece> blackMajors = {};
  Piece? selectedMajor;
  bool whiteDone = false;
  bool blackDone = false;
  bool _cpuPlacementScheduled = false;
  bool _battleNavigationStarted = false;

  static const whiteSlots = <int>[27, 31, 32, 33];
  static const blackSlots = <int>[1, 2, 3, 7];

  List<int> _placementSlotsForSide(bool isWhite) {
    if (_unitForSide(isWhite) == BattleUnit.strasse) {
      return isWhite
          ? List<int>.generate(10, (i) => 25 + i)
          : List<int>.generate(10, (i) => i);
    }
    return isWhite ? whiteSlots : blackSlots;
  }

  @override
  void initState() {
    super.initState();
    // 初期配置は先攻（白/銀）→後攻（黒/金）の順に、
    // テスト端末上で両者とも手動配置する。
    placingWhite = true;
    // 先攻側がCPUなら、初回描画より前に配置を済ませて人間側へ進める。
    // CPU専用の「配置中 / 配置完了」画面は表示しない。
    if (!_isHumanSide(true)) {
      _autoPlaceSide(true);
      whiteDone = true;
      placingWhite = false;
    }
  }

  bool _isHumanSide(bool isWhite) => isWhite == widget.playerIsWhite;

  BattleUnit _unitForSide(bool isWhite) =>
      isWhite == widget.playerIsWhite ? widget.playerUnit : widget.cpuUnit;

  String _unitDisplayName(BattleUnit unit) => switch (unit) {
        BattleUnit.king => 'キング',
        BattleUnit.knight => 'ナイト',
        BattleUnit.emperor => 'エンペラー',
        BattleUnit.strasse => 'シュトラーセ',
      };

  List<Piece> _rosterFor(BattleUnit unit, bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (unit) {
      BattleUnit.knight => [
          Piece('assets/pieces/${side}_knight.png', '騎', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_scholar.png', '博', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_general.png', '将', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_officer.png', '官', major: true, isWhite: isWhite),
        ],
      BattleUnit.king => [
          Piece('assets/pieces/${side}_king.png', '王', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_servant.png', '仕', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_guard.png', '護', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_fighter.png', '闘', major: true, isWhite: isWhite),
        ],
      BattleUnit.emperor => [
          Piece('assets/pieces/${side}_emperor.png', '帝', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_cannon.png', '砲', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_sword.png', '剣', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_shield.png', '盾', major: true, isWhite: isWhite),
        ],
      BattleUnit.strasse => [
          Piece('assets/pieces/${side}_strasse_spear.png', '槍', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_strasse_swift.png', '迅', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_strasse_advance.png', '進', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_strasse_sub.png', '亜', major: true, isWhite: isWhite),
        ],
    };
  }

  void _autoPlaceSide(bool isWhite) {
    final slots = _placementSlotsForSide(isWhite);
    final target = isWhite ? whiteMajors : blackMajors;
    final roster = _rosterFor(_unitForSide(isWhite), isWhite);
    // 配置可能マス数ではなく、実際の大駒数だけ配置する。
    // STRASSEは配置可能10マス・駒4機なので slots.length で回すとCPU配置時に範囲外になる。
    for (var i = 0; i < roster.length && i < slots.length; i++) {
      target[slots[i]] = roster[i];
    }
  }

  String _coreAsset(bool isWhite) {
    final type = isWhite ? whiteCoreType : blackCoreType;
    return 'assets/pieces/${isWhite ? 'white' : 'black'}_core_$type.png';
  }

  Map<int, Piece> _fixedFor(bool isWhite) {
    if (_unitForSide(isWhite) == BattleUnit.strasse) return <int, Piece>{};
    if (isWhite) {
      return {
        25: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        26: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        28: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        29: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        30: Piece(_coreAsset(true), '核', isWhite: true),
        34: Piece(_coreAsset(true), '核', isWhite: true),
      };
    }
    return {
      0: Piece(_coreAsset(false), '核', isWhite: false),
      4: Piece(_coreAsset(false), '核', isWhite: false),
      5: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      6: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      8: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      9: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
    };
  }

  Map<int, Piece> _previewPieces() {
    final map = <int, Piece>{};
    map.addAll(_fixedFor(true));
    map.addAll(_fixedFor(false));
    map.addAll(whiteMajors);
    map.addAll(blackMajors);
    return map;
  }

  void _toggleCore(bool isWhite) {
    if (!_isHumanSide(isWhite) || placingWhite != isWhite) return;
    setState(() {
      if (isWhite) {
        whiteCoreType = whiteCoreType == 2 ? 1 : 2;
      } else {
        blackCoreType = blackCoreType == 2 ? 1 : 2;
      }
    });
  }

  void _tapPlacementCell(int index) {
    final isWhite = placingWhite;
    if (!_isHumanSide(isWhite)) return;
    final slots = _placementSlotsForSide(isWhite);
    if (!slots.contains(index)) return;
    final target = isWhite ? whiteMajors : blackMajors;

    if (selectedMajor != null) {
      setState(() {
        final existingIndex = target.entries
            .where((e) => e.value.label == selectedMajor!.label)
            .map((e) => e.key)
            .cast<int?>()
            .firstWhere((_) => true, orElse: () => null);
        final displaced = target[index];
        if (existingIndex != null) {
          target.remove(existingIndex);
        }
        target[index] = selectedMajor!;
        if (displaced != null && existingIndex != null) {
          target[existingIndex] = displaced;
        }
        selectedMajor = null;
      });
      return;
    }

    final placed = target[index];
    if (placed != null) {
      setState(() => selectedMajor = placed);
    }
  }

  bool _sideComplete(bool isWhite) => (isWhite ? whiteMajors : blackMajors).length == 4;

  void _scheduleCpuPlacementIfNeeded() {
    if (_battleNavigationStarted || _cpuPlacementScheduled || _isHumanSide(placingWhite)) return;
    _cpuPlacementScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      setState(() {
        _autoPlaceSide(placingWhite);
        _cpuPlacementScheduled = false;
      });
      Future<void>.delayed(const Duration(milliseconds: 350), () {
        if (!mounted || _isHumanSide(placingWhite)) return;
        _completeCurrentSide();
      });
    });
  }

  void _completeCurrentSide() {
    final side = placingWhite;
    if (!_sideComplete(side)) return;
    if (side) {
      whiteDone = true;
      // CPUが後攻側なら「CPU 配置完了」の中間画面を描画せず、その場で配置まで完了する。
      if (!_isHumanSide(false)) {
        placingWhite = false;
        selectedMajor = null;
        _autoPlaceSide(false);
        blackDone = true;
      } else {
        setState(() {
          placingWhite = false;
          selectedMajor = null;
        });
      }
    } else {
      blackDone = true;
      setState(() => selectedMajor = null);
    }

    if (whiteDone && blackDone) {
      if (_battleNavigationStarted) return;
      _battleNavigationStarted = true;
      final all = <int, Piece>{}
        ..addAll(_fixedFor(true))
        ..addAll(_fixedFor(false))
        ..addAll(whiteMajors)
        ..addAll(blackMajors);
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => BoardScreen(
          initialPieces: all,
          playerIsWhite: widget.playerIsWhite,
          whiteUnit: _unitForSide(true),
          blackUnit: _unitForSide(false),
        ),
      ));
    }
  }

  Widget _pieceVisual(
    Piece piece, {
    bool playerPerspective = false,
    bool forceUpright = false,
  }) {
    if (piece.asset.isEmpty) {
      return Center(
        child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      );
    }
    final upright = forceUpright
        ? true
        : playerPerspective
            ? piece.isWhite == widget.playerIsWhite
            : piece.isWhite;
    return Transform.rotate(
      angle: upright ? 0 : 3.141592653589793,
      child: Image.asset(piece.asset, fit: BoxFit.contain),
    );
  }

  @override
  Widget build(BuildContext context) {
    _scheduleCpuPlacementIfNeeded();
    final pieces = _previewPieces();
    final humanTurn = _isHumanSide(placingWhite);
    final currentUnit = _unitForSide(placingWhite);
    final currentRoster = _rosterFor(currentUnit, placingWhite);
    final currentPlaced = placingWhite ? whiteMajors : blackMajors;

    return Scaffold(
      appBar: AppBar(title: const Text('INITIAL DEPLOYMENT')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Column(
                children: [
                  Text(
                    placingWhite ? '先攻  WHITE / SILVER  初期配置' : '後攻  BLACK / GOLD  初期配置',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: .8),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '先攻：${_unitDisplayName(_unitForSide(true))}　／　後攻：${_unitDisplayName(_unitForSide(false))}',
                    style: const TextStyle(fontSize: 13, color: Colors.cyanAccent, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    humanTurn ? '核をタップで絵柄切替・大駒を選んで配置' : 'CPU 配置中',
                    style: const TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 5,
                      childAspectRatio: 1,
                    ),
                    itemCount: 35,
                    itemBuilder: (_, visualIndex) {
                      // 初期配置中も YOU は常に画面下側に表示する。
                      final i = widget.playerIsWhite ? visualIndex : 34 - visualIndex;
                      final piece = pieces[i];
                      final isCurrentSlot = _placementSlotsForSide(placingWhite).contains(i);
                      final isStrassePlacement = _unitForSide(placingWhite) == BattleUnit.strasse;
                      final isCurrentCore = !isStrassePlacement &&
                          (placingWhite ? (i == 30 || i == 34) : (i == 0 || i == 4));
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (isCurrentCore) {
                            _toggleCore(placingWhite);
                          } else if (isCurrentSlot) {
                            _tapPlacementCell(i);
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.8) : Colors.white30,
                              width: isCurrentSlot && humanTurn ? 1.4 : .7,
                            ),
                            color: isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.05) : Colors.transparent,
                          ),
                          child: piece == null
                              ? null
                              : Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(3, 3, 3, 17),
                                      child: _pieceVisual(piece, playerPerspective: true),
                                    ),
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        width: double.infinity,
                                        color: Colors.black54,
                                        child: Text(piece.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            if (humanTurn) ...[
              const Divider(height: 1),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: currentRoster.map((piece) {
                    final isPlaced = currentPlaced.values.any((p) => p.label == piece.label);
                    final active = selectedMajor?.label == piece.label;
                    return GestureDetector(
                      onTap: () => setState(() => selectedMajor = piece),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 100),
                        width: 72,
                        height: 88,
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          border: Border.all(color: active ? Colors.cyanAccent : Colors.white24, width: active ? 2 : 1),
                          borderRadius: BorderRadius.circular(8),
                          color: isPlaced ? Colors.white.withOpacity(.03) : Colors.white.withOpacity(.07),
                        ),
                        child: Column(
                          children: [
                            Expanded(child: _pieceVisual(piece, forceUpright: true)),
                            Text(piece.label, style: TextStyle(fontWeight: FontWeight.w800, color: isPlaced ? Colors.white54 : Colors.white)),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 6, 18, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _sideComplete(placingWhite) ? _completeCurrentSide : null,
                    child: Text(placingWhite ? '先攻側 配置完了' : '後攻側 配置完了'),
                  ),
                ),
              ),
            ] else
              Padding(
                padding: const EdgeInsets.all(18),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _completeCurrentSide,
                    child: const Text('CPU 配置完了'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class CrownBadge extends StatelessWidget {
  final Color color;
  final String value;
  final bool darkCrown;
  const CrownBadge({
    super.key,
    required this.color,
    required this.value,
    this.darkCrown = false,
  });

  @override
  Widget build(BuildContext context) {
    final light = Color.lerp(color, Colors.white, .42)!;
    final dark = Color.lerp(color, Colors.black, .45)!;
    final outline = darkCrown ? const Color(0xFFE7EBEF) : light;
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [light, color, dark],
          stops: const [0.0, .46, 1.0],
        ),
        border: Border.all(color: outline, width: 1.0),
        boxShadow: [
          BoxShadow(color: outline.withOpacity(.24), blurRadius: 3.2, spreadRadius: .1),
        ],
      ),
      child: Container(
        margin: const EdgeInsets.all(1.5),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xCC101318),
          border: Border.all(color: Colors.white.withOpacity(.12), width: .5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 13,
              height: 7.5,
              child: CustomPaint(
                painter: _CrownPainter(
                  fill: light,
                  stroke: darkCrown ? Colors.white : light,
                ),
              ),
            ),
            const SizedBox(height: .5),
            Text(
              value,
              style: const TextStyle(
                fontSize: 6.6,
                fontWeight: FontWeight.w900,
                height: .9,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _ShotThreatArcPainter extends CustomPainter {
  final List<(int, int)> pairs;
  final double progress;
  final bool playerIsWhite;
  const _ShotThreatArcPainter({required this.pairs, required this.progress, required this.playerIsWhite});

  Offset _centerFor(int boardIndex, Size size) {
    final visual = playerIsWhite ? boardIndex : 34 - boardIndex;
    return Offset(((visual % 5) + .5) * size.width / 5, ((visual ~/ 5) + .5) * size.height / 7);
  }

  Offset _quad(Offset a, Offset c, Offset b, double t) {
    final u = 1 - t;
    return Offset(u * u * a.dx + 2 * u * t * c.dx + t * t * b.dx,
        u * u * a.dy + 2 * u * t * c.dy + t * t * b.dy);
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (var n = 0; n < pairs.length; n++) {
      final pair = pairs[n];
      final from = _centerFor(pair.$1, size);
      final to = _centerFor(pair.$2, size);
      final mid = (from + to) / 2;
      final distance = (to - from).distance;
      final control = Offset(mid.dx, mid.dy - math.min(42.0, 15.0 + distance * .18));

      // 複数射線は少しだけ位相をずらし、同時にピュンピュンし過ぎないようにする。
      final t = (progress + n * .13) % 1.0;
      final active = t < .62;
      if (!active) continue;
      final headT = Curves.easeInOut.transform((t / .62).clamp(0.0, 1.0));
      final tailT = math.max(0.0, headT - .22);
      final path = Path()..moveTo(_quad(from, control, to, tailT).dx, _quad(from, control, to, tailT).dy);
      for (var k = 1; k <= 12; k++) {
        final q = tailT + (headT - tailT) * k / 12;
        final pt = _quad(from, control, to, q);
        path.lineTo(pt.dx, pt.dy);
      }
      final glow = Paint()
        ..color = Colors.amberAccent.withOpacity(.28)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round;
      final core = Paint()
        ..color = Colors.amberAccent.withOpacity(.88)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;
      canvas.drawPath(path, glow);
      canvas.drawPath(path, core);

      final head = _quad(from, control, to, headT);
      final prev = _quad(from, control, to, math.max(0.0, headT - .025));
      final angle = math.atan2(head.dy - prev.dy, head.dx - prev.dx);
      final arrow = Path()
        ..moveTo(head.dx, head.dy)
        ..lineTo(head.dx - 8 * math.cos(angle - .55), head.dy - 8 * math.sin(angle - .55))
        ..moveTo(head.dx, head.dy)
        ..lineTo(head.dx - 8 * math.cos(angle + .55), head.dy - 8 * math.sin(angle + .55));
      canvas.drawPath(arrow, core..strokeWidth = 2.4);
    }
  }

  @override
  bool shouldRepaint(covariant _ShotThreatArcPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.playerIsWhite != playerIsWhite || oldDelegate.pairs != pairs;
}

class _ShotBeamPainter extends CustomPainter {
  final int originIndex;
  final int targetIndex;
  final double progress;
  final bool playerIsWhite;
  const _ShotBeamPainter({required this.originIndex, required this.targetIndex, required this.progress, required this.playerIsWhite});

  Offset _centerFor(int boardIndex, Size size) {
    final visual = playerIsWhite ? boardIndex : 34 - boardIndex;
    return Offset(((visual % 5) + .5) * size.width / 5, ((visual ~/ 5) + .5) * size.height / 7);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final from = _centerFor(originIndex, size);
    final to = _centerFor(targetIndex, size);
    final beamT = math.min(1.0, progress / .72);
    final head = Offset.lerp(from, to, beamT)!;
    final fade = progress < .78 ? 1.0 : (1.0 - progress) / .22;
    final glow = Paint()..color = Colors.cyanAccent.withOpacity((.42 * fade).clamp(0.0, 1.0))..strokeWidth = 10..strokeCap = StrokeCap.round;
    final core = Paint()..color = Colors.white.withOpacity((.95 * fade).clamp(0.0, 1.0))..strokeWidth = 3.2..strokeCap = StrokeCap.round;
    canvas.drawLine(from, head, glow);
    canvas.drawLine(from, head, core);
    final muzzle = Paint()..color = Colors.cyanAccent.withOpacity((.75 * (1 - progress)).clamp(0.0, 1.0));
    canvas.drawCircle(from, 5 + 7 * math.sin(math.pi * math.min(progress * 2, 1)), muzzle);
    if (progress > .58) {
      final impactT = ((progress - .58) / .42).clamp(0.0, 1.0);
      final impact = Paint()..color = Colors.white.withOpacity((1 - impactT) * .9)..style = PaintingStyle.stroke..strokeWidth = 4 * (1 - impactT) + 1;
      canvas.drawCircle(to, 8 + 24 * impactT, impact);
      final impactGlow = Paint()..color = Colors.cyanAccent.withOpacity((1 - impactT) * .5);
      canvas.drawCircle(to, 10 * (1 - impactT), impactGlow);
    }
  }

  @override
  bool shouldRepaint(covariant _ShotBeamPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.originIndex != originIndex || oldDelegate.targetIndex != targetIndex || oldDelegate.playerIsWhite != playerIsWhite;
}

class _CoreBurstPainter extends CustomPainter {
  final int index;
  final double progress;
  final bool playerIsWhite;
  const _CoreBurstPainter({required this.index, required this.progress, required this.playerIsWhite});

  @override
  void paint(Canvas canvas, Size size) {
    final visual = playerIsWhite ? index : 34 - index;
    final cw = size.width / 5, ch = size.height / 7;
    final center = Offset((visual % 5 + .5) * cw, (visual ~/ 5 + .5) * ch);
    final pulse = (math.sin(progress * math.pi * 7).abs());
    final fade = (1.0 - progress).clamp(0.0, 1.0);
    final radius = math.min(cw, ch) * (.22 + .30 * progress + .08 * pulse);
    final glow = Paint()..color = Colors.orangeAccent.withOpacity((.50 * fade + .20 * pulse).clamp(0, 1))..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawCircle(center, radius, glow);
    final ring = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5 + 2 * pulse..color = Colors.white.withOpacity((.9 * fade).clamp(0,1));
    canvas.drawCircle(center, radius * (.72 + .15 * pulse), ring);
    if (progress > .58) {
      final flash = ((1-progress)/.42).clamp(0.0,1.0);
      canvas.drawCircle(center, radius * 1.15, Paint()..color = Colors.white.withOpacity(.55 * flash));
    }
  }
  @override bool shouldRepaint(covariant _CoreBurstPainter old) => old.progress != progress || old.index != index;
}

class _CoreLinkPainter extends CustomPainter {
  final int fromIndex;
  final int toIndex;
  final double progress;
  final bool playerIsWhite;
  const _CoreLinkPainter({required this.fromIndex, required this.toIndex, required this.progress, required this.playerIsWhite});

  Offset _centerFor(int index, Size size) {
    final visual = playerIsWhite ? index : 34 - index;
    final cw = size.width / 5, ch = size.height / 7;
    return Offset((visual % 5 + .5) * cw, (visual ~/ 5 + .5) * ch);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final a = _centerFor(fromIndex, size), b = _centerFor(toIndex, size);
    final drawT = (progress / .72).clamp(0.0, 1.0);
    final fade = progress < .72 ? 1.0 : ((1.0 - progress) / .28).clamp(0.0, 1.0);
    final end = Offset.lerp(a, b, Curves.easeOutCubic.transform(drawT))!;
    final glow = Paint()..strokeWidth = 7..strokeCap = StrokeCap.round..color = Colors.lightBlueAccent.withOpacity(.30 * fade)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9);
    final line = Paint()..strokeWidth = 2.2..strokeCap = StrokeCap.round..color = Colors.white.withOpacity(.92 * fade);
    canvas.drawLine(a, end, glow);
    canvas.drawLine(a, end, line);
    if (drawT > .82) canvas.drawCircle(b, 6 + 5 * math.sin(progress * math.pi * 5).abs(), Paint()..color = Colors.white.withOpacity(.75 * fade));
  }
  @override bool shouldRepaint(covariant _CoreLinkPainter old) => old.progress != progress || old.fromIndex != fromIndex || old.toIndex != toIndex || old.playerIsWhite != playerIsWhite;
}

class CrownScoreDisplay extends StatelessWidget {
  final String label;
  final String value;
  const CrownScoreDisplay({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.045),
        border: Border.all(color: Colors.white24, width: .7),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: .7)),
          const SizedBox(width: 5),
          SizedBox(
            width: 13,
            height: 10,
            child: CustomPaint(
              painter: const _CrownPainter(fill: Color(0xFFD7DCE2), stroke: Colors.white),
            ),
          ),
          const SizedBox(width: 4),
          Text('$value / 3', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _CrownPainter extends CustomPainter {
  final Color fill;
  final Color stroke;
  const _CrownPainter({required this.fill, required this.stroke});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(w * .08, h * .25)
      ..lineTo(w * .28, h * .58)
      ..lineTo(w * .48, h * .18)
      ..lineTo(w * .68, h * .58)
      ..lineTo(w * .92, h * .25)
      ..lineTo(w * .82, h * .82)
      ..lineTo(w * .18, h * .82)
      ..close();
    canvas.drawPath(path, Paint()..color = fill..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()..color = stroke..style = PaintingStyle.stroke..strokeWidth = 1.0);
    canvas.drawLine(
      Offset(w * .17, h * .88),
      Offset(w * .83, h * .88),
      Paint()..color = stroke..strokeWidth = 1.1,
    );
  }

  @override
  bool shouldRepaint(covariant _CrownPainter oldDelegate) =>
      oldDelegate.fill != fill || oldDelegate.stroke != stroke;
}

class BattleResultScreen extends StatelessWidget {
  final bool playerWon;
  final bool showCrownVictory;
  const BattleResultScreen({
    super.key,
    required this.playerWon,
    this.showCrownVictory = true,
  });

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    playerWon ? 'VICTORY' : 'DEFEAT',
                    style: const TextStyle(
                      fontSize: 44,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                    ),
                  ),
                  if (showCrownVictory) ...[
                    const SizedBox(height: 14),
                    const Text('♛ × 3', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                  ],
                  const SizedBox(height: 34),
                  FilledButton(
                    onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
                    child: const Text('TITLE'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class Piece {
  final String asset;
  final String label;
  final bool major;
  final bool isWhite;
  final bool originalIsWhite;
  final bool captured;
  final int level;
  const Piece(
    this.asset,
    this.label, {
    this.major = false,
    required this.isWhite,
    bool? originalIsWhite,
    this.captured = false,
    this.level = 1,
  }) : originalIsWhite = originalIsWhite ?? isWhite;

  Piece copyWith({
    String? asset,
    String? label,
    bool? major,
    bool? isWhite,
    bool? originalIsWhite,
    bool? captured,
    int? level,
  }) {
    return Piece(
      asset ?? this.asset,
      label ?? this.label,
      major: major ?? this.major,
      isWhite: isWhite ?? this.isWhite,
      originalIsWhite: originalIsWhite ?? this.originalIsWhite,
      captured: captured ?? this.captured,
      level: level ?? this.level,
    );
  }
}

class BoardScreen extends StatefulWidget {
  final Map<int, Piece> initialPieces;
  final bool playerIsWhite;
  final BattleUnit whiteUnit;
  final BattleUnit blackUnit;
  const BoardScreen({
    super.key,
    required this.initialPieces,
    required this.playerIsWhite,
    required this.whiteUnit,
    required this.blackUnit,
  });

  @override
  State<BoardScreen> createState() => _BoardScreenState();
}

class _BoardScreenState extends State<BoardScreen> with TickerProviderStateMixin {
  int? selectedIndex;
  bool whiteTurn = true;
  bool _noLegalActionFinishScheduled = false;
  bool _cpuTurnScheduled = false;
  int? _cpuPreviewTarget;
  String? _cpuPreviewAction;
  // 行動後も選択情報だけを短時間残す。操作自体には待機を入れない。
  int? _actionEchoOrigin;
  int? _actionEchoTarget;
  Set<int> _actionEchoMoveTargets = <int>{};
  Set<int> _actionEchoMergeTargets = <int>{};
  Set<int> _actionEchoEnemyTargets = <int>{};
  int _actionEchoGeneration = 0;
  static const Duration _actionEchoDuration = Duration(milliseconds: 650);
  // 駒の移動を「結果の瞬間切替」ではなく、盤上を実際に移動して見せる。
  int? _motionOrigin;
  int? _motionTarget;
  int _motionGeneration = 0;
  static const Duration _pieceMotionDuration = Duration(milliseconds: 720);
  int? _shotOrigin;
  int? _shotTarget;
  int _shotGeneration = 0;
  static const Duration _shotAnimationDuration = Duration(milliseconds: 420);

  // Lv/Pu変化は通常のText再描画ではなく、盤面側の明示イベントとして扱う。
  // 演出中は入力・CPU進行を止め、完了してから次の処理へ進む。
  bool _statChangeBusy = false;
  int? _statChangeIndex;
  String? _statChangePrefix;
  int? _statChangeValue;
  bool _statChangeUp = true;
  int _statChangeGeneration = 0;
  static const Duration _statChangeDuration = Duration(milliseconds: 760);

  Future<void> _showStatChange(int index, String prefix, int value, {required bool up}) async {
    final generation = ++_statChangeGeneration;
    if (!mounted) return;
    setState(() {
      _statChangeBusy = true;
      _statChangeIndex = index;
      _statChangePrefix = prefix;
      _statChangeValue = value;
      _statChangeUp = up;
    });
    await Future<void>.delayed(_statChangeDuration);
    if (!mounted || generation != _statChangeGeneration) return;
    setState(() {
      _statChangeBusy = false;
      _statChangeIndex = null;
      _statChangePrefix = null;
      _statChangeValue = null;
    });
  }

  // 騎の変形：変形先が上空から降下して装着されるように、
  // 同じマス上で「大きい→本来サイズ」に縮小して奥行きを表現する。
  int? _knightTransformIndex;
  Piece? _knightTransformTargetPiece;
  int _knightTransformGeneration = 0;
  bool _knightTransformBusy = false;
  static const Duration _knightTransformDuration = Duration(milliseconds: 680);

  // 技も通常行動と同じ「タイプ音＋台詞 → 盤面上で発動」で統一する。
  String _skillLineFor(Piece piece, {String? knightTarget}) {
    if (piece.label == '王') return 'そこは危ないよ！';
    if (piece.label == '帝') return 'どこを見ている？';
    if (_isKnightForm(piece)) {
      return switch (knightTarget) {
        '騎弐式' => '白兵戦と行こうか……。',
        '騎参式' => '弾幕を張る。',
        _ => '頃合だ。',
      };
    }
    return '';
  }

  Future<void> _showSkillDialogueForIndex(int index, {String? knightTarget}) async {
    final piece = _topPieceAt(index);
    if (piece == null) return;
    final line = _skillLineFor(piece, knightTarget: knightTarget);
    final name = _pilotNameForPiece(piece);
    final asset = _pilotAssetForPiece(piece);
    if (line.isEmpty || name == null || asset == null) return;
    final generation = ++_pilotDialogueGeneration;
    _traceDialogue('P START g$generation skill [$line]');
    setState(() {
      _pilotDialogueBusy = true;
      _pilotDialogueTyping = true;
      _pilotDialogueText = line;
      _pilotDialogueName = name;
      _pilotDialogueAsset = asset;
    });
    _playActionSfx('audio/se_type.wav');
    await Future<void>.delayed(_pilotTypingDuration);
    if (!mounted || generation != _pilotDialogueGeneration) return;
    setState(() => _pilotDialogueTyping = false);
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _pilotDialogueGeneration) return;
    setState(() => _pilotDialogueBusy = false);
    Future<void>.delayed(
      _pilotDialogueVisibleDuration - _pilotTypingDuration - const Duration(milliseconds: 600),
      () {
        if (!mounted || generation != _pilotDialogueGeneration) return;
        setState(() {
          _pilotDialogueTyping = false;
          _pilotDialogueText = null;
          _pilotDialogueName = null;
          _pilotDialogueAsset = null;
        });
      },
    );
  }

  // パイロット台詞。先に高速タイプ表示し、そのまま行動演出中も残す。
  String? _pilotDialogueText;
  String? _pilotDialogueName;
  String? _pilotDialogueAsset;
  int _pilotDialogueGeneration = 0;
  bool _pilotDialogueBusy = false;
  bool _pilotDialogueTyping = false;

  // Temporary on-screen dialogue trace for isolating the double-display bug.
  final List<String> _dialogueTrace = <String>[];
  int _dialogueTraceSeq = 0;
  void _traceDialogue(String event) {
    final line = '${++_dialogueTraceSeq}: $event';
    _dialogueTrace.add(line);
    if (_dialogueTrace.length > 8) _dialogueTrace.removeAt(0);
  }

  // CPU dialogue has its own state. Never share it with the player's overlay.
  String? _cpuPilotDialogueText;
  String? _cpuPilotDialogueName;
  String? _cpuPilotDialogueAsset;
  int _cpuPilotDialogueGeneration = 0;
  bool _cpuPilotDialogueTyping = false;

  static const Duration _pilotTypingDuration = Duration(milliseconds: 430);
  static const Duration _pilotDialogueVisibleDuration = Duration(milliseconds: 2050);

  String _pilotKeyForPiece(Piece piece) => switch (piece.label) {
    '王' => '王',
    '仕' => '仕',
    '護' => '護',
    '闘' => '闘',
    '騎' || '騎弐式' || '騎参式' => '騎',
    '博' => '博',
    '将' => '将',
    '官' => '官',
    '帝' => '帝',
    '砲' => '砲',
    '剣' => '剣',
    '盾' => '盾',
    _ => '',
  };

  String? _pilotNameForPiece(Piece piece) => switch (_pilotKeyForPiece(piece)) {
    '王' => 'アーキン・バーン',
    '仕' => 'レイ・コール',
    '護' => 'ジェイク・ペイド',
    '闘' => 'アーツ・ロイアー',
    '騎' => 'ブル・キル',
    '博' => 'オース・アイン',
    '将' => 'ファン・オエル',
    '官' => 'ギル・ターク',
    '帝' => '皇帝',
    '砲' => '砲',
    '剣' => '剣',
    '盾' => '盾',
    _ => null,
  };

  String? _pilotAssetForPiece(Piece piece) => switch (_pilotKeyForPiece(piece)) {
    '王' => 'assets/pilots/king.webp',
    '仕' => 'assets/pilots/attendant.webp',
    '護' => 'assets/pilots/guard.webp',
    '闘' => 'assets/pilots/fighter.webp',
    '騎' => 'assets/pilots/knight.webp',
    '博' => 'assets/pilots/scholar.webp',
    '将' => 'assets/pilots/general.webp',
    '官' => 'assets/pilots/officer.webp',
    '帝' => 'assets/pilots/emperor.webp',
    '砲' => 'assets/pilots/cannon.webp',
    '剣' => 'assets/pilots/sword.webp',
    '盾' => 'assets/pilots/shield.webp',
    _ => null,
  };

  String? _pilotLineFor(Piece piece, String action) {
    final k = _pilotKeyForPiece(piece);
    const lines = <String, Map<String, String>>{
      '帝': {'melee':'……！！','ranged':'消え去れ。','suppress':'どうした。','move':'……。','merge':'……。','suppressDestroy':'終わりだ。'},
      '剣': {'melee':'切り捨てる。','ranged':'これでいいだろう。','suppress':'逃げてみろ……。','move':'この距離だな……。','merge':'行くぞ……！','suppressDestroy':'とどめだ。'},
      '盾': {'melee':'これでいいかしら。','ranged':'ん……！！','suppress':'あらら、、、','move':'ん～とりあえずこうね。','merge':'さて、と……。','suppressDestroy':'可哀想だけど……！'},
      '砲': {'melee':'ハハハハハ！！','ranged':'ワタシノテガラダ！','suppress':'ンン……！！イイゾ！！','move':'コッチダ！！','merge':'コレデドウカナ！','suppressDestroy':'ンー！キモチイイ！'},
      '王': {'melee':'これでどうだい！？','ranged':'僕をフリーにしたら……。','suppress':'制圧完了！','move':'おっとっと！','merge':'共に闘おう！','suppressDestroy':'ごめん！！'},
      '闘': {'melee':'オラオラオラ！！','ranged':'ここだろう？','suppress':'逃がさねえぞ。','move':'急かすなよ。','merge':'俺達の力見せてやろうぜ。','suppressDestroy':'あばよ……！'},
      '護': {'melee':'おー当たった！w','ranged':'あーそこにいちゃいけない！','suppress':'制圧しちゃった！','move':'逃げろ～！','merge':'ちょっとここで休憩w','suppressDestroy':'あ、やっちゃった！'},
      '仕': {'melee':'そこだ！！','ranged':'狙い撃ち～！','suppress':'逃げてみなさいよ！','move':'やばい！退散～！','merge':'お茶を濁すわ！','suppressDestroy':'いつまでそこにいるのよ。'},
      '騎': {'melee':'逃げきれん。','ranged':'……。','suppress':'そう慌てるな。','move':'時間を稼ぐ。','merge':'やれやれ。','suppressDestroy':'悪かったな。'},
      '将': {'melee':'退場してもらうわ。','ranged':'失敗だったわね。','suppress':'あら、こんにちは。','move':'退避する。','merge':'また会ったわね。','suppressDestroy':'仕方ないわね。'},
      '官': {'melee':'ぬるいな。','ranged':'こんなものか？','suppress':'さあ、どうした。','move':'こっちだ。','merge':'合流完了。','suppressDestroy':'予定変更だ。'},
      '博': {'melee':'こんなものも避けられないのか。','ranged':'雨あられ……。','suppress':'困ったものだな。','move':'フ、先を急ぐか。','merge':'私の後ろにいるといい。','suppressDestroy':'気の毒だが……。'},
    };
    return lines[k]?[action];
  }

  Future<void> _showPilotDialogueForIndex(int index, String action) async {
    final piece = _topPieceAt(index);
    if (piece == null) return;
    final line = _pilotLineFor(piece, action);
    final name = _pilotNameForPiece(piece);
    final asset = _pilotAssetForPiece(piece);
    if (line == null || name == null || asset == null) return;
    final generation = ++_pilotDialogueGeneration;
    _traceDialogue('P START g$generation $action [$line]');
    setState(() {
      _pilotDialogueBusy = true;
      _pilotDialogueTyping = true;
      _pilotDialogueText = line;
      _pilotDialogueName = name;
      _pilotDialogueAsset = asset;
    });
    _playActionSfx('audio/se_type.wav');
    await Future<void>.delayed(_pilotTypingDuration);
    if (!mounted || generation != _pilotDialogueGeneration) return;
    setState(() => _pilotDialogueTyping = false);

    // 文字が打ち終わってから一度しっかり読ませて、機体の行動へ。
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _pilotDialogueGeneration) return;
    _traceDialogue('P ACTION g$generation');
    setState(() => _pilotDialogueBusy = false);

    // 行動アニメ中も表示し、終わったあとにも少し余韻を残す。
    Future<void>.delayed(
      _pilotDialogueVisibleDuration -
          _pilotTypingDuration -
          const Duration(milliseconds: 600),
      () {
      if (!mounted || generation != _pilotDialogueGeneration) return;
      _traceDialogue('P HIDE g$generation');
      setState(() {
        _pilotDialogueTyping = false;
        _pilotDialogueText = null;
        _pilotDialogueName = null;
        _pilotDialogueAsset = null;
      });
    });
  }


  Future<void> _showCpuPilotDialogueForIndex(int index, String action) async {
    final piece = _topPieceAt(index);
    if (piece == null) return;
    final line = _pilotLineFor(piece, action);
    final name = _pilotNameForPiece(piece);
    final asset = _pilotAssetForPiece(piece);
    if (line == null || name == null || asset == null) return;
    final generation = ++_cpuPilotDialogueGeneration;
    _traceDialogue('C START g$generation $action [$line]');
    setState(() {
      // CPU台詞を出す瞬間に旧共通オーバーレイを完全に破棄する。
      // CPU専用表示と旧表示が同じ位置に重なって「2回目」に見える経路を断つ。
      _pilotDialogueGeneration++;
      _pilotDialogueBusy = false;
      _pilotDialogueTyping = false;
      _pilotDialogueText = null;
      _pilotDialogueName = null;
      _pilotDialogueAsset = null;
      _cpuPilotDialogueTyping = true;
      _cpuPilotDialogueText = line;
      _cpuPilotDialogueName = name;
      _cpuPilotDialogueAsset = asset;
    });
    _playActionSfx('audio/se_type.wav');
    await Future<void>.delayed(_pilotTypingDuration);
    if (!mounted || generation != _cpuPilotDialogueGeneration) return;
    setState(() => _cpuPilotDialogueTyping = false);
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _cpuPilotDialogueGeneration) return;
    _traceDialogue('C ACTION g$generation');
    Future<void>.delayed(
      _pilotDialogueVisibleDuration - _pilotTypingDuration - const Duration(milliseconds: 600),
      () {
        if (!mounted || generation != _cpuPilotDialogueGeneration) return;
        _traceDialogue('C HIDE g$generation');
        setState(() {
          _cpuPilotDialogueTyping = false;
          _cpuPilotDialogueText = null;
          _cpuPilotDialogueName = null;
          _cpuPilotDialogueAsset = null;
        });
      },
    );
  }

  void _beginShotAnimation(int from, int to) {
    setState(() {
      _shotOrigin = from;
      _shotTarget = to;
      _shotGeneration++;
    });
    final generation = _shotGeneration;
    Future<void>.delayed(_shotAnimationDuration, () {
      if (!mounted || generation != _shotGeneration) return;
      setState(() {
        _shotOrigin = null;
        _shotTarget = null;
      });
    });
  }

  void _beginPieceMotion(int from, int to) {
    setState(() {
      _motionOrigin = from;
      _motionTarget = to;
      _motionGeneration++;
    });
    final generation = _motionGeneration;
    Future<void>.delayed(_pieceMotionDuration, () {
      if (!mounted || generation != _motionGeneration) return;
      setState(() {
        _motionOrigin = null;
        _motionTarget = null;
      });
    });
  }
  final AudioPlayer _battleBgmPlayer = AudioPlayer();
  final AudioPlayer _actionSfxPlayer = AudioPlayer();
  int? _coreBurstIndex;
  int _coreBurstGeneration = 0;
  static const Duration _coreBurstDuration = Duration(milliseconds: 760);

  // 核の効果は説明ポップアップではなく、盤面上の対象駒そのものに見せる。
  int? _coreEffectIndex;
  Piece? _coreEffectPiece;
  int? _coreEffectOldLevel;
  bool _coreEffectIsRevival = false;
  int _coreEffectGeneration = 0;
  static const Duration _coreLv3EffectDuration = Duration(milliseconds: 1500);
  static const Duration _coreRevivalEffectDuration = Duration(milliseconds: 1500);
  int? _coreLinkFrom;
  int? _coreLinkTo;
  int _coreLinkGeneration = 0;
  int? _pendingRevivalCoreIndex;

  Future<void> _playActionSfx(String asset) async {
    try {
      await _actionSfxPlayer.setAudioContext(
        AudioContext(
          android: const AudioContextAndroid(
            contentType: AndroidContentType.sonification,
            usageType: AndroidUsageType.game,
            audioFocus: AndroidAudioFocus.none,
          ),
          iOS: AudioContextIOS(
            category: AVAudioSessionCategory.ambient,
            options: const {AVAudioSessionOptions.mixWithOthers},
          ),
        ),
      );
      await _actionSfxPlayer.play(AssetSource(asset));
    } catch (_) {}
  }

  void _beginCoreBurst(int index) {
    setState(() { _coreBurstIndex = index; _coreBurstGeneration++; });
    final g = _coreBurstGeneration;
    _playActionSfx('audio/se_core_charge.wav');
    Future<void>.delayed(const Duration(milliseconds: 470), () {
      if (!mounted || g != _coreBurstGeneration) return;
      _playActionSfx('audio/se_core_burst.wav');
    });
    Future<void>.delayed(_coreBurstDuration, () {
      if (!mounted || g != _coreBurstGeneration) return;
      setState(() => _coreBurstIndex = null);
    });
  }
  bool _showBgmTitle = false;
  static const String _battleBgmAsset = 'audio/5Overdriven Riffs.mp3';
  static const String _battleBgmTitle = 'Overdriven Riffs';
  // 帝「加速」：1回目を選んだ後、2回目の移動が可能なら強制する。
  // 現在は同一端末テスト版。対戦相手への移動経路秘匿・カットインは
  // オンライン同期時に2回目の成否だけ送る形で実装する。
  int _accelerationStep = 0; // 0=通常、1=最初の移動、2=2回目の移動
  int _rapidFireStep = 0; // 王「連射」：0=通常、1=1発目、2=2発目
  // シュトラーセ「逃げるが勝ち」
  // 0=通常、1=格闘対象選択、2=格闘後の移動先選択、3=合流した2機の移動先選択
  int _strasseSkillStep = 0;
  final List<Piece> _whiteDestroyedMajors = <Piece>[];
  final List<Piece> _blackDestroyedMajors = <Piece>[];
  int _whiteSoldierStock = 0;
  int _blackSoldierStock = 0;
  bool _placingStockSoldier = false;
  Set<int> _stockSoldierTargets = <int>{};
  Piece? _pendingRevivalPiece;
  Set<int> _pendingRevivalTargets = <int>{};
  final Set<int> lowerInfoCells = <int>{};
  late final AnimationController _mergeBlinkController;
  late final AnimationController _shotThreatController;

  @override
  void initState() {
    super.initState();
    _mergeBlinkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..repeat(reverse: true);
    _shotThreatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
    cells = {
      for (final entry in widget.initialPieces.entries) entry.key: [entry.value],
    };
    _whiteBattleUnit = _unitFromInitialPieces(true);
    _blackBattleUnit = _unitFromInitialPieces(false);
    _startBattleBgm();
  }

  Future<void> _startBattleBgm() async {
    try {
      await _battleBgmPlayer.setReleaseMode(ReleaseMode.loop);
      await _battleBgmPlayer.play(AssetSource(_battleBgmAsset));
    } catch (_) {
      // BGM failure must never stop the battle itself.
    }
    if (!mounted) return;
    setState(() => _showBgmTitle = true);
    await Future<void>.delayed(const Duration(seconds: 3));
    if (!mounted) return;
    setState(() => _showBgmTitle = false);
  }

  Future<void> _stopBattleBgm() async {
    try {
      await _battleBgmPlayer.stop();
    } catch (_) {}
  }

  @override
  void dispose() {
    _mergeBlinkController.dispose();
    _shotThreatController.dispose();
    _battleBgmPlayer.dispose();
    _actionSfxPlayer.dispose();
    super.dispose();
  }

  late final Map<int, List<Piece>> cells;
  late final BattleUnit _whiteBattleUnit;
  late final BattleUnit _blackBattleUnit;

  // 格闘後などで、敵駒の上に乗って制圧しているマス。
  final Set<int> suppressedCells = <int>{};

  Piece? _topPieceAt(int index) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return null;
    return stack.last;
  }

  bool _isMergedCell(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    return stack.every((piece) => piece.isWhite == stack.first.isWhite);
  }

  bool _isSuppressedCell(int index) => suppressedCells.contains(index);

  BattleUnit _unitFromInitialPieces(bool isWhite) {
    final labels = widget.initialPieces.values
        .where((piece) => piece.isWhite == isWhite)
        .map((piece) => piece.label)
        .toSet();
    if (labels.contains('王')) return BattleUnit.king;
    if (labels.contains('帝')) return BattleUnit.emperor;
    if (labels.any((label) => const {'槍', '迅', '進', '亜'}.contains(label))) return BattleUnit.strasse;
    return BattleUnit.knight;
  }

  BattleUnit _unitForPiece(Piece piece) =>
      piece.originalIsWhite ? _whiteBattleUnit : _blackBattleUnit;

  bool _isLeaderPiece(Piece piece) {
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => piece.label == '王',
      BattleUnit.knight => piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式',
      BattleUnit.emperor => piece.label == '帝',
      BattleUnit.strasse => false,
    };
  }

  double? _crownValueForPiece(Piece piece) {
    if (_unitForPiece(piece) == BattleUnit.strasse && piece.major && !piece.captured) return 1.0;
    if (piece.label == '核') return 1.5;
    if (_isLeaderPiece(piece) && !piece.captured) return 1.5;
    return null;
  }

  Color _crownColorForPiece(Piece piece) {
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => const Color(0xFFFFD740),
      BattleUnit.knight => const Color(0xFF42A5F5),
      BattleUnit.emperor => const Color(0xFFFF5252),
      BattleUnit.strasse => const Color(0xFFEEEEEE),
    };
  }

  String? _crownAssetForPiece(Piece piece) {
    final crownValue = _crownValueForPiece(piece);
    if (_unitForPiece(piece) == BattleUnit.strasse && crownValue == 1.0) {
      return 'assets/pieces/crown_strasse_1.webp';
    }
    if (crownValue != 1.5) return null;
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => 'assets/pieces/crown_king_1_5.webp',
      BattleUnit.knight => 'assets/pieces/crown_knight_1_5.webp',
      BattleUnit.emperor => 'assets/pieces/crown_emperor_1_5.webp',
      BattleUnit.strasse => null,
    };
  }

  String _crownValueText(double value) => value == value.roundToDouble()
      ? value.toInt().toString()
      : value.toStringAsFixed(1);

  double _lostCrownPoints(bool isWhite) {
    final unit = isWhite ? _whiteBattleUnit : _blackBattleUnit;
    if (unit == BattleUnit.strasse) {
      var alive = 0;
      for (final stack in cells.values) {
        for (final piece in stack) {
          if (piece.originalIsWhite == isWhite && !piece.captured && const {'槍', '迅', '進', '亜'}.contains(piece.label)) alive++;
        }
      }
      return (4 - alive.clamp(0, 4).toInt()).toDouble();
    }
    var coresAlive = 0;
    var leaderAlive = false;
    for (final stack in cells.values) {
      for (final piece in stack) {
        if (piece.label == '核' && piece.isWhite == isWhite) coresAlive++;
        if (piece.originalIsWhite != isWhite || piece.captured) continue;
        final isLeader = switch (unit) {
          BattleUnit.king => piece.label == '王',
          BattleUnit.knight => piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式',
          BattleUnit.emperor => piece.label == '帝',
          BattleUnit.strasse => false,
        };
        if (isLeader) leaderAlive = true;
      }
    }
    final missingCores = 2 - coresAlive.clamp(0, 2).toInt();
    final missingLeader = leaderAlive ? 0 : 1;
    return (missingCores + missingLeader) * 1.5;
  }

  bool _sideHasAnyLegalAction(bool isWhite) {
    // 兵ストックから投入できるなら行動あり。
    if (_soldierStockFor(isWhite) > 0 && _soldierDeploymentTargets(isWhite).isNotEmpty) {
      return true;
    }

    for (var i = 0; i < 35; i++) {
      final stack = cells[i];
      if (stack == null || stack.isEmpty) continue;
      final top = stack.last;
      if (top.isWhite != isWhite) continue;

      // 発動可能な核が1つでもあれば行動あり。
      if (top.label == '核') {
        if (_canActivateCoreAt(i)) return true;
        continue;
      }

      // 制圧中の上側は「制圧破壊」が可能。
      if (_isSuppressedCell(i)) return true;

      // 騎は変形そのものが1行動なので、どの形態でも行動あり。
      if (_isKnightForm(top)) return true;

      // 通常移動・合流・敵への行動のどれかがあれば行動あり。
      if (_moveTargetsFor(i).isNotEmpty ||
          _mergeTargetsFor(i).isNotEmpty ||
          _enemyTargetsFor(i).isNotEmpty) {
        return true;
      }
    }
    return false;
  }

  void _scheduleNoLegalActionFinishIfNeeded() {
    if (_noLegalActionFinishScheduled ||
        _placingStockSoldier ||
        _pendingRevivalPiece != null ||
        _rapidFireStep != 0 ||
        _accelerationStep != 0) {
      return;
    }
    if (_lostCrownPoints(true) >= 3.0 || _lostCrownPoints(false) >= 3.0) return;
    if (_sideHasAnyLegalAction(whiteTurn)) return;

    _noLegalActionFinishScheduled = true;
    final loserIsWhite = whiteTurn;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final playerWon = loserIsWhite != widget.playerIsWhite;
      _stopBattleBgm();
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => BattleResultScreen(
            playerWon: playerWon,
            showCrownVictory: false,
          ),
        ),
      );
    });
  }

  bool _maybeFinishBattle() {
    final whiteDefeated = _lostCrownPoints(true) >= 3.0;
    final blackDefeated = _lostCrownPoints(false) >= 3.0;
    if (!whiteDefeated && !blackDefeated) return false;

    final winnerIsWhite = blackDefeated && !whiteDefeated;
    final playerWon = winnerIsWhite == widget.playerIsWhite;
    _accelerationStep = 0;
    _rapidFireStep = 0;
    selectedIndex = null;
    if (!mounted) return true;
    _stopBattleBgm();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => BattleResultScreen(playerWon: playerWon)),
    );
    return true;
  }

  // 上方向を「前」とした白側用の相対座標。
  // 2026-09-22確定版：KNIGHT / KING / EMPEROR 全12大駒＋兵系。
  static const Map<String, List<List<int>>> lv1MoveOffsets = {
    '兵': [
      [-1, 0], [1, 0], [0, -1], [0, 1],
    ],
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '護': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '帝': [
      [-2, 0],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '槍': [[-2,-1],[-2,0],[-2,1],[1,-2],[1,2]],
    '迅': [[-1,-1],[-1,0],[-1,1],[1,-1],[1,1]],
    '進': [[-2,-2],[-2,-1],[-2,1],[-2,2],[1,0]],
    '亜': [[-1,-1],[-1,0],[-1,1],[1,-1],[1,1]],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv2MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, 0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '槍': [[-2,-1],[-2,0],[-2,1],[1,-2],[1,2],[2,-1],[2,1]],
    '迅': [[-1,-1],[-1,0],[-1,1],[1,-1],[1,1],[2,-2],[2,2]],
    '進': [[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[1,0],[2,0]],
    '亜': [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,1]],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv3MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [0, -2], [0, 2],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, -1], [0, 1], [0, 2],
      [1, 0],
    ],
    '王': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -2], [0, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '槍': [[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],
    '迅': [[-2,-2],[-2,2],[-1,-1],[-1,0],[-1,1],[1,-1],[1,1],[2,-2],[2,2]],
    '進': [[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[-1,-1],[-1,1],[1,0],[2,0]],
    '亜': [[-1,-2],[-1,-1],[-1,0],[-1,1],[-1,2],[0,-1],[0,1],[1,-1],[1,1]],
    '核': <List<int>>[],
  };

  static const List<List<int>> mergedSoldierOffsets = [
    [-2, 0], [-1, 0],
    [0, -2], [0, -1], [0, 1], [0, 2],
    [1, 0], [2, 0],
  ];

  static const List<List<int>> frontlineSoldierOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  // 騎の変形形態はLv/Puの影響を受けない固定行動範囲。
  static const List<List<int>> knightSecondOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  static const List<List<int>> knightThirdOffsets = [
    [-2, -1], [-2, 1],
    [-1, -2], [-1, -1], [-1, 1], [-1, 2],
    [1, -1], [1, 1],
  ];

  bool _isKnightForm(Piece piece) =>
      piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式';

  bool _isFixedKnightForm(Piece piece) =>
      piece.label == '騎弐式' || piece.label == '騎参式';

  bool _isFrontlineForPiece(int index, Piece piece) {
    final row = index ~/ 5;
    // 白は下側から上へ進軍、黒は上側から下へ進軍。
    // 相手側3列に入ったら前線パンプ +1。
    return piece.isWhite ? row <= 2 : row >= 4;
  }

  bool _hasFrontlineMergeForSide(bool isWhite) {
    for (final entry in cells.entries) {
      final index = entry.key;
      if (!_isMergedCell(index)) continue;
      final top = _topPieceAt(index);
      if (top == null || top.isWhite != isWhite) continue;
      if (_isFrontlineForPiece(index, top)) return true;
    }
    return false;
  }

  int _pumpForPieceAt(int index, Piece piece, {bool? mergedOverride}) {
    if (!piece.major || _isFixedKnightForm(piece) || piece.level >= 3) return 0;

    final roomToLevel3 = 3 - piece.level;

    // 味方のどこかで「前線＋合流」が成立している間は、
    // 味方大駒全体を最大（実効Lv3）までパンプする。
    if (_hasFrontlineMergeForSide(piece.isWhite)) return roomToLevel3;

    final merged = mergedOverride ?? _isMergedCell(index);
    var pump = 0;
    if (merged) pump++;
    if (_isFrontlineForPiece(index, piece)) pump++;
    return pump > roomToLevel3 ? roomToLevel3 : pump;
  }

  int _effectiveLevelForPieceAt(int index, Piece piece, {bool? mergedOverride}) {
    if (!piece.major || _isFixedKnightForm(piece)) return piece.level;
    final pump = _pumpForPieceAt(index, piece, mergedOverride: mergedOverride);
    final effective = piece.level + pump;
    return effective > 3 ? 3 : effective;
  }

  List<List<int>> _levelOffsetsFor(String label, int level) {
    if (level >= 3) {
      return lv3MoveOffsets[label] ?? lv2MoveOffsets[label] ?? lv1MoveOffsets[label] ?? const <List<int>>[];
    }
    if (level == 2) {
      return lv2MoveOffsets[label] ?? lv1MoveOffsets[label] ?? const <List<int>>[];
    }
    return lv1MoveOffsets[label] ?? const <List<int>>[];
  }

  List<List<int>> _moveOffsetsFor(int index, Piece piece, {bool? mergedOverride}) {
    if (piece.label == '騎弐式') return knightSecondOffsets;
    if (piece.label == '騎参式') return knightThirdOffsets;

    final merged = mergedOverride ?? _isMergedCell(index);
    final frontline = _isFrontlineForPiece(index, piece);

    if (piece.label == '兵') {
      // 兵はLv成長なし。
      // 前線効果（または味方の前線合流による全体パンプ）= 3x3、
      // 合流効果 = 十字2。両方ある場合は効果を合成する。
      final teamMaxPump = _hasFrontlineMergeForSide(piece.isWhite);
      final hasFrontlineEffect = frontline || teamMaxPump;

      if (hasFrontlineEffect && merged) {
        final combined = <String, List<int>>{};
        for (final offset in frontlineSoldierOffsets) {
          combined['${offset[0]},${offset[1]}'] = offset;
        }
        for (final offset in mergedSoldierOffsets) {
          combined['${offset[0]},${offset[1]}'] = offset;
        }
        return combined.values.toList(growable: false);
      }
      if (hasFrontlineEffect) return frontlineSoldierOffsets;
      if (merged) return mergedSoldierOffsets;
      return lv1MoveOffsets['兵'] ?? const <List<int>>[];
    }

    final effectiveLevel = _effectiveLevelForPieceAt(index, piece, mergedOverride: merged);
    return _levelOffsetsFor(piece.label, effectiveLevel);
  }

  Set<int> _actionSquaresFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  bool _isStrassePiece(Piece piece) => const {'槍', '迅', '進', '亜'}.contains(piece.label);

  Set<int> _enemyTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    return _actionSquaresFor(index).where((target) {
      final targetPiece = _topPieceAt(target);
      return targetPiece != null && targetPiece.isWhite != piece.isWhite;
    }).toSet();
  }

  bool _isContested(int attackerIndex, int targetIndex) {
    final attacker = _topPieceAt(attackerIndex);
    final target = _topPieceAt(targetIndex);
    if (attacker == null || target == null) return false;
    // STRASSEは射撃を持たないため、射撃の拮抗には参加しない。
    if (_isStrassePiece(attacker) || _isStrassePiece(target)) return false;
    return _actionSquaresFor(targetIndex).contains(attackerIndex);
  }

  Set<int> _actionSquaresForPieceAt(int index, Piece piece, {bool merged = false}) {
    final offsets = _moveOffsetsFor(index, piece, mergedOverride: merged);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};
    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Piece _pieceAfterKillLevelUp(Piece piece) {
    if (!piece.major || piece.level >= 3) return piece;
    return piece.copyWith(level: piece.level + 1);
  }

  bool get _soldierCaptureEnabled {
    const basics = <BattleUnit>{BattleUnit.king, BattleUnit.knight, BattleUnit.emperor};
    return basics.contains(widget.whiteUnit) && basics.contains(widget.blackUnit);
  }

  void _recordDestroyedPiece(Piece piece) {
    if (piece.label == '兵') {
      if (_soldierCaptureEnabled) {
        // 倒された兵は「倒した側」のストックになる。
        if (piece.isWhite) {
          _blackSoldierStock++;
        } else {
          _whiteSoldierStock++;
        }
      }
      return;
    }
    if (!piece.major) return;
    // 大駒は現在の所属や鹵獲状態に関係なく、破壊されたら必ず本来の持ち主へ戻す。
    final originalSideAsset = piece.originalIsWhite
        ? piece.asset.replaceFirst('pieces/black_', 'pieces/white_')
        : piece.asset.replaceFirst('pieces/white_', 'pieces/black_');
    final returnedPiece = piece.copyWith(
      asset: originalSideAsset,
      isWhite: piece.originalIsWhite,
      captured: false,
    );
    (piece.originalIsWhite ? _whiteDestroyedMajors : _blackDestroyedMajors)
        .add(returnedPiece);
  }

  int _soldierStockFor(bool isWhite) => isWhite ? _whiteSoldierStock : _blackSoldierStock;

  Set<int> _soldierDeploymentTargets(bool isWhite) {
    final result = <int>{};
    for (var i = 0; i < 35; i++) {
      final row = i ~/ 5;
      final inOwnFourRows = isWhite ? row >= 3 : row <= 3;
      if (!inOwnFourRows) continue;
      final stack = cells[i];
      if (stack == null || stack.isEmpty) result.add(i);
    }
    return result;
  }

  void _startStockSoldierDeployment() {
    if (_rapidFireStep != 0 || _accelerationStep != 0 || _pendingRevivalPiece != null) return;
    if (_soldierStockFor(whiteTurn) <= 0) return;
    final targets = _soldierDeploymentTargets(whiteTurn);
    if (targets.isEmpty) return;
    setState(() {
      selectedIndex = null;
      lowerInfoCells.clear();
      _placingStockSoldier = true;
      _stockSoldierTargets = targets;
    });
  }

  void _placeStockSoldier(int index) {
    if (!_placingStockSoldier || !_stockSoldierTargets.contains(index)) return;
    final side = whiteTurn;
    if (_soldierStockFor(side) <= 0) return;
    setState(() {
      final asset = side ? 'assets/pieces/white_soldier.png' : 'assets/pieces/black_soldier.png';
      cells[index] = [Piece(asset, '兵', isWhite: side)];
      if (side) {
        _whiteSoldierStock--;
      } else {
        _blackSoldierStock--;
      }
      _placingStockSoldier = false;
      _stockSoldierTargets = <int>{};
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });
    _maybeFinishBattle();
  }

  List<Piece> _destroyedMajorsFor(bool isWhite) =>
      isWhite ? _whiteDestroyedMajors : _blackDestroyedMajors;

  Set<int> _revivalTargetsFor(bool isWhite) {
    final result = <int>{};
    for (var i = 0; i < 35; i++) {
      final row = i ~/ 5;
      final inOwnFourRows = isWhite ? row >= 3 : row <= 3;
      if (!inOwnFourRows) continue;
      final stack = cells[i];
      if (stack == null || stack.isEmpty) {
        result.add(i);
        continue;
      }
      if (stack.length < 2 && stack.last.isWhite == isWhite) {
        result.add(i);
      }
    }
    return result;
  }

  List<MapEntry<int, Piece>> _lv3Candidates(bool isWhite) {
    final result = <MapEntry<int, Piece>>[];
    for (final entry in cells.entries) {
      final stack = entry.value;
      if (stack.isEmpty) continue;
      for (final piece in stack) {
        if (piece.isWhite == isWhite && piece.major && piece.level < 3) {
          result.add(MapEntry(entry.key, piece));
        }
      }
    }
    return result;
  }

  bool _isLeaderAlive(bool isWhite) {
    for (final stack in cells.values) {
      for (final piece in stack) {
        if (piece.isWhite == isWhite && _isLeaderPiece(piece)) return true;
      }
    }
    return false;
  }

  bool _coreEffectKeepsBattleAlive(Piece core, {Piece? revivedPiece}) {
    var projectedLost = _lostCrownPoints(core.isWhite) + 1.5;
    if (revivedPiece != null &&
        _isLeaderPiece(revivedPiece) &&
        !_isLeaderAlive(core.isWhite)) {
      projectedLost -= 1.5;
    }
    return projectedLost < 3.0;
  }

  List<Piece> _validRevivalPiecesForCore(Piece core) {
    if (_revivalTargetsFor(core.isWhite).isEmpty) return const <Piece>[];
    return _destroyedMajorsFor(core.isWhite)
        .where((piece) => _coreEffectKeepsBattleAlive(core, revivedPiece: piece))
        .toList();
  }

  bool _canActivateCoreAt(int index) {
    if (_accelerationStep != 0 || _rapidFireStep != 0 || _pendingRevivalPiece != null) return false;
    final stack = cells[index];
    if (stack == null || stack.length != 1) return false;
    final core = stack.single;
    if (core.label != '核' || core.isWhite != whiteTurn) return false;
    final canRevive = _validRevivalPiecesForCore(core).isNotEmpty;
    final canLv3 = _coreEffectKeepsBattleAlive(core) && _lv3Candidates(core.isWhite).isNotEmpty;
    return canRevive || canLv3;
  }

  void _consumeCore(int index) {
    _beginCoreBurst(index);
    final stack = cells[index];
    if (stack == null || stack.length != 1 || stack.single.label != '核') return;
    cells.remove(index);
    lowerInfoCells.remove(index);
    selectedIndex = null;
  }

  void _startRevival(int coreIndex, Piece piece) {
    final targets = _revivalTargetsFor(piece.isWhite);
    if (targets.isEmpty) return;
    setState(() {
      _pendingRevivalCoreIndex = coreIndex;
      _consumeCore(coreIndex);
      _pendingRevivalPiece = piece;
      _pendingRevivalTargets = targets;
    });
  }

  Future<void> _placeRevivedPiece(int index) async {
    final piece = _pendingRevivalPiece;
    if (piece == null || !_pendingRevivalTargets.contains(index)) return;
    final revivedPiece =
        (piece.label == '騎弐式' || piece.label == '騎参式')
            ? _knightFormPiece(piece, '騎')
            : piece;
    final coreIndex = _pendingRevivalCoreIndex;
    final generation = ++_coreEffectGeneration;
    setState(() {
      _coreEffectIndex = index;
      _coreEffectPiece = revivedPiece;
      _coreEffectOldLevel = null;
      _coreEffectIsRevival = true;
      _coreLinkFrom = coreIndex;
      _coreLinkTo = index;
      _coreLinkGeneration++;
      selectedIndex = null;
    });

    // 光の輪と輪郭を先に見せ、途中から実体化する。
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      final stack = cells[index];
      if (stack == null || stack.isEmpty) {
        cells[index] = [revivedPiece];
      } else {
        // 既存仕様どおり、味方駒の上への復活＝合流をそのまま維持する。
        stack.add(revivedPiece);
        cells[index] = stack;
      }
      _destroyedMajorsFor(piece.isWhite).remove(piece);
      _pendingRevivalPiece = null;
      _pendingRevivalTargets = <int>{};
      _pendingRevivalCoreIndex = null;
    });
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      _coreEffectIndex = null;
      _coreEffectPiece = null;
      _coreEffectIsRevival = false;
      _coreLinkFrom = null;
      _coreLinkTo = null;
      whiteTurn = !whiteTurn;
    });
    _maybeFinishBattle();
  }

  Future<void> _applyInstantLv3(int coreIndex, int targetIndex, Piece targetPiece) async {
    final oldLevel = targetPiece.level;
    final generation = ++_coreEffectGeneration;
    setState(() {
      _consumeCore(coreIndex);
      _coreEffectIndex = targetIndex;
      _coreEffectPiece = targetPiece;
      _coreEffectOldLevel = oldLevel;
      _coreEffectIsRevival = false;
      _coreLinkFrom = coreIndex;
      _coreLinkTo = targetIndex;
      _coreLinkGeneration++;
    });

    // 核から対象へ光が走り、旧Lvが抜けてからLv3へ切り替える。
    await Future<void>.delayed(const Duration(milliseconds: 760));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      final stack = cells[targetIndex];
      if (stack != null) {
        final pos = stack.indexWhere((p) => identical(p, targetPiece));
        if (pos >= 0) stack[pos] = targetPiece.copyWith(level: 3);
        cells[targetIndex] = stack;
      }
    });
    await Future<void>.delayed(const Duration(milliseconds: 740));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      _coreEffectIndex = null;
      _coreEffectPiece = null;
      _coreEffectOldLevel = null;
      _coreLinkFrom = null;
      _coreLinkTo = null;
      whiteTurn = !whiteTurn;
    });
    _maybeFinishBattle();
  }

  void _showCoreActivationMenu(int index) {
    if (!_canActivateCoreAt(index)) return;
    final core = cells[index]!.single;
    final destroyed = _validRevivalPiecesForCore(core);
    final canRevive = destroyed.isNotEmpty;
    final lv3 = _coreEffectKeepsBattleAlive(core)
        ? _lv3Candidates(core.isWhite)
        : <MapEntry<int, Piece>>[];
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('核発動', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: canRevive ? () {
                    Navigator.of(sheetContext).pop();
                    _showRevivePieceMenu(index, destroyed);
                  } : null,
                  child: const Text('大駒を復活', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: lv3.isNotEmpty ? () {
                    Navigator.of(sheetContext).pop();
                    _showLv3TargetMenu(index, lv3);
                  } : null,
                  child: const Text('大駒を即Lv3', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRevivePieceMenu(int coreIndex, List<Piece> pieces) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('復活する大駒を選択', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final piece in pieces) ...[
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _startRevival(coreIndex, piece);
                    },
                    child: Text(
                      '${(piece.label == '騎弐式' || piece.label == '騎参式') ? '騎' : piece.label}  Lv${piece.level}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _showLv3TargetMenu(int coreIndex, List<MapEntry<int, Piece>> targets) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Lv3にする大駒を選択', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final entry in targets) ...[
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _applyInstantLv3(coreIndex, entry.key, entry.value);
                    },
                    child: Text('${entry.value.label}  Lv${entry.value.level} → Lv3', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Set<int> _legalRangedTargetsFor(
    int attackerIndex, {
    int? afterRemovingTopAt,
    Piece? attackerOverride,
  }) {
    final attacker = attackerOverride ?? _topPieceAt(attackerIndex);
    if (attacker == null || _isStrassePiece(attacker)) return const <int>{};
    final attackerMerged = _isMergedCell(attackerIndex);
    final inRange = _actionSquaresForPieceAt(attackerIndex, attacker, merged: attackerMerged);
    final result = <int>{};
    for (final target in inRange) {
      Piece? targetPiece;
      bool targetMerged = false;
      if (target == afterRemovingTopAt) {
        final stack = cells[target];
        if (stack != null && stack.length >= 2) {
          targetPiece = stack[stack.length - 2];
          targetMerged = false;
        }
      } else {
        targetPiece = _topPieceAt(target);
        targetMerged = _isMergedCell(target);
      }
      if (targetPiece == null || targetPiece.isWhite == attacker.isWhite) continue;
      // STRASSEは射撃を持たないので、相手がSTRASSEなら拮抗しない。
      if (!_isStrassePiece(targetPiece)) {
        final counterRange = _actionSquaresForPieceAt(target, targetPiece, merged: targetMerged);
        if (counterRange.contains(attackerIndex)) continue;
      }
      result.add(target);
    }
    return result;
  }

  Set<int> _rapidFireFirstTargetsFor(int attackerIndex) {
    final attacker = _topPieceAt(attackerIndex);
    if (attacker == null) return const <int>{};
    final current = _legalRangedTargetsFor(attackerIndex);
    final leveledAfterFirst = _pieceAfterKillLevelUp(attacker);
    return current.where((first) =>
      _legalRangedTargetsFor(
        attackerIndex,
        afterRemovingTopAt: first,
        attackerOverride: leveledAfterFirst,
      ).isNotEmpty
    ).toSet();
  }

  bool _canUseRapidFire(int attackerIndex) => _rapidFireFirstTargetsFor(attackerIndex).isNotEmpty;

  Future<void> _executeMelee(int attackerIndex, int targetIndex, {bool showDialogue = true, bool endTurn = true}) async {
    if (showDialogue) await _showPilotDialogueForIndex(attackerIndex, 'melee');
    if (!mounted) return;
    _playActionSfx('audio/se_melee.wav');
    _beginPieceMotion(attackerIndex, targetIndex);
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasMerged = _isMergedCell(targetIndex);
    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    final levelBefore = attackerStack.last.level;

    setState(() {
      // 攻撃側は現在いるマスから上の駒だけが格闘に出る。
      // 制圧中の上駒が破壊以外で離れるため、先に下の大駒を鹵獲する。
      final attackerWasSuppressing = _isSuppressedCell(attackerIndex);
      final departingAttacker = attackerStack.last;
      if (attackerWasSuppressing) {
        _captureSuppressedLowerPiece(attackerIndex, departingAttacker.isWhite);
      }
      var attacker = attackerStack.removeLast();
      attacker = _pieceAfterKillLevelUp(attacker);
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      }

      // 敵の上の駒を破壊。
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();

      if (targetWasSuppressed && targetStack.isNotEmpty) {
        // 制圧中の上側を格闘で破壊。下の駒は絶対に消さない。
        // 格闘した駒はそのマスへ移動するため、残った下の駒の上へ入る。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.remove(targetIndex);
      } else if (targetWasMerged && targetStack.isNotEmpty) {
        // 合流中の敵への格闘：上だけ破壊し、残った下を制圧。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.add(targetIndex);
      } else {
        // 通常格闘：敵を破壊し、その敵がいたマスへ移動。
        cells[targetIndex] = [attacker];
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
    });

    if (_maybeFinishBattle()) return;
    final movedAttacker = _topPieceAt(targetIndex);
    if (movedAttacker != null && movedAttacker.level > levelBefore) {
      await _showStatChange(targetIndex, 'Lv', movedAttacker.level, up: true);
    }
    if (!mounted) return;
    if (endTurn) setState(() => whiteTurn = !whiteTurn);

  }

  Future<void> _executeRanged(int attackerIndex, int targetIndex, {bool showDialogue = true}) async {
    final rangedAttacker = _topPieceAt(attackerIndex);
    if (rangedAttacker == null || _isStrassePiece(rangedAttacker)) return;
    if (showDialogue) await _showPilotDialogueForIndex(attackerIndex, 'ranged');
    if (!mounted) return;
    _playActionSfx('audio/se_ranged.wav');
    _beginShotAnimation(attackerIndex, targetIndex);
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    final levelBefore = attackerStack.last.level;

    setState(() {
      // 射撃は攻撃側がその場に残り、敵の上の駒だけを破壊する。
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();
      attackerStack[attackerStack.length - 1] =
          _pieceAfterKillLevelUp(attackerStack.last);

      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        // 合流中・制圧中とも、下の駒は残す。
        cells[targetIndex] = targetStack;
      }

      // 制圧中の上側が射撃で破壊された場合、下の駒は制圧解除。
      if (targetWasSuppressed) {
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
    });

    if (_maybeFinishBattle()) return;
    final rangedAttackerAfter = _topPieceAt(attackerIndex);
    if (rangedAttackerAfter != null && rangedAttackerAfter.level > levelBefore) {
      await _showStatChange(attackerIndex, 'Lv', rangedAttackerAfter.level, up: true);
    }
    if (!mounted) return;
    setState(() => whiteTurn = !whiteTurn);

  }

  bool _captureSuppressedLowerPiece(int index, bool captorIsWhite) {
    if (!_isSuppressedCell(index)) return false;
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    final lower = stack.first;

    // 兵は鹵獲されない。大駒だけを幻波で鹵獲する。
    if (!lower.major || lower.label == '兵') {
      suppressedCells.remove(index);
      return false;
    }

    // 同じユニット同士では鹵獲しない。
    // 制圧自体は成立するが、上の駒が離れた時は下の駒を元の所属のまま残す。
    if (widget.whiteUnit == widget.blackUnit) {
      suppressedCells.remove(index);
      return false;
    }

    // 現物の駒をひっくり返すのと同じ表現：
    // 機体はそのまま、鹵獲した側の白枠/黒枠の駒画像へ切り替える。
    final capturedAsset = captorIsWhite
        ? lower.asset.replaceFirst('pieces/black_', 'pieces/white_')
        : lower.asset.replaceFirst('pieces/white_', 'pieces/black_');

    stack[0] = lower.copyWith(
      asset: capturedAsset,
      isWhite: captorIsWhite,
      // 本来の持ち主が取り返した場合は鹵獲状態を解除する。
      captured: captorIsWhite != lower.originalIsWhite,
    );
    cells[index] = stack;
    suppressedCells.remove(index);
    return true;
  }

  Future<void> _executeSuppression(int attackerIndex, int targetIndex, {bool showDialogue = true}) async {
    if (showDialogue) await _showPilotDialogueForIndex(attackerIndex, 'suppress');
    if (!mounted) return;
    _playActionSfx('audio/se_suppression.wav');
    _beginPieceMotion(attackerIndex, targetIndex);
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;
    if (_isMergedCell(targetIndex) || _isSuppressedCell(targetIndex)) return;

    setState(() {
      // 制圧側は上の駒だけが対象マスへ移動する。
      // 制圧→別制圧も破壊以外で離れるため、元の下駒を先に鹵獲する。
      final attackerWasSuppressing = _isSuppressedCell(attackerIndex);
      final departingAttacker = attackerStack.last;
      if (attackerWasSuppressing) {
        _captureSuppressedLowerPiece(attackerIndex, departingAttacker.isWhite);
      }
      final attacker = attackerStack.removeLast();
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      }

      // 敵駒は破壊せず下に残し、その上へ攻撃側を重ねる。
      targetStack.add(attacker);
      cells[targetIndex] = targetStack;
      suppressedCells.add(targetIndex);

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

  }


  Future<void> _executeSuppressionDestroy(int index, {bool showDialogue = true}) async {
    if (showDialogue) await _showPilotDialogueForIndex(index, 'suppressDestroy');
    if (!mounted) return;
    _playActionSfx('audio/se_suppress_destroy.wav');
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    setState(() {
      // 制圧破壊：下にいる敵駒だけを破壊し、制圧側の上駒はその場に残る。
      _recordDestroyedPiece(stack.first);
      stack.removeAt(0);
      stack[stack.length - 1] = _pieceAfterKillLevelUp(stack.last);
      cells[index] = stack;
      suppressedCells.remove(index);

      lowerInfoCells.remove(index);
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    if (_maybeFinishBattle()) return;

  }

  void _showSuppressionDestroyMenu(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SUPPRESSION  ${bottomPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () async {
                      Navigator.of(sheetContext).pop();
                      await _executeSuppressionDestroy(index);
                    },
                    child: const Text(
                      '制圧破壊',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showActionMenu(int attackerIndex, int targetIndex) {
    final attacker = _topPieceAt(attackerIndex);
    final targetPiece = _topPieceAt(targetIndex);
    if (attacker == null) return;
    if (targetPiece == null) return;
    final contested = _isContested(attackerIndex, targetIndex);
    final targetMerged = _isMergedCell(targetIndex);
    final targetSuppressed = _isSuppressedCell(targetIndex);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        Widget actionButton(
          String label, {
          bool enabled = true,
          VoidCallback? onPressed,
        }) {
          return SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: enabled
                  ? (onPressed ??
                      () {
                        Navigator.of(sheetContext).pop();
                      })
                  : null,
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: enabled ? null : Colors.white38,
                ),
              ),
            ),
          );
        }

        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'TARGET  ${targetPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                actionButton(
                  '格闘',
                  onPressed: () {
                    Navigator.of(sheetContext).pop();
                    _executeMelee(attackerIndex, targetIndex);
                  },
                ),
                const SizedBox(height: 8),
                actionButton(
                  contested ? '拮抗' : '射撃',
                  enabled: !contested && !_isStrassePiece(attacker),
                  onPressed: (contested || _isStrassePiece(attacker))
                      ? null
                      : () {
                          Navigator.of(sheetContext).pop();
                          _executeRanged(attackerIndex, targetIndex);
                        },
                ),
                const SizedBox(height: 8),
                actionButton(
                  '制圧',
                  enabled: !targetMerged && !targetSuppressed,
                  onPressed: (targetMerged || targetSuppressed)
                      ? null
                      : () {
                          Navigator.of(sheetContext).pop();
                          _executeSuppression(attackerIndex, targetIndex);
                        },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Set<int> _moveTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      if (cells.containsKey(target)) continue;
      targets.add(target);
    }
    return targets;
  }

  Set<int> _mergeTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      final targetStack = cells[target];
      if (targetStack == null || targetStack.isEmpty) continue;
      final targetTop = targetStack.last;
      if (targetTop.isWhite != piece.isWhite) continue;
      if (targetStack.length >= 2) continue;
      targets.add(target);
    }
    return targets;
  }

  void _moveTopPiece({required int from, required int to, required bool merge}) {
    _playActionSfx(merge ? 'audio/se_merge.wav' : 'audio/se_move.wav');
    final sourceStack = cells[from];
    if (sourceStack == null || sourceStack.isEmpty) return;
    final wasSuppressed = _isSuppressedCell(from);
    final movingPiece = sourceStack.last;
    // 通常移動/加速で制圧マスから離れる時は、上を外す前に下の大駒を鹵獲する。
    // 先に removeLast() すると制圧判定が消えてしまい、鹵獲も赤点滅解除も失敗する。
    if (wasSuppressed) {
      _captureSuppressedLowerPiece(from, movingPiece.isWhite);
    }
    sourceStack.removeLast();
    if (sourceStack.isEmpty) {
      cells.remove(from);
    }

    lowerInfoCells.remove(from);
    lowerInfoCells.remove(to);

    if (merge) {
      final targetStack = cells[to] ?? <Piece>[];
      targetStack.add(movingPiece);
      cells[to] = targetStack;
    } else {
      cells[to] = [movingPiece];
    }
  }

  Piece _knightFormPiece(Piece current, String formLabel) {
    final side = current.isWhite ? 'white' : 'black';
    final asset = switch (formLabel) {
      '騎弐式' => 'assets/pieces/${side}_knight_2.png',
      '騎参式' => 'assets/pieces/${side}_knight_3.png',
      _ => 'assets/pieces/${side}_knight.png',
    };
    return Piece(
      asset,
      formLabel,
      major: true,
      isWhite: current.isWhite,
      originalIsWhite: current.originalIsWhite,
      captured: current.captured,
      level: current.level,
    );
  }

  Future<void> _executeKnightTransform(int index, String formLabel) async {
    if (_knightTransformBusy) return;
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return;
    final current = stack.last;
    if (!_isKnightForm(current) || current.isWhite != whiteTurn) return;

    await _showSkillDialogueForIndex(index, knightTarget: formLabel);
    if (!mounted) return;
    final target = _knightFormPiece(current, formLabel);
    final generation = ++_knightTransformGeneration;
    setState(() {
      _knightTransformBusy = true;
      _knightTransformIndex = index;
      _knightTransformTargetPiece = target;
      selectedIndex = null;
      lowerInfoCells.remove(index);
    });
    _playActionSfx('audio/se_transform.wav');

    Future<void>.delayed(_knightTransformDuration, () {
      if (!mounted || generation != _knightTransformGeneration) return;
      final liveStack = cells[index];
      if (liveStack == null || liveStack.isEmpty) return;
      setState(() {
        liveStack[liveStack.length - 1] = target;
        cells[index] = liveStack;
        _knightTransformBusy = false;
        _knightTransformIndex = null;
        _knightTransformTargetPiece = null;
        whiteTurn = !whiteTurn;
      });
    });
  }

  bool _canUseStrasseMeleeMove(int index) {
    final piece = _topPieceAt(index);
    return piece != null && _isStrassePiece(piece) && piece.isWhite == whiteTurn && _enemyTargetsFor(index).isNotEmpty;
  }

  bool _canUseStrasseMergedMove(int index) {
    final piece = _topPieceAt(index);
    return piece != null && _isStrassePiece(piece) && piece.isWhite == whiteTurn && _isMergedCell(index) && _moveTargetsFor(index).isNotEmpty;
  }

  void _startStrasseMeleeMove(int index) {
    if (!_canUseStrasseMeleeMove(index)) return;
    setState(() { selectedIndex = index; _strasseSkillStep = 1; });
  }

  void _startStrasseMergedMove(int index) {
    if (!_canUseStrasseMergedMove(index)) return;
    setState(() { selectedIndex = index; _strasseSkillStep = 3; });
  }

  void _moveMergedStrasseStack(int from, int to) {
    final stack = cells[from];
    if (stack == null || stack.length != 2 || cells.containsKey(to)) return;
    _playActionSfx('audio/se_move.wav');
    cells.remove(from);
    cells[to] = stack;
    suppressedCells.remove(from);
  }

  void _showStrasseSkillMenu(int index) {
    final canMeleeMove = _canUseStrasseMeleeMove(index);
    final canMergedMove = _canUseStrasseMergedMove(index);
    if (!canMeleeMove && !canMergedMove) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  逃げるが勝ち', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(width: double.infinity, child: OutlinedButton(
                onPressed: canMeleeMove ? () { Navigator.of(sheetContext).pop(); _startStrasseMeleeMove(index); } : null,
                child: Text('格闘+移動', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canMeleeMove ? null : Colors.white38)),
              )),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: OutlinedButton(
                onPressed: canMergedMove ? () { Navigator.of(sheetContext).pop(); _startStrasseMergedMove(index); } : null,
                child: Text('合流×移動', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canMergedMove ? null : Colors.white38)),
              )),
            ],
          ),
        ),
      ),
    );
  }

  void _showKnightSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isKnightForm(piece)) return;
    if (piece.isWhite != whiteTurn) return;

    final forms = <String>['騎', '騎弐式', '騎参式']
        .where((form) => form != piece.label)
        .toList();

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SKILL  変形',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                for (var n = 0; n < forms.length; n++) ...[
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.of(sheetContext).pop();
                        _executeKnightTransform(index, forms[n]);
                      },
                      child: Text(
                        '${forms[n]}へ変形',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  if (n != forms.length - 1) const SizedBox(height: 8),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _startKingRapidFire(int index) async {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '王' || piece.isWhite != whiteTurn) return;
    if (!_canUseRapidFire(index)) return;
    await _showSkillDialogueForIndex(index);
    if (!mounted) return;
    setState(() {
      selectedIndex = index;
      lowerInfoCells.remove(index);
      _rapidFireStep = 1;
    });
  }

  void _showKingSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '王' || piece.isWhite != whiteTurn) return;
    final canRapid = _canUseRapidFire(index);
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  王', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: canRapid ? () {
                    Navigator.of(sheetContext).pop();
                    _startKingRapidFire(index);
                  } : null,
                  child: Text('連射', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canRapid ? null : Colors.white38)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _executeRapidFireShot(int attackerIndex, int targetIndex) {
    _playActionSfx('audio/se_ranged.wav');
    _beginShotAnimation(attackerIndex, targetIndex);
    final targetStack = cells[targetIndex];
    if (targetStack == null || targetStack.isEmpty) return;
    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    setState(() {
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();
      final attackerStack = cells[attackerIndex];
      if (attackerStack != null && attackerStack.isNotEmpty) {
        attackerStack[attackerStack.length - 1] =
            _pieceAfterKillLevelUp(attackerStack.last);
        cells[attackerIndex] = attackerStack;
      }
      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        cells[targetIndex] = targetStack;
      }
      if (targetWasSuppressed) suppressedCells.remove(targetIndex);
      lowerInfoCells.clear();

      if (_rapidFireStep == 1) {
        selectedIndex = attackerIndex;
        _rapidFireStep = 2;
      } else {
        selectedIndex = null;
        _rapidFireStep = 0;
        whiteTurn = !whiteTurn;
      }
    });
    _maybeFinishBattle();
  }

  Future<void> _startEmperorAcceleration(int index) async {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '帝' || piece.isWhite != whiteTurn) return;
    if (_moveTargetsFor(index).isEmpty) return;
    await _showSkillDialogueForIndex(index);
    if (!mounted) return;
    setState(() {
      selectedIndex = index;
      lowerInfoCells.remove(index);
      _accelerationStep = 1;
    });
  }

  void _showEmperorSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '帝' || piece.isWhite != whiteTurn) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  帝', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: _moveTargetsFor(index).isEmpty ? null : () {
                    Navigator.of(sheetContext).pop();
                    _startEmperorAcceleration(index);
                  },
                  child: const Text('加速', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  double _cpuTargetValue(Piece piece) {
    final crown = _crownValueForPiece(piece) ?? 0;
    if (crown > 0) return 1000 + crown * 500;
    if (piece.major) return 180 + piece.level * 35;
    return piece.label == '兵' ? 45 : 25;
  }

  double _cpuAdvanceValue(int index, bool isWhite) {
    final row = index ~/ 5;
    return isWhite ? (6 - row).toDouble() : row.toDouble();
  }

  List<(int, int)> _shotThreatPairsForHumanTurn() {
    // 警告は自分のターンだけ。実際に一方的な射撃が成立する組だけを表示する。
    if (whiteTurn != widget.playerIsWhite) return const <(int, int)>[];
    final pairs = <(int, int)>[];
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == widget.playerIsWhite || enemy.label == '核') continue;
      // STRASSEには射撃がないので、射撃警告の攻撃側にはならない。
      if (_isStrassePiece(enemy)) continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      for (final targetIndex in enemyRange) {
        final mine = _topPieceAt(targetIndex);
        if (mine == null || mine.isWhite != widget.playerIsWhite) continue;
        // STRASSEは射撃を持たないため、射撃の拮抗には参加しない。
        if (!_isStrassePiece(mine) && _actionSquaresFor(targetIndex).contains(enemyIndex)) continue;
        pairs.add((enemyIndex, targetIndex));
      }
    }
    return pairs;
  }

  // CPUの最優先思想：
  // 1) 勝てる手は他の損得より常に上。
  // 2) 相手の行動範囲に入らず、こちらの行動範囲に相手を入れる。
  // 3) 既に一方的に範囲へ入れられている味方を、タダで取らせない。
  // 合流・前線・核・Lv・スキルは、それ自体ではなく上記を実現する手段として評価する。
  bool _cpuEnemyCanActOn(int index, bool cpuIsWhite, {int? ignoreEnemyAt}) {
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      if (enemyIndex == ignoreEnemyAt) continue;
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == cpuIsWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      if (_actionSquaresFor(enemyIndex).contains(index)) return true;
    }
    return false;
  }

  int _cpuOneSidedThreatCountAgainst(bool sideIsWhite) {
    var count = 0;
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == sideIsWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      for (final target in _actionSquaresFor(enemyIndex)) {
        final ally = _topPieceAt(target);
        if (ally == null || ally.isWhite != sideIsWhite) continue;
        // 相互範囲なら射撃は拮抗。一方的に入れられている駒だけを危険として数える。
        if (!_actionSquaresFor(target).contains(enemyIndex)) count++;
      }
    }
    return count;
  }

  double _cpuPositionScore(int from, int to, Piece piece, {required bool mergedAtTo}) {
    final myRange = _actionSquaresForPieceAt(to, piece, merged: mergedAtTo);
    var score = 0.0;
    var enemyCanHitMe = false;

    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      final iCanHit = myRange.contains(enemyIndex);
      final enemyCanHit = enemyRange.contains(to);

      if (iCanHit && !enemyCanHit) {
        // 理想形。一方的にこちらの行動範囲へ入れる。
        score += 520 + _cpuTargetValue(enemy) * 1.15;
      } else if (iCanHit && enemyCanHit) {
        // 拮抗は一方的な射撃より下。ただし相手の射撃を止める価値はある。
        score += 75;
      }
      if (enemyCanHit) enemyCanHitMe = true;
    }

    if (enemyCanHitMe) {
      // 相手の範囲へ自分から入る手は原則大幅減点。王冠持ちはさらに重い。
      final crown = _crownValueForPiece(piece) ?? 0;
      score -= crown > 0 ? 2600 : (420 + _cpuTargetValue(piece) * 1.35);
    } else {
      score += 160; // 「相手に入れられない」状態そのものを評価。
    }

    // 危険な味方を一方的射撃から救うため、脅威の敵へ射程を重ねる価値。
    // ただしこれは「一方的にこちらから入れる」より低い。
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite || enemy.label == '核') continue;
      if (!myRange.contains(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      var enemyHasFreeShot = false;
      for (final allyIndex in enemyRange) {
        if (allyIndex == from) continue;
        final ally = _topPieceAt(allyIndex);
        if (ally == null || ally.isWhite != piece.isWhite) continue;
        if (!_actionSquaresFor(allyIndex).contains(enemyIndex)) {
          enemyHasFreeShot = true;
          break;
        }
      }
      if (enemyHasFreeShot) score += 190;
    }
    return score;
  }

  bool _cpuCaptureWouldWin(Piece target, bool cpuIsWhite) {
    final crown = _crownValueForPiece(target) ?? 0;
    if (crown <= 0) return false;
    return _lostCrownPoints(!cpuIsWhite) + crown >= 3.0;
  }

  void _scheduleCpuTurnIfNeeded() {
    final cpuIsWhite = !widget.playerIsWhite;
    if (_pilotDialogueBusy || _knightTransformBusy || _statChangeBusy || _cpuTurnScheduled || whiteTurn != cpuIsWhite) return;
    if (_placingStockSoldier || _pendingRevivalPiece != null ||
        _rapidFireStep != 0 || _accelerationStep != 0 || _strasseSkillStep != 0) return;
    if (_lostCrownPoints(true) >= 3.0 || _lostCrownPoints(false) >= 3.0) return;

    _cpuTurnScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 280), () async {
        if (!mounted) return;
        if (whiteTurn != cpuIsWhite) {
          _cpuTurnScheduled = false;
          return;
        }
        await _runCpuTurn(cpuIsWhite);
        if (mounted) _cpuTurnScheduled = false;
      });
    });
  }

  Future<void> _runCpuTurn(bool cpuIsWhite) async {
    int? bestSuppressionDestroy;
    double bestSuppressionDestroyScore = -1e18;
    for (final index in suppressedCells) {
      final stack = cells[index];
      if (stack == null || stack.length < 2) continue;
      final top = stack.last;
      final bottom = stack.first;
      if (top.isWhite != cpuIsWhite || bottom.isWhite == cpuIsWhite) continue;
      final wins = _cpuCaptureWouldWin(bottom, cpuIsWhite);
      final score = (wins ? 1000000.0 : 650.0) + _cpuTargetValue(bottom);
      if (score > bestSuppressionDestroyScore) {
        bestSuppressionDestroyScore = score;
        bestSuppressionDestroy = index;
      }
    }

    String? bestKind;
    int? bestFrom;
    int? bestTo;
    Piece? bestRevivalPiece;
    Piece? bestLv3Piece;
    String? bestKnightForm;
    int? bestRapidSecond;
    double bestScore = -1e18;

    // 勝利条件は最優先。制圧破壊で勝てるなら即採用。
    if (bestSuppressionDestroy != null && bestSuppressionDestroyScore >= 1000000) {
      bestKind = 'suppressionDestroy';
      bestFrom = bestSuppressionDestroy;
      bestTo = bestSuppressionDestroy;
      bestScore = bestSuppressionDestroyScore;
    }

    // 核は「使えるから使う」を廃止。復活は盤面へ戦力を戻す価値だけ評価し、
    // 即Lv3は位置関係を改善する根拠がない限り低評価にする。
    for (var coreIndex = 0; coreIndex < 35; coreIndex++) {
      final stack = cells[coreIndex];
      if (stack == null || stack.length != 1) continue;
      final core = stack.single;
      if (core.label != '核' || core.isWhite != cpuIsWhite) continue;

      final revivalPieces = _validRevivalPiecesForCore(core);
      if (revivalPieces.isNotEmpty) {
        for (final piece in revivalPieces) {
          for (final to in _revivalTargetsFor(cpuIsWhite)) {
            final merged = cells[to]?.isNotEmpty == true;
            final positional = _cpuPositionScore(coreIndex, to, piece, mergedAtTo: merged);
            final score = 170 + _cpuTargetValue(piece) * .45 + positional;
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'coreRevive';
              bestFrom = coreIndex;
              bestTo = to;
              bestRevivalPiece = piece;
            }
          }
        }
      }

      if (_coreEffectKeepsBattleAlive(core)) {
        for (final target in _lv3Candidates(cpuIsWhite)) {
          // Lv3化そのものにはほぼ点を与えない。開幕即自壊を防ぐためではなく、
          // 「行動範囲の優位を作れる時だけ」選ばれるよう現在位置で比較する。
          final before = _cpuPositionScore(target.key, target.key, target.value, mergedAtTo: _isMergedCell(target.key));
          final lv3Piece = target.value.copyWith(level: 3);
          final after = _cpuPositionScore(target.key, target.key, lv3Piece, mergedAtTo: _isMergedCell(target.key));
          final score = (after - before) - 260; // 核という択を消費するコスト。
          if (score > bestScore) {
            bestScore = score;
            bestKind = 'coreLv3';
            bestFrom = coreIndex;
            bestTo = target.key;
            bestLv3Piece = target.value;
          }
        }
      }
    }

    // 兵投入も「置けるから」ではなく、置いた位置の行動範囲関係で評価。
    if (_soldierStockFor(cpuIsWhite) > 0) {
      final soldierAsset = cpuIsWhite ? 'assets/pieces/white_soldier.png' : 'assets/pieces/black_soldier.png';
      final soldier = Piece(soldierAsset, '兵', isWhite: cpuIsWhite);
      for (final to in _soldierDeploymentTargets(cpuIsWhite)) {
        final score = 25 + _cpuPositionScore(to, to, soldier, mergedAtTo: false);
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'soldier';
          bestFrom = null;
          bestTo = to;
        }
      }
    }

    for (var from = 0; from < 35; from++) {
      final piece = _topPieceAt(from);
      if (piece == null || piece.isWhite != cpuIsWhite || piece.label == '核') continue;
      if (_isSuppressedCell(from)) continue;

      // 王の連射は射撃するなら撃ち得。2発成立する時は通常射撃より優先候補にする。
      if (piece.label == '王' && _canUseRapidFire(from)) {
        for (final first in _rapidFireFirstTargetsFor(from)) {
          final firstTarget = _topPieceAt(first);
          if (firstTarget == null) continue;
          final leveled = _pieceAfterKillLevelUp(piece);
          final seconds = _legalRangedTargetsFor(from, afterRemovingTopAt: first, attackerOverride: leveled);
          for (final second in seconds) {
            Piece? secondTarget;
            final st = cells[second];
            if (second == first && st != null && st.length >= 2) {
              secondTarget = st[st.length - 2];
            } else {
              secondTarget = _topPieceAt(second);
            }
            if (secondTarget == null) continue;
            final crownGain = (_crownValueForPiece(firstTarget) ?? 0) + (_crownValueForPiece(secondTarget) ?? 0);
            final wins = _lostCrownPoints(!cpuIsWhite) + crownGain >= 3.0;
            final score = (wins ? 1000000.0 : 900.0) + _cpuTargetValue(firstTarget) + _cpuTargetValue(secondTarget);
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'rapidFire';
              bestFrom = from;
              bestTo = first;
              bestRapidSecond = second;
            }
          }
        }
      }

      // 敵への行動。勝てる手 > 一方的な射撃 > 必要な格闘/制圧。
      for (final to in _enemyTargetsFor(from)) {
        final target = _topPieceAt(to);
        if (target == null) continue;
        final value = _cpuTargetValue(target);
        final contested = _isContested(from, to);
        final wins = _cpuCaptureWouldWin(target, cpuIsWhite);

        if (!contested && !_isStrassePiece(piece)) {
          final rangedScore = (wins ? 1000000.0 : 760.0) + value;
          if (rangedScore > bestScore) {
            bestScore = rangedScore;
            bestKind = 'ranged'; bestFrom = from; bestTo = to;
          }
        }

        // 格闘後は攻撃側が敵マスへ入る。勝利手なら危険無視、それ以外は
        // 次ターン相手の行動範囲へ入るほど大きく減点する。
        final dangerAfterMelee = _cpuEnemyCanActOn(to, cpuIsWhite, ignoreEnemyAt: to);
        var meleeScore = (wins ? 1000000.0 : 250.0) + value;
        if (!wins && dangerAfterMelee) {
          final crown = _crownValueForPiece(piece) ?? 0;
          meleeScore -= crown > 0 ? 3200 : (500 + _cpuTargetValue(piece) * 1.4);
        }
        if (meleeScore > bestScore) {
          bestScore = meleeScore;
          bestKind = 'melee'; bestFrom = from; bestTo = to;
        }

        if (!_isMergedCell(to) && !_isSuppressedCell(to) && target.major) {
          // 制圧は即勝利ではないので、射撃より下。王冠への圧力は評価する。
          final suppressionScore = 120 + value * .45 + ((_crownValueForPiece(target) ?? 0) > 0 ? 260 : 0);
          if (suppressionScore > bestScore) {
            bestScore = suppressionScore;
            bestKind = 'suppress'; bestFrom = from; bestTo = to;
          }
        }
      }

      // 移動と合流は同じ「位置を作る手」として評価。合流自体にはボーナスを与えない。
      for (final to in _moveTargetsFor(from)) {
        final score = _cpuPositionScore(from, to, piece, mergedAtTo: false);
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'move'; bestFrom = from; bestTo = to;
        }
      }
      for (final to in _mergeTargetsFor(from)) {
        final score = _cpuPositionScore(from, to, piece, mergedAtTo: true);
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'merge'; bestFrom = from; bestTo = to;
        }
      }

      // 変形も「できるから」ではなく、今いる位置で行動範囲関係が改善する時だけ。
      if (_isKnightForm(piece)) {
        final nextForm = switch (piece.label) {
          '騎' => '騎弐式',
          '騎弐式' => '騎参式',
          _ => '騎',
        };
        final transformed = _knightFormPiece(piece, nextForm);
        final before = _cpuPositionScore(from, from, piece, mergedAtTo: _isMergedCell(from));
        final after = _cpuPositionScore(from, from, transformed, mergedAtTo: _isMergedCell(from));
        final score = after - before - 10;
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'knightTransform';
          bestFrom = from;
          bestTo = from;
          bestKnightForm = nextForm;
        }
      }
    }

    // 制圧破壊が勝利手でなくても、他にそれ以上の手が無ければ比較対象にする。
    if (bestSuppressionDestroy != null && bestSuppressionDestroyScore > bestScore) {
      bestScore = bestSuppressionDestroyScore;
      bestKind = 'suppressionDestroy';
      bestFrom = bestSuppressionDestroy;
      bestTo = bestSuppressionDestroy;
    }

    if (bestKind == null || bestTo == null) {
      _scheduleNoLegalActionFinishIfNeeded();
      return;
    }

    final actionName = switch (bestKind) {
      'soldier' => '兵を投入',
      'coreRevive' => '核発動・復活',
      'coreLv3' => '核発動・Lv3',
      'rapidFire' => '連射',
      'suppressionDestroy' => '制圧破壊',
      'melee' => '格闘',
      'ranged' => '射撃',
      'suppress' => '制圧',
      'merge' => '合流',
      'move' => '移動',
      'knightTransform' => '変形',
      _ => '行動',
    };
    _showActionEcho(bestFrom, bestTo, actionLabel: 'CPU：$actionName');

    // CPU通常行動の台詞はここで一度だけ出す。
    // 実行関数側ではCPU台詞を再発火させない。
    final cpuDialogueAction = switch (bestKind) {
      'suppressionDestroy' => 'suppressDestroy',
      'melee' => 'melee',
      'ranged' => 'ranged',
      'suppress' => 'suppress',
      'merge' => 'merge',
      'move' => 'move',
      _ => null,
    };
    if (cpuDialogueAction != null && bestFrom != null) {
      await _showCpuPilotDialogueForIndex(bestFrom!, cpuDialogueAction);
      if (!mounted) return;
    }

    switch (bestKind) {
      case 'suppressionDestroy':
        await _executeSuppressionDestroy(bestTo!, showDialogue: false);
        break;
      case 'soldier':
        setState(() {
          final asset = cpuIsWhite ? 'assets/pieces/white_soldier.png' : 'assets/pieces/black_soldier.png';
          cells[bestTo!] = [Piece(asset, '兵', isWhite: cpuIsWhite)];
          if (cpuIsWhite) { _whiteSoldierStock--; } else { _blackSoldierStock--; }
          selectedIndex = null;
          whiteTurn = !whiteTurn;
        });
        if (_maybeFinishBattle()) return;
        break;
      case 'coreRevive':
        final revived = bestRevivalPiece;
        if (bestFrom == null || revived == null) return;
        setState(() {
          _pendingRevivalCoreIndex = bestFrom;
          _consumeCore(bestFrom!);
          _pendingRevivalPiece = revived;
          _pendingRevivalTargets = <int>{bestTo!};
        });
        await _placeRevivedPiece(bestTo!);
        break;
      case 'coreLv3':
        final targetPiece = bestLv3Piece;
        if (bestFrom == null || targetPiece == null) return;
        await _applyInstantLv3(bestFrom!, bestTo!, targetPiece);
        break;
      case 'rapidFire':
        final second = bestRapidSecond;
        if (bestFrom == null || second == null) return;
        await _showSkillDialogueForIndex(bestFrom!);
        if (!mounted) return;
        setState(() { selectedIndex = bestFrom; _rapidFireStep = 1; });
        _executeRapidFireShot(bestFrom!, bestTo!);
        if (_maybeFinishBattle()) return;
        await Future<void>.delayed(const Duration(milliseconds: 500));
        if (!mounted) return;
        if (_legalRangedTargetsFor(bestFrom!).contains(second)) {
          _executeRapidFireShot(bestFrom!, second);
        } else {
          // 1発目のLvアップ等で予定した2発目が不成立なら、その時点の合法対象から撃つ。
          final legal = _legalRangedTargetsFor(bestFrom!);
          if (legal.isNotEmpty) {
            final fallback = legal.reduce((a, b) => _cpuTargetValue(_topPieceAt(a)!) >= _cpuTargetValue(_topPieceAt(b)!) ? a : b);
            _executeRapidFireShot(bestFrom!, fallback);
          } else {
            setState(() { _rapidFireStep = 0; selectedIndex = null; whiteTurn = !whiteTurn; });
          }
        }
        break;
      case 'melee': await _executeMelee(bestFrom!, bestTo, showDialogue: false); break;
      case 'ranged': await _executeRanged(bestFrom!, bestTo, showDialogue: false); break;
      case 'suppress': await _executeSuppression(bestFrom!, bestTo, showDialogue: false); break;
      case 'merge':
        final cpuMovingPiece = _topPieceAt(bestFrom!);
        final pumpBefore = cpuMovingPiece == null ? 0 : _pumpForPieceAt(bestFrom!, cpuMovingPiece, mergedOverride: _isMergedCell(bestFrom!));
        _beginPieceMotion(bestFrom!, bestTo!);
        setState(() { _moveTopPiece(from: bestFrom!, to: bestTo!, merge: true); selectedIndex = null; });
        if (_maybeFinishBattle()) return;
        final cpuMovedPiece = _topPieceAt(bestTo!);
        final pumpAfter = cpuMovedPiece == null ? 0 : _pumpForPieceAt(bestTo!, cpuMovedPiece, mergedOverride: _isMergedCell(bestTo!));
        if (pumpAfter != pumpBefore) {
          await _showStatChange(bestTo!, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
        }
        if (!mounted) return;
        setState(() => whiteTurn = !whiteTurn);
        break;
      case 'move':
        final cpuMovingPiece = _topPieceAt(bestFrom!);
        final pumpBefore = cpuMovingPiece == null ? 0 : _pumpForPieceAt(bestFrom!, cpuMovingPiece, mergedOverride: _isMergedCell(bestFrom!));
        _beginPieceMotion(bestFrom!, bestTo!);
        setState(() { _moveTopPiece(from: bestFrom!, to: bestTo!, merge: false); selectedIndex = null; });
        if (_maybeFinishBattle()) return;
        final cpuMovedPiece = _topPieceAt(bestTo!);
        final pumpAfter = cpuMovedPiece == null ? 0 : _pumpForPieceAt(bestTo!, cpuMovedPiece, mergedOverride: _isMergedCell(bestTo!));
        if (pumpAfter != pumpBefore) {
          await _showStatChange(bestTo!, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
        }
        if (!mounted) return;
        setState(() => whiteTurn = !whiteTurn);
        break;
      case 'knightTransform':
        final form = bestKnightForm;
        if (bestFrom == null || form == null) return;
        await _executeKnightTransform(bestFrom!, form);
        if (_maybeFinishBattle()) return;
        break;
    }
    if (mounted) {
      setState(() { selectedIndex = null; });
    }
  }

  void _showActionEcho(int? origin, int? target, {String? actionLabel}) {
    final generation = ++_actionEchoGeneration;
    final move = origin == null ? <int>{} : _moveTargetsFor(origin);
    final merge = origin == null ? <int>{} : _mergeTargetsFor(origin);
    final enemy = origin == null ? <int>{} : _enemyTargetsFor(origin);
    setState(() {
      _actionEchoOrigin = origin;
      _actionEchoTarget = target;
      _actionEchoMoveTargets = Set<int>.from(move);
      _actionEchoMergeTargets = Set<int>.from(merge);
      _actionEchoEnemyTargets = Set<int>.from(enemy);
      _cpuPreviewTarget = target;
      _cpuPreviewAction = actionLabel;
    });
    Future<void>.delayed(_actionEchoDuration, () {
      if (!mounted || generation != _actionEchoGeneration) return;
      setState(() {
        _actionEchoOrigin = null;
        _actionEchoTarget = null;
        _actionEchoMoveTargets.clear();
        _actionEchoMergeTargets.clear();
        _actionEchoEnemyTargets.clear();
        _cpuPreviewTarget = null;
        _cpuPreviewAction = null;
      });
    });
  }

  void _handleTap(int index) async {
    // CPU手番中は人間の入力を受け付けない。表示演出は入力をブロックしない。
    if (whiteTurn != widget.playerIsWhite || _pilotDialogueBusy || _statChangeBusy) return;

    if (_placingStockSoldier) {
      if (_stockSoldierTargets.contains(index)) _placeStockSoldier(index);
      return;
    }
    if (_pendingRevivalPiece != null) {
      if (_pendingRevivalTargets.contains(index)) _placeRevivedPiece(index);
      return;
    }

    // シュトラーセ「逃げるが勝ち」発動中。
    if (_strasseSkillStep == 1) {
      final from = selectedIndex;
      if (from == null || !_enemyTargetsFor(from).contains(index)) return;
      await _executeMelee(from, index, endTurn: false);
      if (!mounted || _maybeFinishBattle()) return;
      if (_moveTargetsFor(index).isEmpty) {
        setState(() { selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn; });
      } else {
        setState(() { selectedIndex = index; _strasseSkillStep = 2; });
      }
      return;
    }
    if (_strasseSkillStep == 2) {
      final from = selectedIndex;
      if (from == null || !_moveTargetsFor(from).contains(index)) return;
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn;
      });
      _maybeFinishBattle();
      return;
    }
    if (_strasseSkillStep == 3) {
      final from = selectedIndex;
      if (from == null || !_moveTargetsFor(from).contains(index)) return;
      _beginPieceMotion(from, index);
      setState(() {
        _moveMergedStrasseStack(from, index);
        selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn;
      });
      _maybeFinishBattle();
      return;
    }

    // 連射発動後は、合法な射撃対象以外の操作を受け付けない。
    if (_rapidFireStep != 0) {
      final attackerIndex = selectedIndex;
      if (attackerIndex == null) return;
      final legalTargets = _rapidFireStep == 1
          ? _rapidFireFirstTargetsFor(attackerIndex)
          : _legalRangedTargetsFor(attackerIndex);
      if (!legalTargets.contains(index)) return;
      _showActionEcho(selectedIndex, index);
      _executeRapidFireShot(attackerIndex, index);
      return;
    }

    // 加速発動後は帝の移動先以外の操作を受け付けない。
    if (_accelerationStep != 0) {
      final from = selectedIndex;
      if (from == null || !_moveTargetsFor(from).contains(index)) return;
      final wasFirstMove = _accelerationStep == 1;
      _showActionEcho(selectedIndex, index);
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        if (wasFirstMove && _moveTargetsFor(index).isNotEmpty) {
          selectedIndex = index;
          _accelerationStep = 2;
        } else {
          // 2回目が不可能なら通常移動と同じ結果でターン終了。
          selectedIndex = null;
          _accelerationStep = 0;
          whiteTurn = !whiteTurn;
        }
      });
      if (_maybeFinishBattle()) return;
      return;
    }
    final piece = _topPieceAt(index);
    final moveTargets = selectedIndex == null ? const <int>{} : _moveTargetsFor(selectedIndex!);
    final mergeTargets = selectedIndex == null ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final enemyTargets = selectedIndex == null ? const <int>{} : _enemyTargetsFor(selectedIndex!);
    final isCurrentSidePiece = piece != null &&
        piece.isWhite == whiteTurn;

    if (selectedIndex != null && enemyTargets.contains(index)) {
      _showActionEcho(selectedIndex, index);
      _showActionMenu(selectedIndex!, index);
      return;
    }

    if (selectedIndex != null && moveTargets.contains(index)) {
      final from = selectedIndex!;
      _showActionEcho(selectedIndex, index);
      await _showPilotDialogueForIndex(from, 'move');
      if (!mounted) return;
      final movingPiece = _topPieceAt(from);
      final pumpBefore = movingPiece == null ? 0 : _pumpForPieceAt(from, movingPiece, mergedOverride: _isMergedCell(from));
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        selectedIndex = null;
      });
      if (_maybeFinishBattle()) return;
      final movedPiece = _topPieceAt(index);
      final pumpAfter = movedPiece == null ? 0 : _pumpForPieceAt(index, movedPiece, mergedOverride: _isMergedCell(index));
      if (pumpAfter != pumpBefore) {
        await _showStatChange(index, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
      }
      if (!mounted) return;
      setState(() => whiteTurn = !whiteTurn);
      return;
    }

    if (selectedIndex != null && mergeTargets.contains(index)) {
      final from = selectedIndex!;
      _showActionEcho(selectedIndex, index);
      await _showPilotDialogueForIndex(from, 'merge');
      if (!mounted) return;
      final mergingPiece = _topPieceAt(from);
      final pumpBefore = mergingPiece == null ? 0 : _pumpForPieceAt(from, mergingPiece, mergedOverride: _isMergedCell(from));
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: true);
        selectedIndex = null;
      });
      if (_maybeFinishBattle()) return;
      final mergedPiece = _topPieceAt(index);
      final pumpAfter = mergedPiece == null ? 0 : _pumpForPieceAt(index, mergedPiece, mergedOverride: _isMergedCell(index));
      if (pumpAfter != pumpBefore) {
        await _showStatChange(index, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
      }
      if (!mounted) return;
      setState(() => whiteTurn = !whiteTurn);
      return;
    }

    setState(() {

      if (isCurrentSidePiece) {
        final stack = cells[index];
        final isStacked = stack != null && stack.length > 1;
        if (selectedIndex == index && isStacked) {
          // 重なり中の同じマスをもう一度タップすると、情報欄だけ上↔下を切り替える。
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
        selectedIndex = selectedIndex == index ? null : index;
        lowerInfoCells.remove(index);
        return;
      }

      // 未選択時なら、敵の重なりマスも情報だけ確認できる。
      if (selectedIndex == null && piece != null) {
        final stack = cells[index];
        if (stack != null && stack.length > 1) {
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
      }

      if (piece == null) {
        selectedIndex = null;
      }
    });
    // 制圧から離れた瞬間に下のリーダーを鹵獲する場合があるため、
    // 通常移動/合流の直後も必ず王冠勝敗を再判定する。
    _maybeFinishBattle();
  }

  @override
  Widget build(BuildContext context) {
    _scheduleNoLegalActionFinishIfNeeded();
    _scheduleCpuTurnIfNeeded();
    final liveMoveTargets = selectedIndex == null
        ? const <int>{}
        : (_strasseSkillStep == 1
            ? const <int>{}
            : (_rapidFireStep != 0 ? const <int>{} : _moveTargetsFor(selectedIndex!)));
    final moveTargets = <int>{...liveMoveTargets, ..._actionEchoMoveTargets};
    final liveMergeTargets = (_strasseSkillStep != 0 || _accelerationStep != 0 || _rapidFireStep != 0 || selectedIndex == null) ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final mergeTargets = <int>{...liveMergeTargets, ..._actionEchoMergeTargets};
    final liveEnemyTargets = _rapidFireStep != 0 && selectedIndex != null
        ? (_rapidFireStep == 1 ? _rapidFireFirstTargetsFor(selectedIndex!) : _legalRangedTargetsFor(selectedIndex!))
        : (_accelerationStep != 0 || selectedIndex == null || _strasseSkillStep == 2 || _strasseSkillStep == 3 ? const <int>{} : _enemyTargetsFor(selectedIndex!));
    final enemyTargets = <int>{...liveEnemyTargets, ..._actionEchoEnemyTargets};
    final selectedPiece = selectedIndex == null ? null : _topPieceAt(selectedIndex!);
    final canUseCore = selectedIndex != null && _canActivateCoreAt(selectedIndex!);
    final canShowKingSkill = _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null && selectedPiece.label == '王' && selectedPiece.isWhite == whiteTurn;
    final canUseKingSkill = canShowKingSkill && _canUseRapidFire(selectedIndex!);
    final canUseEmperorSkill = _accelerationStep == 0 && _rapidFireStep == 0 &&
        selectedIndex != null &&
        selectedPiece != null &&
        selectedPiece.label == '帝' &&
        selectedPiece.isWhite == whiteTurn;
    final canUseKnightSkill = _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null &&
        _isKnightForm(selectedPiece) &&
        selectedPiece.isWhite == whiteTurn;
    final canUseStrasseSkill = _strasseSkillStep == 0 && _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null && _isStrassePiece(selectedPiece) && selectedPiece.isWhite == whiteTurn &&
        (_canUseStrasseMeleeMove(selectedIndex!) || _canUseStrasseMergedMove(selectedIndex!));
    final whiteCapturedCrowns = _lostCrownPoints(false);
    final blackCapturedCrowns = _lostCrownPoints(true);

    return Scaffold(
      appBar: AppBar(title: const Text('鋼王騎帝 -ツァームド-')),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 6),
              child: SizedBox(
                height: 26,
                child: Center(
                  child: Text(
                _placingStockSoldier
                    ? '兵の投入位置を選択'
                    : (_pendingRevivalPiece != null
                    ? '復活位置を選択'
                    : (_rapidFireStep != 0
                        ? '連射  SHOT $_rapidFireStep / 2'
                        : (_accelerationStep == 0 ? (whiteTurn ? 'WHITE TURN' : 'BLACK TURN') : '加速  MOVE $_accelerationStep / 2'))),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.8,
                ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CrownScoreDisplay(label: 'WHITE', value: _crownValueText(whiteCapturedCrowns)),
                  const SizedBox(width: 8),
                  CrownScoreDisplay(label: 'BLACK', value: _crownValueText(blackCapturedCrowns)),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5,
              childAspectRatio: 1,
            ),
            itemCount: 35,
            itemBuilder: (_, visualIndex) {
              // YOU は常に画面下側。YOU が黒/金なら盤面表示だけ180度反転する。
              final i = widget.playerIsWhite ? visualIndex : 34 - visualIndex;
              final r = visualIndex ~/ 5, c = visualIndex % 5;
              final cellStack = cells[i];
              final piece = _topPieceAt(i);
              final basePiece = (cellStack != null && cellStack.length > 1) ? cellStack.first : null;
              final isSelected = selectedIndex == i || _actionEchoOrigin == i;
              final isCpuPreviewTarget = _cpuPreviewTarget == i;
              final isMoveTarget = moveTargets.contains(i);
              final isMergeTarget = mergeTargets.contains(i);
              final isEnemyTarget = enemyTargets.contains(i);
              final isMergedCell = _isMergedCell(i);
              final isSuppressedCell = _isSuppressedCell(i);
              final isStackedCell = cellStack != null && cellStack.length > 1;
              final showingLowerInfo = isStackedCell && lowerInfoCells.contains(i);
              final infoPiece = showingLowerInfo ? cellStack!.first : piece;
              final infoPump = infoPiece == null
                  ? 0
                  : _pumpForPieceAt(i, infoPiece, mergedOverride: isMergedCell);
              final showInfoPu = infoPiece != null &&
                  infoPiece.major &&
                  infoPiece.level < 3 &&
                  !_isFixedKnightForm(infoPiece);

              final isRevivalTarget = _pendingRevivalTargets.contains(i);
              final isStockSoldierTarget = _stockSoldierTargets.contains(i);

              Color borderColor;
              double borderWidth;
              List<BoxShadow>? glow;
              Color fillColor;

              if (isCpuPreviewTarget) {
                borderColor = Colors.amberAccent;
                borderWidth = 3.2;
                glow = const [
                  BoxShadow(color: Colors.amberAccent, blurRadius: 13, spreadRadius: 1.5),
                ];
                fillColor = Colors.amberAccent.withOpacity(.22);
              } else if (isRevivalTarget || isStockSoldierTarget) {
                borderColor = Colors.greenAccent;
                borderWidth = 3.0;
                glow = const [
                  BoxShadow(color: Colors.greenAccent, blurRadius: 10, spreadRadius: 1),
                ];
                fillColor = Colors.greenAccent.withOpacity(.20);
              } else if (isSelected) {
                borderColor = Colors.lightBlueAccent;
                borderWidth = 2.4;
                glow = const [
                  BoxShadow(
                    color: Colors.lightBlueAccent,
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ];
                fillColor = Colors.lightBlueAccent.withOpacity(.12);
              } else if (isMergeTarget) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.0;
                glow = const [
                  BoxShadow(
                    color: Colors.greenAccent,
                    blurRadius: 8,
                    spreadRadius: .6,
                  ),
                ];
                fillColor = Colors.greenAccent.withOpacity(.16);
              } else if (isMoveTarget) {
                borderColor = Colors.cyanAccent;
                borderWidth = 2.0;
                glow = const [
                  BoxShadow(
                    color: Colors.cyanAccent,
                    blurRadius: 7,
                    spreadRadius: .5,
                  ),
                ];
                fillColor = Colors.cyanAccent.withOpacity(.18);
              } else if (isEnemyTarget) {
                borderColor = Colors.redAccent;
                borderWidth = 2.2;
                glow = const [
                  BoxShadow(
                    color: Colors.redAccent,
                    blurRadius: 8,
                    spreadRadius: .6,
                  ),
                ];
                fillColor = Colors.redAccent.withOpacity(.16);
              } else if (isSuppressedCell) {
                borderColor = Colors.redAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.redAccent.withOpacity(.04);
              } else if (isMergedCell) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.greenAccent.withOpacity(.04);
              } else {
                borderColor = Colors.white38;
                borderWidth = .7;
                glow = null;
                fillColor = (r + c).isEven ? Colors.white10 : Colors.black12;
              }

              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _handleTap(i),
                onLongPress: () {
                  final top = _topPieceAt(i);
                  if (_accelerationStep == 0 && _rapidFireStep == 0 && top != null &&
                      top.isWhite == whiteTurn &&
                      _isSuppressedCell(i)) {
                    _showSuppressionDestroyMenu(i);
                  }
                },
                child: AnimatedBuilder(
                  animation: _mergeBlinkController,
                  builder: (context, child) {
                    final blink = 0.25 + (_mergeBlinkController.value * 0.75);
                    final showSuppressionBlink = isSuppressedCell && !isSelected && !isMergeTarget && !isEnemyTarget;
                    final showMergeBlink = isMergedCell && !isSelected && !isMergeTarget && !isEnemyTarget;
                    final blinkColor = showSuppressionBlink ? Colors.redAccent : Colors.greenAccent;
                    final showStateBlink = showSuppressionBlink || showMergeBlink;
                    final effectiveBorderColor = showStateBlink
                        ? blinkColor.withOpacity(blink)
                        : borderColor;
                    final effectiveBorderWidth = showStateBlink ? 2.2 : borderWidth;
                    final effectiveGlow = showStateBlink
                        ? [
                            BoxShadow(
                              color: blinkColor.withOpacity(blink * 0.85),
                              blurRadius: 4 + (7 * _mergeBlinkController.value),
                              spreadRadius: .2 + (.8 * _mergeBlinkController.value),
                            ),
                          ]
                        : glow;

                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 90),
                      decoration: BoxDecoration(
                        border: Border.all(color: effectiveBorderColor, width: effectiveBorderWidth),
                        boxShadow: effectiveGlow,
                        color: fillColor,
                      ),
                  child: piece == null
                      ? null
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            if (basePiece != null)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(8, 6, 10, 22),
                                child: Opacity(
                                  opacity: 0.55,
                                  child: Transform.translate(
                                    offset: const Offset(-6, -4),
                                    child: Transform.rotate(
                                      angle: basePiece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                      child: basePiece.asset.isEmpty
                                          ? Center(child: Text(basePiece.label, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)))
                                          : Image.asset(basePiece.asset, fit: BoxFit.contain),
                                    ),
                                  ),
                                ),
                              ),
                            LayoutBuilder(
                              builder: (context, pieceConstraints) {
                                final movingHere = _motionTarget == i && _motionOrigin != null;
                                final origin = _motionOrigin;
                                if (!movingHere || origin == null) {
                                  return Padding(
                                    padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                    child: Transform.rotate(
                                      angle: piece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                      child: piece.asset.isEmpty
                                          ? Center(child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))
                                          : Image.asset(piece.asset, fit: BoxFit.contain),
                                    ),
                                  );
                                }
                                final originVisual = widget.playerIsWhite ? origin : 34 - origin;
                                final targetVisual = widget.playerIsWhite ? i : 34 - i;
                                final fromRow = originVisual ~/ 5;
                                final fromCol = originVisual % 5;
                                final toRow = targetVisual ~/ 5;
                                final toCol = targetVisual % 5;
                                final dx = (fromCol - toCol) * pieceConstraints.maxWidth;
                                final dy = (fromRow - toRow) * pieceConstraints.maxHeight;
                                return TweenAnimationBuilder<double>(
                                  key: ValueKey('piece-motion-$_motionGeneration-$i'),
                                  tween: Tween<double>(begin: 0, end: 1),
                                  duration: _pieceMotionDuration,
                                  curve: Curves.easeInOutCubic,
                                  builder: (context, t, child) {
                                    final lift = -10.0 * math.sin(math.pi * t);
                                    final scale = 1.0 + (0.08 * math.sin(math.pi * t));
                                    return Transform.translate(
                                      offset: Offset(dx * (1 - t), dy * (1 - t) + lift),
                                      child: Transform.scale(scale: scale, child: child),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                    child: Transform.rotate(
                                      angle: piece.isWhite == widget.playerIsWhite ? 0 : 3.141592653589793,
                                      child: piece.asset.isEmpty
                                          ? Center(child: Text(piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))
                                          : Image.asset(piece.asset, fit: BoxFit.contain),
                                    ),
                                  ),
                                );
                              },
                            ),
                            if (_knightTransformIndex == i && _knightTransformTargetPiece != null)
                              TweenAnimationBuilder<double>(
                                key: ValueKey('knight-transform-$_knightTransformGeneration-$i'),
                                tween: Tween<double>(begin: 0, end: 1),
                                duration: _knightTransformDuration,
                                curve: Curves.easeInCubic,
                                builder: (context, t, child) {
                                  // 真上視点なので、巨大な像が急速に本来サイズへ縮むことで
                                  // 「上空から盤面へ降下」してくる奥行きを作る。
                                  final scale = 2.75 - (1.75 * t);
                                  final flash = math.exp(-math.pow((t - .92) / .075, 2));
                                  return Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Transform.scale(
                                        scale: scale,
                                        child: Opacity(
                                          opacity: (0.58 + .42 * t).clamp(0.0, 1.0),
                                          child: child,
                                        ),
                                      ),
                                      if (flash > .02)
                                        IgnorePointer(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white.withOpacity((flash * .62).clamp(0.0, .62)),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.white.withOpacity((flash * .85).clamp(0.0, .85)),
                                                  blurRadius: 18 * flash,
                                                  spreadRadius: 5 * flash,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                    ],
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                  child: Transform.rotate(
                                    angle: _knightTransformTargetPiece!.isWhite == widget.playerIsWhite
                                        ? 0
                                        : 3.141592653589793,
                                    child: _knightTransformTargetPiece!.asset.isEmpty
                                        ? Center(
                                            child: Text(
                                              _knightTransformTargetPiece!.label,
                                              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                                            ),
                                          )
                                        : Image.asset(_knightTransformTargetPiece!.asset, fit: BoxFit.contain),
                                  ),
                                ),
                              ),
                            if (isMergedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.greenAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.greenAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '合流',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            if (isSuppressedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.redAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.redAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '制圧',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
                                color: Colors.black54,
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      if (infoPiece != null && _crownValueForPiece(infoPiece) != null) ...[
                                        if (_crownAssetForPiece(infoPiece) != null)
                                          SizedBox(
                                            width: 20,
                                            height: 15,
                                            child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Image.asset(
                                                  _crownAssetForPiece(infoPiece)!,
                                                  width: 20,
                                                  height: 15,
                                                  fit: BoxFit.contain,
                                                ),
                                                Positioned(
                                                  left: 5.2,
                                                  right: 5.2,
                                                  bottom: 1.7,
                                                  child: Container(
                                                    height: 5.6,
                                                    alignment: Alignment.center,
                                                    decoration: BoxDecoration(
                                                      color: const Color(0xFF111318).withOpacity(.96),
                                                      borderRadius: BorderRadius.circular(1.2),
                                                    ),
                                                    child: Text(
                                                      _crownValueText(_crownValueForPiece(infoPiece)!),
                                                      maxLines: 1,
                                                      textAlign: TextAlign.center,
                                                      style: const TextStyle(color: Colors.white, fontSize: 6.2, fontWeight: FontWeight.w900, height: .82, letterSpacing: -.35),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          )
                                        else
                                          SizedBox(
                                            width: 18,
                                            height: 15,
                                            child: FittedBox(
                                              child: CrownBadge(
                                                color: _crownColorForPiece(infoPiece),
                                                value: _crownValueText(_crownValueForPiece(infoPiece)!),
                                                darkCrown: _unitForPiece(infoPiece) == BattleUnit.strasse,
                                              ),
                                            ),
                                          ),
                                        const SizedBox(width: 2),
                                      ],
                                      if (infoPiece != null)
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              '${isStackedCell ? (showingLowerInfo ? '下：' : '上：') : ''}${infoPiece.label}${infoPiece.major ? '  ' : ''}',
                                              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, height: 1.0),
                                            ),
                                            if (infoPiece.major)
                                              _DeltaStatText(
                                                prefix: 'Lv',
                                                value: infoPiece.level,
                                                strong: true,
                                                color: infoPiece.level >= 3 ? Colors.redAccent : (infoPiece.level == 2 ? Colors.lightBlueAccent : Colors.white),
                                              ),
                                            if (showInfoPu) const Text('/', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, height: 1.0)),
                                            if (showInfoPu)
                                              _DeltaStatText(
                                                prefix: 'Pu',
                                                value: infoPump,
                                                strong: false,
                                                color: infoPump >= 2 ? Colors.redAccent : (infoPump == 1 ? Colors.lightBlueAccent : Colors.white),
                                              ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            if (_coreEffectIndex == i && _coreEffectPiece != null)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: TweenAnimationBuilder<double>(
                                    key: ValueKey('core-effect-$_coreEffectGeneration-$i'),
                                    tween: Tween<double>(begin: 0, end: 1),
                                    duration: _coreEffectIsRevival ? _coreRevivalEffectDuration : _coreLv3EffectDuration,
                                    curve: Curves.easeInOut,
                                    builder: (context, t, _) {
                                      if (_coreEffectIsRevival) {
                                        final materialize = ((t - .18) / .48).clamp(0.0, 1.0);
                                        final fadeOut = t < .78 ? 1.0 : ((1.0 - t) / .22).clamp(0.0, 1.0);
                                        final pulse = .5 + .5 * math.sin(t * math.pi * 8).abs();
                                        return Stack(
                                          fit: StackFit.expand,
                                          children: [
                                            Center(
                                              child: Container(
                                                width: 54 + 16 * t,
                                                height: 18 + 8 * t,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(50),
                                                  border: Border.all(color: Colors.lightBlueAccent.withOpacity(.9 * fadeOut), width: 2),
                                                  boxShadow: [BoxShadow(color: Colors.lightBlueAccent.withOpacity(.65 * fadeOut), blurRadius: 14 + 10 * pulse, spreadRadius: 2)],
                                                ),
                                              ),
                                            ),
                                            Transform.scale(
                                              scale: .82 + .18 * materialize,
                                              child: Opacity(
                                                opacity: (materialize * fadeOut).clamp(0.0, 1.0),
                                                child: Padding(
                                                  padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                                  child: Transform.rotate(
                                                    angle: _coreEffectPiece!.isWhite == widget.playerIsWhite ? 0 : math.pi,
                                                    child: Image.asset(_coreEffectPiece!.asset, fit: BoxFit.contain),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            if (t > .72)
                                              Container(color: Colors.white.withOpacity((.34 * (1.0 - ((t - .72) / .28).clamp(0.0, 1.0))).clamp(0.0, .34))),
                                          ],
                                        );
                                      }
                                      final pulse = math.sin(t * math.pi * 6).abs();
                                      final lift = t < .52 ? -34.0 * (t / .52) : -34.0;
                                      final oldOpacity = t < .52 ? 1.0 - (t / .52) : 0.0;
                                      final newT = ((t - .48) / .34).clamp(0.0, 1.0);
                                      final newY = -34.0 * (1.0 - newT);
                                      final glowFade = t < .84 ? 1.0 : ((1.0 - t) / .16).clamp(0.0, 1.0);
                                      return Stack(
                                        fit: StackFit.expand,
                                        children: [
                                          Transform.scale(
                                            scale: 1.0 + .10 * math.sin(math.pi * t),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.white.withOpacity((.10 + .13 * pulse) * glowFade),
                                                boxShadow: [BoxShadow(color: Colors.lightBlueAccent.withOpacity(.75 * glowFade), blurRadius: 22 + 10 * pulse, spreadRadius: 4)],
                                              ),
                                            ),
                                          ),
                                          if (_coreEffectOldLevel != null && oldOpacity > 0)
                                            Transform.translate(
                                              offset: Offset(0, lift),
                                              child: Opacity(
                                                opacity: oldOpacity.clamp(0.0, 1.0),
                                                child: Center(child: Text('Lv$_coreEffectOldLevel', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.lightBlueAccent, blurRadius: 14), Shadow(color: Colors.black, blurRadius: 4)]))),
                                              ),
                                            ),
                                          if (newT > 0)
                                            Transform.translate(
                                              offset: Offset(0, newY),
                                              child: Transform.scale(
                                                scale: 1.45 - .45 * newT,
                                                child: Opacity(
                                                  opacity: newT,
                                                  child: const Center(child: Text('Lv3', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.lightBlueAccent, blurRadius: 16), Shadow(color: Colors.black, blurRadius: 5)]))),
                                                ),
                                              ),
                                            ),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                              ),
                            if (_statChangeBusy && _statChangeIndex == i && _statChangeValue != null)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: TweenAnimationBuilder<double>(
                                    key: ValueKey('stat-${_statChangeGeneration}-$i'),
                                    tween: Tween<double>(begin: 0, end: 1),
                                    duration: _statChangeDuration,
                                    curve: Curves.easeOutCubic,
                                    builder: (context, t, _) {
                                      final y = _statChangeUp ? (-38.0 * t) : (-38.0 * (1.0 - t));
                                      final opacity = _statChangeUp ? (t < .80 ? 1.0 : ((1.0 - t) / .20).clamp(0.0, 1.0)) : 1.0;
                                      final scale = _statChangeUp ? 1.0 : (1.75 - .75 * t);
                                      return Transform.translate(
                                        offset: Offset(0, y),
                                        child: Transform.scale(
                                          scale: scale,
                                          child: Opacity(
                                            opacity: opacity,
                                            child: Center(
                                              child: Text(
                                                '${_statChangePrefix}${_statChangeValue}',
                                                style: const TextStyle(
                                                  color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900,
                                                  shadows: [Shadow(color: Colors.black, blurRadius: 5, offset: Offset(0, 2)), Shadow(color: Colors.lightBlueAccent, blurRadius: 12)],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                          ],
                        ),
                    );
                  },
                ),
              );
                    },
                  ),
                      if (_coreLinkFrom != null && _coreLinkTo != null)
                        IgnorePointer(
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('core-link-$_coreLinkGeneration'),
                            tween: Tween<double>(begin: 0, end: 1),
                            duration: const Duration(milliseconds: 520),
                            builder: (context, t, _) => CustomPaint(
                              painter: _CoreLinkPainter(
                                fromIndex: _coreLinkFrom!,
                                toIndex: _coreLinkTo!,
                                progress: t,
                                playerIsWhite: widget.playerIsWhite,
                              ),
                            ),
                          ),
                        ),
                      if (_coreBurstIndex != null)
                        IgnorePointer(
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('core-burst-$_coreBurstGeneration'),
                            tween: Tween<double>(begin: 0, end: 1),
                            duration: _coreBurstDuration,
                            builder: (context, t, _) => CustomPaint(
                              painter: _CoreBurstPainter(
                                index: _coreBurstIndex!,
                                progress: t,
                                playerIsWhite: widget.playerIsWhite,
                              ),
                            ),
                          ),
                        ),
                      if (whiteTurn == widget.playerIsWhite)
                        IgnorePointer(
                          child: AnimatedBuilder(
                            animation: _shotThreatController,
                            builder: (context, _) {
                              final pairs = _shotThreatPairsForHumanTurn();
                              if (pairs.isEmpty) return const SizedBox.shrink();
                              return CustomPaint(
                                painter: _ShotThreatArcPainter(
                                  pairs: pairs,
                                  progress: _shotThreatController.value,
                                  playerIsWhite: widget.playerIsWhite,
                                ),
                              );
                            },
                          ),
                        ),
                      if (_shotOrigin != null && _shotTarget != null)
                        IgnorePointer(
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('shot-$_shotGeneration'),
                            tween: Tween<double>(begin: 0, end: 1),
                            duration: _shotAnimationDuration,
                            curve: Curves.easeOutCubic,
                            builder: (context, t, _) => CustomPaint(
                              painter: _ShotBeamPainter(
                                originIndex: _shotOrigin!,
                                targetIndex: _shotTarget!,
                                progress: t,
                                playerIsWhite: widget.playerIsWhite,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            // 盤面位置を完全固定するため、下部操作欄は常に同じ高さを確保する。
            // SKILL/核/兵投入の表示が消えても、この領域自体は縮めない。
            SizedBox(
              height: 112,
              child: Column(
                children: [
                  SizedBox(
                    height: 52,
                    child: ((whiteTurn ? _whiteBattleUnit : _blackBattleUnit) != BattleUnit.strasse &&
                            !_placingStockSoldier &&
                            _pendingRevivalPiece == null &&
                            _rapidFireStep == 0 &&
                            _accelerationStep == 0)
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(12, 6, 12, 2),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    '兵ストック  ×${_soldierStockFor(whiteTurn)}',
                                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                                  ),
                                ),
                                FilledButton.tonal(
                                  onPressed: _soldierStockFor(whiteTurn) > 0 &&
                                          _soldierDeploymentTargets(whiteTurn).isNotEmpty
                                      ? _startStockSoldierDeployment
                                      : null,
                                  child: const Text('兵を投入', style: TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ],
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                  SizedBox(
                    height: 60,
                    child: canUseCore
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                            child: SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonal(
                                onPressed: () => _showCoreActivationMenu(selectedIndex!),
                                child: const Text(
                                  '核発動',
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.6),
                                ),
                              ),
                            ),
                          )
                        : (canUseKnightSkill || canUseEmperorSkill || canShowKingSkill || canUseStrasseSkill)
                            ? Padding(
                                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                                child: SizedBox(
                                  width: double.infinity,
                                  child: FilledButton.tonal(
                                    onPressed: canShowKingSkill
                                        ? (canUseKingSkill ? () => _showKingSkillMenu(selectedIndex!) : null)
                                        : () => canUseStrasseSkill
                                            ? _showStrasseSkillMenu(selectedIndex!)
                                            : canUseKnightSkill
                                                ? _showKnightSkillMenu(selectedIndex!)
                                                : _showEmperorSkillMenu(selectedIndex!),
                                    child: Text(
                                      'SKILL',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 1.6,
                                        color: canShowKingSkill && !canUseKingSkill ? Colors.white38 : null,
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ],
            ),
            if (_cpuPreviewAction != null)
              Positioned(
                top: 54,
                left: 0,
                right: 0,
                child: IgnorePointer(
                  child: Center(
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 160),
                      opacity: _cpuPreviewAction == null ? 0 : 1,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.78),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white24),
                        ),
                        child: Text(
                          _cpuPreviewAction!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .6,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            if (_cpuPilotDialogueText != null && _cpuPilotDialogueAsset != null)
              Positioned(
                left: 10, right: 10, bottom: 14,
                child: IgnorePointer(
                  child: _StablePilotTypewriter(
                    key: ValueKey('cpu-pilot-dialogue-$_cpuPilotDialogueGeneration'),
                    text: _cpuPilotDialogueText!,
                    duration: _pilotTypingDuration,
                    completed: !_cpuPilotDialogueTyping,
                    childBuilder: (context, shown) {
                      return Container(
                        height: 112,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.88),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white24),
                          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
                        ),
                        child: Row(children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.horizontal(left: Radius.circular(7)),
                            child: SizedBox(width: 104, height: 112, child: Image.asset(_cpuPilotDialogueAsset!, fit: BoxFit.cover)),
                          ),
                          Expanded(child: Padding(
                            padding: const EdgeInsets.fromLTRB(13, 10, 12, 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(_cpuPilotDialogueName ?? '', style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .7)),
                                const SizedBox(height: 5),
                                Text(shown, maxLines: 2, overflow: TextOverflow.clip, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, height: 1.2)),
                              ],
                            ),
                          )),
                        ]),
                      );
                    },
                  ),
                ),
              ),
            // CPU専用台詞が生きている間は旧共通台詞を絶対に描画しない。
            if (_cpuPilotDialogueText == null &&
                _pilotDialogueText != null && _pilotDialogueAsset != null)
              Positioned(
                left: 10,
                right: 10,
                bottom: 14,
                child: IgnorePointer(
                  child: _StablePilotTypewriter(
                    key: ValueKey('pilot-dialogue-$_pilotDialogueGeneration'),
                    text: _pilotDialogueText!,
                    duration: _pilotTypingDuration,
                    completed: !_pilotDialogueTyping,
                    childBuilder: (context, shown) {
                      return Container(
                        height: 112,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.88),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white24),
                          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.horizontal(left: Radius.circular(7)),
                              child: SizedBox(
                                width: 104,
                                height: 112,
                                child: Image.asset(_pilotDialogueAsset!, fit: BoxFit.cover),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(13, 10, 12, 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      _pilotDialogueName ?? '',
                                      style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .7),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      shown,
                                      maxLines: 2,
                                      overflow: TextOverflow.clip,
                                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, height: 1.2),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class _DeltaStatText extends StatelessWidget {
  const _DeltaStatText({
    required this.prefix,
    required this.value,
    required this.strong,
    required this.color,
  });

  final String prefix;
  final int value;
  final bool strong;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Text(
      '$prefix$value',
      style: TextStyle(
        color: color,
        fontSize: 10,
        fontWeight: value >= 1 ? FontWeight.w900 : FontWeight.w700,
        height: 1.0,
      ),
    );
  }
}
