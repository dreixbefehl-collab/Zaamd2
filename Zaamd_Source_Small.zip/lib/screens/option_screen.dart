import 'package:flutter/material.dart';
class OptionScreen extends StatefulWidget { const OptionScreen({super.key}); @override State<OptionScreen> createState()=>_OptionScreenState(); }
class _OptionScreenState extends State<OptionScreen> {
  double bgm=.75,se=.8; bool vibration=true,speech=true;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('OPTION')),body:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('BGM VOLUME'),Slider(value:bgm,onChanged:(v)=>setState(()=>bgm=v)),
    const Text('SE VOLUME'),Slider(value:se,onChanged:(v)=>setState(()=>se=v)),
    SwitchListTile(title:const Text('VIBRATION'),value:vibration,onChanged:(v)=>setState(()=>vibration=v)),
    SwitchListTile(title:const Text('SPEECH TEXT'),value:speech,onChanged:(v)=>setState(()=>speech=v)),
  ]));
}
