import 'package:flutter/material.dart';
import 'main_menu_screen.dart';

/// Legacy entry kept for compatibility with older prototype references.
/// New builds start at TitleScreen and then enter MainMenuScreen.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => const MainMenuScreen();
}
