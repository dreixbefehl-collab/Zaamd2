import 'dart:math' as math;
import 'dart:async';
import 'dart:ui' as ui;
import 'dart:io';
import 'dart:convert';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:archive/archive.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';



enum CpuDifficulty { easy, normal, hard }

extension CpuDifficultyInfo on CpuDifficulty {
  String get label => switch (this) {
        CpuDifficulty.easy => 'EASY',
        CpuDifficulty.normal => 'NORMAL',
        CpuDifficulty.hard => 'HARD',
      };
  String get jp => switch (this) {
        CpuDifficulty.easy => '現在のCPU',
        CpuDifficulty.normal => '標準',
        CpuDifficulty.hard => '上級',
      };
}

// UI sounds are independent of BGM and never request Android audio focus.
class _AudioSettings {
  static double bgm = 1.0, se = 1.0;
  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    bgm = (p.getDouble('option_bgm_v1') ?? 1.0).clamp(0.0, 1.0).toDouble();
    se = (p.getDouble('option_se_v1') ?? 1.0).clamp(0.0, 1.0).toDouble();
  }
  static Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('option_bgm_v1', bgm);
    await p.setDouble('option_se_v1', se);
  }
}

class _UiSounds {
  _UiSounds._();
  static final AudioPlayer _tap = AudioPlayer();
  static final AudioPlayer _confirm = AudioPlayer();
  static final AudioPlayer _back = AudioPlayer();
  static Future<void>? _setup;

  static Future<void> _configure() async {
    final context = AudioContext(
      android: const AudioContextAndroid(
        contentType: AndroidContentType.sonification,
        usageType: AndroidUsageType.game,
        audioFocus: AndroidAudioFocus.none,
      ),
      iOS: AudioContextIOS(
        category: AVAudioSessionCategory.ambient,
        options: const {AVAudioSessionOptions.mixWithOthers},
      ),
    );
    await Future.wait([_tap, _confirm, _back].map((p) async {
      await p.setAudioContext(context);
      await p.setReleaseMode(ReleaseMode.stop);
    }));
  }

  static Future<void> _play(AudioPlayer player, String name) async {
    try {
      await (_setup ??= _configure());
      await player.stop();
      await player.play(AssetSource('audio/$name'), volume: _AudioSettings.se);
    } catch (_) { /* UI actions must never depend on sound playback. */ }
  }
  static void tap() { unawaited(_play(_tap, 'Zaamd_UI_Tap.mp3')); }
  static void confirm() { unawaited(_play(_confirm, 'Zaamd_UI_Confirm.mp3')); }
  static void back() { unawaited(_play(_back, 'Zaamd_UI_Tap.mp3')); }
}

VoidCallback _withUiTap(VoidCallback action) => () { _UiSounds.tap(); action(); };

class _CpuDifficultyState { static CpuDifficulty current = CpuDifficulty.easy; }

class _RearLineProgress {
  static const _onlineBattlesKey = 'rear_line_online_battles_completed';
  static const _lastOnlineBattleIdKey = 'rear_line_last_online_battle_id';
  static Future<int> onlineBattlesCompleted() async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(_onlineBattlesKey) ?? 0;
  }
  static Future<bool> recordOnlineBattleCompletedOnce(String battleId) async {
    final p = await SharedPreferences.getInstance();
    if (p.getString(_lastOnlineBattleIdKey) == battleId) return false;
    final current = p.getInt(_onlineBattlesKey) ?? 0;
    await p.setString(_lastOnlineBattleIdKey, battleId);
    await p.setInt(_onlineBattlesKey, current + 1);
    return true;
  }
  static Future<bool> unlocked() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool('training_completed_v2') ?? false;
  }
}

class _HiddenUnlocks {
  static const _goryuKey = 'unlock_goryu';
  static const _kuruKey = 'unlock_kuru';
  static bool goryu = false;
  static bool kuru = false;
  static bool pendingGoryuReveal = false;
  static bool pendingGoryuIsWhite = true;
  static bool pendingGoryuVictoryNotice = false;

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    goryu = prefs.getBool(_goryuKey) ?? false;
    kuru = prefs.getBool(_kuruKey) ?? false;
    await _MasterProgress.load();
  }

  static Future<void> unlockGoryu({required bool isWhite, bool showPostBattleReveal = true}) async {
    if (goryu || !_StoryProgress.isChapter2Unlocked(12)) return;
    goryu = true;
    pendingGoryuReveal = showPostBattleReveal;
    pendingGoryuIsWhite = isWhite;
    if (!showPostBattleReveal) pendingGoryuVictoryNotice = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_goryuKey, true);
    await _UnlockInbox.markUnit('GORYU');
  }

  static Future<void> unlockKuru() async {
    if (kuru) return;
    kuru = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kuruKey, true);
    await _UnlockInbox.markUnit('KURU');
  }
}

class _MasterProgress {
  static const int souvenirWinsRequired = 11;
  static int kingWins = 0, knightWins = 0, emperorWins = 0, strasseWins = 0, masterWins = 0;
  static String? first33;
  // Souvenir pieces are preserved in acquisition order.
  // DATABASE placement: 1st=center, 2nd=left, 3rd=right.
  static List<String> acquiredMasterPieces = <String>[];
  static bool masterUnlocked = false;

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    // v2 keys intentionally ignore the old CPU/PRACTICE-only test counters.
    kingWins = p.getInt('progress_v2_wins_king') ?? 0;
    knightWins = p.getInt('progress_v2_wins_knight') ?? 0;
    emperorWins = p.getInt('progress_v2_wins_emperor') ?? 0;
    strasseWins = p.getInt('progress_v2_wins_strasse') ?? 0;
    masterWins = p.getInt('progress_v2_wins_master') ?? 0;
    first33 = p.getString('souvenir_first_v2');
    acquiredMasterPieces = p.getStringList('souvenir_piece_order_v2') ?? <String>[];
    masterUnlocked = p.getBool('unlock_master') ?? false;
  }

  static int wins(BattleUnit u) => switch (u) {
    BattleUnit.king => kingWins,
    BattleUnit.knight => knightWins,
    BattleUnit.emperor => emperorWins,
    BattleUnit.strasse => strasseWins,
    BattleUnit.master => masterWins,
  };

  static Future<void> recordWin(BattleUnit u) async {
    final p = await SharedPreferences.getInstance();
    final v = wins(u) + 1;
    if (u == BattleUnit.king) { kingWins = v; await p.setInt('progress_v2_wins_king', v); }
    if (u == BattleUnit.knight) { knightWins = v; await p.setInt('progress_v2_wins_knight', v); }
    if (u == BattleUnit.emperor) { emperorWins = v; await p.setInt('progress_v2_wins_emperor', v); }
    if (u == BattleUnit.strasse) { strasseWins = v; await p.setInt('progress_v2_wins_strasse', v); }
    if (u == BattleUnit.master) { masterWins = v; await p.setInt('progress_v2_wins_master', v); }
    if ((u == BattleUnit.king || u == BattleUnit.knight || u == BattleUnit.emperor) && v == souvenirWinsRequired) {
      if (first33 == null) {
        first33 = u.name;
        await p.setString('souvenir_first_v2', u.name);
      }
      if (!acquiredMasterPieces.contains(u.name)) {
        acquiredMasterPieces.add(u.name);
        await p.setStringList('souvenir_piece_order_v2', acquiredMasterPieces);
        await _UnlockInbox.markSouvenir(u.name);
      }
    }
  }

  static Future<bool> unlockMaster() async {
    if (masterUnlocked) return false;
    masterUnlocked = true;
    final p = await SharedPreferences.getInstance();
    await p.setBool('unlock_master', true);
    await _UnlockInbox.markUnit('MASTER');
    return true;
  }

  static String masterPieceAsset(String unitName, {bool isWhite = true}) {
    final side = isWhite ? 'white' : 'black';
    return switch (unitName) {
      'knight' => 'assets/pieces/master_knight_${side}.png',
      'emperor' => 'assets/pieces/master_emperor_${side}.png',
      _ => 'assets/pieces/master_king_${side}.png',
    };
  }

  static String masterPieceLabel(String unitName) => switch (unitName) {
    'knight' => '騎',
    'emperor' => '帝',
    _ => '王',
  };

  static String masterRepresentative(bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (first33) {
      'knight' => 'assets/pieces/master_knight_${side}.png',
      'emperor' => 'assets/pieces/master_emperor_${side}.png',
      _ => 'assets/pieces/master_king_${side}.png',
    };
  }
}


class _StoryBgmPlan {
  // 第1章の仮選曲。ユーザー実機確認後に曲だけ差し替えられるよう話数単位で管理する。
  static const byEpisode = <int, String>{
    1: 'audio/6Target Lock.m4a',
    2: 'audio/4Unit Deployment.mp3',
    3: "audio/8Commander\'s Gambit.m4a",
    4: 'audio/9Heavy Metal Strategy.m4a',
    5: 'audio/10Tactical Velocity.m4a',
    6: 'audio/2War Room Protocol.mp3',
    7: 'audio/5Overdriven Riffs.m4a',
    8: 'audio/3Unit Lockdown.m4a',
    9: 'audio/11Doubt.mp3 （リミックス） (Remastered).m4a',
    10: 'audio/7Target Lock2.m4a',
    11: 'audio/12Final Tactical Maneuver.m4a',
    12: 'audio/13Tactical Aftermathematical End.m4a',
  };
}

class _StoryChapter2BgmPlan {
  // 第2章チェック用の仮選曲。1〜11話は実機確認後に話数単位で差し替える。
  static const byEpisode = <int, String>{
    1: 'audio/11Doubt.mp3 （リミックス） (Remastered).m4a',
    2: 'audio/2War Room Protocol.mp3',
    3: 'audio/1Dawn After the War (Remastered).m4a',
    4: 'audio/1Dawn After the War (Remastered).m4a',
    5: 'audio/5Overdriven Riffs.m4a',
    6: 'audio/10Tactical Velocity.m4a',
    7: 'audio/7Target Lock2.m4a',
    8: 'audio/3Unit Lockdown.m4a',
    9: "audio/8Commander's Gambit.m4a",
    10: 'audio/4Unit Deployment.mp3',
    11: 'audio/11Doubt.mp3 （リミックス） (Remastered).m4a',
    12: 'audio/12Final Tactical Maneuver.m4a',
    13: 'audio/STREET FLOWER.mp3',
    14: 'audio/STREET FLOWER.mp3',
  };
}

class _UnlockNotice {
  const _UnlockNotice(this.kicker, this.title, [this.subtitle, this.imageAsset]);
  final String kicker;
  final String title;
  final String? subtitle;
  final String? imageAsset;
}

class _UnlockInbox {
  static const _storyUnreadKey = 'notify_story_unread_v2';
  static const _storyKickerKey = 'notify_story_kicker_v2';
  static const _storyTitleKey = 'notify_story_title_v2';
  static const _storySubtitleKey = 'notify_story_subtitle_v2';
  static const _unitIdsKey = 'notify_unit_ids_v2';
  static const _souvenirIdsKey = 'notify_souvenir_ids_v2';

  static bool storyUnread = false;
  static List<String> unitIds = <String>[];
  static List<String> souvenirIds = <String>[];

  static bool get unitUnread => unitIds.isNotEmpty;
  static bool get souvenirUnread => souvenirIds.isNotEmpty;
  static bool get databaseUnread => unitUnread || souvenirUnread;

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    storyUnread = p.getBool(_storyUnreadKey) ?? false;
    unitIds = p.getStringList(_unitIdsKey) ?? <String>[];
    souvenirIds = p.getStringList(_souvenirIdsKey) ?? <String>[];
  }

  static Future<void> markStory(_UnlockNotice notice) async {
    storyUnread = true;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_storyUnreadKey, true);
    await p.setString(_storyKickerKey, notice.kicker);
    await p.setString(_storyTitleKey, notice.title);
    await p.setString(_storySubtitleKey, notice.subtitle ?? '');
  }

  static Future<_UnlockNotice?> takeStory() async {
    if (!storyUnread) return null;
    final p = await SharedPreferences.getInstance();
    final title = p.getString(_storyTitleKey);
    if (title == null || title.isEmpty) {
      storyUnread = false;
      await p.setBool(_storyUnreadKey, false);
      return null;
    }
    final notice = _UnlockNotice(
      p.getString(_storyKickerKey) ?? 'STORY UNLOCKED',
      title,
      (p.getString(_storySubtitleKey) ?? '').isEmpty ? null : p.getString(_storySubtitleKey),
    );
    storyUnread = false;
    await p.setBool(_storyUnreadKey, false);
    return notice;
  }

  static Future<void> markUnit(String id) async {
    if (unitIds.contains(id)) return;
    unitIds = <String>[...unitIds, id];
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_unitIdsKey, unitIds);
  }

  static _UnlockNotice? _unitNotice(String id) => switch (id) {
    'KNIGHT' => const _UnlockNotice('UNIT UNLOCKED', 'KNIGHT', 'ナイトユニットが使用可能になりました。'),
    'EMPEROR' => const _UnlockNotice('UNIT UNLOCKED', 'EMPEROR', 'エンペラーユニットが使用可能になりました。'),
    'STRASSE' => const _UnlockNotice('UNIT UNLOCKED', 'STRASSE', 'STRASSEが使用可能になりました。'),
    'MASTER' => const _UnlockNotice('UNIT UNLOCKED', 'MASTER', 'MASTERが使用可能になりました。'),
    'GORYU' => const _UnlockNotice('MACHINE UNLOCKED', '豪竜', '豪竜がDATABASEに追加されました。'),
    'KURU' => const _UnlockNotice('PILOT UNLOCKED', 'クル', 'クルがDATABASEに追加されました。'),
    _ => null,
  };

  static Future<List<_UnlockNotice>> takeUnitNotices() async {
    final ids = List<String>.from(unitIds);
    unitIds = <String>[];
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_unitIdsKey, unitIds);
    final notices = <_UnlockNotice>[];
    for (final id in ids) { final notice = _unitNotice(id); if (notice != null) notices.add(notice); }
    return notices;
  }

  static Future<void> markSouvenir(String unitName) async {
    if (souvenirIds.contains(unitName)) return;
    souvenirIds = <String>[...souvenirIds, unitName];
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_souvenirIdsKey, souvenirIds);
  }

  static Future<List<_UnlockNotice>> takeSouvenirNotices() async {
    final ids = List<String>.from(souvenirIds);
    souvenirIds = <String>[];
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_souvenirIdsKey, souvenirIds);
    return [for (final id in ids)
      _UnlockNotice(
        'MASTER PIECE ACQUIRED',
        '${_MasterProgress.masterPieceLabel(id)} 記念品',
        '記念品を獲得しました。',
        _MasterProgress.masterPieceAsset(id),
      )
    ];
  }
}

class _UnlockNoticeDialog extends StatefulWidget {
  const _UnlockNoticeDialog({required this.notice});
  final _UnlockNotice notice;

  @override
  State<_UnlockNoticeDialog> createState() => _UnlockNoticeDialogState();
}

class _UnlockNoticeDialogState extends State<_UnlockNoticeDialog> {
  final AudioPlayer _player = AudioPlayer();
  bool _canClose = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _playUnlockSound());
  }

  Future<void> _playUnlockSound() async {
    try {
      await _player.setAudioContext(
        AudioContext(
          android: const AudioContextAndroid(
            contentType: AndroidContentType.sonification,
            usageType: AndroidUsageType.game,
            audioFocus: AndroidAudioFocus.none,
          ),
          iOS: AudioContextIOS(
            category: AVAudioSessionCategory.ambient,
            options: const {AVAudioSessionOptions.mixWithOthers},
          ),
        ),
      );
      final completed = _player.onPlayerComplete.first;
      await _player.play(AssetSource('audio/unlock_general.mp3'), volume: _AudioSettings.se);
      await completed.timeout(const Duration(seconds: 10));
    } catch (_) {}
    if (mounted) setState(() => _canClose = true);
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: _canClose,
        child: Dialog(
          backgroundColor: const Color(0xFF0B0D12),
          insetPadding: const EdgeInsets.symmetric(horizontal: 26),
          shape: RoundedRectangleBorder(
            side: const BorderSide(color: Colors.white24),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 30, 24, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(widget.notice.kicker, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 2.2)),
                const SizedBox(height: 14),
                Text(widget.notice.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, height: 1.2, letterSpacing: .7)),
                if (widget.notice.imageAsset != null) ...[
                  const SizedBox(height: 14),
                  Image.asset(widget.notice.imageAsset!, height: 150, fit: BoxFit.contain),
                ],
                if (widget.notice.subtitle != null) ...[
                  const SizedBox(height: 10),
                  Text(widget.notice.subtitle!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.w700, height: 1.45)),
                ],
                const SizedBox(height: 24),
                FilledButton(onPressed: _canClose ? () => Navigator.of(context).pop() : null, child: const Text('OK')),
              ],
            ),
          ),
        ),
      );
}

Future<void> _showUnlockNotice(BuildContext context, _UnlockNotice notice) async {
  if (!context.mounted) return;
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierColor: Colors.black87,
    builder: (_) => _UnlockNoticeDialog(notice: notice),
  );
}

Future<void> _showUnlockNotices(BuildContext context, List<_UnlockNotice> notices) async {
  for (final notice in notices) {
    if (!context.mounted) return;
    await _showUnlockNotice(context, notice);
  }
}

class _StoryProgress {
  static const _ep1UnlockedKey = 'story_ep1_unlocked';
  static const _ep1ReadKey = 'story_ep1_read';
  static const _practiceDoneKey = 'story_progress_practice_done_v1';
  static const _chapter2StepWinsKey = 'story_ch2_step_wins_v1';
  static const _finalReadyKey = 'story_final_requirements_ready_v1';
  static const _finalWinsKey = 'story_final_post_requirements_wins_v1';
  static final Set<int> _unlocked = <int>{};
  static final Set<int> _chapter2Unlocked = <int>{};
  static final Set<int> _read = <int>{};
  static int _chapter2StepWins = 0;
  static bool _finalRequirementsReady = false;
  static int _finalPostRequirementsWins = 0;

  static String _unlockKey(int episode) => episode == 1 ? _ep1UnlockedKey : 'story_ep${episode}_unlocked';
  static String _chapter2UnlockKey(int episode) => 'story_ch2_ep${episode}_unlocked';
  static String _readKey(int episode) => episode == 1 ? _ep1ReadKey : 'story_ep${episode}_read';

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _unlocked.clear();
    _chapter2Unlocked.clear();
    _read.clear();
    for (var ep = 1; ep <= 12; ep++) {
      if (p.getBool(_unlockKey(ep)) ?? false) _unlocked.add(ep);
      if (p.getBool(_readKey(ep)) ?? false) _read.add(ep);
    }
    for (var ep = 1; ep <= 14; ep++) {
      if (p.getBool(_chapter2UnlockKey(ep)) ?? false) _chapter2Unlocked.add(ep);
      if (p.getBool(_readKey(100 + ep)) ?? false) _read.add(100 + ep);
    }
    _chapter2StepWins = p.getInt(_chapter2StepWinsKey) ?? 0;
    _finalRequirementsReady = p.getBool(_finalReadyKey) ?? false;
    _finalPostRequirementsWins = p.getInt(_finalWinsKey) ?? 0;
  }

  static bool isUnlocked(int episode) => _unlocked.contains(episode);
  static bool isRead(int episode) => _read.contains(episode);
  static bool isChapter2Unlocked(int episode) => _chapter2Unlocked.contains(episode);
  static bool isChapter2Read(int episode) => _read.contains(100 + episode);
  static Future<void> markChapter2Read(int episode) => markEpisodeRead(100 + episode);

  static bool get episode1Unlocked => isUnlocked(1);
  static bool get episode1Read => isRead(1);
  static bool get knightUnlocked => isUnlocked(8);
  static bool get emperorUnlocked => isUnlocked(12);
  static bool get strasseUnlocked => isChapter2Unlocked(12);
  static bool get masterUnlocked => _MasterProgress.masterUnlocked;

  static List<BattleUnit> get availableUnits {
    final units = <BattleUnit>[BattleUnit.king];
    if (knightUnlocked) units.add(BattleUnit.knight);
    if (emperorUnlocked) units.add(BattleUnit.emperor);
    if (strasseUnlocked) units.add(BattleUnit.strasse);
    if (masterUnlocked) units.add(BattleUnit.master);
    return units;
  }

  static const Map<int, String> _chapter1NoticeTitles = <int, String>{
    1: '脱走、戦闘', 2: '逆転、安堵', 3: '醒書、団結', 4: '狼煙、開戦',
    5: '拮抗、少女', 6: '石版、過去', 7: '再来、咆哮', 8: '教導、逃亡',
    9: 'それぞれの道、そして', 10: '醒める、幻', 11: '始まりの終わり', 12: '夢の終わり',
  };

  static const Map<int, String> _chapter2NoticeTitles = <int, String>{
    1: 'あの戦い', 2: '投げやり', 3: '花屋', 4: '風呂', 5: 'シュトラーセ', 6: '真価',
    7: '魔法', 8: '光の中', 9: '断片', 10: '勢揃い', 11: '同化', 12: '総力戦',
    13: '最後の光', 14: '枯れない花',
  };

  static Future<void> _unlockChapter1(int episode) async {
    if (episode < 1 || episode > 12 || _unlocked.contains(episode)) return;
    _unlocked.add(episode);
    final p = await SharedPreferences.getInstance();
    await p.setBool(_unlockKey(episode), true);
    await _UnlockInbox.markStory(_UnlockNotice('STORY UNLOCKED', '第1章 第$episode話', '「${_chapter1NoticeTitles[episode] ?? ''}」'));
    if (episode == 8) await _UnlockInbox.markUnit('KNIGHT');
    if (episode == 12) await _UnlockInbox.markUnit('EMPEROR');
  }

  static Future<void> _unlockChapter2(int episode) async {
    if (episode < 1 || episode > 14 || _chapter2Unlocked.contains(episode)) return;
    _chapter2Unlocked.add(episode);
    final p = await SharedPreferences.getInstance();
    await p.setBool(_chapter2UnlockKey(episode), true);
    await _UnlockInbox.markStory(_UnlockNotice('STORY UNLOCKED', episode == 14 ? '第2章 最終話' : '第2章 第$episode話', '「${_chapter2NoticeTitles[episode] ?? ''}」'));
    if (episode == 12) await _UnlockInbox.markUnit('STRASSE');
  }

  static Future<void> unlockEpisode(int episode) => _unlockChapter1(episode);

  static Future<void> recordTrainingCompleted() async {
    await _unlockChapter1(1);
  }

  static Future<void> _unlockNextChapter1Episode() async {
    if (!isUnlocked(1)) return;
    for (var ep = 2; ep <= 12; ep++) {
      if (!isUnlocked(ep)) {
        await _unlockChapter1(ep);
        return;
      }
    }
  }

  static Future<void> recordPracticeCompleted() async {
    // PRACTICEは初回正常終了時だけ「1話分」の補助進行。必須ルートにはしない。
    final p = await SharedPreferences.getInstance();
    if (p.getBool(_practiceDoneKey) ?? false) return;
    await p.setBool(_practiceDoneKey, true);
    await _unlockNextChapter1Episode();
  }

  static Future<void> recordNormalOnlineCompleted() async {
    // 第2話以降のメイン進行。正常終了したONLINE BATTLEごとに次の1話を解禁する。
    await _unlockNextChapter1Episode();
  }

  static int _chapter2RequiredWinsFor(int episode) {
    if (episode >= 1 && episode <= 4) return 1;
    if (episode >= 5 && episode <= 8) return 2;
    if (episode >= 9 && episode <= 11) return 3;
    return 0;
  }

  static int? get chapter2WinsRemaining {
    if (!isChapter2Unlocked(1) || isChapter2Unlocked(12)) return null;
    var current = 1;
    for (var ep = 1; ep <= 11; ep++) {
      if (isChapter2Unlocked(ep)) current = ep;
    }
    final required = _chapter2RequiredWinsFor(current);
    if (required <= 0) return null;
    return math.max(0, required - _chapter2StepWins);
  }

  static int? get finalWinsRemaining {
    if (isChapter2Unlocked(14) || !_finalRequirementsReady) return null;
    return math.max(0, 3 - _finalPostRequirementsWins);
  }

  static String? get chapter2ProgressLabel {
    final next = chapter2WinsRemaining;
    if (next != null) return '次の話まであと$next勝';
    final finalWins = finalWinsRemaining;
    if (finalWins != null) return '最終章解禁まであと$finalWins勝';
    return null;
  }

  static Future<bool> recordOnlineWin({bool allowChapter2Progress = true, bool allowChapter2Start = false}) async {
    // 第1章全話がすでに解禁済みの状態で迎えた次のONLINE勝利で、第2章を初めて出現させる。
    if (allowChapter2Start && isUnlocked(12) && !isChapter2Unlocked(1)) {
      await _unlockChapter2(1);
      return false;
    }

    // 第2章1〜12話は、その時点で解禁済みの最新話ごとの勝利数で進める。
    if (allowChapter2Progress && isChapter2Unlocked(1) && !isChapter2Unlocked(12)) {
      var current = 1;
      for (var ep = 1; ep <= 11; ep++) {
        if (isChapter2Unlocked(ep)) current = ep;
      }
      final required = _chapter2RequiredWinsFor(current);
      if (required > 0) {
        final p = await SharedPreferences.getInstance();
        _chapter2StepWins += 1;
        if (_chapter2StepWins >= required) {
          _chapter2StepWins = 0;
          await p.setInt(_chapter2StepWinsKey, 0);
          await _unlockChapter2(current + 1);
        } else {
          await p.setInt(_chapter2StepWinsKey, _chapter2StepWins);
        }
        return false;
      }
    }

    // 第13話と最終話はCHIP不可。豪竜＋記念品3つ成立後、その後の3勝だけを数える。
    if (!allowChapter2Progress || !isChapter2Unlocked(12) || isChapter2Unlocked(14)) return false;
    final prerequisites = _HiddenUnlocks.goryu && _MasterProgress.acquiredMasterPieces.length >= 3;
    if (!prerequisites) return false;
    final p = await SharedPreferences.getInstance();
    if (!_finalRequirementsReady) {
      _finalRequirementsReady = true;
      _finalPostRequirementsWins = 0;
      await p.setBool(_finalReadyKey, true);
      await p.setInt(_finalWinsKey, 0);
      return false;
    }
    _finalPostRequirementsWins += 1;
    await p.setInt(_finalWinsKey, _finalPostRequirementsWins);
    if (_finalPostRequirementsWins < 3) return false;
    await _unlockChapter2(13);
    await _unlockChapter2(14);
    return _MasterProgress.unlockMaster();
  }

  static Future<void> markEpisodeRead(int episode) async {
    if (_read.contains(episode)) return;
    _read.add(episode);
    final p = await SharedPreferences.getInstance();
    await p.setBool(_readKey(episode), true);
  }

  static Future<void> unlockEpisode1() => _unlockChapter1(1);
  static Future<void> markEpisode1Read() => markEpisodeRead(1);
}

class _AdditionalData {
  static const videoUrl = 'https://github.com/dreixbefehl-collab/Zaamd2/releases/download/ending-v1/Z_Armed.mp4';
  static const videoBytes = 78694678;
  static const packUrl = 'https://github.com/dreixbefehl-collab/Zaamd2/releases/download/ending-v1/Zaamd_Additional_Data_v2.zip';
  static const packBytes = 4863151;
  static const bgmPackUrl = 'https://github.com/dreixbefehl-collab/Zaamd2/releases/download/ending-v1/Zaamd_BGM_v1.zip';
  static const bgmPackBytes = 21399921;
  static const storyImagePackUrl = 'https://github.com/dreixbefehl-collab/Zaamd2/releases/download/ending-v1/Zaamd_Images_v9.zip';
  static const storyImagePackBytes = 43230462;
  static const storyPanelPackUrl = 'https://github.com/dreixbefehl-collab/Zaamd2/releases/download/ending-v1/Zaamd_Images_v9.zip';
  static const storyPanelPackBytes = 0;
  static const chapter2PackUrl = 'https://github.com/dreixbefehl-collab/Zaamd2/releases/download/ending-v1/Zaamd_Chapter2_v2.zip';
  static const chapter2PackBytes = 18293351;
  static const version = 11;
  static int get expectedBytes => videoBytes + packBytes + bgmPackBytes + storyImagePackBytes + storyPanelPackBytes + chapter2PackBytes;

  static const bgmFiles = <String>[
    '1Dawn After the War (Remastered).m4a',
    '2War Room Protocol.mp3',
    '3Unit Lockdown.m4a',
    '4Unit Deployment.mp3',
    '5Overdriven Riffs.m4a',
    '6Target Lock.m4a',
    '7Target Lock2.m4a',
    "8Commander's Gambit.m4a",
    '9Heavy Metal Strategy.m4a',
    '10Tactical Velocity.m4a',
    '11Doubt.mp3 （リミックス） (Remastered).m4a',
    '12Final Tactical Maneuver.m4a',
    '13Tactical Aftermathematical End.m4a',
  ];

  static Future<Directory> root() async => Directory('${(await getApplicationSupportDirectory()).path}/additional_v$version');
  static Future<File> file() async => File('${(await root()).path}/Z_Armed.mp4');
  static Future<File> packFile() async => File('${(await root()).path}/Zaamd_Additional_Data_v2.zip');
  static Future<File> bgmPackFile() async => File('${(await root()).path}/Zaamd_BGM_v1.zip');
  static Future<File> storyImagePackFile() async => File('${(await root()).path}/Zaamd_Images_v9.zip');
  static Future<File> storyPanelPackFile() async => File('${(await root()).path}/Zaamd_Images_v9.zip');
  static Future<File> chapter2PackFile() async => File('${(await root()).path}/Zaamd_Chapter2_v2.zip');
  static Future<File> asset(String relativePath) async => File('${(await root()).path}/$relativePath');
  static Future<File> storyImage(String relativePath) async => File('${(await root()).path}/story_ch1/$relativePath');
  static Future<File> storyPanel(String relativePath) async => File('${(await root()).path}/story_panels/$relativePath');
  static Future<File> storyChapter2(String relativePath) async => File('${(await root()).path}/story_ch2/$relativePath');
  static Future<File> storyAssetsV2Marker() async => File('${(await root()).path}/.story_assets_v9_ready');

  static Future<bool> ready() async {
    final v = await file();
    final marker = await asset('.ready');
    final lala = await asset('database/yorishiro/lala.jpg');
    final knightsWhite = await asset('database/knights/white.jpg');
    final knightsBlack = await asset('database/knights/black.jpg');
    if (!(await v.exists() && await v.length() == videoBytes && await marker.exists() && await lala.exists() && await knightsWhite.exists() && await knightsBlack.exists())) return false;
    for (final name in bgmFiles) {
      final f = await asset('audio/$name');
      if (!await f.exists() || await f.length() == 0) return false;
    }
    final storyManifest = await storyImage('manifest.json');
    final storyCover1 = await storyImage('covers/episode_01.jpg');
    final storyCover12 = await storyImage('covers/episode_12.jpg');
    final storyArts = await storyImage('pilots/12934.jpg');
    final storyBull = await storyImage('pilots/12940.jpg');
    final storyPanelManifest = await storyPanel('manifest.json');
    final storyPanel1 = await storyPanel('ep01/panel_08.webp');
    final storyPanel12 = await storyPanel('ep12/panel_34.webp');
    final storyAssetsMarker = await storyAssetsV2Marker();
    if (!await storyAssetsMarker.exists()) return false;
    if (!await storyManifest.exists() || !await storyCover1.exists() || !await storyCover12.exists() || !await storyArts.exists() || !await storyBull.exists()) return false;
    if (!await storyPanelManifest.exists() || !await storyPanel1.exists() || !await storyPanel12.exists()) return false;
    final chapter2Manifest = await storyChapter2('manifest.json');
    final chapter2Cover1 = await storyChapter2('covers/episode_01.jpg');
    final chapter2Cover14 = await storyChapter2('covers/episode_14.jpg');
    final chapter2Panel1 = await storyChapter2('panels/ep01/panel_01.webp');
    final chapter2Panel14 = await storyChapter2('panels/ep14/panel_12.webp');
    final streetFlower = await asset('audio/STREET FLOWER.mp3');
    if (!await chapter2Manifest.exists() || !await chapter2Cover1.exists() || !await chapter2Cover14.exists() || !await chapter2Panel1.exists() || !await chapter2Panel14.exists() || !await streetFlower.exists() || await streetFlower.length() == 0) return false;
    return true;
  }

  static Future<void> _downloadOne(String url, File out, int expected, int base, void Function(int,int) progress) async {
    await out.parent.create(recursive: true);
    final tmp = File('${out.path}.part');
    if (await tmp.exists()) await tmp.delete();
    final client = HttpClient();
    try {
      final req = await client.getUrl(Uri.parse(url));
      final res = await req.close();
      if (res.statusCode < 200 || res.statusCode >= 300) throw HttpException('HTTP ${res.statusCode}');
      final sink = tmp.openWrite(); int got = 0;
      await for (final chunk in res) { sink.add(chunk); got += chunk.length; progress(base + got, expectedBytes); }
      await sink.close();
      if (await tmp.length() != expected) { await tmp.delete(); throw const FormatException('size mismatch'); }
      if (await out.exists()) await out.delete();
      await tmp.rename(out.path);
    } finally { client.close(force: true); }
  }

  static Future<void> _extractZip(File zip, String prefix) async {
    final bytes = await zip.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final base = await root();
    for (final entry in archive) {
      var name = entry.name;
      if (name.startsWith(prefix)) name = name.substring(prefix.length);
      if (name.isEmpty || name.endsWith('/')) continue;
      if (name.contains('..')) continue;
      final out = File('${base.path}/$name');
      await out.parent.create(recursive: true);
      await out.writeAsBytes(entry.content as List<int>, flush: true);
    }
  }

  static Future<void> _extractPack() async {
    final zip = await packFile();
    await _extractZip(zip, 'Zaamd_Additional_Data_v2/');
  }

  static Future<void> _extractBgmPack() async {
    final zip = await bgmPackFile();
    await _extractZip(zip, 'Zaamd_BGM_v1/');
  }

  static Future<void> _extractStoryImagePack() async {
    final zip = await storyImagePackFile();
    final bytes = await zip.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final base = await root();
    for (final entry in archive) {
      var name = entry.name;
      const prefix = 'Zaamd_Images/images/';
      if (name.startsWith(prefix)) name = name.substring(prefix.length);
      if (name.isEmpty || name.endsWith('/') || name.contains('..')) continue;
      final out = File('${base.path}/story_ch1/$name');
      await out.parent.create(recursive: true);
      await out.writeAsBytes(entry.content as List<int>, flush: true);
    }
  }

  static Future<void> _extractStoryPanelPack() async {
    final zip = await storyPanelPackFile();
    final bytes = await zip.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final base = await root();
    for (final entry in archive) {
      var name = entry.name;
      const prefix = 'Zaamd_Images/panels/';
      if (name.startsWith(prefix)) name = name.substring(prefix.length);
      if (name.isEmpty || name.endsWith('/') || name.contains('..')) continue;
      final out = File('${base.path}/story_panels/$name');
      await out.parent.create(recursive: true);
      await out.writeAsBytes(entry.content as List<int>, flush: true);
    }
  }

  static Future<void> _extractChapter2Pack() async {
    final zip = await chapter2PackFile();
    await _extractZip(zip, 'Zaamd_Chapter2_v2/');
  }

  static Future<void> download(void Function(int,int) progress) async {
    final r = await root(); await r.create(recursive: true);

    // BGM is fetched first so the title music starts on the ADDITIONAL DATA screen
    // while the larger video/image downloads continue.
    final b = await bgmPackFile();
    var bgmExtractedReady = true;
    for (final name in bgmFiles) {
      final f = await asset('audio/$name');
      if (!await f.exists() || await f.length() == 0) {
        bgmExtractedReady = false;
        break;
      }
    }
    if (!bgmExtractedReady) {
      if (!await b.exists() || await b.length() != bgmPackBytes) {
        await _downloadOne(bgmPackUrl, b, bgmPackBytes, 0, progress);
      }
      await _extractBgmPack();
      if (await b.exists()) await b.delete();
    } else {
      progress(bgmPackBytes, expectedBytes);
    }
    await _AppBgm.play('audio/1Dawn After the War (Remastered).m4a');

    final v = await file();
    if (!await v.exists() || await v.length() != videoBytes) {
      await _downloadOne(videoUrl, v, videoBytes, bgmPackBytes, progress);
    } else { progress(bgmPackBytes + videoBytes, expectedBytes); }

    final z = await packFile();
    if (!await z.exists() || await z.length() != packBytes) {
      await _downloadOne(packUrl, z, packBytes, bgmPackBytes + videoBytes, progress);
    } else { progress(bgmPackBytes + videoBytes + packBytes, expectedBytes); }
    await _extractPack();

    final si = await storyImagePackFile();
    final storyBase = bgmPackBytes + videoBytes + packBytes;
    final storyAssetsMarker = await storyAssetsV2Marker();
    final storyImagesReady = await storyAssetsMarker.exists() && await (await storyImage('manifest.json')).exists() && await (await storyImage('covers/episode_01.jpg')).exists() && await (await storyImage('covers/episode_12.jpg')).exists();
    final storyPanelsReady = await storyAssetsMarker.exists() && await (await storyPanel('manifest.json')).exists() && await (await storyPanel('ep12/panel_34.webp')).exists();
    if (!storyImagesReady || !storyPanelsReady) {
      if (!await si.exists() || await si.length() != storyImagePackBytes) {
        await _downloadOne(storyImagePackUrl, si, storyImagePackBytes, storyBase, progress);
      }
      if (!await storyAssetsMarker.exists()) {
        final oldImages = Directory('${r.path}/story_ch1');
        final oldPanels = Directory('${r.path}/story_panels');
        if (await oldImages.exists()) await oldImages.delete(recursive: true);
        if (await oldPanels.exists()) await oldPanels.delete(recursive: true);
      }
      if (!storyImagesReady) await _extractStoryImagePack();
      if (!storyPanelsReady) await _extractStoryPanelPack();
      await storyAssetsMarker.writeAsString('Zaamd_Images_v9');
      if (await si.exists()) await si.delete();
    } else {
      progress(storyBase + storyImagePackBytes, expectedBytes);
    }

    final chapter2Base = storyBase + storyImagePackBytes + storyPanelPackBytes;
    final chapter2Manifest = await storyChapter2('manifest.json');
    final chapter2Cover14 = await storyChapter2('covers/episode_14.jpg');
    final chapter2Panel14 = await storyChapter2('panels/ep14/panel_12.webp');
    final streetFlower = await asset('audio/STREET FLOWER.mp3');
    final chapter2Ready = await chapter2Manifest.exists() && await chapter2Cover14.exists() && await chapter2Panel14.exists() && await streetFlower.exists() && await streetFlower.length() > 0;
    final c2 = await chapter2PackFile();
    if (!chapter2Ready) {
      if (!await c2.exists() || await c2.length() != chapter2PackBytes) {
        await _downloadOne(chapter2PackUrl, c2, chapter2PackBytes, chapter2Base, progress);
      }
      await _extractChapter2Pack();
      if (await c2.exists()) await c2.delete();
    } else {
      progress(expectedBytes, expectedBytes);
    }

    await File('${r.path}/.ready').writeAsString('v$version');
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _AudioSettings.load();
  await _HiddenUnlocks.load();
  await _StoryProgress.load();
  await _UnlockInbox.load();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const ZaamdApp());
}


class _AppBgm {
  _AppBgm._();
  static final AudioPlayer _player = AudioPlayer();
  static String? _current;
  static Future<void> play(String asset) async {
    if (_current == asset) return;
    try {
      final f = await _AdditionalData.asset(asset);
      if (!await f.exists()) { _current = null; return; }
      await _player.stop();
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.play(DeviceFileSource(f.path), volume: _AudioSettings.bgm);
      _current = asset;
    } catch (_) { _current = null; }
  }
  static Future<void> stop() async {
    _current = null;
    try { await _player.stop(); } catch (_) {}
  }
}

class _ScreenBgm extends StatefulWidget {
  const _ScreenBgm({required this.asset, required this.child});
  final String asset;
  final Widget child;
  @override State<_ScreenBgm> createState() => _ScreenBgmState();
}
class _ScreenBgmState extends State<_ScreenBgm> {
  @override void initState() { super.initState(); _AppBgm.play(widget.asset); }
  @override void didUpdateWidget(covariant _ScreenBgm oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.asset != widget.asset) _AppBgm.play(widget.asset);
  }
  @override Widget build(BuildContext context) => widget.child;
}

class _StablePilotTypewriter extends StatefulWidget {
  const _StablePilotTypewriter({
    super.key,
    required this.text,
    required this.duration,
    required this.childBuilder,
    this.completed = false,
  });
  final String text;
  final Duration duration;
  final bool completed;
  final Widget Function(BuildContext, String) childBuilder;
  @override
  State<_StablePilotTypewriter> createState() => _StablePilotTypewriterState();
}

class _StablePilotTypewriterState extends State<_StablePilotTypewriter>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: widget.duration)
      ..addListener(() { if (mounted) setState(() {}); })
      ..forward();
  }
  @override
  void didUpdateWidget(covariant _StablePilotTypewriter oldWidget) {
    super.didUpdateWidget(oldWidget);
    // CPU preview/action rebuilds must never restart the same dialogue.
    if (oldWidget.duration != widget.duration) _controller.duration = widget.duration;
    if (widget.completed && !oldWidget.completed) {
      _controller.stop();
      _controller.value = 1.0;
    }
  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final count = widget.completed
        ? widget.text.length
        : (widget.text.length * _controller.value).ceil().clamp(0, widget.text.length);
    return widget.childBuilder(context, widget.text.substring(0, count));
  }
}

class ZaamdApp extends StatefulWidget {
  const ZaamdApp({super.key});
  @override
  State<ZaamdApp> createState() => _ZaamdAppState();
}

class _ZaamdAppState extends State<ZaamdApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // Android のシステム Back は、ツァームド起動中は全画面で消費する。
  // ゲーム内の戻る/退出ボタンによる Navigator 操作だけを許可する。
  @override
  Future<bool> didPopRoute() async => true;

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: '鋼王騎帝 -ツァームド-',
        theme: ThemeData.dark(useMaterial3: true),
        builder: (context, child) => PopScope(canPop: false, child: child ?? const SizedBox.shrink()),
        home: const _StartupGate(),
      );
}

class _StartupGate extends StatefulWidget { const _StartupGate(); @override State<_StartupGate> createState()=>_StartupGateState(); }
class _StartupGateState extends State<_StartupGate> {
  bool _checking=true, _downloading=false, _failed=false; int _got=0,_total=_AdditionalData.expectedBytes;
  @override void initState(){ super.initState(); WidgetsBinding.instance.addPostFrameCallback((_)=>_ensure()); }
  Future<void> _ensure() async {
    if (!mounted) return;
    setState(() { _checking=true; _failed=false; });
    if (await _AdditionalData.ready()) { if(mounted)setState(()=>_checking=false); return; }
    await _download();
  }
  Future<void> _download() async {
    if(!mounted)return; setState((){_checking=false;_downloading=true;_failed=false;});
    try {
      await _AppBgm.play('audio/1Dawn After the War (Remastered).m4a');
      await _AdditionalData.download((a,b){if(mounted)setState((){_got=a;_total=b;});});
      if(!await _AdditionalData.ready()) throw const FormatException('additional data incomplete');
      await _AppBgm.play('audio/1Dawn After the War (Remastered).m4a');
    }
    catch(_){ if(mounted)setState(()=>_failed=true); }
    finally {if(mounted)setState(()=>_downloading=false);}
  }
  @override Widget build(BuildContext context)=>Stack(children:[
    const TitleScreen(),
    if(_checking||_downloading||_failed) Positioned.fill(child:Material(color:Colors.black87,child:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[
      Text(_failed?'ADDITIONAL DATA ERROR':'ADDITIONAL DATA',style:const TextStyle(letterSpacing:2,fontWeight:FontWeight.w900)),
      const SizedBox(height:18),
      if(_checking) const CircularProgressIndicator(),
      if(_downloading)...[SizedBox(width:280,child:LinearProgressIndicator(value:_total>0?_got/_total:null)),const SizedBox(height:10),Text('${(_got/1024/1024).toStringAsFixed(1)} / ${(_total/1024/1024).toStringAsFixed(1)} MB')],
      if(_failed)...[const Text('追加データの取得に失敗しました。'),const SizedBox(height:14),FilledButton(onPressed:_ensure,child:const Text('RETRY'))],
    ]))))),
  ]);
}

class _EndingScreen extends StatefulWidget { const _EndingScreen(); @override State<_EndingScreen> createState()=>_EndingScreenState(); }
class _EndingScreenState extends State<_EndingScreen> {
  VideoPlayerController? _c; bool _normalEnd=false;
  @override void initState(){super.initState();_init();}
  Future<void> _init() async { final f=await _AdditionalData.file(); final c=VideoPlayerController.file(f); _c=c; await c.initialize(); c.addListener(_watch); await _AppBgm.stop(); await c.setVolume(_AudioSettings.bgm); await c.play(); if(mounted)setState((){}); }
  void _watch(){final c=_c;if(c==null||!c.value.isInitialized||_normalEnd)return; final d=c.value.duration,p=c.value.position;if(d>Duration.zero && p>=d-const Duration(milliseconds:350)){_normalEnd=true;_finish();}}
  Future<void> _finish() async {
    final firstKuruUnlock = !_HiddenUnlocks.kuru;
    if (firstKuruUnlock) {
      await _HiddenUnlocks.unlockKuru();
      if (!mounted) return;
    }
    if (mounted) {
      _AppBgm.play('audio/1Dawn After the War (Remastered).m4a');
      Navigator.of(context).popUntil((r) => r.isFirst);
    }
  }
  @override void dispose(){_c?.removeListener(_watch);_c?.dispose();super.dispose();}
  @override Widget build(BuildContext context){final c=_c;return PopScope(canPop:false,child:Scaffold(backgroundColor:Colors.black,body:SafeArea(child:Stack(children:[Positioned.fill(child:c!=null&&c.value.isInitialized?Center(child:AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c))):const Center(child:CircularProgressIndicator())),Positioned(left:12,bottom:12,child:TextButton(onPressed:(){_AppBgm.play('audio/1Dawn After the War (Remastered).m4a');Navigator.of(context).popUntil((r)=>r.isFirst);},child:const Text('タイトル画面に戻る')))]))));}
}

Future<void> _confirmMatchExit(BuildContext context) async {
  final leave = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      backgroundColor: const Color(0xFF101216),
      title: const Text('BATTLE EXIT'),
      content: const Text('現在の対戦を終了してメニューへ戻りますか？'),
      actions: [
        TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('CANCEL')),
        FilledButton(onPressed: () => Navigator.of(dialogContext).pop(true), child: const Text('退出')),
      ],
    ),
  );
  if (leave == true && context.mounted) {
    _AppBgm.play('audio/2War Room Protocol.mp3');
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainMenuScreen()),
      (route) => route.isFirst,
    );
  }
}

class _MatchExitGuard extends StatelessWidget {
  const _MatchExitGuard({required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => PopScope(
    canPop: false,
    child: child,
  );
}

Widget _matchExitButton(BuildContext context) => IconButton(
  tooltip: '退出',
  icon: const Icon(Icons.logout_rounded),
  onPressed: () => _confirmMatchExit(context),
);

// 見た目の位置・大きさは標準の戻る矢印のまま、leading 全体をタップ判定にする。
// IconButton の 48px より少し広い AppBar の 56px 枠を丸ごと押せるようにしている。
Widget _easyBackButton(BuildContext context, {VoidCallback? onPressed}) => SizedBox.expand(
  child: Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: () { _UiSounds.back(); (onPressed ?? () => Navigator.of(context).pop())(); },
      child: const Center(child: Icon(Icons.arrow_back, size: 24)),
    ),
  ),
);

class _GameGuide {
  static const String _introCountKey = 'system_intro_notice_count_v1';
  static const int _introMax = 3;

  static const String premise =
      '『鋼王騎帝 -ツァームド-』では、対戦相手の特性や戦術を事前にすべて知ることはできない。\n\n'
      '敗北もまた攻略のための情報だ。戦いを重ね、敵を知り、自ら攻略法を見つけていく。\n\n'
      '王冠を3つ失えば敗北。それが、このゲームの鉄の掟だ。';

  static Future<void> showIntroIfNeeded(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final count = prefs.getInt(_introCountKey) ?? 0;
    if (count >= _introMax || !context.mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF101216),
        title: const Text('このゲームについて', style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text(premise, style: TextStyle(height: 1.65)),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
    await prefs.setInt(_introCountKey, count + 1);
  }
}


Route<T> _quietTransitionRoute<T>(Widget page) => PageRouteBuilder<T>(
  transitionDuration: const Duration(milliseconds: 1500),
  reverseTransitionDuration: const Duration(milliseconds: 650),
  pageBuilder: (_, __, ___) => page,
  transitionsBuilder: (context, animation, secondaryAnimation, child) {
    final fade = CurvedAnimation(
      parent: animation,
      curve: const Interval(.72, 1.0, curve: Curves.easeOutCubic),
    );
    final lineIn = CurvedAnimation(
      parent: animation,
      curve: const Interval(.14, .50, curve: Curves.easeOutCubic),
    );
    final lineOut = CurvedAnimation(
      parent: animation,
      curve: const Interval(.50, .70, curve: Curves.easeInCubic),
    );
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.black),
        FadeTransition(opacity: fade, child: child),
        IgnorePointer(
          child: Center(
            child: FadeTransition(
              opacity: Tween<double>(begin: 1, end: 0).animate(lineOut),
              child: ScaleTransition(
                scale: Tween<double>(begin: 0, end: 1).animate(lineIn),
                child: Container(
                  height: 2,
                  width: 190,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0x00FFFFFF), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0x00FFFFFF)]),
                    boxShadow: [
                      BoxShadow(color: Colors.white.withOpacity(.80), blurRadius: 10, spreadRadius: 2),
                      BoxShadow(color: const Color(0xFFBDEBFF).withOpacity(.55), blurRadius: 20, spreadRadius: 4),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  },
);

Route<T> _battleIntroRoute<T>(Widget page) => PageRouteBuilder<T>(
  transitionDuration: const Duration(milliseconds: 2100),
  reverseTransitionDuration: const Duration(milliseconds: 650),
  pageBuilder: (_, __, ___) => page,
  transitionsBuilder: (context, animation, secondaryAnimation, child) {
    final pageFade = CurvedAnimation(
      parent: animation,
      curve: const Interval(.74, 1.0, curve: Curves.easeOutCubic),
    );
    final titleFade = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: 1.0), weight: 25),
      TweenSequenceItem(tween: ConstantTween(1.0), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.0), weight: 25),
     ]).animate(CurvedAnimation(parent: animation, curve: const Interval(.14, .82)));
    final lineScale = CurvedAnimation(
      parent: animation,
      curve: const Interval(.12, .48, curve: Curves.easeOutCubic),
    );
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.black),
        FadeTransition(opacity: pageFade, child: child),
        IgnorePointer(
          child: FadeTransition(
            opacity: titleFade,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Color(0xFFFFFFFF), Color(0xFFB9BEC5), Color(0xFFF4F5F6)],
                    ).createShader(bounds),
                    child: const Text('BATTLE', style: TextStyle(
                      fontSize: 31, fontWeight: FontWeight.w700, letterSpacing: 9,
                      color: Colors.white, shadows: [Shadow(color: Color(0xAAFFFFFF), blurRadius: 12)],
                    )),
                  ),
                  const SizedBox(height: 13),
                  ScaleTransition(
                    scale: Tween<double>(begin: 0, end: 1).animate(lineScale),
                    child: Container(
                      height: 2, width: 210,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0x00FFFFFF), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0x00FFFFFF)]),
                        boxShadow: [BoxShadow(color: Colors.white.withOpacity(.75), blurRadius: 10, spreadRadius: 2)],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text('ENGAGE', style: TextStyle(fontSize: 9, letterSpacing: 5, color: Color(0xFF8E949C))),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  },
);

Route<T> _resultTransitionRoute<T>(Widget page) => PageRouteBuilder<T>(
  transitionDuration: const Duration(milliseconds: 1800),
  reverseTransitionDuration: const Duration(milliseconds: 650),
  pageBuilder: (_, __, ___) => page,
  transitionsBuilder: (context, animation, secondaryAnimation, child) {
    final fade = CurvedAnimation(
      parent: animation,
      curve: const Interval(.58, 1.0, curve: Curves.easeInOutCubic),
    );
    return FadeTransition(opacity: fade, child: child);
  },
);

class TitleScreen extends StatefulWidget {
  const TitleScreen({super.key});
  @override State<TitleScreen> createState() => _TitleScreenState();
}

class _TitleScreenState extends State<TitleScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _fadeController;
  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..forward();
  }
  @override void dispose() { _fadeController.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: _ScreenBgm(
          asset: 'audio/1Dawn After the War (Remastered).m4a',
          child: SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: Center(
                    child: AnimatedBuilder(
                      animation: _fadeController,
                      builder: (context, child) {
                        final t = Curves.easeOutCubic.transform(_fadeController.value);
                        return Opacity(
                          opacity: .45 + .55 * t,
                          child: ImageFiltered(
                            imageFilter: ui.ImageFilter.blur(sigmaX: 12 * (1 - t), sigmaY: 12 * (1 - t)),
                            child: child,
                          ),
                        );
                      },
                      child: Image.asset('assets/title/title.png', fit: BoxFit.contain, width: double.infinity, height: double.infinity),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(28, 10, 28, 122),
                  child: SizedBox(
                    width: double.infinity,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () async {
                          _UiSounds.confirm();
                          final prefs = await SharedPreferences.getInstance();
                          final trainingDone = prefs.getBool('training_completed_v2') ?? false;
                          if (!context.mounted) return;
                          if (!trainingDone) {
                            Navigator.of(context).push(_quietTransitionRoute(const TrainingScreen()));
                            return;
                          }
                          final profileDone = prefs.getBool('player_profile_registered_v1') ?? false;
                          if (!profileDone) {
                            Navigator.of(context).push(_quietTransitionRoute(const PlayerRegistrationScreen()));
                            return;
                          }
                          await _GameGuide.showIntroIfNeeded(context);
                          if (context.mounted) {
                            Navigator.of(context).push(_quietTransitionRoute(const MainMenuScreen()));
                          }
                        },
                        borderRadius: BorderRadius.circular(3),
                        child: Ink(
                          decoration: BoxDecoration(
                            color: const Color(0xD914171B),
                            borderRadius: BorderRadius.circular(3),
                            border: Border.all(color: const Color(0xFF9AA0A8), width: 1),
                          ),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 15),
                            child: Column(mainAxisSize: MainAxisSize.min, children: [
                              Text('START', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 5, color: Color(0xFFE5E7EA))),
                              SizedBox(height: 5),
                              SizedBox(width: 56, child: Divider(height: 1, thickness: 1, color: Color(0xFF777D85))),
                            ]),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

// First-time local profile setup. Online identity will be bound to a server later.
class PlayerRegistrationScreen extends StatefulWidget {
  const PlayerRegistrationScreen({super.key});
  @override State<PlayerRegistrationScreen> createState() => _PlayerRegistrationScreenState();
}

class _PlayerRegistrationScreenState extends State<PlayerRegistrationScreen> {
  final TextEditingController _name = TextEditingController();
  String _icon = 'arts';
  bool _saving = false;

  @override void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    final name = _name.text.trim();
    if (name.isEmpty || name.runes.length > 8 || _saving) return;
    if (_ProfileText.blocked(name)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text("使用できない文字列が含まれています"))); return; }
    setState(() => _saving = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      // Persist the identifier once. It is not yet an authenticated online ID.
      final existingId = prefs.getString('player_local_id_v1');
      final random = math.Random.secure();
      final localId = existingId ??
          '${DateTime.now().microsecondsSinceEpoch.toRadixString(16)}-'
          '${random.nextInt(0x7fffffff).toRadixString(16)}';
      await prefs.setString('player_local_id_v1', localId);
      await prefs.setString('player_name_v1', name);
      await prefs.setString('player_icon_v1', _icon);
      await prefs.setBool('player_profile_registered_v1', true);
      unawaited(_RemoteProfile.syncQuietly());
      if (!mounted) return;
      _UiSounds.confirm();
      Navigator.of(context).pushReplacement(_quietTransitionRoute(const MainMenuScreen()));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('登録情報を保存できませんでした。もう一度お試しください。')),
      );
      setState(() => _saving = false);
    }
  }

  Widget _iconChoice(String id, String label, String asset) {
    final selected = _icon == id;
    return Expanded(
      child: InkWell(
        onTap: _saving ? null : () { _UiSounds.tap(); setState(() => _icon = id); },
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFF2D2920) : const Color(0xFF17191C),
            border: Border.all(color: selected ? const Color(0xFFE0B967) : const Color(0xFF555A60), width: selected ? 2 : 1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AspectRatio(aspectRatio: 1, child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Image.asset(asset, fit: BoxFit.cover),
            )),
            const SizedBox(height: 9),
            Text(label, style: TextStyle(color: selected ? const Color(0xFFE0B967) : Colors.white, fontWeight: FontWeight.bold)),
            const SizedBox(height: 3),
            Text(selected ? '選択中' : '無料', style: TextStyle(fontSize: 11, color: selected ? const Color(0xFFE0B967) : Colors.white60)),
          ]),
        ),
      ),
    );
  }

  @override Widget build(BuildContext context) {
    final valid = _name.text.trim().isNotEmpty && _name.text.trim().runes.length <= 8;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF0C0F13),
        body: SafeArea(child: Center(child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('PLAYER REGISTRATION', textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFE0B967), fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2)),
              const SizedBox(height: 8),
              const Text('プレイヤー登録', textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 30),
              const Text('PLAYER NAME', style: TextStyle(color: Color(0xFFE0B967), letterSpacing: 2)),
              const SizedBox(height: 9),
              TextField(
                controller: _name, enabled: !_saving, maxLength: 8,
                maxLengthEnforcement: MaxLengthEnforcement.enforced,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'プレイヤー名を入力', hintStyle: TextStyle(color: Colors.white38),
                  counterStyle: TextStyle(color: Colors.white54),
                  enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF656B73))),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFFE0B967))),
                ),
              ),
              const SizedBox(height: 16),
              const SizedBox(height: 20),
              const Text('SELECT ICON', style: TextStyle(color: Color(0xFFE0B967), letterSpacing: 2)),
              const SizedBox(height: 12),
              Row(children: [
                _iconChoice('arts', 'アーツ', 'assets/profile/arts.webp'),
                const SizedBox(width: 14),
                _iconChoice('rei', 'レイ', 'assets/profile/rei.webp'),
              ]),
              const SizedBox(height: 12),
              const Text('どちらのアイコンも、あとから無料で切り替えられます。',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 28),
              FilledButton(
                onPressed: valid && !_saving ? _register : null,
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB9934D),
                  foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 17)),
                child: Text(_saving ? '登録中…' : '登録してメニューへ', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          )),
        ))),
      ),
    );
  }
}

// Local profile display and free starter-icon editing.
// Paid name changes are intentionally not charged until the chip ledger exists.
// Reuse the exact existing combat lines for profile selection.
const _profileBattleLines = <String, Map<String, String>>{
      '帝': {'melee':'……！！','ranged':'消え去れ。','suppress':'どうした。','move':'……。','merge':'……。','suppressDestroy':'終わりだ。'},
      '剣': {'melee':'切り捨てる。','ranged':'これでいいだろう。','suppress':'逃げてみろ……。','move':'この距離だな……。','merge':'行くぞ……！','suppressDestroy':'とどめだ。'},
      '盾': {'melee':'これでいいかしら。','ranged':'ん……！！','suppress':'あらら、、、','move':'ん～とりあえずこうね。','merge':'さて、と……。','suppressDestroy':'可哀想だけど……！'},
      '砲': {'melee':'ハハハハハ！！','ranged':'ワタシノテガラダ！','suppress':'ンン……！！イイゾ！！','move':'コッチダ！！','merge':'コレデドウカナ！','suppressDestroy':'ンー！キモチイイ！'},
      '王': {'melee':'これでどうだい！？','ranged':'僕をフリーにしたら……。','suppress':'制圧完了！','move':'おっとっと！','merge':'共に闘おう！','suppressDestroy':'ごめん！！'},
      '闘': {'melee':'オラオラオラ！！','ranged':'ここだろう？','suppress':'逃がさねえぞ。','move':'急かすなよ。','merge':'俺達の力見せてやろうぜ。','suppressDestroy':'あばよ……！'},
      '護': {'melee':'おー当たった！w','ranged':'あーそこにいちゃいけない！','suppress':'制圧しちゃった！','move':'逃げろ～！','merge':'ちょっとここで休憩w','suppressDestroy':'あ、やっちゃった！'},
      '仕': {'melee':'そこだ！！','ranged':'狙い撃ち～！','suppress':'逃げてみなさいよ！','move':'やばい！退散～！','merge':'お茶を濁すわ！','suppressDestroy':'いつまでそこにいるのよ。'},
      '騎': {'melee':'逃げきれん。','ranged':'……。','suppress':'そう慌てるな。','move':'時間を稼ぐ。','merge':'やれやれ。','suppressDestroy':'悪かったな。'},
      '将': {'melee':'退場してもらうわ。','ranged':'失敗だったわね。','suppress':'あら、こんにちは。','move':'退避する。','merge':'また会ったわね。','suppressDestroy':'仕方ないわね。'},
      '官': {'melee':'ぬるいな。','ranged':'こんなものか？','suppress':'さあ、どうした。','move':'こっちだ。','merge':'合流完了。','suppressDestroy':'予定変更だ。'},
      '軍': {'melee':'潰せ。豪竜。','ranged':'耐えられるか？','suppress':'もう遅い。','move':'この力強さ、本物だ。','merge':'今、見せてやる。','suppressDestroy':'タイムリミットだ。'},
      '博': {'melee':'こんなものも避けられないのか。','ranged':'雨あられ……。','suppress':'困ったものだな。','move':'フ、先を急ぐか。','merge':'私の後ろにいるといい。','suppressDestroy':'気の毒だが……。'},
      '槍': {'melee':'この一発はデカいぜ。','suppress':'よーし、OK！','move':'お前ら、逃げるぞ！','merge':'俺についてこい！','mergedMove':'お前も来い！'},
      '迅': {'melee':'これでも！！','suppress':'このやろ！！','move':'速いな、俺！','merge':'いくぜ！！','mergedMove':'一緒に行くぞ！！'},
      '進': {'melee':'案外いけるな……。','suppress':'こいつをこうして……。','move':'身体が軽い……！','merge':'こっからどーすんだ？','mergedMove':'二人ならいけるか……。'},
      '亜': {'melee':'うおおおお！！','suppress':'うおあ！！？','move':'ま、まってくれよ！！','merge':'今日はオレが前やるの！？','mergedMove':'今日は俺がリーダー！'},
    };

const _profileKuruLines = <String, String>{
        'melee':'フッ……。',
        'ranged':'手に馴染むな。',
        'suppress':'久しぶりなんだ。ゆっくりいこう。',
        'move':'こっちか？',
        'merge':'フフ……久しぶりだな。',
        'form1':'頃合だ。',
        'form2':'白兵戦と行こうか……。',
        'form3':'弾幕を張る。',
        'suppressDestroy':'少し寝ていろ。',
      };

class _ProfileQuoteChoice {
  final String id, pilot, line;
  const _ProfileQuoteChoice(this.id, this.pilot, this.line);
}

List<_ProfileQuoteChoice> _availableProfileQuotes() {
  final groups = <List<_UnitDbEntry>>[
    _UnitDatabaseScreenState.king,
    if (_StoryProgress.knightUnlocked) _UnitDatabaseScreenState.knight,
    if (_StoryProgress.emperorUnlocked) _UnitDatabaseScreenState.emperor,
    if (_StoryProgress.strasseUnlocked) _UnitDatabaseScreenState.strasse,
    if (_HiddenUnlocks.goryu) [_UnitDatabaseScreenState.goryu],
  ];
  final choices = <_ProfileQuoteChoice>[];
  for (final group in groups) {
    for (final unit in group) {
      choices.add(_ProfileQuoteChoice('${unit.piece}:database', unit.pilot, unit.quote));
      final lines = _profileBattleLines[unit.piece];
      if (lines != null) {
        for (final entry in lines.entries) {
          choices.add(_ProfileQuoteChoice('${unit.piece}:${entry.key}', unit.pilot, entry.value));
        }
      }
    }
  }
  if (_MasterProgress.masterUnlocked) {
    for (final item in MasterUnitDatabaseScreen._items.skip(3)) {
      if (item.person != null && item.quote != null) {
        choices.add(_ProfileQuoteChoice('master:${item.title}', item.person!, item.quote!));
      }
    }
  }
  if (_HiddenUnlocks.kuru) {
    choices.add(const _ProfileQuoteChoice('kuru:silent', 'クル', '……。'));
    for (final entry in _profileKuruLines.entries) {
      choices.add(_ProfileQuoteChoice('kuru:${entry.key}', 'クル', entry.value));
    }
  }
  // Never show the same quote twice for a character (e.g. unlocked forms).
  final seen = <String>{};
  return choices.where((c) => seen.add('${c.pilot}:${c.line}')).toList();
}

class _ProfileIcon {
  final String id, label, group;
  final int cost;
  const _ProfileIcon(this.id, this.label, this.group, this.cost);
  bool get unlocked => switch (group) {
    'KING' => true,
    'KNIGHT' => _StoryProgress.knightUnlocked,
    'EMPEROR' => _StoryProgress.emperorUnlocked,
    'STRASSE' => _StoryProgress.strasseUnlocked,
    'MASTER' => _MasterProgress.masterUnlocked,
    'KURU' => _HiddenUnlocks.kuru,
    _ => false,
  };
  static const all = <_ProfileIcon>[
    _ProfileIcon('arts', 'アーツ', 'KING', 0),
    _ProfileIcon('rei', 'レイ', 'KING', 0),
    _ProfileIcon('ark', 'アーキン', 'KING', 500),
    _ProfileIcon('jake', 'ジェイク', 'KING', 500),
    _ProfileIcon('blue', 'ブル', 'KNIGHT', 500),
    _ProfileIcon('oath', 'オース', 'KNIGHT', 500),
    _ProfileIcon('fan', 'ファン', 'KNIGHT', 500),
    _ProfileIcon('gil', 'ギル', 'KNIGHT', 500),
    _ProfileIcon('emperor', '皇帝', 'EMPEROR', 500),
    _ProfileIcon('cannon', '砲', 'EMPEROR', 500),
    _ProfileIcon('sword', '剣', 'EMPEROR', 500),
    _ProfileIcon('shield', '盾', 'EMPEROR', 500),
    _ProfileIcon('leader', 'リーダ', 'STRASSE', 500),
    _ProfileIcon('mite', 'ミテ', 'STRASSE', 500),
    _ProfileIcon('traum', 'トラーム', 'STRASSE', 500),
    _ProfileIcon('mike', 'マイク', 'STRASSE', 500),
    _ProfileIcon('master_ark', 'アーキン', 'MASTER', 1000),
    _ProfileIcon('master_blue', 'ブル', 'MASTER', 1000),
    _ProfileIcon('master_emperor', '皇帝', 'MASTER', 1000),
    _ProfileIcon('kuru', 'クル', 'KURU', 1500),
  ];
  static Set<String> owned(SharedPreferences p) => {'arts', 'rei', ...?p.getStringList('profile_owned_icons_v1')};
  static int extraSpent = 0;
  static int balance(Set<String> owned) {
    final earned = 100 + 50 * BattleUnit.values.fold<int>(0, (sum, u) => sum + _MasterProgress.wins(u));
    final spent = all.where((i) => owned.contains(i.id)).fold<int>(0, (sum, i) => sum + i.cost);
    return math.max(0, earned - spent - extraSpent);
  }
}

class _ProfileText {
  // Preliminary local filter; authoritative moderation is required on the server.
  static bool blocked(String value) {
    final normalized = String.fromCharCodes(value.runes.map((c) {
      if (c >= 0xff01 && c <= 0xff5e) c -= 0xfee0;
      if (c >= 0x30a1 && c <= 0x30f6) c -= 0x60;
      return c;
    })).toLowerCase().replaceAll(RegExp(r'[\s\u200b-\u200f\u3000\u3001-\u303f\u30fb\u30fc!-/:-@\[-`{-~]'), '');
    return ['殺すぞ','死ね','しね','fuck','nigger','ちんこ','ちんぽ','まんこ','おまんこ','せっくす','せくす','せくっす','せっくうす','せくうす','せつくす','ふぇら','おなにー','おなに','性交','強姦','レイプ','れいぷ','精液','射精','sex','penis','vagina','pussy','ﾁﾝｺ','ﾁﾝﾎﾟ','ﾏﾝｺ','ｾｯｸｽ','えっちしたい','えっちしよう','えっちして','えっちしませんか','えっちしよ','えろ写真','えろ写','えろ画像','えろ動画','えろい写真','裸の写真','裸写真','裸見せ','裸みせ','はだか見せ','はだかみせ','脱いで','ぬいで'].any((word)=>normalized.contains(word));
  }
}

class _LocalPlayerProfile {
  final String name;
  final String icon;
  final String quoteId;
  final Set<String> owned;
  final int rating, grade;
  final String title;
  const _LocalPlayerProfile(this.name, this.icon, this.quoteId, this.owned, this.rating, this.grade, this.title);
  static Widget portrait(String asset, {BoxFit fit = BoxFit.cover}) => Image.asset(asset, fit: fit);

  static Future<_LocalPlayerProfile> load() async {
    final prefs = await SharedPreferences.getInstance();
    _ProfileIcon.extraSpent = prefs.getInt('profile_extra_spent_v1') ?? 0;
    final owned = _ProfileIcon.owned(prefs);
    final selected = prefs.getString('player_icon_v1') ?? 'arts';
    return _LocalPlayerProfile(
      prefs.getString('player_name_v1') ?? 'PLAYER',
      _ProfileIcon.all.any((i) => i.id == selected && i.unlocked && owned.contains(i.id)) ? selected : 'arts',
      prefs.getString('player_quote_v1') ?? '闘:database',
      owned,
      prefs.getInt('competitive_rating') ?? 1000,
      (prefs.getInt('competitive_grade') ?? 0).clamp(0,12).toInt(),
      prefs.getString('competitive_selected_title') ?? '',
    );
  }

  static String image(String icon) =>
      _ProfileIcon.all.any((i) => i.id == icon) ? 'assets/profile/$icon.webp' : 'assets/profile/arts.webp';
}


const _profileExtras = <(String,String,String,int,String)>[
  ('bg', 'bg_23789', '荒野', 200, 'assets/profile/bg_23789.png'),
  ('bg', 'bg_23791', '軍事基地の格納庫', 300, 'assets/profile/bg_23791.png'),
  ('bg', 'bg_23792', '荘厳な城内', 500, 'assets/profile/bg_23792.png'),
  ('bg', 'bg_23793', '月夜の花畑', 300, 'assets/profile/bg_23793.png'),
  ('bg', 'bg_23794', '水晶洞窟', 400, 'assets/profile/bg_23794.png'),
  ('bg', 'bg_23795', 'オーロラが広がる雪原', 400, 'assets/profile/bg_23795.png'),
  ('bg', 'bg_23796', 'クマのぬいぐるみ', 300, 'assets/profile/bg_23796.png'),
  ('bg', 'bg_23797', '温泉', 300, 'assets/profile/bg_23797.png'),
  ('bg', 'bg_23798', '札束の山', 1000, 'assets/profile/bg_23798.png'),
  ('将来の夢', 'fun_0_0', '英雄', 0, ''),
  ('将来の夢', 'fun_0_1', '平和に暮らす', 0, ''),
  ('将来の夢', 'fun_0_2', '旅人', 0, ''),
  ('将来の夢', 'fun_0_3', '有名人', 0, ''),
  ('将来の夢', 'fun_0_4', '特にない', 0, ''),
  ('将来の夢', 'fun_0_5', '皇帝', 200, ''),
  ('将来の夢', 'fun_0_6', '金持ち', 100, ''),
  ('将来の夢', 'fun_0_7', '隠居', 100, ''),
  ('将来の夢', 'fun_0_8', '無職', 200, ''),
  ('将来の夢', 'fun_0_9', '赤ちゃん', 300, ''),
  ('戦う理由', 'fun_1_0', '正義', 0, ''),
  ('戦う理由', 'fun_1_1', '仲間のため', 0, ''),
  ('戦う理由', 'fun_1_2', '生きるため', 0, ''),
  ('戦う理由', 'fun_1_3', '強くなるため', 0, ''),
  ('戦う理由', 'fun_1_4', 'なんとなく', 0, ''),
  ('戦う理由', 'fun_1_5', '金のため', 100, ''),
  ('戦う理由', 'fun_1_6', 'モテたい', 150, ''),
  ('戦う理由', 'fun_1_7', '暇つぶし', 100, ''),
  ('戦う理由', 'fun_1_8', '断れなかった', 200, ''),
  ('戦う理由', 'fun_1_9', '忘れた', 250, ''),
  ('好きなもの', 'fun_2_0', '勝利', 0, ''),
  ('好きなもの', 'fun_2_1', '仲間', 0, ''),
  ('好きなもの', 'fun_2_2', 'Z', 0, ''),
  ('好きなもの', 'fun_2_3', 'ごはん', 0, ''),
  ('好きなもの', 'fun_2_4', '睡眠', 0, ''),
  ('好きなもの', 'fun_2_5', 'チップ', 50, ''),
  ('好きなもの', 'fun_2_6', 'お金', 100, ''),
  ('好きなもの', 'fun_2_7', '静かな時間', 50, ''),
  ('好きなもの', 'fun_2_8', '自分', 150, ''),
  ('好きなもの', 'fun_2_9', '何もしたくない時間', 200, ''),
  ('苦手なもの', 'fun_3_0', '敗北', 0, ''),
  ('苦手なもの', 'fun_3_1', '朝', 0, ''),
  ('苦手なもの', 'fun_3_2', '強い相手', 0, ''),
  ('苦手なもの', 'fun_3_3', '空腹', 0, ''),
  ('苦手なもの', 'fun_3_4', '集団行動', 0, ''),
  ('苦手なもの', 'fun_3_5', '面倒ごと', 50, ''),
  ('苦手なもの', 'fun_3_6', '説教', 100, ''),
  ('苦手なもの', 'fun_3_7', '努力', 150, ''),
  ('苦手なもの', 'fun_3_8', '人付き合い', 100, ''),
  ('苦手なもの', 'fun_3_9', 'だいたい全部', 250, ''),
  ('戦場での役割', 'fun_4_0', 'エース', 0, ''),
  ('戦場での役割', 'fun_4_1', '参謀', 0, ''),
  ('戦場での役割', 'fun_4_2', '守備役', 0, ''),
  ('戦場での役割', 'fun_4_3', '切り込み隊長', 0, ''),
  ('戦場での役割', 'fun_4_4', '支援役', 0, ''),
  ('戦場での役割', 'fun_4_5', '囮', 100, ''),
  ('戦場での役割', 'fun_4_6', '応援', 100, ''),
  ('戦場での役割', 'fun_4_7', '見学', 250, ''),
  ('戦場での役割', 'fun_4_8', '帰りたい人', 250, ''),
  ('戦場での役割', 'fun_4_9', 'たまたま来た人', 300, ''),
  ('自分を一言で', 'fun_5_0', '凡人', 0, ''),
  ('自分を一言で', 'fun_5_1', '努力家', 0, ''),
  ('自分を一言で', 'fun_5_2', '平和主義者', 0, ''),
  ('自分を一言で', 'fun_5_3', '自由人', 0, ''),
  ('自分を一言で', 'fun_5_4', '負けず嫌い', 0, ''),
  ('自分を一言で', 'fun_5_5', '天才', 150, ''),
  ('自分を一言で', 'fun_5_6', '危険人物', 200, ''),
  ('自分を一言で', 'fun_5_7', '人見知り', 50, ''),
  ('自分を一言で', 'fun_5_8', '赤ちゃん', 300, ''),
  ('自分を一言で', 'fun_5_9', 'わからない', 200, ''),
  ('欲しいもの', 'fun_6_0', '強さ', 0, ''),
  ('欲しいもの', 'fun_6_1', '仲間', 0, ''),
  ('欲しいもの', 'fun_6_2', '愛', 0, ''),
  ('欲しいもの', 'fun_6_3', '自由', 0, ''),
  ('欲しいもの', 'fun_6_4', '休み', 0, ''),
  ('欲しいもの', 'fun_6_5', 'お金', 100, ''),
  ('欲しいもの', 'fun_6_6', 'チップ', 50, ''),
  ('欲しいもの', 'fun_6_7', '新しいZ', 150, ''),
  ('欲しいもの', 'fun_6_8', '睡眠時間', 100, ''),
  ('欲しいもの', 'fun_6_9', '全部', 250, ''),
  ('大事なもの', 'fun_7_0', '仲間', 0, ''),
  ('大事なもの', 'fun_7_1', '家族', 0, ''),
  ('大事なもの', 'fun_7_2', '誇り', 0, ''),
  ('大事なもの', 'fun_7_3', '約束', 0, ''),
  ('大事なもの', 'fun_7_4', '命', 0, ''),
  ('大事なもの', 'fun_7_5', '自由', 50, ''),
  ('大事なもの', 'fun_7_6', 'お金', 100, ''),
  ('大事なもの', 'fun_7_7', '自分', 150, ''),
  ('大事なもの', 'fun_7_8', 'ごはん', 100, ''),
  ('大事なもの', 'fun_7_9', '特にない', 200, ''),
  ('座右の銘', 'fun_8_0', '生きて帰る', 0, ''),
  ('座右の銘', 'fun_8_1', '急がば回れ', 0, ''),
  ('座右の銘', 'fun_8_2', '明日は明日の風が吹く', 0, ''),
  ('座右の銘', 'fun_8_3', 'やる時はやる', 0, ''),
  ('座右の銘', 'fun_8_4', 'なんとかなる', 0, ''),
  ('座右の銘', 'fun_8_5', '勝てばいい', 150, ''),
  ('座右の銘', 'fun_8_6', '無理はしない', 50, ''),
  ('座右の銘', 'fun_8_7', '寝れば治る', 150, ''),
  ('座右の銘', 'fun_8_8', '金がすべて', 200, ''),
  ('座右の銘', 'fun_8_9', '知らんけど', 300, ''),
  ('もし戦争が終わったら', 'fun_9_0', '旅に出る', 0, ''),
  ('もし戦争が終わったら', 'fun_9_1', '家に帰る', 0, ''),
  ('もし戦争が終わったら', 'fun_9_2', '店を開く', 0, ''),
  ('もし戦争が終わったら', 'fun_9_3', 'のんびり暮らす', 0, ''),
  ('もし戦争が終わったら', 'fun_9_4', '結婚する', 0, ''),
  ('もし戦争が終わったら', 'fun_9_5', 'Zを降りる', 50, ''),
  ('もし戦争が終わったら', 'fun_9_6', 'いっぱい寝る', 100, ''),
  ('もし戦争が終わったら', 'fun_9_7', '働かない', 250, ''),
  ('もし戦争が終わったら', 'fun_9_8', 'また戦う', 200, ''),
  ('もし戦争が終わったら', 'fun_9_9', '何も考えてない', 200, ''),
];

class _ProfileExtrasScreen extends StatefulWidget {
  const _ProfileExtrasScreen();
  @override State<_ProfileExtrasScreen> createState() => _ProfileExtrasScreenState();
}
class _ProfileExtrasScreenState extends State<_ProfileExtrasScreen> {
  SharedPreferences? prefs;
  bool busy = false;
  @override void initState() { super.initState(); SharedPreferences.getInstance().then((p) { if(mounted) setState(() { prefs=p; }); }); }
  Set<String> get owned => {...?prefs?.getStringList('profile_extras_owned_v1')};
  String selected(String g) => prefs?.getString('profile_extra_selected_$g') ?? '';
  Future<void> choose((String,String,String,int,String) item) async {
    final p=prefs!; if(busy) return;
    final (g,id,name,cost,asset)=item;
    final o=owned; final price=o.contains(id)?0:cost;
    if(price>_ProfileIcon.balance(_ProfileIcon.owned(p))) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('チップが不足しています'))); return; }
    final displayFull = g!='bg' && selected(g).isEmpty && id.isNotEmpty && _profileExtras.map((x)=>x.$1).toSet().where((x)=>x!='bg'&&selected(x).isNotEmpty).length>=5;
    if(displayFull && price==0) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('表示は5項目までです。別の項目を解除してください。')));
      return;
    }
    setState(()=>busy=true);
    try {
      if(price>0) {
        final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text('$name を購入'),content:Text(displayFull ? '$price CHIP 消費しますか？ 購入のみ行い、現在の表示5項目は変更しません。' : '$price CHIP 消費しますか？'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('取消')),TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('購入'))]));
        if(ok!=true) return;
        final old=p.getInt('profile_extra_spent_v1')??0;
        if(!await p.setInt('profile_extra_spent_v1',old+price)) return;
        if(!await p.setStringList('profile_extras_owned_v1',[...o,id])) { await p.setInt('profile_extra_spent_v1',old); return; }
        _ProfileIcon.extraSpent=old+price;
      }
      if(!displayFull) {
        await p.setString('profile_extra_selected_$g',id);
      } else if(mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('購入しました。表示するには別の項目を解除してください。')));
      }
    } finally { if(mounted) setState(()=>busy=false); }
  }
  @override Widget build(BuildContext context) {
    final p=prefs; if(p==null) return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final groups=_profileExtras.map((x)=>x.$1).toSet();
    String asset(String g) { for(final x in _profileExtras) { if(x.$2==selected(g)) return x.$5; } return ''; }
    final bg=asset('bg');
    return Scaffold(appBar:AppBar(title:const Text('プロフィール装飾')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('CHIP ${_ProfileIcon.balance(_ProfileIcon.owned(p))}'),
      Container(height:260,decoration:BoxDecoration(color:Colors.black,image:bg.isEmpty?null:DecorationImage(image:AssetImage(bg),fit:BoxFit.cover)),child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[SizedBox(width:110,height:110,child:Stack(fit:StackFit.expand,children:[Image.asset(_LocalPlayerProfile.image(p.getString('player_icon_v1')??'arts'))])),Container(color:Colors.black54,child:Text(p.getString('player_name_v1')??'PLAYER',style:const TextStyle(color:Colors.white,fontSize:20))),for(final g in groups.where((g)=>g!='bg')) for(final x in _profileExtras.where((x)=>x.$1==g&&x.$2==selected(g))) Container(color:Colors.black54,child:Text('$g：${x.$3}',style:const TextStyle(color:Colors.white))) ]))),
      for(final g in groups) ExpansionTile(title:Text(g=='bg'?'背景':g),subtitle:Text(selected(g).isEmpty?'未設定':_profileExtras.firstWhere((x)=>x.$2==selected(g)).$3),children:[
        ListTile(title:const Text('設定なし'),onTap:busy?null:()=>choose((g,'','設定なし',0,''))),
        for(final x in _profileExtras.where((x)=>x.$1==g)) ListTile(leading:x.$5.isEmpty?null:Image.asset(x.$5,width:48,height:48,fit:BoxFit.contain),title:Text(x.$3),subtitle:Text(selected(g)==x.$2?'使用中':x.$4==0?'無料':owned.contains(x.$2)?'購入済み':'${x.$4} CHIP'),onTap:busy?null:()=>choose(x)),
      ])
    ]));
  }
}

// Local display cache for future authoritative random-match results.
// Development onlineTest CPU matches update this local ledger until server migration.
class _CompetitiveProfile {
  static const ranks = ['E','D','C','B','A','S','SS','SSS'];
  static const grades = ['二等兵','一等兵','伍長','軍曹','曹長','少尉','中尉','大尉','少佐','中佐','大佐','准将','少将'];
  static const winsRequired = [0,3,10,20,35,50,75,100,150,200,300,400,500];
  static const rankRequired = [0,0,0,1,1,2,2,3,3,4,4,5,6];
  static const titles = <(String,String,int)>[
    ('勇者の卵','wins',1),('新米騎士','wins',5),('期待の新星','wins',10),
    ('七転び八起き','losses',10),('小さな英雄','wins',20),('好敵手','matches',30),
    ('獅子心王','king',50),('青龍','knight',50),('皇帝','emperor',50),
    ('疾風迅雷','strasse',50),('覇者','master',50),('豪竜','goryu',50),
    ('戦場の亡霊','ranged',100),('闘神','melee',100),('征服者','capture',100),
    ('百戦錬磨','matches',100),('歴戦の勇士','matches',500),('不沈','bestStreak',10),
    ('不屈の魂','losses',100),('黄金の覇者','spent',10000),('枯れない花','ending',1),
  ];
  static int rank(int rating) => rating < 900 ? 0 : math.min(7, 1 + (rating-900) ~/ 200);
  static int delta(int rating,int opponent,bool won) => (32*((won?1:0)-1/(1+math.pow(10,(opponent-rating)/400)))).round();
  static int grade(int wins,int highest) {
    var result=0;
    for(var i=0;i<grades.length;i++) { if(wins>=winsRequired[i] && highest>=rankRequired[i]) result=i; }
    return result;
  }
  static int count(SharedPreferences p,String key) {
    if(key=='ending') return _HiddenUnlocks.kuru?1:0;
    if(key=='spent') return (p.getInt('profile_extra_spent_v1')??0)+_ProfileIcon.all.where((i)=>_ProfileIcon.owned(p).contains(i.id)).fold<int>(0,(a,i)=>a+i.cost);
    return p.getInt('competitive_$key')??0;
  }
  // Development-only simulated random match; replace with server results before release.
  static Future<void> recordTestMatch(bool won, BattleUnit? unit, int ranged, int melee, int capture, bool goryu) async {
    final p = await SharedPreferences.getInstance();
    Future<void> add(String key, int n) async { await p.setInt('competitive_$key', (p.getInt('competitive_$key') ?? 0) + n); }
    final rating = p.getInt('competitive_rating') ?? 1000;
    final next = rating + delta(rating, 1000, won);
    final highest = math.max(p.getInt('competitive_highest_rank') ?? 1, rank(next));
    await p.setInt('competitive_rating', next);
    await p.setInt('competitive_highest_rank', highest);
    await add('matches', 1);
    await add(won ? 'wins' : 'losses', 1);
    if (won && unit != null) await add(unit.name, 1);
    if (won && goryu) await add('goryu', 1);
    await add('ranged', ranged); await add('melee', melee); await add('capture', capture);
    final streak = won ? (p.getInt('competitive_streak') ?? 0) + 1 : 0;
    await p.setInt('competitive_streak', streak);
    await p.setInt('competitive_bestStreak', math.max(streak, p.getInt('competitive_bestStreak') ?? 0));
    final oldGrade = p.getInt('competitive_grade') ?? 0;
    final newGrade = grade(count(p, 'wins'), highest);
    if (newGrade > oldGrade) { await p.setInt('competitive_grade', newGrade); await p.setBool('competitive_promotion_pending', true); }
    await unlocked(p);
  }
  static Future<Set<String>> unlocked(SharedPreferences p) async {
    final owned=<String>{...?p.getStringList('competitive_titles')};
    for(final t in titles) { if(count(p,t.$2)>=t.$3) owned.add(t.$1); }
    await p.setStringList('competitive_titles',owned.toList());
    return owned;
  }
}

class _CompetitiveProfilePanel extends StatefulWidget {
  const _CompetitiveProfilePanel({super.key});
  @override State<_CompetitiveProfilePanel> createState()=>_CompetitiveProfilePanelState();
}
class _CompetitiveProfilePanelState extends State<_CompetitiveProfilePanel> {
  SharedPreferences? prefs;
  Set<String> owned={};
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    final o=await _CompetitiveProfile.unlocked(p);
    if(mounted) setState((){prefs=p;owned=o;});
  }
  @override Widget build(BuildContext context){
    final p=prefs;if(p==null)return const SizedBox.shrink();
    final rating=p.getInt('competitive_rating')??1000;
    final highest=p.getInt('competitive_highest_rank')??1;
    final grade=p.getInt('competitive_grade')??0;
    final selected=p.getString('competitive_selected_title')??'';
    return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('ランク ${_CompetitiveProfile.ranks[_CompetitiveProfile.rank(rating)]} / $rating'),
      Text('最高到達ランク ${_CompetitiveProfile.ranks[highest.clamp(0,7).toInt()]}'),
      Text('階級 ${_CompetitiveProfile.grades[grade.clamp(0,12).toInt()]}'),
      Text('戦績 ${_CompetitiveProfile.count(p,"wins")}勝 ${_CompetitiveProfile.count(p,"losses")}敗'),
      const Text('開発中：仮ONLINEの戦績（本番移行時にリセット）',style:TextStyle(color:Colors.white60,fontSize:12)),
      DropdownButton<String>(isExpanded:true,value:owned.contains(selected)?selected:'',items:[
        const DropdownMenuItem(value:'',child:Text('称号なし')),
        for(final t in _CompetitiveProfile.titles) if(owned.contains(t.$1)) DropdownMenuItem(value:t.$1,child:Text(t.$1)),
      ],onChanged:(v) async {if(v!=null){await p.setString('competitive_selected_title',v);if(mounted)setState((){});}}),
    ]);
  }
}

class PlayerProfileScreen extends StatefulWidget {
  const PlayerProfileScreen({super.key});
  @override State<PlayerProfileScreen> createState() => _PlayerProfileScreenState();
}

class _PlayerProfileScreenState extends State<PlayerProfileScreen> {
  late Future<_LocalPlayerProfile> _profile;
  bool _saving = false;
  @override void initState() { super.initState(); _profile = _LocalPlayerProfile.load(); WidgetsBinding.instance.addPostFrameCallback((_) => _showPromotion()); }
  Future<void> _showPromotion() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted || !(p.getBool('competitive_promotion_pending') ?? false)) return;
    final grade = (p.getInt('competitive_grade') ?? 0).clamp(0,12).toInt();
    await _showUnlockNotice(context, _UnlockNotice('PROMOTION', _CompetitiveProfile.grades[grade], '昇進'));
    await p.setBool('competitive_promotion_pending', false);
  }

  Future<void> _changeComment() async {
    final p=await SharedPreferences.getInstance();
    if (!mounted) return;
    var value=p.getString('player_comment_v1')??'';
    final next=await showDialog<String>(context:context,builder:(c)=>AlertDialog(
      title:const Text('一言コメント（無料）'),
      content:TextFormField(initialValue:value,maxLength:16,maxLengthEnforcement:MaxLengthEnforcement.enforced,onChanged:(v)=>value=v.trim()),
      actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('取消')),TextButton(onPressed:()=>Navigator.pop(c,value),child:const Text('保存'))]));
    if(!mounted||next==null) return;
    if(next.runes.length>16||_ProfileText.blocked(next)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('使用できないコメントです'))); return; }
    await p.setString('player_comment_v1',next);
    if(mounted) setState(()=>_profile=_LocalPlayerProfile.load());
  }

  Future<void> _changeName() async {
    if (_saving) return;
    final profile = await _profile;
    if (!mounted || _saving) return;
    if (_ProfileIcon.balance(profile.owned) < 300) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('チップが不足しています。'))); return;
    }
    String name = profile.name;
    final next = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      title: const Text('名前変更：300チップ'),
      content: TextFormField(initialValue: name, maxLength: 8, onChanged: (v) => name = v.trim()),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('キャンセル')),
        TextButton(onPressed: () { if (name.isNotEmpty && name.runes.length <= 8 && name != profile.name) Navigator.pop(c, name); }, child: const Text('確認'))],
    ));
    if (!mounted || next == null) return;
    if (_ProfileText.blocked(next)) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text("使用できない文字列が含まれています"))); return; }
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('名前変更'), content: Text('$next に300チップで変更しますか？'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('キャンセル')), TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('変更'))]));
    if (!mounted || ok != true || _saving) return;
    setState(() => _saving = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final spent = prefs.getInt('profile_extra_spent_v1') ?? 0;
      if (!await prefs.setInt('profile_extra_spent_v1', spent + 300)) throw StateError('save');
      if (!await prefs.setString('player_name_v1', next)) { await prefs.setInt('profile_extra_spent_v1', spent); throw StateError('save'); }
      _ProfileIcon.extraSpent = spent + 300;
      unawaited(_RemoteProfile.syncQuietly());
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('名前を保存できませんでした。')));
    } finally { if (mounted) setState(() { _saving = false; _profile = _LocalPlayerProfile.load(); }); }
  }

  Future<void> _changeIcon(String icon) async {
    if (_saving) return;
    final item = _ProfileIcon.all.firstWhere((i) => i.id == icon);
    if (!item.unlocked) return;
    setState(() => _saving = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final owned = _ProfileIcon.owned(prefs);
      if (!owned.contains(icon)) {
        if (_ProfileIcon.balance(owned) < item.cost) {
          if (mounted) {
            setState(() => _saving = false);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('チップが不足しています。')));
          }
          return;
        }
        if (!mounted) return;
        final confirmed = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
          title: Text(item.label), content: Text('${item.cost}チップで購入しますか？'),
          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('キャンセル')),
            TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('購入'))],
        ));
        if (!mounted) return;
        if (confirmed != true) { setState(() => _saving = false); return; }
        owned.add(icon);
        if (!await prefs.setStringList('profile_owned_icons_v1', owned.toList())) throw StateError('Purchase save failed');
      }
      final ok = await prefs.setString('player_icon_v1', icon);
      if (!ok) throw StateError('Icon could not be saved');
      unawaited(_RemoteProfile.syncQuietly());
      if (!mounted) return;
      _UiSounds.confirm();
      setState(() { _profile = _LocalPlayerProfile.load(); _saving = false; });
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('アイコンを保存できませんでした。')));
    }
  }

  Future<void> _changeQuote(String id) async {
    if (_saving || !_availableProfileQuotes().any((q) => q.id == id)) return;
    setState(() => _saving = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!await prefs.setString('player_quote_v1', id)) throw StateError('Quote save failed');
      if (!mounted) return;
      _UiSounds.confirm();
      setState(() { _profile = _LocalPlayerProfile.load(); _saving = false; });
    } catch (_) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('セリフを保存できませんでした。')));
    }
  }

  Widget _choice(_ProfileIcon item, _LocalPlayerProfile profile) {
    final icon = item.id, label = item.label;
    final active = icon == profile.icon;
    return InkWell(
      onTap: _saving ? null : () => _changeIcon(icon),
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF2D2920) : const Color(0xFF17191C),
          border: Border.all(color: active ? const Color(0xFFE0B967) : const Color(0xFF555A60), width: active ? 2 : 1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          AspectRatio(aspectRatio: 1, child: ClipRRect(borderRadius: BorderRadius.circular(4),
            child: Image.asset(_LocalPlayerProfile.image(icon), fit: BoxFit.cover))),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(color: active ? const Color(0xFFE0B967) : Colors.white, fontWeight: FontWeight.bold)),
          Text(active ? '使用中' : profile.owned.contains(icon) ? (item.cost == 0 ? '無料で変更' : '購入済み') : '${item.cost} CHIP', style: TextStyle(fontSize: 11, color: active ? const Color(0xFFE0B967) : Colors.white60)),
        ]),
      ),
    );
  }

  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF0C0F13),
    appBar: AppBar(title: const Text('PLAYER PROFILE')),
    body: FutureBuilder<_LocalPlayerProfile>(
      future: _profile,
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final profile = snap.data!;
        return SafeArea(child: Center(child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child:
            Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Text('PLAYER NAME', style: TextStyle(color: Color(0xFFE0B967), letterSpacing: 2)),
              const SizedBox(height: 8),
              Container(padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(border: Border.all(color: Colors.white38), borderRadius: BorderRadius.circular(6)),
                child: Text(profile.name, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
              const SizedBox(height: 8),
              TextButton(onPressed: _saving ? null : _changeName, child: const Text('名前変更：300チップ')),
              FutureBuilder<SharedPreferences>(future:SharedPreferences.getInstance(),builder:(_,snap)=>Text('一言コメント：${snap.data?.getString('player_comment_v1')??''}')),
              TextButton(onPressed:_saving?null:_changeComment,child:const Text('一言コメント変更：無料')),
              _CompetitiveProfilePanel(key: ValueKey(_ProfileIcon.extraSpent + _ProfileIcon.all.where((i) => profile.owned.contains(i.id)).fold<int>(0, (sum, i) => sum + i.cost))),
              TextButton(onPressed:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const _OwnProfilePreview())),child:const Text('詳細プロフィールを確認')),

              TextButton(onPressed: _saving ? null : () async { await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _ProfileExtrasScreen())); if(mounted) setState(() { _profile = _LocalPlayerProfile.load(); }); }, child: const Text('背景・遊びプロフィール')),
              const SizedBox(height: 32),
              const Text('SELECT ICON', style: TextStyle(color: Color(0xFFE0B967), letterSpacing: 2)),
              const SizedBox(height: 12),
              Text('CHIP ${_ProfileIcon.balance(profile.owned)}', style: const TextStyle(color: Color(0xFFE0B967))),
              for (final group in ['KING', 'KNIGHT', 'EMPEROR', 'STRASSE', 'MASTER', 'KURU'])
                if (_ProfileIcon.all.any((i) => i.group == group && i.unlocked)) ...[
                  const SizedBox(height: 14),
                  Text(group == 'KURU' ? 'クル' : group, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.74,
                    children: [for (final item in _ProfileIcon.all.where((i) => i.group == group && i.unlocked)) _choice(item, profile)]),
                ],
              const SizedBox(height: 28),
              const Text('SELECT QUOTE', style: TextStyle(color: Color(0xFFE0B967), letterSpacing: 2)),
              const SizedBox(height: 8),
              const Text('解禁済みユニットのキャラクターから選択できます。アイコンとは別に設定できます。',
                style: TextStyle(color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 12),
              ..._availableProfileQuotes().map((q) => RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text('「${q.line}」', style: const TextStyle(fontSize: 14)),
                subtitle: Text(q.pilot, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                value: q.id,
                groupValue: _availableProfileQuotes().any((c) => c.id == profile.quoteId)
                    ? profile.quoteId : '闘:database',
                onChanged: _saving ? null : (value) { if (value != null) _changeQuote(value); },
              )),
            ])),
        )));
      },
    ),
  );
}

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});
  @override State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen> {
  static const items = [
    ('BATTLE','作戦開始'), ('REAR LINE','オンライン拠点'), ('WATCH','リプレイ鑑賞'),
    ('TRAINING','訓練'), ('STORY','物語'), ('DATABASE','データベース'), ('RECORD','戦績'), ('OPTION','各種設定'),
  ];
  late Future<bool> _rear;
  late Future<_LocalPlayerProfile> _profile;
  @override void initState(){ super.initState(); _rear=_RearLineProgress.unlocked(); _profile=_LocalPlayerProfile.load(); }
  Future<void> _openProfile() async {
    _UiSounds.tap();
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PlayerProfileScreen()));
    if (mounted) setState(() => _profile = _LocalPlayerProfile.load());
  }
  @override Widget build(BuildContext context)=>FutureBuilder<bool>(future:_rear,builder:(context,snap){
    final rearUnlocked=snap.data??false;
    return Scaffold(
      appBar:AppBar(title:const SizedBox.shrink(),leading:_easyBackButton(context,onPressed:(){_AppBgm.play('audio/1Dawn After the War (Remastered).m4a');Navigator.of(context).pop();})),
      body:_ScreenBgm(asset:'audio/2War Room Protocol.mp3',child:SafeArea(child:Center(child:SingleChildScrollView(
        padding:const EdgeInsets.symmetric(vertical:24),
        child:Column(mainAxisSize:MainAxisSize.min,children:[
          FutureBuilder<_LocalPlayerProfile>(future:_profile,builder:(context,snap){
            final player=snap.data;
            if(player==null)return const SizedBox.shrink();
            return Padding(
              padding:const EdgeInsets.fromLTRB(24,0,24,20),
              child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),
                child:Material(color:const Color(0xFF17191C),borderRadius:BorderRadius.circular(8),
                  child:InkWell(onTap:_openProfile,borderRadius:BorderRadius.circular(8),
                    child:Container(padding:const EdgeInsets.all(10),
                      decoration:BoxDecoration(border:Border.all(color:const Color(0xFF806C49)),borderRadius:BorderRadius.circular(8)),
                      child:Row(children:[
                        ClipRRect(borderRadius:BorderRadius.circular(5),
                          child:SizedBox(width:58,height:58,child:_LocalPlayerProfile.portrait(_LocalPlayerProfile.image(player.icon)))),
                        const SizedBox(width:12),
                        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                          Text(player.name,maxLines:1,overflow:TextOverflow.ellipsis,
                            style:const TextStyle(color:Color(0xFFE0B967),fontSize:17,fontWeight:FontWeight.bold)),
                          const SizedBox(height:4),
                          Row(children:[const Text('プロフィールを編集',style:TextStyle(color:Colors.white60,fontSize:11)), const SizedBox(width:6), FutureBuilder<SharedPreferences>(future:SharedPreferences.getInstance(),builder:(_,snap)=> (snap.data?.getBool('competitive_promotion_pending')??false) ? Container(width:8,height:8,decoration:const BoxDecoration(color:Colors.red,shape:BoxShape.circle)) : const SizedBox.shrink())]),
                        ])),
                        const Icon(Icons.chevron_right,color:Color(0xFFE0B967)),
                      ])),
                  ),
                ),
              ),
            );
          }),
          for(final item in items)...[
            _MenuEntry(
              title:item.$1, subtitle:item.$2, enabled:item.$1!='REAR LINE'||rearUnlocked, unread:item.$1=='STORY'?_UnlockInbox.storyUnread:item.$1=='DATABASE'?_UnlockInbox.databaseUnread:false,
              onTap:item.$1=='BATTLE'?()async{await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const BattleMenuScreen()));if(mounted)setState((){_rear=_RearLineProgress.unlocked();_profile=_LocalPlayerProfile.load();});}
                :item.$1=='REAR LINE'?()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const RearLineScreen()))
                :item.$1=='TRAINING'?()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const TrainingScreen()))
                :item.$1=='STORY'?()async{await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const StoryListScreen()));if(mounted)setState((){});}
                :item.$1=='DATABASE'?()async{await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const DatabaseCategoryScreen()));if(mounted)setState((){});}
                :item.$1=='OPTION'?()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const _OptionScreen()))
                :item.$1=='RECORD'?()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const RecordScreen()))
                :()=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${item.$1} は仮組み中'))),
              onDisabledTap:item.$1=='REAR LINE'?()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('REAR LINE：TRAININGクリアで解禁'))) : null,
            ),
            const SizedBox(height:8),
          ]
        ]),
      )))),
    );
  });
}


class _FirebaseTestConnection {
  static Future<String>? _pending;
  static Future<String> connect() async {
    if (_pending != null) return await _pending!;
    final task = _connect();
    _pending = task;
    try { return await task; } finally { _pending = null; }
  }
  static Future<String> _connect() async {
    if (!Platform.isAndroid) throw UnsupportedError('Android test only');
    if (Firebase.apps.isEmpty) {
      await Firebase.initializeApp(options: const FirebaseOptions(
          apiKey: "AIzaSyDODrtRNehh87EnxM6v7pJoUnvhfPgQ2uE",
          appId: "1:494447149896:android:3106ae323c66d40043e97d",
          messagingSenderId: "494447149896",
          projectId: "zaamd-test",
          storageBucket: "zaamd-test.firebasestorage.app",
      ));
    }
    final auth = FirebaseAuth.instance;
    final user = auth.currentUser ?? (await auth.signInAnonymously()).user;
    if (user == null) throw StateError('No Firebase user');
    await user.getIdToken(true);
    return user.uid;
  }
}

// Test profile transport: authenticated REST, owner-only database rules.
class _RemoteProfile {
  static Future<String> _queue = Future.value('');
  static Future<String> sync() {
    final task = _queue.then((_) => _sync());
    _queue = task.catchError((Object _) => '');
    return task;
  }
  static Future<String> _sync() async {
    final p = await SharedPreferences.getInstance();
    if (!(p.getBool('player_profile_registered_v1') ?? false)) {
      return 'プロフィール未登録';
    }
    final profile = await _LocalPlayerProfile.load();
    final uid = await _FirebaseTestConnection.connect().timeout(const Duration(seconds: 20));
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.uid != uid) throw StateError('auth');
    final token = await user.getIdToken();
    if (token == null) throw StateError('token');
    final uri = Uri.https('zaamd-test-default-rtdb.asia-southeast1.firebasedatabase.app', '/profiles/$uid.json', {'auth': token});
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    Future<dynamic> request(String method, [Map<String, String>? data]) async {
      final req = await client.openUrl(method, uri);
      if (data != null) {
        req.headers.contentType = ContentType.json;
        req.write(jsonEncode(data));
      }
      final res = await req.close();
      final body = await res.transform(utf8.decoder).join();
      if (res.statusCode != 200) throw StateError('HTTP ${res.statusCode}');
      return jsonDecode(body);
    }
    try {
      final data = {'uid': uid, 'name': profile.name, 'icon': profile.icon};
      await request('PUT', data).timeout(const Duration(seconds: 15));
      final remote = await request('GET').timeout(const Duration(seconds: 15));
      if (remote is! Map || remote['uid'] != uid || remote['name'] != profile.name || remote['icon'] != profile.icon) {
        throw StateError('profile mismatch');
      }
      return '保存・取得成功\n名前: ${remote['name']}\nアイコン: ${remote['icon']}';
    } finally { client.close(force: true); }
  }
  static Future<void> syncQuietly() async {
    try { await sync(); } catch (_) { /* Local play remains available; retry in OPTION. */ }
  }
}

// Isolated two-device matchmaking test. Never starts a CPU or real battle.
class _MatchProbeScreen extends StatefulWidget {
  const _MatchProbeScreen();
  @override State<_MatchProbeScreen> createState() => _MatchProbeScreenState();
}
class _MatchProbeScreenState extends State<_MatchProbeScreen> {
  bool _running = false;
  bool _stop = false;
  String _status = '開始を押してください';
  void _show(String s) { if (mounted) setState(() => _status = s); }
  @override void dispose() { _stop = true; super.dispose(); }
  Future<void> _start() async {
    if (_running) return;
    setState(() { _running = true; _stop = false; _status = '認証中…'; });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    String? myUid;
    String? myRoom;
    Uri? uri;
    Future<(int, String?, dynamic)> req(String method, {String? etag, Object? data}) async {
      final r = await client.openUrl(method, uri!);
      if (method == 'GET') r.headers.set('X-Firebase-ETag', 'true');
      if (etag != null) r.headers.set('if-match', etag);
      if (method == 'PUT') { r.headers.contentType = ContentType.json; r.write(jsonEncode(data)); }
      final response = await r.close();
      final body = await response.transform(utf8.decoder).join();
      return (response.statusCode, response.headers.value('etag'), jsonDecode(body));
    }
    try {
      final sync = await _RemoteProfile.sync();
      if (!sync.startsWith('保存・取得成功')) throw StateError('プロフィール未登録');
      final uid = await _FirebaseTestConnection.connect().timeout(const Duration(seconds: 20));
      myUid = uid;
      final token = await FirebaseAuth.instance.currentUser!.getIdToken();
      if (token == null) throw StateError('認証失敗');
      uri = Uri.https('zaamd-test-default-rtdb.asia-southeast1.firebasedatabase.app', '/matchTest.json', {'auth': token});
      final p = await _LocalPlayerProfile.load();
      final me = {'uid': uid, 'name': p.name, 'icon': p.icon};
      final deadline = DateTime.now().add(const Duration(seconds: 75));
      while (!_stop && DateTime.now().isBefore(deadline)) {
        final (code, tag, raw) = await req('GET').timeout(const Duration(seconds: 12));
        if (code != 200 || tag == null) throw StateError('HTTP $code');
        if (_stop) break;
        final now = DateTime.now().millisecondsSinceEpoch;
        final m = raw is Map ? raw : null;
        final a = m?['a']; final b = m?['b'];
        if (m == null || (m['expires'] is num && m['expires'] <= now)) {
          final room = '$uid-$now';
          myRoom = room;
          final (c, _, _) = await req('PUT', etag: tag, data: {'room':room,'a':me,'expires':now+90000}).timeout(const Duration(seconds:12));
          if (c != 200 && c != 412) throw StateError('HTTP $c');
        } else if (a is Map && b is Map && (a['uid'] == uid || b['uid'] == uid)) {
          final other = a['uid'] == uid ? b : a;
          _show('マッチング成功\nルーム: ${m['room']}\n相手: ${other['name']}\nアイコン: ${other['icon']}');
          return;
        } else if (a is Map && b == null && a['uid'] != uid) {
          final next = Map<String,dynamic>.from(m!)..['b'] = me;
          final (c, _, _) = await req('PUT', etag:tag, data:next).timeout(const Duration(seconds:12));
          if (c != 200 && c != 412) throw StateError('HTTP $c');
        } else if (a is Map && a['uid'] == uid && b == null) {
          myRoom = m!['room'] as String;
          _show('対戦相手を検索中…');
        } else { _show('テストルーム使用中…'); }
        await Future<void>.delayed(const Duration(seconds: 2));
      }
      _show(_stop ? 'キャンセルしました' : '待機時間終了');
    } catch (e) { _show('通信テスト失敗: ${e is StateError ? e.message : e.runtimeType}'); }
    finally {
      if (uri != null && myUid != null && myRoom != null) {
        try {
          final (c, tag, raw) = await req('GET').timeout(const Duration(seconds: 8));
          if (c == 200 && tag != null && raw is Map && raw['room'] == myRoom && raw['b'] == null && raw['a'] is Map && raw['a']['uid'] == myUid) {
            await req('PUT', etag:tag, data:null).timeout(const Duration(seconds:8));
          }
        } catch (_) { /* Expiry releases abandoned waiting slots. */ }
      }
      client.close(force:true);
      if (mounted) setState(() => _running = false);
    }
  }
  // Separate experimental queue: never joins the legacy CPU battle flow.
  Future<void> _realQueue() async {
    if (_running) return;
    setState(() { _running = true; _stop = false; _status = '本番候補マッチング認証中…'; });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    Uri? uri;
    String? uid;
    String? ticket;
    bool completed = false;
    Future<(int, String?, dynamic)> request(String method, {String? tag, Object? data}) async {
      final r = await client.openUrl(method, uri!);
      if (method == 'GET') r.headers.set('X-Firebase-ETag', 'true');
      if (tag != null) r.headers.set('if-match', tag);
      if (method == 'PUT') { r.headers.contentType = ContentType.json; r.write(jsonEncode(data)); }
      final response = await r.close();
      final body = await response.transform(utf8.decoder).join();
      return (response.statusCode, response.headers.value('etag'), jsonDecode(body));
    }
    Map<String,dynamic> map(dynamic v) => v is Map ? Map<String,dynamic>.from(v) : <String,dynamic>{};
    Future<(String, Map<String,dynamic>)> read() async {
      final (code, tag, raw) = await request('GET').timeout(const Duration(seconds: 10));
      if (code != 200 || tag == null) throw StateError('HTTP $code');
      return (tag, map(raw));
    }
    Future<bool> write(String tag, Map<String,dynamic> root) async {
      final (code, _, _) = await request('PUT', tag: tag, data: root).timeout(const Duration(seconds: 10));
      if (code == 412) return false;
      if (code != 200) throw StateError('HTTP $code');
      return true;
    }
    try {
      final sync = await _RemoteProfile.sync();
      if (!sync.startsWith('保存・取得成功')) throw StateError('プロフィール未登録');
      final me = await _FirebaseTestConnection.connect().timeout(const Duration(seconds: 20));
      uid = me;
      final token = await FirebaseAuth.instance.currentUser!.getIdToken();
      if (token == null) throw StateError('認証失敗');
      uri = Uri.https('zaamd-test-default-rtdb.asia-southeast1.firebasedatabase.app', '/matchQueueV1.json', {'auth': token});
      final p = await _LocalPlayerProfile.load();
      final start = DateTime.now().millisecondsSinceEpoch;
      final id = '$me-$start-${math.Random.secure().nextInt(1 << 30)}';
      ticket = id;
      final deadline = start + 75000;
      final profile = {'uid': me, 'name': p.name, 'icon': p.icon, 'ticket': id, 'expires': deadline};
      while (!_stop && DateTime.now().millisecondsSinceEpoch < deadline) {
        final (tag, root) = await read();
        if (_stop) break;
        final now = DateTime.now().millisecondsSinceEpoch;
        final waiting = map(root['waiting']);
        final rooms = map(root['rooms']);
        waiting.removeWhere((k,v) => v is! Map || v['expires'] is! num || v['expires'] <= now);
        rooms.removeWhere((k,v) => v is! Map || v['expires'] is! num || v['expires'] <= now);
        root['waiting'] = waiting; root['rooms'] = rooms;
        String? roomId;
        Map<String,dynamic>? room;
        for (final entry in rooms.entries) {
          final r = map(entry.value);
          final a = map(r['a']); final b = map(r['b']);
          if (a['ticket'] == id || b['ticket'] == id) { roomId = entry.key; room = r; break; }
          if (a['uid'] == me || b['uid'] == me) throw StateError('既存ルーム使用中');
        }
        if (room != null && roomId != null) {
          if (room['cancelled'] == true) { _show('相手がキャンセルしました'); return; }
          final a = map(room['a']); final b = map(room['b']);
          final other = a['ticket'] == id ? b : a;
          final ack = map(room['ack']);
          if (ack[me] != true) {
            ack[me] = true; room['ack'] = ack; rooms[roomId] = room;
            await write(tag, root);
          } else if (ack[other['uid']] == true) {
            completed = true;
            _show('双方マッチング確認成功\nルーム: $roomId\n相手UID: ${other['uid']}\n相手: ${other['name']}\nアイコン: ${other['icon']}');
            return;
          } else { _show('相手の成立確認待ち…'); }
        } else {
          final own = map(waiting[me]);
          if (own.isNotEmpty && own['ticket'] != id) throw StateError('二重参加拒否');
          String? peerKey;
          for (final entry in waiting.entries) {
            final v = map(entry.value);
            if (entry.key != me && v['uid'] == entry.key && v['ticket'] is String) { peerKey = entry.key; break; }
          }
          if (peerKey != null) {
            final peer = map(waiting[peerKey]);
            waiting.remove(peerKey); waiting.remove(me);
            rooms[id] = {'a': peer, 'b': profile, 'ack': {me: true}, 'expires': now + 90000};
            await write(tag, root);
          } else if (own.isEmpty) {
            waiting[me] = profile;
            await write(tag, root);
          }
          _show('対戦相手を検索中…');
        }
        await Future<void>.delayed(const Duration(seconds: 1));
      }
      _show(_stop ? 'キャンセルしました' : '待機時間終了');
    } catch (e) { _show(_stop ? 'キャンセルしました' : '通信テスト失敗: ${e is StateError ? e.message : e.runtimeType}'); }
    finally {
      if (!completed && uri != null && uid != null && ticket != null) {
        try {
          for (int i = 0; i < 3; i++) {
            final (tag, root) = await read();
            final waiting = map(root['waiting']); final rooms = map(root['rooms']);
            if (map(waiting[uid])['ticket'] == ticket) waiting.remove(uid);
            for (final entry in rooms.entries.toList()) {
              final r = map(entry.value);
              if (map(r['a'])['ticket'] == ticket || map(r['b'])['ticket'] == ticket) { r['cancelled'] = true; rooms[entry.key] = r; }
            }
            root['waiting'] = waiting; root['rooms'] = rooms;
            if (await write(tag, root)) break;
          }
        } catch (_) { /* Expiry releases abandoned entries. */ }
      }
      client.close(force: true);
      if (mounted) setState(() => _running = false);
    }
  }
  // Two independent anonymous sessions, isolated from the normal queue and local profile.
  Future<Map<String,String>> _dualPeer(Uri uri, String me, String name, String icon) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    Future<(int, String?, dynamic)> request(String method, {String? tag, Object? data}) async {
      final r = await client.openUrl(method, uri);
      if (method == 'GET') r.headers.set('X-Firebase-ETag', 'true');
      if (tag != null) r.headers.set('if-match', tag);
      if (method == 'PUT') { r.headers.contentType = ContentType.json; r.write(jsonEncode(data)); }
      final response = await r.close();
      final body = await response.transform(utf8.decoder).join();
      return (response.statusCode, response.headers.value('etag'), jsonDecode(body));
    }
    Map<String,dynamic> map(dynamic v) => v is Map ? Map<String,dynamic>.from(v) : <String,dynamic>{};
    Future<(String, Map<String,dynamic>)> read() async {
      final (code, tag, raw) = await request('GET').timeout(const Duration(seconds: 10));
      if (code != 200 || tag == null) throw StateError('HTTP $code');
      return (tag, map(raw));
    }
    Future<bool> write(String tag, Map<String,dynamic> root) async {
      final (code, _, _) = await request('PUT', tag: tag, data: root).timeout(const Duration(seconds: 10));
      if (code == 412) return false;
      if (code != 200) throw StateError('HTTP $code');
      return true;
    }
    try {
      final start = DateTime.now().millisecondsSinceEpoch;
      final id = '$me-$start-${math.Random.secure().nextInt(1 << 30)}';
      
      final deadline = start + 75000;
      final profile = {'uid': me, 'name': name, 'icon': icon, 'ticket': id, 'expires': deadline};
      while (!_stop && DateTime.now().millisecondsSinceEpoch < deadline) {
        final (tag, root) = await read();
        if (_stop) break;
        final now = DateTime.now().millisecondsSinceEpoch;
        final waiting = map(root['waiting']);
        final rooms = map(root['rooms']);
        waiting.removeWhere((k,v) => v is! Map || v['expires'] is! num || v['expires'] <= now);
        rooms.removeWhere((k,v) => v is! Map || v['expires'] is! num || v['expires'] <= now);
        root['waiting'] = waiting; root['rooms'] = rooms;
        String? roomId;
        Map<String,dynamic>? room;
        for (final entry in rooms.entries) {
          final r = map(entry.value);
          final a = map(r['a']); final b = map(r['b']);
          if (a['ticket'] == id || b['ticket'] == id) { roomId = entry.key; room = r; break; }
          if (a['uid'] == me || b['uid'] == me) throw StateError('既存ルーム使用中');
        }
        if (room != null && roomId != null) {
          if (room['cancelled'] == true) { throw StateError('相手がキャンセルしました'); }
          final a = map(room['a']); final b = map(room['b']);
          final other = a['ticket'] == id ? b : a;
          final ack = map(room['ack']);
          if (ack[me] != true) {
            ack[me] = true; room['ack'] = ack; rooms[roomId] = room;
            await write(tag, root);
          } else if (ack[other['uid']] == true) {
            
            return {'room': roomId, 'uid': other['uid'].toString(), 'name': other['name'].toString(), 'icon': other['icon'].toString()};
          } else { _show('相手の成立確認待ち…'); }
        } else {
          final own = map(waiting[me]);
          if (own.isNotEmpty && own['ticket'] != id) throw StateError('二重参加拒否');
          String? peerKey;
          for (final entry in waiting.entries) {
            final v = map(entry.value);
            if (entry.key != me && v['uid'] == entry.key && v['ticket'] is String) { peerKey = entry.key; break; }
          }
          if (peerKey != null) {
            final peer = map(waiting[peerKey]);
            waiting.remove(peerKey); waiting.remove(me);
            rooms[id] = {'a': peer, 'b': profile, 'ack': {me: true}, 'expires': now + 90000};
            await write(tag, root);
          } else if (own.isEmpty) {
            waiting[me] = profile;
            await write(tag, root);
          }
          _show('対戦相手を検索中…');
        }
        await Future<void>.delayed(const Duration(seconds: 1));
      }
      throw StateError(_stop ? 'キャンセルしました' : '待機時間終了');
    } finally { client.close(force: true); }
  }
  Future<void> _dualTest() async {
    if (_running) return;
    setState(() { _running = true; _stop = false; _status = '独立認証テスト中…'; });
    final apps = <FirebaseApp>[];
    final users = <User>[];
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    Uri? cleanup;
    String result = '独立認証テスト失敗';
    final session = '${DateTime.now().millisecondsSinceEpoch}-${math.Random.secure().nextInt(1 << 30)}';
    try {
      final original = await _FirebaseTestConnection.connect().timeout(const Duration(seconds: 20));
      final options = Firebase.app().options;
      final tokens = <String>[];
      for (int i = 0; i < 2; i++) {
        if (_stop) throw StateError('キャンセルしました');
        final app = await Firebase.initializeApp(name: 'dual-$session-$i', options: options);
        apps.add(app);
        final user = (await FirebaseAuth.instanceFor(app: app).signInAnonymously().timeout(const Duration(seconds: 20))).user;
        if (user == null) throw StateError('独立認証失敗');
        users.add(user);
        final token = await user.getIdToken(true);
        if (token == null) throw StateError('認証トークン取得失敗');
        tokens.add(token);
      }
      if (users[0].uid == users[1].uid || users.any((u) => u.uid == original)) throw StateError('UID分離失敗');
      Uri endpoint(String token) => Uri.https('zaamd-test-default-rtdb.asia-southeast1.firebasedatabase.app', '/matchQueueV1/testSessions/$session.json', {'auth': token});
      cleanup = endpoint(tokens[0]);
      _show('独立UID確認OK・双方マッチング中…');
      final results = await Future.wait([
        _dualPeer(endpoint(tokens[0]), users[0].uid, 'TEST A', 'arts'),
        _dualPeer(endpoint(tokens[1]), users[1].uid, 'TEST B', 'rei'),
      ]);
      final a = results[0]; final b = results[1];
      if (a['room'] != b['room'] || a['uid'] != users[1].uid || b['uid'] != users[0].uid || a['name'] != 'TEST B' || b['name'] != 'TEST A' || a['icon'] != 'rei' || b['icon'] != 'arts') throw StateError('双方情報不一致');
      if (FirebaseAuth.instance.currentUser?.uid != original) throw StateError('既存UID変化');
      result = '独立2認証マッチング成功\n別UID・同一ルーム・双方プロフィール: OK\n既存UID維持: OK\nルーム: ${a['room']}';
    } catch (e) { result = _stop ? 'キャンセルしました' : '独立認証テスト失敗: ${e is StateError ? e.message : e.runtimeType}'; }
    finally {
      if (cleanup != null) {
        try {
          final req = await client.deleteUrl(cleanup);
          final res = await req.close().timeout(const Duration(seconds: 10));
          await res.drain();
          final verify = await client.getUrl(cleanup);
          final read = await verify.close().timeout(const Duration(seconds: 10));
          final body = await read.transform(utf8.decoder).join();
          result += res.statusCode == 200 && read.statusCode == 200 && jsonDecode(body) == null ? '\nテストデータ削除: OK' : '\nテストデータ削除未確認';
        } catch (_) { result += '\nテストデータ削除未確認'; }
      }
      bool removed = true;
      for (final user in users) { try { await user.delete().timeout(const Duration(seconds: 10)); } catch (_) { removed = false; } }
      for (final app in apps) { try { await app.delete(); } catch (_) { removed = false; } }
      result += removed ? '\nテスト認証削除: OK' : '\nテスト認証削除未確認';
      client.close(force: true);
      if (mounted) setState(() { _running = false; _status = result; });
    }
  }
  // A simulated peer uses the existing test endpoint, never a real battle.
  Future<void> _simulate() async {
    if (_running) return;
    setState(() { _running = true; _stop = false; _status = '疑似マッチング認証中…'; });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    Uri? uri;
    String? room;
    String? owner;
    String result = '通信テスト失敗';
    Future<(int, String?, dynamic)> request(String method, {String? tag, Object? data}) async {
      final r = await client.openUrl(method, uri!);
      if (method == 'GET') r.headers.set('X-Firebase-ETag', 'true');
      if (tag != null) r.headers.set('if-match', tag);
      if (method == 'PUT') { r.headers.contentType = ContentType.json; r.write(jsonEncode(data)); }
      final response = await r.close();
      final body = await response.transform(utf8.decoder).join();
      return (response.statusCode, response.headers.value('etag'), jsonDecode(body));
    }
    Future<(int, String?, dynamic)> get() async {
      final v = await request('GET').timeout(const Duration(seconds: 12));
      if (v.$1 != 200 || v.$2 == null) throw StateError('HTTP ${v.$1}');
      return v;
    }
    Future<int> put(String tag, Object? data) async => (await request('PUT', tag: tag, data: data).timeout(const Duration(seconds: 12))).$1;
    void check(bool ok, String message) { if (!ok) throw StateError(message); }
    void active() { if (_stop) throw StateError('キャンセルしました'); }
    bool canJoin(Map m, String uid) => m['a'] is Map && m['a']['uid'] != uid && m['b'] == null && m['expires'] is num && m['expires'] > DateTime.now().millisecondsSinceEpoch;
    try {
      final sync = await _RemoteProfile.sync();
      check(sync.startsWith('保存・取得成功'), 'プロフィール未登録');
      final uid = await _FirebaseTestConnection.connect().timeout(const Duration(seconds: 20));
      owner = uid;
      final token = await FirebaseAuth.instance.currentUser!.getIdToken();
      if (token == null) throw StateError('認証失敗');
      // Share the existing test slot with conditional writes; never overwrite an active room.
      uri = Uri.https('zaamd-test-default-rtdb.asia-southeast1.firebasedatabase.app', '/matchTest.json', {'auth': token});
      final p = await _LocalPlayerProfile.load();
      final me = {'uid': uid, 'name': p.name, 'icon': p.icon};
      final peer = {'uid': 'simulated-$uid', 'name': 'TEST CPU', 'icon': p.icon};
      active();
      final initial = await get();
      final old = initial.$3;
      final now = DateTime.now().millisecondsSinceEpoch;
      check(old == null || (old is Map && old['expires'] is num && old['expires'] <= now), '疑似テストルーム使用中');
      room = 'simulation-$uid-$now';
      final waiting = {'room': room, 'a': me, 'expires': now + 90000};
      active();
      check(await put(initial.$2!, waiting) == 200, '待機登録競合');
      _show('疑似プレイヤーを検索中…');
      await Future<void>.delayed(const Duration(seconds: 2));
      active();
      final slot = await get();
      final raw = slot.$3;
      check(raw is Map && raw['room'] == room, 'ルーム不一致');
      final m = Map<String, dynamic>.from(raw as Map);
      check(!canJoin(m, uid), '自己マッチング防止失敗');
      check(canJoin(m, peer['uid']!), '疑似参加不可');
      final joined = Map<String, dynamic>.from(m)..['b'] = peer;
      active();
      check(await put(slot.$2!, joined) == 200, 'マッチング競合');
      active();
      final confirmed = await get();
      final matched = confirmed.$3;
      check(matched is Map && matched['room'] == room && matched['a'] is Map && matched['b'] is Map && matched['a']['uid'] == uid && matched['b']['uid'] == peer['uid'] && matched['b']['name'] == peer['name'] && matched['b']['icon'] == peer['icon'], '相手情報不一致');
      check(!canJoin(matched as Map, 'third-$uid'), '二重参加防止失敗');
      active();
      check(await put(slot.$2!, joined) == 412, '古いETagの拒否失敗');
      active();
      result = '疑似マッチング成功\nルーム: $room\n相手UID: ${peer['uid']}\n相手: ${peer['name']}\nアイコン: ${peer['icon']}\n自己参加拒否・二重参加拒否・競合拒否: OK';
    } catch (e) {
      result = _stop ? 'キャンセルしました' : '通信テスト失敗: ${e is StateError ? e.message : e.runtimeType}';
    } finally {
      if (uri != null && room != null) {
        try {
          final current = await get();
          final m = current.$3;
          if (m is Map && m['room'] == room && m['a'] is Map && m['a']['uid'] == owner) {
            final code = await put(current.$2!, null);
            if (code != 200) throw StateError('cleanup HTTP $code');
            result += '\nテストルーム削除: OK';
          }
        } catch (_) { result += '\n削除未確認（有効期限90秒）'; }
      }
      client.close(force: true);
      if (mounted) setState(() { _running = false; _status = result; });
    }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('マッチング確認（テスト）')),
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: ListView(children: [
      SelectableText(_status), const SizedBox(height:20),
      ElevatedButton(onPressed: _running ? null : _start, child: const Text('開始')),
      ElevatedButton(onPressed: _running ? null : _simulate, child: const Text('疑似プレイヤーテスト')),
      ElevatedButton(onPressed: _running ? null : _realQueue, child: const Text('本番候補マッチング（テスト）')),
      ElevatedButton(onPressed: _running ? null : _dualTest, child: const Text('独立2認証マッチング（テスト）')),
      OutlinedButton(onPressed: _running ? () { _stop = true; _show('キャンセル中…'); } : null, child: const Text('CANCEL')),
      const Text('通信確認専用・対戦は開始しません。'),
    ]))),
  );
}

class _OptionScreen extends StatefulWidget {
  const _OptionScreen();
  @override State<_OptionScreen> createState() => _OptionScreenState();
}
class _OptionScreenState extends State<_OptionScreen> {
  bool _checkingProfile = false;
  String _profileStatus = '未確認（テスト環境）';
  Future<void> _checkProfile() async {
    if (_checkingProfile) return;
    setState(() { _checkingProfile = true; _profileStatus = '同期中…'; });
    String result;
    try { result = await _RemoteProfile.sync(); }
    catch (_) { result = '同期失敗。接続・ルールを確認して再試行してください。'; }
    if (!mounted) return;
    setState(() { _checkingProfile = false; _profileStatus = result; });
  }
  bool _checkingConnection = false;
  String _connectionStatus = '未確認（テスト環境）';
  Future<void> _checkConnection() async {
    if (_checkingConnection) return;
    setState(() { _checkingConnection = true; _connectionStatus = '認証確認中…'; });
    String result;
    try {
      final uid = await _FirebaseTestConnection.connect().timeout(const Duration(seconds: 25));
      result = '匿名認証成功\nプレイヤーID: $uid';
    } on FirebaseException catch (e) {
      result = '認証失敗: ${e.code}';
    } on TimeoutException {
      result = '接続タイムアウト。再試行してください。';
    } catch (_) {
      result = '接続確認失敗。再試行してください。';
    }
    if (!mounted) return;
    setState(() { _checkingConnection = false; _connectionStatus = result; });
  }
  void _info(String title, String body) {
    _UiSounds.tap();
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: SelectableText(body))),
    )));
  }
  Widget _volume(String label, double value, ValueChanged<double> change, ValueChanged<double> end) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [Text('$label  ${(value * 100).round()}％'), Slider(value: value, divisions: 100, onChanged: change, onChangeEnd: end)],
  );
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('OPTION'), leading: _easyBackButton(context)),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      _volume('BGM', _AudioSettings.bgm, (v) {
        setState(() => _AudioSettings.bgm = v);
        unawaited(_AppBgm._player.setVolume(v).catchError((Object _) {}));
      }, (_) { unawaited(_AudioSettings.save()); }),
      _volume('SE', _AudioSettings.se, (v) { setState(() => _AudioSettings.se = v); }, (_) { unawaited(_AudioSettings.save()); _UiSounds.tap(); }),
      const Divider(),
      ListTile(title: const Text('利用規約'), onTap: () => _info('利用規約（暫定版）', '鋼王騎帝 -ツァームド-\n\n本アプリでは暴言、差別、性的勧誘、嫌がらせ、不正操作、チートを禁止します。違反時は利用制限を行う場合があります。ゲーム内素材の無断転載・再配布は禁止します。通信障害や保守によりサービスが中断する場合があります。課金・チップの正式条件は公開前に確定します。\n\nお問い合わせ：zaamd.support@gmail.com')),
      ListTile(title: const Text('プライバシーポリシー'), onTap: () => _info('プライバシーポリシー（暫定版）', '本アプリは端末内にプレイヤー名、プロフィール、戦績、進行状況、設定を保存します。これらはゲーム機能の提供に使用します。本番通信・課金・外部サービスに関する情報の取り扱いは公開前に確定します。\n\nお問い合わせ：zaamd.support@gmail.com')),
      ListTile(title: const Text('お問い合わせ'), subtitle: const Text('zaamd.support@gmail.com'), trailing: const Icon(Icons.copy), onTap: () async {
        await Clipboard.setData(const ClipboardData(text: 'zaamd.support@gmail.com'));
        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('メールアドレスをコピーしました')));
      }),
      const ListTile(title: Text('バージョン情報'), subtitle: Text('0.2.0')),
      ListTile(title: const Text('マッチング確認（テスト）'), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _MatchProbeScreen()))),
      ListTile(title: const Text('プロフィール同期確認（テスト）'), subtitle: Text(_profileStatus), trailing: const Icon(Icons.sync), onTap: _checkingProfile ? null : _checkProfile),
      ListTile(title: const Text('Firebase接続確認（テスト）'), subtitle: Text(_connectionStatus), trailing: const Icon(Icons.sync), onTap: _checkingConnection ? null : _checkConnection),
    ])),
  );
}

class RecordScreen extends StatefulWidget {
  const RecordScreen({super.key});
  @override State<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends State<RecordScreen> {
  late Future<void> _load;

  @override
  void initState() {
    super.initState();
    _load = _MasterProgress.load();
  }

  Widget _unitRow(BattleUnit unit) {
    final wins = _MasterProgress.wins(unit);
    final required = _MasterProgress.souvenirWinsRequired;
    final acquired = _MasterProgress.acquiredMasterPieces.contains(unit.name);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.035),
        border: Border.all(color: Colors.white24),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(unit.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          const SizedBox(height: 4),
          Text(unit.jp, style: const TextStyle(color: Colors.white60)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('$wins WIN', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          if (acquired) ...[
            const SizedBox(height: 3),
            const Text(
              '記念品 獲得済み',
              style: TextStyle(color: Colors.white70, fontSize: 12),
            ),
          ],
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: const Text('RECORD')),
    body: FutureBuilder<void>(
      future: _load,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
          children: [
            const Text('UNIT RECORD', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2.2)),
            const SizedBox(height: 6),
            const Text('ONLINE BATTLE / REAR LINE', style: TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 16),
            _unitRow(BattleUnit.king),
            if (_StoryProgress.knightUnlocked) ...[
              const SizedBox(height: 10),
              _unitRow(BattleUnit.knight),
            ],
            if (_StoryProgress.emperorUnlocked) ...[
              const SizedBox(height: 10),
              _unitRow(BattleUnit.emperor),
            ],
            if (_StoryProgress.strasseUnlocked) ...[
              const SizedBox(height: 10),
              _unitRow(BattleUnit.strasse),
            ],
            if (_MasterProgress.masterUnlocked) ...[
              const SizedBox(height: 10),
              _unitRow(BattleUnit.master),
            ],
          ],
        );
      },
    ),
  );
}


class _TrainingPiece {
  const _TrainingPiece(this.label, this.isWhite, {this.level = 1, this.pu = 0, this.lower, this.suppressed = false});
  final String label;
  final bool isWhite;
  final int level;
  final int pu;
  final String? lower;
  final bool suppressed;

  _TrainingPiece copyWith({String? label, bool? isWhite, int? level, int? pu, String? lower, bool clearLower = false, bool? suppressed}) =>
      _TrainingPiece(
        label ?? this.label,
        isWhite ?? this.isWhite,
        level: level ?? this.level,
        pu: pu ?? this.pu,
        lower: clearLower ? null : (lower ?? this.lower),
        suppressed: suppressed ?? this.suppressed,
      );
}

enum _TrainingInput { next, cell, action, finish }

class TrainingScreen extends StatelessWidget {
  const TrainingScreen({super.key});

  Map<int, Piece> _pieces() => <int, Piece>{
        0: const Piece('assets/pieces/black_core_2.png', '核', isWhite: false),
        1: const Piece('assets/pieces/black_fighter.png', '闘', major: true, isWhite: false),
        2: const Piece('assets/pieces/black_guard.png', '護', major: true, isWhite: false),
        3: const Piece('assets/pieces/black_servant.png', '仕', major: true, isWhite: false),
        4: const Piece('assets/pieces/black_core_2.png', '核', isWhite: false),
        5: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
        6: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
        7: const Piece('assets/pieces/black_king.png', '王', major: true, isWhite: false),
        8: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
        9: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
        25: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        26: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        27: const Piece('assets/pieces/white_king.png', '王', major: true, isWhite: true),
        28: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        29: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        30: const Piece('assets/pieces/white_core_2.png', '核', isWhite: true),
        31: const Piece('assets/pieces/white_servant.png', '仕', major: true, isWhite: true),
        32: const Piece('assets/pieces/white_guard.png', '護', major: true, isWhite: true),
        33: const Piece('assets/pieces/white_fighter.png', '闘', major: true, isWhite: true),
        34: const Piece('assets/pieces/white_core_2.png', '核', isWhite: true),
      };

  @override
  Widget build(BuildContext context) => BoardScreen(
        initialPieces: _pieces(),
        playerIsWhite: true,
        whiteUnit: BattleUnit.king,
        blackUnit: BattleUnit.king,
        trainingMode: true,
      );
}

class _TrainingCell extends StatelessWidget {
  const _TrainingCell({required this.piece, required this.asset, required this.blue, required this.yellow, required this.red, required this.dashed, required this.arrow, required this.onTap});
  final _TrainingPiece? piece;
  final String? asset;
  final bool blue;
  final bool yellow;
  final bool red;
  final bool dashed;
  final bool arrow;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = blue ? Colors.lightBlueAccent : (yellow ? Colors.amberAccent : (red ? Colors.redAccent : Colors.white24));
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: blue ? const Color(0x2418BFFF) : yellow ? const Color(0x24FFD740) : red ? const Color(0x24FF5252) : const Color(0xFF17151D)),
          if (piece != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(3, 3, 3, 16),
              child: Image.asset(asset!, fit: BoxFit.contain),
            ),
          if (piece != null)
            Positioned(
              left: 2,
              right: 2,
              bottom: 1,
              child: Text(
                piece!.lower != null ? '上: ${piece!.label} Lv${piece!.level}/Pu${piece!.pu}' : '${piece!.label}${piece!.label == '兵' || piece!.label == '核' ? '' : ' Lv${piece!.level}/Pu${piece!.pu}'}',
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.clip,
                style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800),
              ),
            ),
          if (piece?.lower != null)
            Positioned(
              top: 2,
              right: 2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(color: piece!.suppressed ? Colors.redAccent.withOpacity(.8) : Colors.green.withOpacity(.78), borderRadius: BorderRadius.circular(7)),
                child: Text(piece!.suppressed ? '制圧' : '合流', style: const TextStyle(fontSize: 7, fontWeight: FontWeight.w800)),
              ),
            ),
          Positioned.fill(child: IgnorePointer(child: dashed ? CustomPaint(painter: _TrainingDashedBorderPainter(color)) : Container(decoration: BoxDecoration(border: Border.all(color: color, width: blue || yellow || red ? 2 : 1))))),
          if (arrow)
            const Positioned(top: -3, left: 0, right: 0, child: IgnorePointer(child: _TrainingArrow())),
        ],
      ),
    );
  }
}

class _TrainingCrown extends StatelessWidget {
  const _TrainingCrown({required this.label, required this.value, required this.arrow});
  final String label;
  final String value;
  final bool arrow;
  @override
  Widget build(BuildContext context) => Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
            decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(18)),
            child: Text('$label  👑 $value/3', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
          ),
          if (arrow) const Positioned(top: -40, left: 0, right: 0, child: _TrainingArrow()),
        ],
      );
}

class _TrainingDialogue extends StatelessWidget {
  const _TrainingDialogue({super.key, required this.text, required this.typing, required this.showNext, required this.showFinish, required this.onNext, required this.onFinish});
  final String text;
  final bool typing;
  final bool showNext;
  final bool showFinish;
  final VoidCallback onNext;
  final VoidCallback onFinish;

  @override
  Widget build(BuildContext context) {
    return _StablePilotTypewriter(
      text: text,
      duration: const Duration(milliseconds: 430),
      completed: !typing,
      childBuilder: (context, shown) => Container(
        height: 116,
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(.9),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white24),
          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
        ),
        child: Row(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(13, 8, 8, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('ブル', style: TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: .5)),
                    const SizedBox(height: 4),
                    Expanded(child: Align(alignment: Alignment.centerLeft, child: Text(shown, maxLines: 4, overflow: TextOverflow.clip, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, height: 1.18)))),
                    if (showNext || showFinish)
                      Align(
                        alignment: Alignment.bottomRight,
                        child: InkWell(
                          onTap: showFinish ? onFinish : onNext,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                            child: Text(showFinish ? 'TRAINING終了' : 'つぎへ', style: const TextStyle(color: Color(0xFFD9C2FF), fontSize: 12, fontWeight: FontWeight.w900)),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            ClipRRect(
              borderRadius: const BorderRadius.horizontal(right: Radius.circular(7)),
              child: SizedBox(width: 102, height: 116, child: Image.asset('assets/pilots/knight.webp', fit: BoxFit.cover)),
            ),
          ],
        ),
      ),
    );
  }
}

class _TrainingActionButton extends StatelessWidget {
  const _TrainingActionButton({required this.label, required this.expected, required this.onTap});
  final String label;
  final bool expected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        height: 54,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned.fill(
              child: OutlinedButton(
                onPressed: onTap,
                style: OutlinedButton.styleFrom(side: BorderSide(color: expected ? const Color(0xFFD9C2FF) : Colors.white24, width: 1.2)),
                child: Text(label, style: TextStyle(color: expected ? const Color(0xFFD9C2FF) : Colors.white38, fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            if (expected) const Positioned(left: 14, top: 8, child: _TrainingArrow()),
          ],
        ),
      );
}

class _TrainingArrow extends StatefulWidget {
  const _TrainingArrow();
  @override
  State<_TrainingArrow> createState() => _TrainingArrowState();
}

class _TrainingArrowState extends State<_TrainingArrow> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 520))..repeat(reverse: true);
  }
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (context, child) => Transform.translate(offset: Offset(0, 10 * _c.value), child: child),
        child: const Icon(
          Icons.keyboard_double_arrow_down_rounded,
          color: Colors.white,
          size: 50,
          shadows: [
            Shadow(color: Colors.black, blurRadius: 8, offset: Offset(2, 0)),
            Shadow(color: Colors.black, blurRadius: 8, offset: Offset(-2, 0)),
            Shadow(color: Colors.black, blurRadius: 8, offset: Offset(0, 2)),
            Shadow(color: Colors.black, blurRadius: 8, offset: Offset(0, -2)),
          ],
        ),
      );
}

class _TrainingDashedBorderPainter extends CustomPainter {
  _TrainingDashedBorderPainter(this.color);
  final Color color;
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = color..strokeWidth = 2..style = PaintingStyle.stroke;
    const dash = 7.0;
    const gap = 5.0;
    void h(double y) { for (double x = 0; x < size.width; x += dash + gap) canvas.drawLine(Offset(x, y), Offset((x + dash).clamp(0.0, size.width).toDouble(), y), p); }
    void v(double x) { for (double y = 0; y < size.height; y += dash + gap) canvas.drawLine(Offset(x, y), Offset(x, (y + dash).clamp(0.0, size.height).toDouble()), p); }
    h(1); h(size.height - 1); v(1); v(size.width - 1);
  }
  @override bool shouldRepaint(covariant _TrainingDashedBorderPainter oldDelegate) => oldDelegate.color != color;
}

class _TrainingWarningPainter extends CustomPainter {
  const _TrainingWarningPainter({required this.cellW, required this.cellH});
  final double cellW;
  final double cellH;
  @override
  void paint(Canvas canvas, Size size) {
    final start = Offset(cellW * 3.5, cellH * 3.5);
    final end = Offset(cellW * 3.5, cellH * 5.45);
    final control = Offset(cellW * 4.35, cellH * 4.45);
    final path = Path()..moveTo(start.dx, start.dy)..quadraticBezierTo(control.dx, control.dy, end.dx, end.dy);
    final paint = Paint()..color = Colors.amberAccent..strokeWidth = 3..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    canvas.drawPath(path, paint);
    canvas.drawLine(end, end + const Offset(-8, -12), paint);
    canvas.drawLine(end, end + const Offset(8, -12), paint);
  }
  @override bool shouldRepaint(covariant _TrainingWarningPainter oldDelegate) => false;
}


class _MenuEntry extends StatefulWidget {
  const _MenuEntry({required this.title,required this.subtitle,required this.onTap,this.enabled=true,this.onDisabledTap,this.unread=false});
  final String title; final String subtitle; final VoidCallback onTap; final bool enabled; final VoidCallback? onDisabledTap; final bool unread;
  @override State<_MenuEntry> createState()=>_MenuEntryState();
}
class _MenuEntryState extends State<_MenuEntry>{
  bool _active=false;
  Future<void> _press() async {
    if(!widget.enabled){widget.onDisabledTap?.call();return;}
    if(_active)return;_UiSounds.tap();setState(()=>_active=true);await Future<void>.delayed(const Duration(milliseconds:140));if(!mounted)return;widget.onTap();await Future<void>.delayed(const Duration(milliseconds:120));if(mounted)setState(()=>_active=false);
  }
  @override Widget build(BuildContext context)=>SizedBox(width:270,child:InkWell(onTap:_press,borderRadius:BorderRadius.circular(2),child:Padding(
    padding:const EdgeInsets.symmetric(vertical:8,horizontal:10),
    child:Column(children:[
      AnimatedDefaultTextStyle(duration:const Duration(milliseconds:120),style:TextStyle(fontSize:25,fontWeight:FontWeight.w700,letterSpacing:_active?2.8:1.5,color:!widget.enabled?Colors.white24:(_active?Colors.white:const Color(0xFFD4D0E0))),child:Row(mainAxisSize:MainAxisSize.min,children:[Text(widget.title,textAlign:TextAlign.center),if(widget.unread)...[const SizedBox(width:7),Container(width:7,height:7,decoration:const BoxDecoration(color:Color(0xFFE53935),shape:BoxShape.circle))]])),
      const SizedBox(height:3),
      AnimatedContainer(duration:const Duration(milliseconds:140),height:1,width:_active?116:38,color:!widget.enabled?Colors.white12:(_active?const Color(0xFFC9CDD3):const Color(0xFF5C6067))),
      const SizedBox(height:4),
      Text(widget.subtitle,textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:widget.enabled?Colors.white54:Colors.white24)),
    ]),
  )));
}


class StoryListScreen extends StatefulWidget {
  const StoryListScreen({super.key});
  @override
  State<StoryListScreen> createState() => _StoryListScreenState();
}

class _StoryListScreenState extends State<StoryListScreen> {
  @override
  void initState(){super.initState();WidgetsBinding.instance.addPostFrameCallback((_)=>_showStoryUnlock());}
  Future<void> _showStoryUnlock() async {final notice=await _UnlockInbox.takeStory();if(!mounted||notice==null)return;await _showUnlockNotice(context,notice);if(mounted)setState((){});}

  static const _chapter1Titles = <int, String>{
    1: '脱走、戦闘',
    2: '逆転、安堵',
    3: '醒書、団結',
    4: '狼煙、開戦',
    5: '拮抗、少女',
    6: '石版、過去',
    7: '再来、咆哮',
    8: '教導、逃亡',
    9: 'それぞれの道、そして',
    10: '醒める、幻',
    11: '始まりの終わり',
    12: '夢の終わり',
  };

  static const _chapter2Titles = <int, String>{
    1: 'あの戦い', 2: '投げやり', 3: '花屋', 4: '風呂',
    5: 'シュトラーセ', 6: '真価', 7: '魔法', 8: '光の中',
    9: '断片', 10: '勢揃い', 11: '同化', 12: '総力戦',
    13: '最後の光', 14: '枯れない花',
  };

  Future<void> _openChapter1Episode(int episode) async {
    if (!_StoryProgress.isUnlocked(episode)) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StoryPanelEpisodeScreen(episode: episode, title: _chapter1Titles[episode]!),
      ),
    );
    if (mounted) setState(() {});
  }

  Future<void> _openChapter2Episode(int episode) async {
    if (!_StoryProgress.isChapter2Unlocked(episode)) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StoryChapter2EpisodeScreen(episode: episode, title: _chapter2Titles[episode]!),
      ),
    );
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    var chapter1LastUnlocked = 0;
    for (var ep = 1; ep <= 12; ep++) {
      if (_StoryProgress.isUnlocked(ep)) chapter1LastUnlocked = ep;
    }
    final chapter1VisibleThrough = chapter1LastUnlocked == 0 ? 0 : math.min(12, chapter1LastUnlocked + 1);

    var chapter2LastUnlocked = 0;
    for (var ep = 1; ep <= 14; ep++) {
      if (_StoryProgress.isChapter2Unlocked(ep)) chapter2LastUnlocked = ep;
    }
    final chapter2VisibleThrough = chapter2LastUnlocked == 0 ? 0 : math.min(14, chapter2LastUnlocked + 1);

    return Scaffold(
      appBar: AppBar(
        leading: _easyBackButton(context),
        title: const Text('STORY'),
      ),
      body: _ScreenBgm(
        asset: 'audio/2War Room Protocol.mp3',
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 620),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(22, 24, 22, 32),
                children: [
                  const Text('第1章', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                  if (chapter1VisibleThrough > 0) ...[
                    const SizedBox(height: 18),
                    for (var ep = 1; ep <= chapter1VisibleThrough; ep++) ...[
                      _StoryEpisodeTile(
                        number: '第$ep話',
                        title: _chapter1Titles[ep]!,
                        unlocked: _StoryProgress.isUnlocked(ep),
                        read: _StoryProgress.isRead(ep),
                        onTap: () => _openChapter1Episode(ep),
                      ),
                      if (ep != chapter1VisibleThrough) const SizedBox(height: 10),
                    ],
                  ],
                  if (chapter2VisibleThrough > 0) ...[
                    const SizedBox(height: 34),
                    const Divider(color: Colors.white24),
                    const SizedBox(height: 26),
                    const Text('第2章', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                    if (_StoryProgress.chapter2ProgressLabel != null) ...[
                      const SizedBox(height: 8),
                      Text(_StoryProgress.chapter2ProgressLabel!, style: const TextStyle(color: Colors.white60, fontSize: 13)),
                    ],
                    const SizedBox(height: 18),
                    for (var ep = 1; ep <= chapter2VisibleThrough; ep++) ...[
                      _StoryEpisodeTile(
                        number: ep == 14 ? '最終話' : '第$ep話',
                        title: _chapter2Titles[ep]!,
                        unlocked: _StoryProgress.isChapter2Unlocked(ep),
                        read: _StoryProgress.isChapter2Read(ep),
                        onTap: () => _openChapter2Episode(ep),
                      ),
                      if (ep != chapter2VisibleThrough) const SizedBox(height: 10),
                    ],
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

}

class _StoryEpisodeTile extends StatelessWidget {
  const _StoryEpisodeTile({
    required this.number,
    required this.title,
    required this.unlocked,
    required this.read,
    this.onTap,
  });
  final String number;
  final String title;
  final bool unlocked;
  final bool read;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Opacity(
        opacity: unlocked ? 1.0 : 0.42,
        child: InkWell(
          onTap: unlocked ? () { _UiSounds.tap(); onTap?.call(); } : null,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
            decoration: BoxDecoration(
              border: Border.all(color: unlocked ? Colors.white30 : Colors.white12),
              borderRadius: BorderRadius.circular(8),
              color: Colors.white.withOpacity(unlocked ? 0.035 : 0.015),
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 58,
                  child: Text(number, style: const TextStyle(fontSize: 13, color: Colors.white60)),
                ),
                Expanded(
                  child: Text(
                    unlocked ? title : 'LOCKED',
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                  ),
                ),
                if (unlocked && read)
                  const Text('READ', style: TextStyle(fontSize: 11, color: Colors.white54, letterSpacing: 1.2))
                else
                  Icon(unlocked ? Icons.chevron_right : Icons.lock_outline, size: 19, color: Colors.white54),
              ],
            ),
          ),
        ),
      );
}

class StoryEpisodeOneScreen extends StatefulWidget {
  const StoryEpisodeOneScreen({super.key});
  @override
  State<StoryEpisodeOneScreen> createState() => _StoryEpisodeOneScreenState();
}

class _StoryEpisodeOneScreenState extends State<StoryEpisodeOneScreen> {
  static final _bgmAsset = _StoryBgmPlan.byEpisode[1]!;
  final ScrollController _scrollController = ScrollController();
  bool _bgmOn = true;
  bool _markedRead = false;
  bool _handoffToNext = false;

  // 旧note版のページ構成を崩さず、本文だけをアプリ内テキストとして再構成する。
  static const String _worldIntro = '''
戦争に使われる兵器は〈ゼット〉と呼ばれる大型の戦闘兵器が主流であった。
ゼットには多くの種類が存在したが、全てパイロットが乗って操縦する必要があった。
多くのパイロットは操縦スキルのみならず、あらゆる状況における判断力とゼット抜きでも戦い抜けるファイティングスキルを持っていた。
ゼットの入手経路、訓練方法、全ては民にとって謎の存在であり、パイロットはなろうとしてなれる存在でもなかった。
ただわかることは、ゼットがこの世界における最強の兵器であることだけであった。
''';

  static const String _artsPage = '''
とある牢獄。
ある男が幽閉されている。はずだった。
男の名はアーツ。
アーツ「あいつ、俺を逃がしやがった。何を考えてやがるんだ。」
アーツが何者かに脱走を助けられ、何処へ逃げるか考えているところであった。目の前に現れたのはアーツの愛機だった。
アーツ「おいおい、どうして俺のゼットがここに？　罠……？　いや、不自然すぎる。」
その時アーツが、後ろの気配に気付いた。
''';

  static const String _bullPage = '''
男「これはこれは、アーツさんじゃないですか。」
''';

  static const String _faceOffPage = '''
アーツ「ブル……！？」
ブル・キル。
名の知れたゼットのパイロットであり、騎士である。
アーツ「なんで俺の名を知ってる？」
アーツにとっては面識がなかった。敵か、味方か。
アーツ「今急ぎでな。またにしてくれるか。」
後ずさりするアーツ。
少しずつ近づくブル。
警戒心が感じられる足取りで分かる。こいつは敵だ。
''';

  static const String _clashPage = '''
背を向けるアーツ。ゆっくりと愛機へと向かう。
アーツ（決まりだ。）
振り返り殴りかかるアーツ。
ブル「最初からそのつもりだ。」
！！？
拳をいなし、ブルがアーツの肩の上で逆立ちをする。
背中を強打されるアーツ。膝が入った。
アーツ「ぐっ……！」
（この男、戦い慣れている。俺がこうも一方的に。）
''';

  static const String _finishPage = '''
アーツ「うおおおおおおお……！」
全力のタックル。
避けられる。そんな事は分かっていた。
アーツ「オッラァァァァァァァァ……！」
アーツの投げが決まった。
！！
アーツ「お前みたいなチョコマカ野郎に背中に乗られるのだけが、ネックな作戦だったからよ。」
起動するアーツの愛機。
形勢が逆転した。
''';

  @override
  void initState() {
    super.initState();
    _AppBgm.play(_bgmAsset);
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_markedRead || !_scrollController.hasClients) return;
    final p = _scrollController.position;
    if (p.maxScrollExtent > 0 && p.pixels >= p.maxScrollExtent - 36) {
      _markedRead = true;
      _StoryProgress.markEpisode1Read();
    }
  }

  Future<void> _toggleBgm() async {
    if (_bgmOn) {
      await _AppBgm.stop();
    } else {
      await _AppBgm.play(_bgmAsset);
    }
    if (mounted) setState(() => _bgmOn = !_bgmOn);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    if (!_handoffToNext) {
      _AppBgm.play('audio/2War Room Protocol.mp3');
    }
    super.dispose();
  }

  List<String> _verticalLines(String text) {
    final normalized = text.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final lines = normalized.split('\n');
    while (lines.isNotEmpty && lines.first.isEmpty) { lines.removeAt(0); }
    while (lines.isNotEmpty && lines.last.isEmpty) { lines.removeLast(); }
    return lines;
  }

  // 縦組み用 Unicode 字形。原稿の文字・改行は変えない。
  String _verticalGlyphText(String ch) => switch (ch) {
        '、' => '︑',
        '。' => '︒',
        '！' => '︕',
        '？' => '︖',
        '：' => '︓',
        '；' => '︔',
        '…' => '︙',
        '「' => '﹁',
        '」' => '﹂',
        '『' => '﹃',
        '』' => '﹄',
        '（' => '︵',
        '）' => '︶',
        '(' => '︵',
        ')' => '︶',
        '〈' => '︿',
        '〉' => '﹀',
        '《' => '︽',
        '》' => '︾',
        '【' => '︻',
        '】' => '︼',
        '〔' => '︹',
        '〕' => '︺',
        '［' => '﹇',
        '］' => '﹈',
        '｛' => '︷',
        '｝' => '︸',
        _ => ch,
      };

  bool _rotateVerticalGlyph(String ch) =>
      ch == 'ー' || ch == 'ｰ' || ch == '―' || ch == '—' || ch == '−' || ch == '-';

  Widget _verticalGlyph(String ch, double fontSize, double cellHeight, double columnWidth) {
    if (ch == '　' || ch == ' ') return SizedBox(width: columnWidth, height: cellHeight);
    Widget glyph = Text(
      _verticalGlyphText(ch),
      textAlign: TextAlign.center,
      style: TextStyle(fontSize: fontSize, height: 1.0, color: const Color(0xFFE8E8E8), fontWeight: FontWeight.w400),
    );
    if (_rotateVerticalGlyph(ch)) glyph = Transform.rotate(angle: math.pi / 2, child: glyph);
    return SizedBox(width: columnWidth, height: cellHeight, child: Center(child: glyph));
  }

  Widget _verticalColumn(String text, double fontSize, double cellHeight, double columnWidth) {
    final chars = text.runes.map((r) => String.fromCharCode(r)).toList();
    return SizedBox(
      width: columnWidth,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        for (final ch in chars) _verticalGlyph(ch, fontSize, cellHeight, columnWidth),
      ]),
    );
  }

  // 原稿の1行＝縦組みの1列。自動で列を増やさず、収まらない場合だけ文字を縮小する。
  // これによりユーザー指定の改行・空行をそのまま維持する。
  Widget _verticalFlowText(String text, {double fontSize = 15.0, double minFontSize = 9.0}) {
    final lines = _verticalLines(text);
    return LayoutBuilder(
      builder: (context, box) {
        if (lines.isEmpty) return const SizedBox.shrink();
        final maxChars = lines.fold<int>(0, (m, line) => math.max(m, line.runes.length));
        final columnCount = lines.length;
        final byHeight = maxChars == 0 ? fontSize : box.maxHeight / (maxChars * 1.52);
        final byWidth = columnCount == 0 ? fontSize : box.maxWidth / (columnCount * 1.56);
        final fitted = math.max(minFontSize, math.min(fontSize, math.min(byHeight, byWidth)));
        final cellHeight = fitted * 1.52;
        final columnWidth = fitted * 1.56;
        return Align(
          alignment: Alignment.topCenter,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final line in lines.reversed)
                line.isEmpty
                    ? SizedBox(width: columnWidth)
                    : _verticalColumn(line, fitted, cellHeight, columnWidth),
            ],
          ),
        );
      },
    );
  }

  Widget _verticalColumns(List<String> columns, {double fontSize = 24.0}) {
    final cellHeight = fontSize * 1.52;
    final columnWidth = fontSize * 1.58;
    return Center(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final col in columns.reversed)
            _verticalColumn(col, fontSize, cellHeight, columnWidth),
        ],
      ),
    );
  }

  Widget _storyPage(Widget child) => AspectRatio(
        aspectRatio: 563 / 1000,
        child: Container(
          color: Colors.black,
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 28),
          child: child,
        ),
      );

  Widget _storyFileImage(
    String relativePath, {
    BoxFit fit = BoxFit.cover,
    Alignment alignment = Alignment.topCenter,
  }) => FutureBuilder<File>(
        future: _AdditionalData.storyImage(relativePath),
        builder: (context, snap) {
          final f = snap.data;
          if (f == null || !f.existsSync()) return const SizedBox.shrink();
          return Image.file(f, fit: fit, alignment: alignment, filterQuality: FilterQuality.high);
        },
      );

  Widget _storyPilotImage(String relativePath) => Center(
        child: FractionallySizedBox(
          widthFactor: 0.78,
          child: AspectRatio(
            aspectRatio: 1,
            child: _storyFileImage(relativePath),
          ),
        ),
      );

  Widget _storyDualPilotImage() => Center(
        child: FractionallySizedBox(
          widthFactor: 0.82,
          child: AspectRatio(
            aspectRatio: 1,
            child: ClipRect(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: _storyFileImage('pilots/12934.jpg')),
                  Expanded(child: _storyFileImage('pilots/12940.jpg')),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _pilotImage(String asset) => Center(
        child: FractionallySizedBox(
          widthFactor: 0.78,
          child: AspectRatio(
            aspectRatio: 1,
            child: Image.asset(asset, fit: BoxFit.cover, alignment: Alignment.topCenter),
          ),
        ),
      );

  // 2人・3人の人物画像を、それぞれ中央寄りに細く切り抜いて隙間なく接続する。
  // 1枚の横長カットのように見せるため、名前ラベルや境界線は入れない。
  Widget _splitPilotImage(
    List<String> assets, {
    List<Alignment>? alignments,
  }) => Center(
        child: FractionallySizedBox(
          widthFactor: 0.82,
          child: AspectRatio(
            aspectRatio: 1,
            child: ClipRect(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (var i = 0; i < assets.length; i++)
                    Expanded(
                      child: ClipRect(
                        child: Image.asset(
                          assets[i],
                          fit: BoxFit.cover,
                          alignment: alignments != null && i < alignments.length
                              ? alignments[i]
                              : Alignment.topCenter,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _dualPilotImage() => _splitPilotImage(
        const [
          'assets/pilots/fighter.webp',
          'assets/pilots/knight.webp',
        ],
      );


  Widget _episodeCoverHeader() => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AspectRatio(
            aspectRatio: 16 / 7.6,
            child: ClipRect(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: _storyFileImage('pilots/12934.jpg')),
                  Expanded(child: _storyFileImage('pilots/12940.jpg')),
                ],
              ),
            ),
          ),
          const SizedBox(height:22),
          const Padding(
            padding:EdgeInsets.symmetric(horizontal:8),
            child:Text('小説〈Z〉第1話「脱走、戦闘」',textAlign:TextAlign.center,style:TextStyle(fontSize:23,fontWeight:FontWeight.w800)),
          ),
        ],
      );

  Widget _titlePage() => _storyPage(
        Center(
          child: _verticalColumns(
            const ['これは、戦争の終わらない', 'ある世界のお話。'],
            fontSize: 25,
          ),
        ),
      );

  Widget _worldPage() => _storyPage(
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
          child: _verticalFlowText(_worldIntro, fontSize: 15.5),
        ),
      );

  Widget _artsStoryPage() => _storyPage(
        Column(
          children: [
            const SizedBox(height: 20),
            Expanded(flex: 9, child: _storyPilotImage('pilots/12934.jpg')),
            const SizedBox(height: 18),
            Expanded(flex: 11, child: _verticalFlowText(_artsPage, fontSize: 13.5)),
          ],
        ),
      );

  Widget _bullStoryPage() => _storyPage(
        Column(
          children: [
            const SizedBox(height: 20),
            Expanded(flex: 12, child: _storyPilotImage('pilots/12940.jpg')),
            const SizedBox(height: 24),
            Expanded(
              flex: 8,
              child: _verticalColumns(
                const ['男「これはこれは、アーツさんじゃないですか。」'],
                fontSize: 15.5,
              ),
            ),
          ],
        ),
      );

  Widget _faceOffStoryPage() => _storyPage(
        Column(
          children: [
            const SizedBox(height: 20),
            Expanded(flex: 9, child: _storyDualPilotImage()),
            const SizedBox(height: 18),
            Expanded(flex: 11, child: _verticalFlowText(_faceOffPage, fontSize: 13.5)),
          ],
        ),
      );

  Widget _clashStoryPage() => _storyPage(
        Column(
          children: [
            const SizedBox(height: 20),
            Expanded(flex: 9, child: _storyDualPilotImage()),
            const SizedBox(height: 18),
            Expanded(flex: 11, child: _verticalFlowText(_clashPage, fontSize: 13.5)),
          ],
        ),
      );

  Widget _finishStoryPage() => _storyPage(
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
          child: _verticalFlowText(_finishPage, fontSize: 14.5),
        ),
      );

  Widget _continuePage() => _storyPage(
        Center(
          child: _verticalColumns(const ['つづく。'], fontSize: 34),
        ),
      );

  Future<void> _finishRead() async {
    if (!_markedRead) {
      _markedRead = true;
      await _StoryProgress.markEpisode1Read();
    }
  }

  Future<void> _openEpisode2() async {
    await _finishRead();
    if (!mounted) return;
    _handoffToNext = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => const StoryPanelEpisodeScreen(episode: 2, title: '逆転、安堵'),
      ),
    );
  }

  Future<void> _backToStoryList() async {
    await _finishRead();
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  Future<void> _backToMainMenu() async {
    await _finishRead();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainMenuScreen()),
      (route) => route.isFirst,
    );
  }

  Widget _endNavigation() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _withUiTap(_openEpisode2),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('第2話へ進む', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _withUiTap(_backToStoryList),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('STORY一覧へ戻る', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: _withUiTap(_backToMainMenu),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text('メインメニューへ戻る', style: TextStyle(fontSize: 15, color: Colors.white70)),
                ),
              ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: _easyBackButton(context),
          title: const Text('第1話「脱走、戦闘」'),
          actions: [
            IconButton(
              tooltip: _bgmOn ? 'BGM OFF' : 'BGM ON',
              onPressed: _withUiTap(_toggleBgm),
              icon: Icon(_bgmOn ? Icons.volume_up : Icons.volume_off),
            ),
          ],
        ),
        body: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 563),
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: const EdgeInsets.fromLTRB(12, 14, 12, 34),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _episodeCoverHeader(),
                    const SizedBox(height:24),
                    _titlePage(),
                    const SizedBox(height: 12),
                    _worldPage(),
                    const SizedBox(height: 12),
                    _artsStoryPage(),
                    const SizedBox(height: 12),
                    _bullStoryPage(),
                    const SizedBox(height: 12),
                    _faceOffStoryPage(),
                    const SizedBox(height: 12),
                    _clashStoryPage(),
                    const SizedBox(height: 12),
                    _finishStoryPage(),
                    const SizedBox(height: 12),
                    _continuePage(),
                    const SizedBox(height: 18),
                    _endNavigation(),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}


class StoryPanelEpisodeScreen extends StatefulWidget {
  const StoryPanelEpisodeScreen({super.key, required this.episode, required this.title});
  final int episode;
  final String title;

  @override
  State<StoryPanelEpisodeScreen> createState() => _StoryPanelEpisodeScreenState();
}

class _StoryPanelEpisodeScreenState extends State<StoryPanelEpisodeScreen> {
  static const _panelCounts = <int, int>{
    1: 8,
    2: 13,
    3: 11,
    4: 10,
    5: 12,
    6: 25,
    7: 25,
    8: 30,
    9: 30,
    10: 35,
    11: 33,
    12: 34,
  };

  final ScrollController _scrollController = ScrollController();
  bool _bgmOn = true;
  bool _markedRead = false;
  bool _handoffToNext = false;

  String get _bgmAsset => _StoryBgmPlan.byEpisode[widget.episode]!;
  String get _episodeDir => 'ep${widget.episode.toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    _AppBgm.play(_bgmAsset);
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_markedRead || !_scrollController.hasClients) return;
    final p = _scrollController.position;
    if (p.maxScrollExtent > 0 && p.pixels >= p.maxScrollExtent - 36) {
      _markedRead = true;
      _StoryProgress.markEpisodeRead(widget.episode);
    }
  }

  Future<void> _toggleBgm() async {
    if (_bgmOn) {
      await _AppBgm.stop();
    } else {
      await _AppBgm.play(_bgmAsset);
    }
    if (mounted) setState(() => _bgmOn = !_bgmOn);
  }

  Future<void> _finishRead() async {
    if (_markedRead) return;
    _markedRead = true;
    await _StoryProgress.markEpisodeRead(widget.episode);
  }

  Future<void> _openNext() async {
    await _finishRead();
    if (!mounted || widget.episode >= 12) return;
    const titles = <int, String>{
      2: '逆転、安堵', 3: '醒書、団結', 4: '狼煙、開戦', 5: '拮抗、少女', 6: '石版、過去',
      7: '再来、咆哮', 8: '教導、逃亡', 9: 'それぞれの道、そして',
      10: '醒める、幻', 11: '始まりの終わり', 12: '夢の終わり',
    };
    final next = widget.episode + 1;
    if (!_StoryProgress.isUnlocked(next)) return;
    _handoffToNext = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => StoryPanelEpisodeScreen(episode: next, title: titles[next]!)),
    );
  }

  Future<void> _backToStoryList() async {
    await _finishRead();
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _backToMainMenu() async {
    await _finishRead();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainMenuScreen()),
      (route) => route.isFirst,
    );
  }

  Widget _storyFileImage(String relativePath, {BoxFit fit = BoxFit.contain}) => FutureBuilder<File>(
        future: _AdditionalData.storyImage(relativePath),
        builder: (context, snap) {
          final f = snap.data;
          if (f == null || !f.existsSync()) return const SizedBox.shrink();
          return Image.file(f, fit: fit, filterQuality: FilterQuality.high);
        },
      );

  Widget _storyPanelImage(int number) => FutureBuilder<File>(
        future: _AdditionalData.storyPanel('$_episodeDir/panel_${number.toString().padLeft(2, '0')}.webp'),
        builder: (context, snap) {
          final f = snap.data;
          if (f == null || !f.existsSync()) {
            return const AspectRatio(
              aspectRatio: 9 / 16,
              child: ColoredBox(color: Colors.black),
            );
          }
          return Image.file(f, fit: BoxFit.fitWidth, filterQuality: FilterQuality.high);
        },
      );

  Widget _cover() => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AspectRatio(
            aspectRatio: 16 / 7.6,
            child: ClipRect(
              child: _storyFileImage('covers/episode_${widget.episode.toString().padLeft(2, '0')}.jpg', fit: BoxFit.cover),
            ),
          ),
          const SizedBox(height: 22),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              '小説〈Z〉第${widget.episode}話「${widget.title}」',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      );

  Widget _endNavigation() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
        child: Column(
          children: [
            if (widget.episode < 12 && _StoryProgress.isUnlocked(widget.episode + 1)) ...[
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _withUiTap(_openNext),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('次の話へ進む', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _withUiTap(_backToStoryList),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('STORY一覧へ戻る', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: _withUiTap(_backToMainMenu),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text('メインメニューへ戻る', style: TextStyle(fontSize: 15, color: Colors.white70)),
                ),
              ),
            ),
          ],
        ),
      );

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    if (!_handoffToNext) {
      _AppBgm.play('audio/2War Room Protocol.mp3');
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final count = _panelCounts[widget.episode] ?? 0;
    return Scaffold(
      appBar: AppBar(
        leading: _easyBackButton(context),
        title: Text('第${widget.episode}話「${widget.title}」'),
        actions: [
          IconButton(
            tooltip: _bgmOn ? 'BGM OFF' : 'BGM ON',
            onPressed: _withUiTap(_toggleBgm),
            icon: Icon(_bgmOn ? Icons.volume_up : Icons.volume_off),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 563),
            child: SingleChildScrollView(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(12, 14, 12, 34),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _cover(),
                  const SizedBox(height: 24),
                  for (var i = 1; i <= count; i++) ...[
                    _storyPanelImage(i),
                    if (i != count) const SizedBox(height: 12),
                  ],
                  const SizedBox(height: 18),
                  _endNavigation(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StoryChapter2EpisodeScreen extends StatefulWidget {
  const StoryChapter2EpisodeScreen({super.key, required this.episode, required this.title});
  final int episode;
  final String title;

  @override
  State<StoryChapter2EpisodeScreen> createState() => _StoryChapter2EpisodeScreenState();
}

class _StoryChapter2EpisodeScreenState extends State<StoryChapter2EpisodeScreen> {
  static const _panelCounts = <int, int>{
    1: 13, 2: 11, 3: 12, 4: 14, 5: 14, 6: 11, 7: 13,
    8: 14, 9: 15, 10: 16, 11: 19, 12: 20, 13: 15, 14: 12,
  };
  static const _titles = <int, String>{
    1: 'あの戦い', 2: '投げやり', 3: '花屋', 4: '風呂',
    5: 'シュトラーセ', 6: '真価', 7: '魔法', 8: '光の中',
    9: '断片', 10: '勢揃い', 11: '同化', 12: '総力戦',
    13: '最後の光', 14: '枯れない花',
  };

  final ScrollController _scrollController = ScrollController();
  bool _bgmOn = true;
  bool _markedRead = false;
  bool _handoffToNext = false;

  String get _bgmAsset => _StoryChapter2BgmPlan.byEpisode[widget.episode]!;
  String get _episodeDir => 'panels/ep${widget.episode.toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    _AppBgm.play(_bgmAsset);
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_markedRead || !_scrollController.hasClients) return;
    final p = _scrollController.position;
    if (p.maxScrollExtent > 0 && p.pixels >= p.maxScrollExtent - 36) {
      _markedRead = true;
      _StoryProgress.markChapter2Read(widget.episode);
    }
  }

  Future<void> _toggleBgm() async {
    if (_bgmOn) {
      await _AppBgm.stop();
    } else {
      await _AppBgm.play(_bgmAsset);
    }
    if (mounted) setState(() => _bgmOn = !_bgmOn);
  }

  Future<void> _finishRead() async {
    if (_markedRead) return;
    _markedRead = true;
    await _StoryProgress.markChapter2Read(widget.episode);
  }

  Future<void> _openNext() async {
    await _finishRead();
    if (!mounted || widget.episode >= 14) return;
    final next = widget.episode + 1;
    if (!_StoryProgress.isChapter2Unlocked(next)) return;
    _handoffToNext = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => StoryChapter2EpisodeScreen(episode: next, title: _titles[next]!)),
    );
  }

  Future<void> _backToStoryList() async {
    await _finishRead();
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _backToMainMenu() async {
    await _finishRead();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainMenuScreen()),
      (route) => route.isFirst,
    );
  }

  Widget _fileImage(String relativePath, {BoxFit fit = BoxFit.contain}) => FutureBuilder<File>(
        future: _AdditionalData.storyChapter2(relativePath),
        builder: (context, snap) {
          final f = snap.data;
          if (f == null || !f.existsSync()) {
            return const AspectRatio(aspectRatio: 1, child: ColoredBox(color: Colors.black));
          }
          return Image.file(f, fit: fit, filterQuality: FilterQuality.high);
        },
      );

  Widget _cover() => ClipRect(
        child: _fileImage(
          'covers/episode_${widget.episode.toString().padLeft(2, '0')}.jpg',
          fit: BoxFit.fitWidth,
        ),
      );

  Widget _endNavigation() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
        child: Column(
          children: [
            if (widget.episode < 14 && _StoryProgress.isChapter2Unlocked(widget.episode + 1)) ...[
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _withUiTap(_openNext),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12),
                    child: Text('次の話へ進む', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _withUiTap(_backToStoryList),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('STORY一覧へ戻る', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: _withUiTap(_backToMainMenu),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text('メインメニューへ戻る', style: TextStyle(fontSize: 15, color: Colors.white70)),
                ),
              ),
            ),
          ],
        ),
      );

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    if (!_handoffToNext) _AppBgm.play('audio/2War Room Protocol.mp3');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final count = _panelCounts[widget.episode] ?? 0;
    return Scaffold(
      appBar: AppBar(
        leading: _easyBackButton(context),
        title: Text(widget.episode == 14 ? '最終話「${widget.title}」' : '第${widget.episode}話「${widget.title}」'),
        actions: [
          IconButton(
            tooltip: _bgmOn ? 'BGM OFF' : 'BGM ON',
            onPressed: _withUiTap(_toggleBgm),
            icon: Icon(_bgmOn ? Icons.volume_up : Icons.volume_off),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 563),
            child: SingleChildScrollView(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(12, 14, 12, 34),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (widget.episode == 1) ...[
                    for (var i = 1; i <= 2; i++) ...[
                      _fileImage('intro/panel_${i.toString().padLeft(2, '0')}.webp', fit: BoxFit.fitWidth),
                      const SizedBox(height: 12),
                    ],
                  ],
                  _cover(),
                  const SizedBox(height: 24),
                  for (var i = 1; i <= count; i++) ...[
                    _fileImage('$_episodeDir/panel_${i.toString().padLeft(2, '0')}.webp', fit: BoxFit.fitWidth),
                    if (i != count) const SizedBox(height: 12),
                  ],
                  const SizedBox(height: 18),
                  _endNavigation(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _OwnProfilePreview extends StatelessWidget {
  const _OwnProfilePreview();
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('詳細プロフィール')),body:FutureBuilder<SharedPreferences>(future:SharedPreferences.getInstance(),builder:(context,snap){
    final p=snap.data;if(p==null)return const Center(child:CircularProgressIndicator());
    String asset(String g){for(final x in _profileExtras){if(x.$1==g&&x.$2==p.getString('profile_extra_selected_$g'))return x.$5;}return '';}
    final bg=asset('bg'),rating=p.getInt('competitive_rating')??1000;
    return Container(decoration:BoxDecoration(color:Colors.black,image:bg.isEmpty?null:DecorationImage(image:AssetImage(bg),fit:BoxFit.cover)),child:SafeArea(child:ListView(padding:const EdgeInsets.all(24),children:[
      Center(child:SizedBox(width:126,height:126,child:Stack(fit:StackFit.expand,children:[Image.asset(_LocalPlayerProfile.image(p.getString('player_icon_v1')??'arts'),fit:BoxFit.contain)]))),
      const SizedBox(height:16),Container(padding:const EdgeInsets.all(16),color:Colors.black.withOpacity(.65),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(p.getString('player_name_v1')??'PLAYER',style:const TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.bold)),
        Text(p.getString('player_comment_v1')??'',style:const TextStyle(color:Colors.white)),
        const Divider(),Text('ランク ${_CompetitiveProfile.ranks[_CompetitiveProfile.rank(rating)]} / $rating'),
        Text('階級 ${_CompetitiveProfile.grades[(p.getInt('competitive_grade')??0).clamp(0,12).toInt()]}'),
        Text('称号 ${p.getString('competitive_selected_title')??''}'),
        Text('戦績 ${_CompetitiveProfile.count(p,'wins')}勝 ${_CompetitiveProfile.count(p,'losses')}敗'),
        const Text('いいね 0（通信未接続）'),const Divider(),
        for(final x in _profileExtras.where((x)=>x.$1!='bg'&&x.$2==p.getString('profile_extra_selected_${x.$1}')).take(5))Text('${x.$1}：${x.$3}'),
      ]))])));
  }));
}

class _RearLineDummyPlayer {
  const _RearLineDummyPlayer(this.name,this.asset,this.message,this.unit,this.rank,this.status);
  final String name,asset,message,unit,status; final int rank;
}
class RearLineScreen extends StatelessWidget {
  const RearLineScreen({super.key});
  static const _players=< _RearLineDummyPlayer>[
    _RearLineDummyPlayer('RYOTA','assets/pilots/fighter.webp','今日はKINGでいく','第七独立',12,'オンライン'),
    _RearLineDummyPlayer('AOBA','assets/pilots/guard.webp','対戦募集中','黒鉄旅団',3,'オンライン'),
    _RearLineDummyPlayer('REI','assets/pilots/attendant.webp','のんびりやる','第七独立',12,'団体戦待機中'),
    _RearLineDummyPlayer('GIL','assets/pilots/general.webp','負けたら寝る','蒼天機兵',21,'出撃中'),
    _RearLineDummyPlayer('JACK','assets/pilots/king.webp','よろしく','無所属',0,'離席中'),
    _RearLineDummyPlayer('ARTS','assets/pilots/fighter.webp','KINGしか勝たん','白銀隊',8,'オンライン'),
  ];
  void _profile(BuildContext context,_RearLineDummyPlayer p){
    showModalBottomSheet<void>(context:context,isScrollControlled:true,backgroundColor:const Color(0xFF11141A),builder:(_)=>SafeArea(child:SingleChildScrollView(padding:const EdgeInsets.fromLTRB(22,18,22,28),child:Column(mainAxisSize:MainAxisSize.min,children:[
      Container(width:92,height:92,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white38)),padding:const EdgeInsets.all(5),child:ClipOval(child:Image.asset(p.asset,fit:BoxFit.cover))),
      const SizedBox(height:12),Text(p.name,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text('「${p.message}」',style:const TextStyle(color:Colors.white70)),const SizedBox(height:12),
      Text('${p.unit}${p.rank>0?'  ${p.rank}位':''}',style:const TextStyle(fontWeight:FontWeight.w800)),const Divider(color:Colors.white24),
      const Align(alignment:Alignment.centerLeft,child:Text('ランク　B / 1380')),const Align(alignment:Alignment.centerLeft,child:Text('階級　軍曹')),const Align(alignment:Alignment.centerLeft,child:Text('称号　獅子心王')),const Align(alignment:Alignment.centerLeft,child:Text('累計いいね　84')),
      const SizedBox(height:8),const Align(alignment:Alignment.centerLeft,child:Text('将来の夢　赤ちゃん')),const Align(alignment:Alignment.centerLeft,child:Text('戦う理由　なんとなく')),const Align(alignment:Alignment.centerLeft,child:Text('戦場での役割　見学')),const Align(alignment:Alignment.centerLeft,child:Text('座右の銘　知らんけど')),const Align(alignment:Alignment.centerLeft,child:Text('欲しいもの　睡眠時間')),
    ]))));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(leading:_easyBackButton(context),title:const Text('REAR LINE'),actions:[Padding(padding:const EdgeInsets.only(right:14),child:Center(child:FutureBuilder<_LocalPlayerProfile>(future:_LocalPlayerProfile.load(),builder:(context,snap)=>Text(snap.hasData?'CHIP ${_ProfileIcon.balance(snap.data!.owned)}':'CHIP …',style:const TextStyle(fontWeight:FontWeight.w900)))))]),
    body:_ScreenBgm(asset:'audio/2War Room Protocol.mp3',child:SafeArea(child:DefaultTabController(length:2,child:Column(children:[const Text('開発用サンプル・通信未接続',style:TextStyle(color:Colors.white60,fontSize:12)),TextButton(onPressed:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const _OwnProfilePreview())),child:const Text('自分の詳細プロフィール')),const TabBar(tabs:[Tab(text:'全員'),Tab(text:'知り合い')]),Expanded(child:TabBarView(children:[ListView.separated(padding:const EdgeInsets.fromLTRB(14,14,14,24),itemCount:_players.length,separatorBuilder:(_,__)=>const SizedBox(height:10),itemBuilder:(_,i){final p=_players[i];return InkWell(onTap:_withUiTap(()=>_profile(context,p)),borderRadius:BorderRadius.circular(12),child:Container(
      padding:const EdgeInsets.all(12),decoration:BoxDecoration(border:Border.all(color:Colors.white24),borderRadius:BorderRadius.circular(12),color:Colors.black.withOpacity(.20)),
      child:Row(children:[
        Container(width:58,height:58,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white30)),padding:const EdgeInsets.all(3),child:ClipOval(child:Image.asset(p.asset,fit:BoxFit.cover))),
        const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(p.name,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900))),Text(p.status,style:const TextStyle(fontSize:11,color:Colors.cyanAccent))]),const SizedBox(height:4),Text('「${p.message}」',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70)),const SizedBox(height:4),Text('${p.unit}${p.rank>0?'  ${p.rank}位':''}',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:12,color:Colors.white54))]))
      ]),
    ));}),const Center(child:Text('本番通信接続後に対戦相手を表示します'))]))])))),
  );
}

class CpuDifficultyScreen extends StatelessWidget {
  const CpuDifficultyScreen({super.key});
  void _start(BuildContext context,CpuDifficulty d){
    _CpuDifficultyState.current=d;
    final playerWonInitiative=math.Random().nextBool();
    Navigator.of(context).push(MaterialPageRoute(builder:(_)=>_unitSelectionEntry(playerWonJanken:playerWonInitiative, mode:BattleMode.cpu)));
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(leading:_matchExitButton(context),title:const Text('CPU LEVEL')),body:_ScreenBgm(asset:'audio/3Unit Lockdown.m4a',child:SafeArea(child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
    for(final d in CpuDifficulty.values)...[SizedBox(width:280,child:OutlinedButton(onPressed:_withUiTap(()=>_start(context,d)),child:Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Column(children:[Text(d.label,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900,letterSpacing:1.5)),const SizedBox(height:3),Text(d.jp,style:const TextStyle(color:Colors.white60))])))),const SizedBox(height:14)]
  ])))));
}

class BattleMenuScreen extends StatelessWidget {
  const BattleMenuScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(leading: _easyBackButton(context), title: const Text('BATTLE')),
        body: _ScreenBgm(asset: 'audio/2War Room Protocol.mp3', child: SafeArea(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () {
                      _CpuDifficultyState.current = CpuDifficulty.easy;
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const JankenScreen()));
                    },
                    child: const Column(
                      children: [
                        Text('PRACTICE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('オンライン対戦の練習', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: _withUiTap(() => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LocalJankenResultScreen()))),
                    child: const Column(
                      children: [
                        Text('LOCAL BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('1台で2人対戦', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: 260,
                  child: TextButton(
                    onPressed: () {
                      // ONLINE BATTLE test: flow is online-oriented from entry to result.
                      // Only the remote input source is temporarily substituted by EASY CPU.
                      _CpuDifficultyState.current = CpuDifficulty.easy;
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => const OnlineMatchingScreen(),
                      ));
                    },
                    child: const Column(
                      children: [
                        Text('ONLINE BATTLE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                        SizedBox(height: 3),
                        Text('オンライン対戦  /  TEST', style: TextStyle(fontSize: 12, color: Colors.white60)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        )),
      );
}


class LocalJankenResultScreen extends StatelessWidget {
  const LocalJankenResultScreen({super.key});

  void _start(BuildContext context, bool player1Won) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _unitSelectionEntry(
        playerWonJanken: player1Won,
        mode: BattleMode.local,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) => _MatchExitGuard(
        child: Scaffold(
          appBar: AppBar(leading: _matchExitButton(context), title: const Text('LOCAL BATTLE')),
          body: _ScreenBgm(
            asset: 'audio/3Unit Lockdown.m4a',
            child: SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('INITIATIVE', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 10),
                      const Text('端末の外でじゃんけんをしてください', style: TextStyle(fontSize: 15, color: Colors.white60)),
                      const SizedBox(height: 30),
                      const Text('勝ったプレイヤーを入力', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 22),
                      SizedBox(
                        width: 270,
                        child: OutlinedButton(
                          onPressed: _withUiTap(() => _start(context, true)),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 13),
                            child: Text('PLAYER 1  勝利', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: 270,
                        child: OutlinedButton(
                          onPressed: _withUiTap(() => _start(context, false)),
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 13),
                            child: Text('PLAYER 2  勝利', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}


class OnlineMatchingScreen extends StatefulWidget {
  const OnlineMatchingScreen({super.key});

  @override
  State<OnlineMatchingScreen> createState() => _OnlineMatchingScreenState();
}

class _OnlineMatchingScreenState extends State<OnlineMatchingScreen> {
  int _secondsLeft = 10;
  Timer? _timer;
  bool _matched = false;
  _LocalPlayerProfile? _localProfile;

  @override
  void initState() {
    super.initState();
    _LocalPlayerProfile.load().then((p) { if (mounted) setState(() => _localProfile = p); });
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _matched) {
        timer.cancel();
        return;
      }
      if (_secondsLeft <= 1) {
        timer.cancel();
        _completeMatch();
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  void _completeMatch() {
    if (!mounted || _matched) return;
    setState(() {
      _matched = true;
      _secondsLeft = 0;
    });
    // The current ONLINE flow is a local test; do not invent a remote player.
    _timer = Timer(const Duration(seconds: 5), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => const JankenScreen(mode: BattleMode.onlineTest),
      ));
    });
  }

  void _cancelSearch() {
    if (_matched || !mounted) return;
    _timer?.cancel();
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: !_matched,
        onPopInvokedWithResult: (didPop, result) {
          if (didPop) _timer?.cancel();
        },
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            leading: IconButton(
              tooltip: '戻る',
              onPressed: _matched ? null : _withUiTap(_cancelSearch),
              icon: const Icon(Icons.arrow_back),
            ),
            title: const Text('ONLINE BATTLE'),
          ),
          body: _ScreenBgm(
            asset: 'audio/3Unit Lockdown.m4a',
            child: SafeArea(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (_matched) ...[
                    Image.asset('assets/title/matching_desert.png', fit: BoxFit.cover),
                    Container(color: const Color(0x99050008)),
                  ],
                  Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                      child: _matched
                          ? LayoutBuilder(builder: (context, constraints) {
                              final compact = constraints.maxHeight < 580;
                              final portraitSize = compact ? 76.0 : 106.0;
                              final quote = _availableProfileQuotes()
                                  .where((q) => q.id == _localProfile?.quoteId)
                                  .map((q) => q.line)
                                  .firstOrNull ?? _availableProfileQuotes().first.line;
                              Widget portrait(String asset, Color accent, {BoxFit fit = BoxFit.cover}) => Container(
                                width: portraitSize,
                                height: portraitSize,
                                decoration: BoxDecoration(
                                  border: Border.all(color: accent, width: 2),
                                  borderRadius: BorderRadius.circular(7),
                                  boxShadow: [BoxShadow(color: accent.withOpacity(0.45), blurRadius: 12)],
                                ),
                                clipBehavior: Clip.antiAlias,
                                child: _LocalPlayerProfile.portrait(asset, fit: fit),
                              );
                              Widget info(String name, String? line, Color accent, {required int rating, required int grade, String title = ''}) => Expanded(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                                  decoration: BoxDecoration(
                                    color: const Color(0xD9101018),
                                    border: Border(bottom: BorderSide(color: accent, width: 2)),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                        style: TextStyle(fontSize: compact ? 19 : 23, fontWeight: FontWeight.bold, color: Colors.white)),
                                      Text('${_CompetitiveProfile.ranks[_CompetitiveProfile.rank(rating)]} / RATE $rating  ${_CompetitiveProfile.grades[grade]}', style: TextStyle(color: accent, fontSize: compact ? 11 : 14)),
                                      if (title.isNotEmpty) Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                                      if (line != null) ...[
                                        const SizedBox(height: 7),
                                        Text('「$line」', maxLines: 3, overflow: TextOverflow.ellipsis,
                                          style: TextStyle(fontSize: compact ? 12 : 15, color: Colors.white)),
                                      ],
                                    ],
                                  ),
                                ),
                              );
                              return Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Text('MATCHING COMPLETE',
                                      style: TextStyle(color: Color(0xFFECC67C), fontSize: 25,
                                        fontWeight: FontWeight.bold, letterSpacing: 1.4,
                                        shadows: [Shadow(color: Color(0xFFB66C16), blurRadius: 12)])),
                                  ),
                                  const SizedBox(height: 22),
                                  Row(children: [
                                    portrait(_LocalPlayerProfile.image(_localProfile?.icon ?? 'arts'), const Color(0xFF86C5FF)),
                                    const SizedBox(width: 12),
                                    info(_localProfile?.name ?? 'PLAYER', quote, const Color(0xFF86C5FF), rating: _localProfile?.rating ?? 1000, grade: _localProfile?.grade ?? 0, title: _localProfile?.title ?? ''),
                                  ]),
                                  const SizedBox(height: 14),
                                  const Text('VS', style: TextStyle(fontSize: 52, fontWeight: FontWeight.w900,
                                    fontStyle: FontStyle.italic, color: Colors.white,
                                    shadows: [Shadow(color: Color(0xFFFFA632), blurRadius: 20)])),
                                  const SizedBox(height: 14),
                                  Row(children: [
                                    portrait('assets/profile/arts.webp', const Color(0xFFFF6868)),
                                    const SizedBox(width: 12),
                                    info('CPU（通信テスト）', null, const Color(0xFFFF6868), rating: 1000, grade: 0),
                                  ]),
                                ],
                              );
                            })
                          : Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const SizedBox(width: 54, height: 54,
                                  child: CircularProgressIndicator(strokeWidth: 4)),
                                const SizedBox(height: 24),
                                const Text('対戦相手を検索中…',
                                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                                const SizedBox(height: 30),
                                OutlinedButton(onPressed: _withUiTap(_cancelSearch),
                                  child: const Text('CANCEL')),
                              ],
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
}

class JankenScreen extends StatefulWidget {
  final BattleMode mode;
  const JankenScreen({super.key, this.mode = BattleMode.cpu});

  @override
  State<JankenScreen> createState() => _JankenScreenState();
}

class _JankenScreenState extends State<JankenScreen> {
  String? playerHand;
  String? cpuHand;
  String? result;
  int _secondsLeft = 15;
  Timer? _timer;
  Timer? _autoNextTimer;

  static const hands = ['グー', 'チョキ', 'パー'];

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    _secondsLeft = 15;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || (result != null && result != 'DRAW')) { timer.cancel(); return; }
      if (_secondsLeft <= 1) {
        timer.cancel();
        // CPU戦ではCPUは常に選択済み扱い。YOU未選択はじゃんけん負け。
        setState(() {
          _secondsLeft = 0;
          playerHand = '未選択';
          cpuHand = hands[DateTime.now().microsecondsSinceEpoch % 3];
          result = 'LOSE';
        });
        _autoNextTimer?.cancel();
        _autoNextTimer = Timer(const Duration(seconds: 3), () {
          if (mounted && result == 'LOSE') _goNext();
        });
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  @override
  void dispose() { _timer?.cancel(); _autoNextTimer?.cancel(); super.dispose(); }

  void play(String hand) {
    if (result != null) return;
    _timer?.cancel();
    final cpu = hands[DateTime.now().microsecondsSinceEpoch % 3];
    String r;
    if (hand == cpu) {
      r = 'DRAW';
    } else if ((hand == 'グー' && cpu == 'チョキ') ||
        (hand == 'チョキ' && cpu == 'パー') ||
        (hand == 'パー' && cpu == 'グー')) {
      r = 'WIN';
    } else {
      r = 'LOSE';
    }
    setState(() {
      playerHand = hand;
      cpuHand = cpu;
      result = r;
    });
    if (r != 'DRAW') {
      _autoNextTimer?.cancel();
      _autoNextTimer = Timer(const Duration(seconds: 3), () {
        if (mounted && result != null && result != 'DRAW') _goNext();
      });
    }
    if (r == 'DRAW') {
      Future<void>.delayed(const Duration(milliseconds: 850), () {
        if (!mounted || result != 'DRAW') return;
        setState(() { playerHand = null; cpuHand = null; result = null; });
        _startTimer();
      });
    }
  }

  void _goNext() {
    _autoNextTimer?.cancel();
    final playerWon = result == 'WIN';
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _unitSelectionEntry(playerWonJanken: playerWon, mode: widget.mode),
    ));
  }

  @override
  Widget build(BuildContext context) => _MatchExitGuard(child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: widget.mode == BattleMode.onlineTest ? null : _matchExitButton(context),
          title: Text(widget.mode == BattleMode.onlineTest ? 'ONLINE BATTLE' : 'PRACTICE'),
        ),
        body: _ScreenBgm(asset: 'audio/3Unit Lockdown.m4a', child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('INITIATIVE', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('じゃんけん', style: TextStyle(fontSize: 15, color: Colors.white60)),
                  const SizedBox(height: 8),
                  Text('$_secondsLeft', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.cyanAccent)),
                  const SizedBox(height: 20),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 12,
                    children: [
                      for (final hand in hands)
                        OutlinedButton(
                          onPressed: result == null ? _withUiTap(() => play(hand)) : null,
                          child: Text(hand, style: const TextStyle(fontSize: 18)),
                        ),
                    ],
                  ),
                  const SizedBox(height: 34),
                  if (result != null) ...[
                    Text('YOU  $playerHand   /   ${widget.mode == BattleMode.onlineTest ? 'OPPONENT' : 'CPU'}  $cpuHand', style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 12),
                    Text(result!, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w800, letterSpacing: 3)),
                    const SizedBox(height: 28),
                    if (result != 'DRAW')
                      FilledButton(onPressed: _withUiTap(_goNext), child: const Text('NEXT')),
                  ],
                ],
              ),
            ),
          ),
        )),
      ));
}

enum BattleMode { cpu, local, onlineTest }

enum BattleUnit { king, knight, emperor, strasse, master }

extension BattleUnitInfo on BattleUnit {
  String get title => switch (this) {
        BattleUnit.king => 'KING',
        BattleUnit.knight => 'KNIGHT',
        BattleUnit.emperor => 'EMPEROR',
        BattleUnit.strasse => 'STRASSE',
        BattleUnit.master => 'MASTER',
      };

  String get jp => switch (this) {
        BattleUnit.king => 'キング',
        BattleUnit.knight => 'ナイト',
        BattleUnit.emperor => 'エンペラー',
        BattleUnit.strasse => 'シュトラーセ',
        BattleUnit.master => 'マスター',
      };

  String representativeAsset(bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (this) {
      BattleUnit.king => 'assets/pieces/${side}_king.png',
      BattleUnit.knight => 'assets/pieces/${side}_knight.png',
      BattleUnit.emperor => 'assets/pieces/${side}_emperor.png',
      BattleUnit.strasse => 'assets/pieces/${side}_strasse_spear.png',
      BattleUnit.master => _MasterProgress.masterRepresentative(isWhite),
    };
  }
}

// KINGが唯一の解禁ユニットなら、UNIT SELECT画面を表示せず次へ進む。
// 複数解禁後の通常選択フローは変更しない。
Widget _unitSelectionEntry({required bool playerWonJanken, required BattleMode mode}) {
  final units = _StoryProgress.availableUnits;
  if (units.length != 1) {
    return UnitSelectionScreen(playerWonJanken: playerWonJanken, mode: mode);
  }
  final onlyUnit = units.single;
  if (mode != BattleMode.local && !playerWonJanken) {
    final cpuChoosesFirst = DateTime.now().microsecondsSinceEpoch.isEven;
    return InitialPlacementScreen(
      playerUnit: onlyUnit,
      cpuUnit: onlyUnit,
      playerIsWhite: !cpuChoosesFirst,
      mode: mode,
    );
  }
  return InitiativeChoiceScreen(
    playerWonJanken: playerWonJanken,
    playerUnit: onlyUnit,
    cpuUnit: onlyUnit,
    mode: mode,
  );
}

class UnitSelectionScreen extends StatefulWidget {
  final bool playerWonJanken;
  final BattleMode mode;
  const UnitSelectionScreen({
    super.key,
    required this.playerWonJanken,
    this.mode = BattleMode.cpu,
  });

  @override
  State<UnitSelectionScreen> createState() => _UnitSelectionScreenState();
}

class _UnitSelectionScreenState extends State<UnitSelectionScreen> {
  BattleUnit? selected;
  BattleUnit? playerUnit;
  BattleUnit? cpuUnit;
  int step = 0;
  bool _cpuUnitSelectionScheduled = false;
  bool _unitSelectionFinished = false;
  int _unitSecondsLeft = 15;
  Timer? _unitTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startUnitTimerIfHuman());
  }

  void _startUnitTimerIfHuman() {
    _unitTimer?.cancel();
    if (!mounted || _unitSelectionFinished || !selectingPlayer || !_usesSimulatedRemote) return;
    setState(() => _unitSecondsLeft = 15);
    _unitTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _unitSelectionFinished || !selectingPlayer || !_usesSimulatedRemote) { timer.cancel(); return; }
      if (_unitSecondsLeft <= 1) {
        timer.cancel();
        final units = _availableUnits; selected = units[math.Random().nextInt(units.length)];
        _confirm();
      } else {
        setState(() => _unitSecondsLeft--);
      }
    });
  }

  @override
  void dispose() { _unitTimer?.cancel(); super.dispose(); }

  bool get selectingPlayer =>
      widget.playerWonJanken ? step == 0 : step == 1;

  bool get _usesSimulatedRemote => widget.mode == BattleMode.cpu || widget.mode == BattleMode.onlineTest;
  String get _player1Name => widget.mode == BattleMode.local ? 'PLAYER 1' : 'YOU';
  String get _player2Name => widget.mode == BattleMode.local ? 'PLAYER 2' : (widget.mode == BattleMode.onlineTest ? 'OPPONENT' : 'CPU');
  String get selectingName => selectingPlayer ? _player1Name : _player2Name;
  bool get _manualSelection => widget.mode == BattleMode.local || selectingPlayer;

  List<BattleUnit> get _availableUnits => _StoryProgress.availableUnits;

  void _scheduleCpuUnitSelectionIfNeeded() {
    if (!_usesSimulatedRemote || _unitSelectionFinished || selectingPlayer || _cpuUnitSelectionScheduled) return;
    _cpuUnitSelectionScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (!mounted || _unitSelectionFinished || selectingPlayer) return;
        final units = _availableUnits;
        selected = units[DateTime.now().microsecondsSinceEpoch % units.length];
        _cpuUnitSelectionScheduled = false;
        _confirm();
      });
    });
  }

  void _confirm() {
    if (selected == null) return;

    setState(() {
      if (selectingPlayer) {
        playerUnit = selected;
      } else {
        cpuUnit = selected;
      }

      if (step == 0) {
        step = 1;
        selected = null;
        WidgetsBinding.instance.addPostFrameCallback((_) => _startUnitTimerIfHuman());
        return;
      }
    });

    if (playerUnit == null || cpuUnit == null || _unitSelectionFinished) return;
    _unitSelectionFinished = true;

    // CPUがじゃんけん勝者の時は、プレイヤーが操作しないINITIATIVE画面を
    // 1フレームも描画しない。CPUの先後攻は内部決定して配置へ直接進む。
    final Widget next;
    if (_usesSimulatedRemote && !widget.playerWonJanken) {
      final cpuChoosesFirst = DateTime.now().microsecondsSinceEpoch.isEven;
      next = InitialPlacementScreen(
        playerUnit: playerUnit!,
        cpuUnit: cpuUnit!,
        playerIsWhite: !cpuChoosesFirst,
        mode: widget.mode,
      );
    } else {
      next = InitiativeChoiceScreen(
        playerWonJanken: widget.playerWonJanken,
        playerUnit: playerUnit!,
        cpuUnit: cpuUnit!,
        mode: widget.mode,
      );
    }

    if (widget.mode == BattleMode.cpu &&
        (cpuUnit == BattleUnit.strasse || cpuUnit == BattleUnit.master)) {
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => CpuBattleHintScreen(cpuUnit: cpuUnit!, next: next),
      ));
    } else {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => next));
    }
  }

  @override
  Widget build(BuildContext context) {
    _scheduleCpuUnitSelectionIfNeeded();
    final winnerName = widget.playerWonJanken ? _player1Name : _player2Name;
    final loserName = widget.playerWonJanken ? _player2Name : _player1Name;
    final instruction = step == 0
        ? 'じゃんけん勝者：$winnerName － 先にユニットを選択'
        : 'じゃんけん敗者：$loserName － 次にユニットを選択';

    return _MatchExitGuard(child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: widget.mode == BattleMode.onlineTest ? null : _matchExitButton(context),
        title: const Text('UNIT SELECT'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          child: Column(
            children: [
              Text(
                instruction,
                style: const TextStyle(fontSize: 15, color: Colors.white70),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              if (selectingPlayer && _usesSimulatedRemote)
                Text('残り $_unitSecondsLeft 秒', style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.w800)),
              if (selectingPlayer && _usesSimulatedRemote) const SizedBox(height: 4),
              Text(
                '現在：$selectingName のユニットを選択',
                style: const TextStyle(fontSize: 14, color: Colors.white60),
              ),
              if (step == 1 && (playerUnit != null || cpuUnit != null)) ...[
                const SizedBox(height: 10),
                Builder(builder: (context) {
                  // CPUが先に選んだ場合も、確定した相手ユニットは通常どおり表示する。
                  // 隠すのはCPU抽選中の候補一覧だけ。
                  final firstUnit = playerUnit ?? cpuUnit!;
                  final firstName = playerUnit != null ? _player1Name : _player2Name;
                  return Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(border: Border.all(color: Colors.cyanAccent.withOpacity(.55)), borderRadius: BorderRadius.circular(10)),
                    child: Row(children: [
                      SizedBox(width: 42, height: 42, child: Image.asset(firstUnit.representativeAsset(playerUnit != null), fit: BoxFit.contain)),
                      const SizedBox(width: 10),
                      Expanded(child: Text('$firstName 選択済み：${firstUnit.title} / ${firstUnit.jp}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
                    ]),
                  );
                }),
              ],
              const SizedBox(height: 18),
              Expanded(
                child: _usesSimulatedRemote && !selectingPlayer
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(width: 34, height: 34, child: CircularProgressIndicator(strokeWidth: 2.5)),
                            SizedBox(height: 16),
                            Text('${widget.mode == BattleMode.onlineTest ? 'OPPONENT' : 'CPU'} SELECTING...', style: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
                          ],
                        ),
                      )
                    : ListView.separated(
                        itemCount: _availableUnits.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (_, i) {
                          final unit = _availableUnits[i];
                          final active = selected == unit;
                          return InkWell(
                            onTap: _manualSelection ? _withUiTap(() => setState(() => selected = unit)) : null,
                            borderRadius: BorderRadius.circular(14),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 120),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: active ? Colors.cyanAccent : Colors.white24,
                                  width: active ? 2 : 1,
                                ),
                                color: active ? Colors.cyanAccent.withOpacity(.08) : Colors.white.withOpacity(.02),
                              ),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 78,
                                    height: 78,
                                    child: Image.asset(unit.representativeAsset(true), fit: BoxFit.contain),
                                  ),
                                  const SizedBox(width: 18),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(unit.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                                        const SizedBox(height: 2),
                                        Text(unit.jp, style: const TextStyle(color: Colors.white60)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: !_manualSelection || selected == null ? null : _withUiTap(_confirm),
                  child: Text(step == 0 ? '決定して次へ' : '決定'),
                ),
              ),
            ],
          ),
        ),
      ),
    ));
  }
}


class CpuBattleHintScreen extends StatefulWidget {
  final BattleUnit cpuUnit;
  final Widget next;
  const CpuBattleHintScreen({super.key, required this.cpuUnit, required this.next});

  @override
  State<CpuBattleHintScreen> createState() => _CpuBattleHintScreenState();
}

class _CpuBattleHintScreenState extends State<CpuBattleHintScreen> {
  Timer? _autoNextTimer;
  bool _navigating = false;

  String get _hint => switch (widget.cpuUnit) {
        BattleUnit.strasse => 'この敵は、通常とは異なる機動戦を得意とする。',
        BattleUnit.master => '見慣れない駒には、それぞれ異なる役割がある。',
        _ => '',
      };

  @override
  void initState() {
    super.initState();
    _autoNextTimer = Timer(const Duration(seconds: 10), _goNext);
  }

  @override
  void dispose() {
    _autoNextTimer?.cancel();
    super.dispose();
  }

  void _goNext() {
    if (!mounted || _navigating) return;
    _navigating = true;
    _autoNextTimer?.cancel();
    // ヒント画面へ戻れてしまわないよう、次画面へ置き換える。
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => widget.next));
  }

  @override
  Widget build(BuildContext context) => _MatchExitGuard(
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(leading: _matchExitButton(context), title: const Text('PRACTICE')),
          body: SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('BATTLE HINT', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 2.4)),
                    const SizedBox(height: 26),
                    Text(_hint, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, height: 1.65, color: Colors.white)),
                    const SizedBox(height: 34),
                    SizedBox(
                      width: 220,
                      child: FilledButton(
                        onPressed: _withUiTap(_goNext),
                        child: const Text('NEXT'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class InitiativeChoiceScreen extends StatefulWidget {
  final bool playerWonJanken;
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  final BattleMode mode;
  const InitiativeChoiceScreen({
    super.key,
    required this.playerWonJanken,
    required this.playerUnit,
    required this.cpuUnit,
    this.mode = BattleMode.cpu,
  });

  @override
  State<InitiativeChoiceScreen> createState() => _InitiativeChoiceScreenState();
}

class _InitiativeChoiceScreenState extends State<InitiativeChoiceScreen> {
  bool _cpuInitiativeScheduled = false;
  bool get _usesSimulatedRemote => widget.mode == BattleMode.cpu || widget.mode == BattleMode.onlineTest;
  bool _initiativeNavigationStarted = false;
  int _initiativeSecondsLeft = 15;
  Timer? _initiativeTimer;

  @override
  void initState() {
    super.initState();
    if (_usesSimulatedRemote && widget.playerWonJanken) {
      _initiativeTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!mounted || _initiativeNavigationStarted) { timer.cancel(); return; }
        if (_initiativeSecondsLeft <= 1) {
          timer.cancel();
          _startSetup(math.Random().nextBool());
        } else {
          setState(() => _initiativeSecondsLeft--);
        }
      });
    }
  }

  @override void dispose() { _initiativeTimer?.cancel(); super.dispose(); }

  void _scheduleCpuInitiativeIfNeeded() {
    if (!_usesSimulatedRemote || widget.playerWonJanken || _cpuInitiativeScheduled || _initiativeNavigationStarted) return;
    _cpuInitiativeScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (!mounted || _initiativeNavigationStarted) return;
        final chooseFirst = DateTime.now().microsecondsSinceEpoch.isEven;
        _startSetup(chooseFirst);
      });
    });
  }

  void _startSetup(bool winnerChoosesFirst) {
    if (_initiativeNavigationStarted) return;
    _initiativeNavigationStarted = true;
    _initiativeTimer?.cancel();
    // 勝者が先攻を選んだ場合：勝者が白。後攻なら勝者が黒。
    // YOU がじゃんけん勝者かどうかを加味して YOU の色を決める。
    final playerIsWhite = widget.playerWonJanken
        ? winnerChoosesFirst
        : !winnerChoosesFirst;

    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => InitialPlacementScreen(
        playerUnit: widget.playerUnit,
        cpuUnit: widget.cpuUnit,
        playerIsWhite: playerIsWhite,
        mode: widget.mode,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    _scheduleCpuInitiativeIfNeeded();
    final winnerName = widget.playerWonJanken
        ? (widget.mode == BattleMode.local ? 'PLAYER 1' : 'YOU')
        : (widget.mode == BattleMode.local ? 'PLAYER 2' : (widget.mode == BattleMode.onlineTest ? 'OPPONENT' : 'CPU'));
    return _MatchExitGuard(child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: widget.mode == BattleMode.onlineTest ? null : _matchExitButton(context),
        title: const Text('INITIATIVE'),
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('先攻・後攻選択', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Text(
                  'じゃんけん勝者：$winnerName が選択',
                  style: const TextStyle(color: Colors.white60),
                ),
                if (_usesSimulatedRemote && widget.playerWonJanken) ...[
                  const SizedBox(height: 10),
                  Text('残り $_initiativeSecondsLeft 秒', style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.w800)),
                ],
                const SizedBox(height: 20),
                Container(
                  width: 300,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white24),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      Text(
                        widget.mode == BattleMode.local
                            ? 'PLAYER 1：${widget.playerUnit.title} / ${widget.playerUnit.jp}'
                            : 'YOU：${widget.playerUnit.title} / ${widget.playerUnit.jp}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.mode == BattleMode.local
                            ? 'PLAYER 2：${widget.cpuUnit.title} / ${widget.cpuUnit.jp}'
                            : '${widget.mode == BattleMode.onlineTest ? 'OPPONENT' : 'CPU'}：${widget.cpuUnit.title} / ${widget.cpuUnit.jp}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: (widget.mode == BattleMode.local || widget.playerWonJanken) ? _withUiTap(() => _startSetup(true)) : null,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('先攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('白', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: 260,
                  child: OutlinedButton(
                    onPressed: (widget.mode == BattleMode.local || widget.playerWonJanken) ? _withUiTap(() => _startSetup(false)) : null,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Column(children: [
                        Text('後攻', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                        Text('黒', style: TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }
}

class InitialPlacementScreen extends StatefulWidget {
  final BattleUnit playerUnit;
  final BattleUnit cpuUnit;
  final bool playerIsWhite;
  final BattleMode mode;
  const InitialPlacementScreen({
    super.key,
    required this.playerUnit,
    required this.cpuUnit,
    required this.playerIsWhite,
    this.mode = BattleMode.cpu,
  });

  @override
  State<InitialPlacementScreen> createState() => _InitialPlacementScreenState();
}

class _InitialPlacementScreenState extends State<InitialPlacementScreen> {
  late bool placingWhite;
  int whiteCoreType = 2;
  int blackCoreType = 2;
  final Map<int, Piece> whiteMajors = {};
  final Map<int, Piece> blackMajors = {};
  Piece? selectedMajor;
  bool whiteDone = false;
  bool blackDone = false;
  bool _cpuPlacementScheduled = false;
  bool _battleNavigationStarted = false;
  int _placementSecondsLeft = 30;
  Timer? _placementTimer;
  Timer? _selectionPulseTimer;
  bool _selectionPulse = false;
  final Set<int> _swapFlashCells = <int>{};
  bool _boardConfirmFlash = false;
  bool _goryuUnlocked = _HiddenUnlocks.goryu;

  static const whiteSlots = <int>[27, 31, 32, 33];
  static const blackSlots = <int>[1, 2, 3, 7];

  List<int> _placementSlotsForSide(bool isWhite) {
    final unit = _unitForSide(isWhite);
    if (unit == BattleUnit.strasse) {
      return isWhite ? List<int>.generate(10, (i) => 25 + i) : List<int>.generate(10, (i) => i);
    }
    if (unit == BattleUnit.master) {
      return isWhite
          ? <int>[25,26,27,28,29,30,31,33,34]
          : <int>[0,1,3,4,5,6,7,8,9];
    }
    return isWhite ? whiteSlots : blackSlots;
  }

  @override
  void initState() {
    super.initState();
    _AppBgm.play('audio/4Unit Deployment.mp3');
    _selectionPulseTimer = Timer.periodic(const Duration(milliseconds: 480), (_) {
      if (mounted && selectedMajor != null) setState(() => _selectionPulse = !_selectionPulse);
    });
    // 初期配置は先攻（白/銀）→後攻（黒/金）の順に、
    // テスト端末上で両者とも手動配置する。
    placingWhite = true;
    // KING / KNIGHT / EMPEROR / MASTER は基本陣形を最初から完成状態で表示し、
    // プレイヤーは対応する駒同士をタップして位置だけを交換する。
    for (final side in <bool>[true, false]) {
      final unit = _unitForSide(side);
      if (unit != BattleUnit.strasse) _autoPlaceSide(side);
    }
    // 先攻側がCPUなら、初回描画より前に配置を済ませて人間側へ進める。
    if (!_isHumanSide(true)) {
      _autoPlaceSide(true);
      whiteDone = true;
      placingWhite = false;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _startPlacementTimerIfHuman());
  }

  void _startPlacementTimerIfHuman() {
    _placementTimer?.cancel();
    if (widget.mode == BattleMode.local) return;
    if (!mounted || _battleNavigationStarted || !_isHumanSide(placingWhite)) return;
    setState(() => _placementSecondsLeft = 30);
    _placementTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _battleNavigationStarted || !_isHumanSide(placingWhite)) { timer.cancel(); return; }
      if (_placementSecondsLeft <= 1) {
        timer.cancel();
        setState(() {
          _placementSecondsLeft = 0;
          _autoPlaceSide(placingWhite);
        });
        _completeCurrentSide();
      } else {
        setState(() => _placementSecondsLeft--);
      }
    });
  }

  @override
  void dispose() { _placementTimer?.cancel(); _selectionPulseTimer?.cancel(); super.dispose(); }

  bool _isHumanSide(bool isWhite) =>
      widget.mode == BattleMode.local || isWhite == widget.playerIsWhite;

  bool get _placementViewIsWhite =>
      widget.mode == BattleMode.local ? placingWhite : widget.playerIsWhite;

  BattleUnit _unitForSide(bool isWhite) =>
      isWhite == widget.playerIsWhite ? widget.playerUnit : widget.cpuUnit;

  String _unitDisplayName(BattleUnit unit) => switch (unit) {
        BattleUnit.king => 'キング',
        BattleUnit.knight => 'ナイト',
        BattleUnit.emperor => 'エンペラー',
        BattleUnit.strasse => 'シュトラーセ',
        BattleUnit.master => 'マスター',
      };

  List<Piece> _rosterFor(BattleUnit unit, bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    return switch (unit) {
      BattleUnit.knight => [
          Piece('assets/pieces/${side}_knight.png', '騎', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_scholar.png', '博', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_general.png', '将', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_officer.png', '官', major: true, isWhite: isWhite),
        ],
      BattleUnit.king => [
          Piece('assets/pieces/${side}_king.png', '王', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_servant.png', '仕', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_guard.png', '護', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_fighter.png', '闘', major: true, isWhite: isWhite),
        ],
      BattleUnit.emperor => [
          Piece('assets/pieces/${side}_emperor.png', '帝', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_cannon.png', '砲', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_sword.png', '剣', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_shield.png', '盾', major: true, isWhite: isWhite),
        ],
      BattleUnit.strasse => [
          Piece('assets/pieces/${side}_strasse_spear.png', '槍', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_strasse_swift.png', '迅', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_strasse_advance.png', '進', major: true, isWhite: isWhite),
          Piece('assets/pieces/${side}_strasse_sub.png', '亜', major: true, isWhite: isWhite),
        ],
      BattleUnit.master => [
          Piece('assets/pieces/master_king_${side}.png', '王', major: true, isWhite: isWhite),
          Piece('assets/pieces/master_emperor_${side}.png', '帝', major: true, isWhite: isWhite),
          Piece('assets/pieces/master_knight_${side}.png', '騎', major: true, isWhite: isWhite),
          Piece('assets/pieces/master_divine_elephant_${side}.png', '神仕象', isWhite: isWhite),
          Piece('assets/pieces/master_divine_elephant_${side}.png', '神仕象2', isWhite: isWhite),
          Piece('assets/pieces/master_divine_beast_${side}.png', '神仕獣', isWhite: isWhite),
          Piece('assets/pieces/master_divine_beast_${side}.png', '神仕獣2', isWhite: isWhite),
          Piece('assets/pieces/master_air_triangle_${side}.png', '三角型飛空城', major: true, isWhite: isWhite),
          Piece('assets/pieces/master_air_disc_${side}.png', '円盤型飛空城', major: true, isWhite: isWhite),
        ],
    };
  }

  void _autoPlaceSide(bool isWhite) {
    final slots = _placementSlotsForSide(isWhite);
    final target = isWhite ? whiteMajors : blackMajors;
    final unit = _unitForSide(isWhite);
    final roster = _rosterFor(unit, isWhite);
    target.clear();
    if (unit == BattleUnit.master) {
      // MASTER基本陣形。中央の通常飛空城＋生命の像は _fixedFor で完全固定。
      // MASTER3機 / 神仕4体 / 三角・円盤型飛空城は各グループ内だけ交換可能。
      final positions = isWhite
          ? <int>[33, 31, 27, 25, 26, 28, 29, 34, 30]
          : <int>[1, 3, 7, 5, 6, 8, 9, 0, 4];
      for (var i = 0; i < roster.length; i++) target[positions[i]] = roster[i];
      return;
    }
    // 配置可能マス数ではなく、実際の大駒数だけ配置する。
    // STRASSEは配置可能10マス・駒4機なので slots.length で回すとCPU配置時に範囲外になる。
    for (var i = 0; i < roster.length && i < slots.length; i++) target[slots[i]] = roster[i];
  }

  String _coreAsset(bool isWhite) {
    final type = isWhite ? whiteCoreType : blackCoreType;
    return 'assets/pieces/${isWhite ? 'white' : 'black'}_core_$type.png';
  }

  Map<int, Piece> _fixedFor(bool isWhite) {
    final unit = _unitForSide(isWhite);
    if (unit == BattleUnit.strasse) return <int, Piece>{};
    if (unit == BattleUnit.master) {
      final side = isWhite ? 'white' : 'black';
      final center = isWhite ? 32 : 2;
      // 配置画面では合流状態の上側（通常飛空城）を表示。生命の像はBoard生成時に下へ入れる。
      return {center: Piece('assets/pieces/master_air_${side}.png', '飛空城', major: true, isWhite: isWhite)};
    }
    if (isWhite) {
      return {
        25: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        26: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        28: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        29: const Piece('assets/pieces/white_soldier.png', '兵', isWhite: true),
        30: Piece(_coreAsset(true), '核', isWhite: true),
        34: Piece(_coreAsset(true), '核', isWhite: true),
      };
    }
    return {
      0: Piece(_coreAsset(false), '核', isWhite: false),
      4: Piece(_coreAsset(false), '核', isWhite: false),
      5: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      6: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      8: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
      9: const Piece('assets/pieces/black_soldier.png', '兵', isWhite: false),
    };
  }

  Map<int, Piece> _previewPieces() {
    final map = <int, Piece>{};
    map.addAll(_fixedFor(true));
    map.addAll(_fixedFor(false));
    map.addAll(whiteMajors);
    map.addAll(blackMajors);
    return map;
  }

  void _toggleCore(bool isWhite) {
    if (!_isHumanSide(isWhite) || placingWhite != isWhite) return;
    setState(() {
      if (isWhite) {
        whiteCoreType = whiteCoreType == 2 ? 1 : 2;
      } else {
        blackCoreType = blackCoreType == 2 ? 1 : 2;
      }
    });
  }

  String? _swapGroup(Piece piece, BattleUnit unit) {
    if (unit == BattleUnit.master) {
      if (piece.label == '王' || piece.label == '帝' || piece.label == '騎') return 'master';
      if (piece.label.startsWith('神仕')) return 'divine';
      if (piece.label == '三角型飛空城' || piece.label == '円盤型飛空城') return 'air';
      return null;
    }
    if (unit == BattleUnit.king || unit == BattleUnit.knight || unit == BattleUnit.emperor) return 'major';
    return null;
  }

  bool _canUseKuruOnPlacementPiece(Piece piece, BattleUnit unit) {
    if (!piece.major) return false;
    if (unit == BattleUnit.king || unit == BattleUnit.knight || unit == BattleUnit.emperor) return true;
    if (unit == BattleUnit.master) return const {'王','騎','帝'}.contains(piece.label);
    return false;
  }

  Future<void> _showPilotSelection(int index) async {
    if (!_isHumanSide(placingWhite)) return;
    final target = placingWhite ? whiteMajors : blackMajors;
    final current = target[index];
    if (current == null) return;
    final unit = _unitForSide(placingWhite);
    final canKuru = _HiddenUnlocks.kuru && _canUseKuruOnPlacementPiece(current, unit);
    final canUnitChange = _goryuUnlocked && unit == BattleUnit.knight && (current.label == '官' || current.label == '軍');
    if (!canKuru && !canUnitChange) return;

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('PILOT SELECT', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.8)),
              const SizedBox(height: 14),
              if (canKuru) ...[
                ListTile(
                  leading: ClipRRect(borderRadius: BorderRadius.circular(4), child: Image.asset('assets/pilots/kuru.webp', width: 52, height: 52, fit: BoxFit.cover)),
                  title: Text(current.pilotId == 'kuru' ? 'クル  ✓' : 'クル', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: const Text('Lv / Puを捨て、固有の2マスを追加'),
                  onTap: () {
                    Navigator.of(sheetContext).pop();
                    setState(() {
                      target[index] = current.copyWith(pilotId: 'kuru', level: 1);
                      selectedMajor = null;
                    });
                  },
                ),
                ListTile(
                  leading: const SizedBox(width: 52, height: 52, child: Icon(Icons.person_outline, size: 34)),
                  title: Text(current.pilotId != 'kuru' ? '通常パイロット  ✓' : '通常パイロット', style: const TextStyle(fontWeight: FontWeight.w800)),
                  onTap: () {
                    Navigator.of(sheetContext).pop();
                    setState(() {
                      target[index] = current.copyWith(clearPilot: true);
                      selectedMajor = null;
                    });
                  },
                ),
              ],
              if (canUnitChange) ...[
                const Divider(height: 24),
                ListTile(
                  leading: const SizedBox(width: 52, height: 52, child: Icon(Icons.swap_horiz_rounded, size: 34)),
                  title: Text(current.label == '官' ? '豪竜（軍）へ機体変更' : '官へ機体変更', style: const TextStyle(fontWeight: FontWeight.w800)),
                  onTap: () {
                    Navigator.of(sheetContext).pop();
                    _showKnightUnitChange(index);
                  },
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showKnightUnitChange(int index) async {
    if (!_goryuUnlocked || _unitForSide(placingWhite) != BattleUnit.knight || !_isHumanSide(placingWhite)) return;
    final target = placingWhite ? whiteMajors : blackMajors;
    final current = target[index];
    if (current == null || (current.label != '官' && current.label != '軍')) return;
    final useArmy = current.label == '官';
    final side = placingWhite ? 'white' : 'black';
    final changed = Piece(
      useArmy ? 'assets/pieces/${side}_goryu.webp' : 'assets/pieces/${side}_officer.png',
      useArmy ? '軍' : '官',
      major: true,
      isWhite: placingWhite,
      pilotId: current.pilotId,
    );
    setState(() {
      target[index] = changed;
      selectedMajor = null;
      _swapFlashCells..clear()..add(index);
    });
    await Future<void>.delayed(const Duration(milliseconds: 320));
    if (mounted) setState(() => _swapFlashCells.clear());
  }

  void _tapPlacementCell(int index) {
    final isWhite = placingWhite;
    if (!_isHumanSide(isWhite)) return;
    final slots = _placementSlotsForSide(isWhite);
    if (!slots.contains(index)) return;
    final target = isWhite ? whiteMajors : blackMajors;
    final unit = _unitForSide(isWhite);

    // 基本3ユニットとMASTERは「置く」のではなく、完成済み陣形の同系統駒を交換する。
    if (unit != BattleUnit.strasse) {
      final tapped = target[index];
      if (tapped == null) return;
      if (selectedMajor == null) {
        setState(() => selectedMajor = tapped);
        return;
      }
      final selectedEntry = target.entries.where((e) => identical(e.value, selectedMajor) || e.value.label == selectedMajor!.label).toList();
      if (selectedEntry.isEmpty) { setState(() => selectedMajor = tapped); return; }
      final selectedIndex = selectedEntry.first.key;
      if (selectedIndex == index) { setState(() => selectedMajor = null); return; }
      if (_swapGroup(selectedMajor!, unit) != _swapGroup(tapped, unit)) return;
      setState(() {
        final a = target[selectedIndex]!;
        target[selectedIndex] = tapped;
        target[index] = a;
        selectedMajor = null;
        _swapFlashCells
          ..clear()
          ..addAll(<int>[selectedIndex, index]);
      });
      Future<void>.delayed(const Duration(milliseconds: 320), () {
        if (mounted) setState(() => _swapFlashCells.clear());
      });
      return;
    }

    // SCHTRASSEは従来通り自陣2列への自由配置。
    if (selectedMajor != null) {
      setState(() {
        final existingIndex = target.entries.where((e) => e.value.label == selectedMajor!.label).map((e) => e.key).cast<int?>().firstWhere((_) => true, orElse: () => null);
        final displaced = target[index];
        if (existingIndex != null) target.remove(existingIndex);
        target[index] = selectedMajor!;
        if (displaced != null && existingIndex != null) target[existingIndex] = displaced;
        selectedMajor = null;
      });
      return;
    }
    final placed = target[index];
    if (placed != null) setState(() => selectedMajor = placed);
  }

  bool _sideComplete(bool isWhite) {
    final required = _unitForSide(isWhite) == BattleUnit.master ? 9 : 4;
    return (isWhite ? whiteMajors : blackMajors).length == required;
  }

  void _scheduleCpuPlacementIfNeeded() {
    if (_battleNavigationStarted || _cpuPlacementScheduled || _isHumanSide(placingWhite)) return;
    _cpuPlacementScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      setState(() {
        _autoPlaceSide(placingWhite);
        _cpuPlacementScheduled = false;
      });
      Future<void>.delayed(const Duration(milliseconds: 350), () {
        if (!mounted || _isHumanSide(placingWhite)) return;
        _completeCurrentSide();
      });
    });
  }

  Future<void> _completeCurrentSide() async {
    final side = placingWhite;
    if (!_sideComplete(side)) return;
    if (_isHumanSide(side)) {
      setState(() => _boardConfirmFlash = true);
      await Future<void>.delayed(const Duration(milliseconds: 260));
      if (!mounted) return;
      setState(() => _boardConfirmFlash = false);
    }
    if (side) {
      whiteDone = true;
      // CPUが後攻側なら「CPU 配置完了」の中間画面を描画せず、その場で配置まで完了する。
      if (!_isHumanSide(false)) {
        placingWhite = false;
        selectedMajor = null;
        _autoPlaceSide(false);
        blackDone = true;
      } else {
        setState(() {
          placingWhite = false;
          selectedMajor = null;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) => _startPlacementTimerIfHuman());
      }
    } else {
      blackDone = true;
      setState(() => selectedMajor = null);
    }

    if (whiteDone && blackDone) {
      if (_battleNavigationStarted) return;
      _battleNavigationStarted = true;
      final all = <int, Piece>{}
        ..addAll(_fixedFor(true))
        ..addAll(_fixedFor(false))
        ..addAll(whiteMajors)
        ..addAll(blackMajors);
      Navigator.of(context).push(_battleIntroRoute(
        BoardScreen(
          initialPieces: all,
          playerIsWhite: widget.playerIsWhite,
          whiteUnit: _unitForSide(true),
          blackUnit: _unitForSide(false),
          localBattle: widget.mode == BattleMode.local,
          battleMode: widget.mode,
        ),
      ));
    }
  }

  Widget _pieceVisual(
    Piece piece, {
    bool playerPerspective = false,
    bool forceUpright = false,
  }) {
    if (piece.asset.isEmpty) {
      return Center(
        child: Text(piece.label.startsWith('神仕') ? '神仕' : piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      );
    }
    final upright = forceUpright
        ? true
        : playerPerspective
            ? piece.isWhite == _placementViewIsWhite
            : piece.isWhite;
    return Transform.rotate(
      angle: upright ? 0 : 3.141592653589793,
      child: Image.asset(piece.asset, fit: BoxFit.contain),
    );
  }

  @override
  Widget build(BuildContext context) {
    _scheduleCpuPlacementIfNeeded();
    final pieces = _previewPieces();
    final humanTurn = _isHumanSide(placingWhite);
    final currentUnit = _unitForSide(placingWhite);
    final currentRoster = _rosterFor(currentUnit, placingWhite);
    final currentPlaced = placingWhite ? whiteMajors : blackMajors;

    return _MatchExitGuard(child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: widget.mode == BattleMode.onlineTest ? null : _matchExitButton(context),
        title: const Text('INITIAL DEPLOYMENT'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Column(
                children: [
                  Text(
                    placingWhite ? '先攻  WHITE  初期配置' : '後攻  BLACK  初期配置',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: .8),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '先攻：${_unitDisplayName(_unitForSide(true))}　／　後攻：${_unitDisplayName(_unitForSide(false))}',
                    style: const TextStyle(fontSize: 13, color: Colors.cyanAccent, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 3),
                  if (humanTurn && widget.mode != BattleMode.local)
                    Text('残り $_placementSecondsLeft 秒', style: const TextStyle(fontSize: 13, color: Colors.cyanAccent, fontWeight: FontWeight.w800)),
                  if (humanTurn && widget.mode != BattleMode.local) const SizedBox(height: 3),
                  Text(
                    humanTurn
                        ? (_unitForSide(placingWhite) == BattleUnit.strasse
                            ? '4機を自陣2列に自由配置'
                            : _unitForSide(placingWhite) == BattleUnit.master
                                ? '同じ種類の駒を2体タップして位置を交換'
                                : '大駒を2体タップして位置を交換')
                        : (widget.mode == BattleMode.onlineTest ? 'OPPONENT 配置中' : 'CPU 配置中'),
                    style: const TextStyle(fontSize: 12, color: Colors.white60),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 5,
                      childAspectRatio: 1,
                    ),
                    itemCount: 35,
                    itemBuilder: (_, visualIndex) {
                      // 初期配置中も YOU は常に画面下側に表示する。
                      final i = _placementViewIsWhite ? visualIndex : 34 - visualIndex;
                      final piece = pieces[i];
                      final isCurrentSlot = _placementSlotsForSide(placingWhite).contains(i);
                      final isStrassePlacement = _unitForSide(placingWhite) == BattleUnit.strasse;
                      final isMasterPlacement = _unitForSide(placingWhite) == BattleUnit.master;
                      final isCurrentCore = !isStrassePlacement && !isMasterPlacement &&
                          (placingWhite ? (i == 30 || i == 34) : (i == 0 || i == 4));
                      final targetMap = placingWhite ? whiteMajors : blackMajors;
                      final selectedEntries = selectedMajor == null ? const <MapEntry<int, Piece>>[] : targetMap.entries.where((e) => identical(e.value, selectedMajor) || e.value.label == selectedMajor!.label).toList();
                      final selectedIndex = selectedEntries.isEmpty ? null : selectedEntries.first.key;
                      final isSelectedCell = selectedIndex == i;
                      final selectedGroup = selectedMajor == null ? null : _swapGroup(selectedMajor!, currentUnit);
                      final isSwapCandidate = selectedMajor != null && piece != null && !isSelectedCell && selectedGroup != null && _swapGroup(piece, currentUnit) == selectedGroup;
                      final isSwapFlash = _swapFlashCells.contains(i);
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (isCurrentCore) {
                            _toggleCore(placingWhite);
                          } else if (isCurrentSlot) {
                            _tapPlacementCell(i);
                          }
                        },
                        onLongPress: () {
                          if (isCurrentSlot && piece != null) _showPilotSelection(i);
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: isSwapFlash
                                  ? Colors.white
                                  : isSelectedCell
                                      ? Colors.cyanAccent.withOpacity(_selectionPulse ? 1.0 : .55)
                                      : isSwapCandidate
                                          ? Colors.cyanAccent.withOpacity(.78)
                                          : _boardConfirmFlash
                                              ? Colors.cyanAccent.withOpacity(.95)
                                              : isCurrentSlot && humanTurn
                                                  ? Colors.cyanAccent.withOpacity(.45)
                                                  : Colors.white30,
                              width: isSwapFlash
                                  ? 3.2
                                  : isSelectedCell
                                      ? (_selectionPulse ? 3.4 : 2.5)
                                      : isSwapCandidate
                                          ? 1.8
                                          : _boardConfirmFlash
                                              ? 2.0
                                              : isCurrentSlot && humanTurn ? 1.0 : .7,
                            ),
                            boxShadow: (isSelectedCell || isSwapFlash || _boardConfirmFlash)
                                ? <BoxShadow>[BoxShadow(color: Colors.cyanAccent.withOpacity(isSwapFlash ? .8 : .35), blurRadius: isSwapFlash ? 12 : 7)]
                                : null,
                            color: isSwapFlash
                                ? Colors.cyanAccent.withOpacity(.16)
                                : isSelectedCell
                                    ? Colors.cyanAccent.withOpacity(_selectionPulse ? .14 : .06)
                                    : isSwapCandidate
                                        ? Colors.cyanAccent.withOpacity(.035)
                                        : isCurrentSlot && humanTurn ? Colors.cyanAccent.withOpacity(.025) : Colors.transparent,
                          ),
                          child: piece == null
                              ? null
                              : Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(3, 3, 3, 17),
                                      child: _pieceVisual(piece, playerPerspective: true),
                                    ),
                                    Align(
                                      alignment: Alignment.bottomCenter,
                                      child: Container(
                                        width: double.infinity,
                                        color: Colors.black54,
                                        child: Text(piece.label.startsWith('神仕') ? '神仕' : piece.label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            if (humanTurn) ...[
              const Divider(height: 1),
              if (currentUnit == BattleUnit.strasse)
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: currentRoster.map((piece) {
                        final isPlaced = currentPlaced.values.any((p) => p.label == piece.label);
                        final active = selectedMajor?.label == piece.label;
                        return GestureDetector(
                          onTap: _withUiTap(() => setState(() => selectedMajor = piece)),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 100), width: 72, height: 88, padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              border: Border.all(color: active ? Colors.cyanAccent : Colors.white24, width: active ? 2 : 1),
                              borderRadius: BorderRadius.circular(8),
                              color: isPlaced ? Colors.white.withOpacity(.03) : Colors.white.withOpacity(.07),
                            ),
                            child: Column(children: [Expanded(child: _pieceVisual(piece, forceUpright: true)), Text(piece.label, style: TextStyle(fontWeight: FontWeight.w800, color: isPlaced ? Colors.white54 : Colors.white))]),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 10, 18, 6),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(10), color: Colors.white.withOpacity(.025)),
                    child: Text(
                      currentUnit == BattleUnit.master
                          ? '配置変更：MASTER同士／神仕同士／三角型・円盤型飛空城を、2体タップで交換できます。'
                          : (currentUnit == BattleUnit.knight && _goryuUnlocked
                              ? 'タップ：配置交換 ／ 官・軍を長押し：機体変更　　兵と核は固定です。'
                              : '配置変更：大駒を2体タップすると位置を交換できます。兵と核は固定です。'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 11.5, height: 1.45, color: Colors.white70),
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 6, 18, 14),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _sideComplete(placingWhite) ? _withUiTap(_completeCurrentSide) : null,
                    child: Text(placingWhite ? '先攻側 配置完了' : '後攻側 配置完了'),
                  ),
                ),
              ),
            ] else
              Padding(
                padding: const EdgeInsets.all(18),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _withUiTap(_completeCurrentSide),
                    child: Text(widget.mode == BattleMode.onlineTest ? 'OPPONENT 配置完了' : 'CPU 配置完了'),
                  ),
                ),
              ),
          ],
        ),
      ),
    ));
  }
}


class CrownBadge extends StatelessWidget {
  final Color color;
  final String value;
  final bool darkCrown;
  const CrownBadge({
    super.key,
    required this.color,
    required this.value,
    this.darkCrown = false,
  });

  @override
  Widget build(BuildContext context) {
    final light = Color.lerp(color, Colors.white, .42)!;
    final dark = Color.lerp(color, Colors.black, .45)!;
    final outline = darkCrown ? const Color(0xFFE7EBEF) : light;
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [light, color, dark],
          stops: const [0.0, .46, 1.0],
        ),
        border: Border.all(color: outline, width: 1.0),
        boxShadow: [
          BoxShadow(color: outline.withOpacity(.24), blurRadius: 3.2, spreadRadius: .1),
        ],
      ),
      child: Container(
        margin: const EdgeInsets.all(1.5),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xCC101318),
          border: Border.all(color: Colors.white.withOpacity(.12), width: .5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 13,
              height: 7.5,
              child: CustomPaint(
                painter: _CrownPainter(
                  fill: light,
                  stroke: darkCrown ? Colors.white : light,
                ),
              ),
            ),
            const SizedBox(height: .5),
            Text(
              value,
              style: const TextStyle(
                fontSize: 6.6,
                fontWeight: FontWeight.w900,
                height: .9,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _ShotThreatArcPainter extends CustomPainter {
  final List<(int, int)> pairs;
  final double progress;
  final bool playerIsWhite;
  const _ShotThreatArcPainter({required this.pairs, required this.progress, required this.playerIsWhite});

  Offset _centerFor(int boardIndex, Size size) {
    final visual = playerIsWhite ? boardIndex : 34 - boardIndex;
    return Offset(((visual % 5) + .5) * size.width / 5, ((visual ~/ 5) + .5) * size.height / 7);
  }

  Offset _quad(Offset a, Offset c, Offset b, double t) {
    final u = 1 - t;
    return Offset(u * u * a.dx + 2 * u * t * c.dx + t * t * b.dx,
        u * u * a.dy + 2 * u * t * c.dy + t * t * b.dy);
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (var n = 0; n < pairs.length; n++) {
      final pair = pairs[n];
      final from = _centerFor(pair.$1, size);
      final to = _centerFor(pair.$2, size);
      final mid = (from + to) / 2;
      final distance = (to - from).distance;
      final control = Offset(mid.dx, mid.dy - math.min(42.0, 15.0 + distance * .18));

      // 複数射線は少しだけ位相をずらし、同時にピュンピュンし過ぎないようにする。
      final t = (progress + n * .13) % 1.0;
      final active = t < .62;
      if (!active) continue;
      final headT = Curves.easeInOut.transform((t / .62).clamp(0.0, 1.0));
      final tailT = math.max(0.0, headT - .22);
      final path = Path()..moveTo(_quad(from, control, to, tailT).dx, _quad(from, control, to, tailT).dy);
      for (var k = 1; k <= 12; k++) {
        final q = tailT + (headT - tailT) * k / 12;
        final pt = _quad(from, control, to, q);
        path.lineTo(pt.dx, pt.dy);
      }
      final glow = Paint()
        ..color = Colors.amberAccent.withOpacity(.28)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round;
      final core = Paint()
        ..color = Colors.amberAccent.withOpacity(.88)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;
      canvas.drawPath(path, glow);
      canvas.drawPath(path, core);

      final head = _quad(from, control, to, headT);
      final prev = _quad(from, control, to, math.max(0.0, headT - .025));
      final angle = math.atan2(head.dy - prev.dy, head.dx - prev.dx);
      final arrow = Path()
        ..moveTo(head.dx, head.dy)
        ..lineTo(head.dx - 8 * math.cos(angle - .55), head.dy - 8 * math.sin(angle - .55))
        ..moveTo(head.dx, head.dy)
        ..lineTo(head.dx - 8 * math.cos(angle + .55), head.dy - 8 * math.sin(angle + .55));
      canvas.drawPath(arrow, core..strokeWidth = 2.4);
    }
  }

  @override
  bool shouldRepaint(covariant _ShotThreatArcPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.playerIsWhite != playerIsWhite || oldDelegate.pairs != pairs;
}

class _ShotBeamPainter extends CustomPainter {
  final int originIndex;
  final int targetIndex;
  final double progress;
  final bool playerIsWhite;
  final String? finalBlowKind; // 'emperor' = 帝, 'knight' = 騎
  const _ShotBeamPainter({required this.originIndex, required this.targetIndex, required this.progress, required this.playerIsWhite, this.finalBlowKind});

  Offset _centerFor(int boardIndex, Size size) {
    final visual = playerIsWhite ? boardIndex : 34 - boardIndex;
    return Offset(((visual % 5) + .5) * size.width / 5, ((visual ~/ 5) + .5) * size.height / 7);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final from = _centerFor(originIndex, size);
    final to = _centerFor(targetIndex, size);
    final isFinal = finalBlowKind != null;
    final accent = finalBlowKind == 'emperor'
        ? const Color(0xFFFF3030)
        : finalBlowKind == 'knight'
            ? const Color(0xFF2196FF)
            : Colors.cyanAccent;

    if (!isFinal) {
      final beamT = math.min(1.0, progress / .72);
      final head = Offset.lerp(from, to, beamT)!;
      final fade = progress < .78 ? 1.0 : (1.0 - progress) / .22;
      final glow = Paint()..color = Colors.cyanAccent.withOpacity((.42 * fade).clamp(0.0, 1.0))..strokeWidth = 10..strokeCap = StrokeCap.round;
      final core = Paint()..color = Colors.white.withOpacity((.95 * fade).clamp(0.0, 1.0))..strokeWidth = 3.2..strokeCap = StrokeCap.round;
      canvas.drawLine(from, head, glow);
      canvas.drawLine(from, head, core);
      final muzzle = Paint()..color = Colors.cyanAccent.withOpacity((.75 * (1 - progress)).clamp(0.0, 1.0));
      canvas.drawCircle(from, 5 + 7 * math.sin(math.pi * math.min(progress * 2, 1)), muzzle);
      if (progress > .58) {
        final impactT = ((progress - .58) / .42).clamp(0.0, 1.0);
        final impact = Paint()..color = Colors.white.withOpacity((1 - impactT) * .9)..style = PaintingStyle.stroke..strokeWidth = 4 * (1 - impactT) + 1;
        canvas.drawCircle(to, 8 + 24 * impactT, impact);
        canvas.drawCircle(to, 10 * (1 - impactT), Paint()..color = Colors.cyanAccent.withOpacity((1 - impactT) * .5));
      }
      return;
    }

    // 0.00-0.32: 溜め。発射点へ光が収束し、リングが縮む。
    if (progress < .36) {
      final chargeT = (progress / .36).clamp(0.0, 1.0);
      final pulse = .72 + .28 * math.sin(chargeT * math.pi * 7).abs();
      final glow = Paint()..color = accent.withOpacity((.28 + .50 * chargeT) * pulse)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
      canvas.drawCircle(from, 10 + 22 * chargeT, glow);
      canvas.drawCircle(from, 4 + 10 * chargeT, Paint()..color = Colors.white.withOpacity(.45 + .50 * chargeT));
      final ring = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5 + 2.5 * chargeT..color = accent.withOpacity(.85);
      canvas.drawCircle(from, 36 - 22 * chargeT, ring);
      // 8方向から中心へ吸い込まれる粒子。
      for (var i = 0; i < 8; i++) {
        final a = i * math.pi / 4 + chargeT * .7;
        final radius = 46 * (1 - chargeT) + 9;
        final pt = from + Offset(math.cos(a), math.sin(a)) * radius;
        canvas.drawCircle(pt, 1.8 + 2.0 * chargeT, Paint()..color = Colors.white.withOpacity(.35 + .55 * chargeT));
      }
      return;
    }

    // 0.32-0.40: 発射フラッシュ。
    if (progress < .42) {
      final flashT = ((progress - .36) / .06).clamp(0.0, 1.0);
      canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white.withOpacity(.48 * (1 - flashT)));
    }

    // 0.36-0.82: 極太ビーム。最初に一気に伸び、その後しっかり保持する。
    final beamPhase = ((progress - .36) / .46).clamp(0.0, 1.0);
    final beamT = Curves.easeOutCubic.transform((beamPhase / .28).clamp(0.0, 1.0));
    final head = Offset.lerp(from, to, beamT)!;
    final fade = progress < .82 ? 1.0 : ((1.0 - progress) / .18).clamp(0.0, 1.0);
    final throb = .90 + .10 * math.sin(progress * math.pi * 18);
    final outer = Paint()..color = accent.withOpacity((.50 * fade).clamp(0.0, 1.0))..strokeWidth = 36 * throb..strokeCap = StrokeCap.round..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    final mid = Paint()..color = accent.withOpacity((.95 * fade).clamp(0.0, 1.0))..strokeWidth = 23 * throb..strokeCap = StrokeCap.round;
    final core = Paint()..color = Colors.white.withOpacity((.98 * fade).clamp(0.0, 1.0))..strokeWidth = 10.5 * throb..strokeCap = StrokeCap.round;
    // 真っ直ぐな「棒」に見えないよう、外周を複数の揺れるエネルギー帯で構成。
    final delta = head - from;
    final len = delta.distance;
    final dir = len > 0 ? delta / len : const Offset(1, 0);
    final normal = Offset(-dir.dy, dir.dx);
    final pathOuter = Path()..moveTo(from.dx, from.dy);
    final pathMid = Path()..moveTo(from.dx, from.dy);
    const segments = 18;
    for (var i = 1; i <= segments; i++) {
      final t = i / segments;
      final base = Offset.lerp(from, head, t)!;
      final envelope = math.sin(math.pi * t);
      final wobble = (math.sin(t * math.pi * 9 + progress * 35) * 5.5 +
              math.sin(t * math.pi * 17 - progress * 24) * 2.8) * envelope;
      final wobble2 = math.sin(t * math.pi * 13 - progress * 31) * 2.2 * envelope;
      final po = base + normal * wobble;
      final pm = base + normal * wobble2;
      pathOuter.lineTo(po.dx, po.dy);
      pathMid.lineTo(pm.dx, pm.dy);
    }
    canvas.drawPath(pathOuter, outer);
    canvas.drawPath(pathMid, mid);
    canvas.drawLine(from, head, core);
    // 芯の周囲に細い不規則な放電を足して輪郭を崩す。
    final arc = Paint()..color = Colors.white.withOpacity(.48 * fade)..strokeWidth = 2.2..strokeCap = StrokeCap.round;
    for (var k = 0; k < 3; k++) {
      final pth = Path()..moveTo(from.dx, from.dy);
      for (var i = 1; i <= 10; i++) {
        final t = i / 10;
        final base = Offset.lerp(from, head, t)!;
        final j = math.sin(t * math.pi * (7 + k * 2) + progress * (28 + k * 5)) * (5 + k * 2) * math.sin(math.pi * t);
        final q = base + normal * j;
        pth.lineTo(q.dx, q.dy);
      }
      canvas.drawPath(pth, arc);
    }
    canvas.drawCircle(from, 19 * throb, Paint()..color = Colors.white.withOpacity(.90 * fade));
    canvas.drawCircle(from, 31 * throb, Paint()..color = accent.withOpacity(.38 * fade)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 13));

    if (beamT > .92) {
      final impactT = ((progress - .48) / .52).clamp(0.0, 1.0);
      final impactPulse = .75 + .25 * math.sin(progress * math.pi * 20).abs();
      canvas.drawCircle(to, 18 + 18 * impactT, Paint()..color = accent.withOpacity(.42 * fade * impactPulse)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 15));
      canvas.drawCircle(to, 9 + 9 * impactPulse, Paint()..color = Colors.white.withOpacity(.90 * fade));
      final ring = Paint()..style = PaintingStyle.stroke..strokeWidth = 5 * fade + 1..color = Colors.white.withOpacity(.75 * fade);
      canvas.drawCircle(to, 12 + 42 * impactT, ring);
    }
  }

  @override
  bool shouldRepaint(covariant _ShotBeamPainter oldDelegate) => oldDelegate.progress != progress || oldDelegate.originIndex != originIndex || oldDelegate.targetIndex != targetIndex || oldDelegate.playerIsWhite != playerIsWhite || oldDelegate.finalBlowKind != finalBlowKind;
}

class _CoreBurstPainter extends CustomPainter {
  final int index;
  final double progress;
  final bool playerIsWhite;
  const _CoreBurstPainter({required this.index, required this.progress, required this.playerIsWhite});

  @override
  void paint(Canvas canvas, Size size) {
    final visual = playerIsWhite ? index : 34 - index;
    final cw = size.width / 5, ch = size.height / 7;
    final center = Offset((visual % 5 + .5) * cw, (visual ~/ 5 + .5) * ch);
    final pulse = (math.sin(progress * math.pi * 7).abs());
    final fade = (1.0 - progress).clamp(0.0, 1.0);
    final radius = math.min(cw, ch) * (.22 + .30 * progress + .08 * pulse);
    final glow = Paint()..color = Colors.orangeAccent.withOpacity((.50 * fade + .20 * pulse).clamp(0, 1))..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
    canvas.drawCircle(center, radius, glow);
    final ring = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5 + 2 * pulse..color = Colors.white.withOpacity((.9 * fade).clamp(0,1));
    canvas.drawCircle(center, radius * (.72 + .15 * pulse), ring);
    if (progress > .58) {
      final flash = ((1-progress)/.42).clamp(0.0,1.0);
      canvas.drawCircle(center, radius * 1.15, Paint()..color = Colors.white.withOpacity(.55 * flash));
    }
  }
  @override bool shouldRepaint(covariant _CoreBurstPainter old) => old.progress != progress || old.index != index;
}

class _CoreLinkPainter extends CustomPainter {
  final int fromIndex;
  final int toIndex;
  final double progress;
  final bool playerIsWhite;
  const _CoreLinkPainter({required this.fromIndex, required this.toIndex, required this.progress, required this.playerIsWhite});

  Offset _centerFor(int index, Size size) {
    final visual = playerIsWhite ? index : 34 - index;
    final cw = size.width / 5, ch = size.height / 7;
    return Offset((visual % 5 + .5) * cw, (visual ~/ 5 + .5) * ch);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final a = _centerFor(fromIndex, size), b = _centerFor(toIndex, size);
    final drawT = (progress / .72).clamp(0.0, 1.0);
    final fade = progress < .72 ? 1.0 : ((1.0 - progress) / .28).clamp(0.0, 1.0);
    final end = Offset.lerp(a, b, Curves.easeOutCubic.transform(drawT))!;
    final glow = Paint()..strokeWidth = 7..strokeCap = StrokeCap.round..color = Colors.lightBlueAccent.withOpacity(.30 * fade)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9);
    final line = Paint()..strokeWidth = 2.2..strokeCap = StrokeCap.round..color = Colors.white.withOpacity(.92 * fade);
    canvas.drawLine(a, end, glow);
    canvas.drawLine(a, end, line);
    if (drawT > .82) canvas.drawCircle(b, 6 + 5 * math.sin(progress * math.pi * 5).abs(), Paint()..color = Colors.white.withOpacity(.75 * fade));
  }
  @override bool shouldRepaint(covariant _CoreLinkPainter old) => old.progress != progress || old.fromIndex != fromIndex || old.toIndex != toIndex || old.playerIsWhite != playerIsWhite;
}

class CrownScoreDisplay extends StatelessWidget {
  final String label;
  final String value;
  const CrownScoreDisplay({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.045),
        border: Border.all(color: Colors.white24, width: .7),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: .7)),
          const SizedBox(width: 5),
          SizedBox(
            width: 13,
            height: 10,
            child: CustomPaint(
              painter: const _CrownPainter(fill: Color(0xFFD7DCE2), stroke: Colors.white),
            ),
          ),
          const SizedBox(width: 4),
          Text('$value / 3', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _CrownPainter extends CustomPainter {
  final Color fill;
  final Color stroke;
  const _CrownPainter({required this.fill, required this.stroke});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(w * .08, h * .25)
      ..lineTo(w * .28, h * .58)
      ..lineTo(w * .48, h * .18)
      ..lineTo(w * .68, h * .58)
      ..lineTo(w * .92, h * .25)
      ..lineTo(w * .82, h * .82)
      ..lineTo(w * .18, h * .82)
      ..close();
    canvas.drawPath(path, Paint()..color = fill..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()..color = stroke..style = PaintingStyle.stroke..strokeWidth = 1.0);
    canvas.drawLine(
      Offset(w * .17, h * .88),
      Offset(w * .83, h * .88),
      Paint()..color = stroke..strokeWidth = 1.1,
    );
  }

  @override
  bool shouldRepaint(covariant _CrownPainter oldDelegate) =>
      oldDelegate.fill != fill || oldDelegate.stroke != stroke;
}

class _MasterRecordPiece extends StatefulWidget {
  final String unit;
  const _MasterRecordPiece({required this.unit});
  @override State<_MasterRecordPiece> createState() => _MasterRecordPieceState();
}

class _MasterRecordPieceState extends State<_MasterRecordPiece> with SingleTickerProviderStateMixin {
  late final AnimationController _flip = AnimationController(vsync: this, duration: const Duration(milliseconds: 650));
  bool _black = false;
  @override void dispose() { _flip.dispose(); super.dispose(); }
  void _toggle() { if (_flip.isAnimating) return; setState(() => _black = !_black); _black ? _flip.forward() : _flip.reverse(); }
  @override Widget build(BuildContext context) => GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: _toggle,
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Expanded(child: AnimatedBuilder(animation: _flip, builder: (_, __) {
        final angle = _flip.value * math.pi;
        final showBlack = angle > math.pi / 2;
        final shownAngle = showBlack ? angle - math.pi : angle;
        return Transform(
          alignment: Alignment.center,
          transform: Matrix4.identity()..setEntry(3, 2, .0012)..rotateY(shownAngle),
          child: Image.asset(_MasterProgress.masterPieceAsset(widget.unit, isWhite: !showBlack), fit: BoxFit.contain),
        );
      })),
      const SizedBox(height: 5),
      Text(_MasterProgress.masterPieceLabel(widget.unit), style: const TextStyle(fontWeight: FontWeight.w800)),
    ]),
  );
}

class DatabaseCategoryScreen extends StatefulWidget {
  const DatabaseCategoryScreen({super.key});
  @override State<DatabaseCategoryScreen> createState() => _DatabaseCategoryScreenState();
}

class _DatabaseCategoryScreenState extends State<DatabaseCategoryScreen> {
  @override
  void initState(){super.initState();WidgetsBinding.instance.addPostFrameCallback((_)=>_showSouvenirUnlocks());}
  Future<void> _showSouvenirUnlocks() async {final notices=await _UnlockInbox.takeSouvenirNotices();if(!mounted||notices.isEmpty)return;await _showUnlockNotices(context,notices);if(mounted)setState((){});}

  static const categories = <(String, String)>[
    ('UNIT', '機体 / 駒 / パイロット'),
    ('SYSTEM', 'ルール / システム'),
    ('SOUNDTRACK', 'サウンドトラック'),
  ];

  Widget _masterRecord() {
    final order = _MasterProgress.acquiredMasterPieces;
    if (order.isEmpty) return const SizedBox.shrink();
    // Visual positions are left / center / right, while acquisition slots are
    // 2nd / 1st / 3rd. Missing slots stay empty so the first piece is always centered.
    final slots = <String?>[
      order.length >= 2 ? order[1] : null,
      order.isNotEmpty ? order[0] : null,
      order.length >= 3 ? order[2] : null,
    ];
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 18, 18, 8),
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.035),
        border: Border.all(color: Colors.white24),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(children: [
        const Text('MASTER RECORD', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2.2)),
        const SizedBox(height: 14),
        Row(children: List.generate(3, (i) {
          final unit = slots[i];
          return Expanded(child: SizedBox(height: 116, child: unit == null
            ? const SizedBox.shrink()
            : _MasterRecordPiece(unit: unit)));
        })),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(leading: _easyBackButton(context), title: const Text('DATABASE')),
        body: SafeArea(
          child: Column(children: [
            _masterRecord(),
            Expanded(child: Builder(builder: (context) {
              final items = <(String, String)>[...categories];
              if (_MasterProgress.masterUnlocked) items.add(('ENDING', 'エンディング'));
              return ListView.separated(
                padding: const EdgeInsets.symmetric(vertical: 12),
                itemCount: items.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, i) {
                  final item = items[i];
                  return ListTile(
                    title: Row(mainAxisSize: MainAxisSize.min, children:[Text(item.$1), if(item.$1=='UNIT' && _UnlockInbox.unitUnread)...[const SizedBox(width:7),Container(width:7,height:7,decoration:const BoxDecoration(color:Color(0xFFE53935),shape:BoxShape.circle))]]),
                    subtitle: Text(item.$2),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: item.$1 == 'UNIT'
                        ? () async { _UiSounds.tap(); await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const UnitDatabaseScreen())); if (mounted) setState(() {}); }
                        : item.$1 == 'SYSTEM'
                        ? _withUiTap(() => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SystemDatabaseScreen())))
                        : item.$1 == 'SOUNDTRACK'
                        ? _withUiTap(() => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SoundtrackDatabaseScreen())))
                        : item.$1 == 'ENDING'
                            ? () async {
                                _UiSounds.tap();
                                if (await _AdditionalData.ready()) {
                                  if (context.mounted) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _EndingScreen()));
                                } else if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ADDITIONAL DATA が必要です。次回起動時に DOWNLOAD してください。')));
                                }
                              }
                            : () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${item.$1} は準備中'))),
                  );
                },
              );
            })),
          ]),
        ),
      );
}


class _SystemChunk {
  final String text;
  final String? ruleId;
  final String? displayId;
  const _SystemChunk(this.text, {this.ruleId, this.displayId});
}

void _openSystemRule(BuildContext context, String id) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => _SystemRuleDetailScreen(id: id)));
}

void _openSystemDisplay(BuildContext context, String id) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => _SystemDisplayDetailScreen(id: id)));
}

class _SystemInline extends StatelessWidget {
  final List<_SystemChunk> chunks;
  const _SystemInline(this.chunks);

  @override
  Widget build(BuildContext context) {
    final base = DefaultTextStyle.of(context).style.copyWith(fontSize: 15.5, height: 1.75, color: Colors.white.withOpacity(.92));
    return RichText(
      text: TextSpan(
        style: base,
        children: [
          for (final chunk in chunks)
            if (chunk.ruleId == null && chunk.displayId == null)
              TextSpan(text: chunk.text)
            else
              WidgetSpan(
                alignment: PlaceholderAlignment.baseline,
                baseline: TextBaseline.alphabetic,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    _UiSounds.tap();
                    if (chunk.ruleId != null) _openSystemRule(context, chunk.ruleId!);
                    if (chunk.displayId != null) _openSystemDisplay(context, chunk.displayId!);
                  },
                  child: Text(
                    chunk.text,
                    style: base.copyWith(
                      color: Colors.lightBlueAccent,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
        ],
      ),
    );
  }
}

class _ManualCell {
  final List<String> assets;
  final Color? borderColor;
  final Color? fillColor;
  final bool dashed;
  final bool blink;
  final String? tag;
  final Color? tagColor;
  const _ManualCell({
    this.assets = const [],
    this.borderColor,
    this.fillColor,
    this.dashed = false,
    this.blink = false,
    this.tag,
    this.tagColor,
  });
}

class _ManualBoard extends StatefulWidget {
  final Map<int, _ManualCell> cells;
  final Set<int> highlightRows;
  final List<(int, int)> threatPairs;
  final bool showZLine;
  final String? caption;
  const _ManualBoard({
    this.cells = const {},
    this.highlightRows = const {},
    this.threatPairs = const [],
    this.showZLine = false,
    this.caption,
  });

  @override
  State<_ManualBoard> createState() => _ManualBoardState();
}

class _ManualBoardState extends State<_ManualBoard> with TickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 650))..repeat(reverse: true);
  late final AnimationController _arc = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..repeat();

  @override
  void dispose() {
    _pulse.dispose();
    _arc.dispose();
    super.dispose();
  }

  Widget _manualPiece(String asset) {
    final image = Image.asset(asset, fit: BoxFit.contain);
    final isBlackSide = asset.contains('/black_') || asset.contains('_black.');
    return isBlackSide ? Transform.rotate(angle: math.pi, child: image) : image;
  }

  Widget _pieceStack(_ManualCell cell) {
    if (cell.assets.isEmpty) return const SizedBox.shrink();
    if (cell.assets.length == 1) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(2, 2, 2, 9),
        child: _manualPiece(cell.assets.first),
      );
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(7, 6, 9, 12),
          child: Opacity(
            opacity: .55,
            child: Transform.translate(
              offset: const Offset(-4, -3),
              child: _manualPiece(cell.assets.first),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(2, 2, 2, 9),
          child: _manualPiece(cell.assets.last),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Center(
          child: SizedBox(
            width: 238,
            child: AspectRatio(
              aspectRatio: 5 / 7,
              child: LayoutBuilder(builder: (context, constraints) {
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    AnimatedBuilder(
                      animation: _pulse,
                      builder: (context, _) => GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 5),
                        itemCount: 35,
                        itemBuilder: (_, i) {
                          final r = i ~/ 5, c = i % 5;
                          final cell = widget.cells[i];
                          final border = cell?.borderColor;
                          final blinkOpacity = .28 + .72 * _pulse.value;
                          final effectiveBorder = border == null
                              ? Colors.white24
                              : (cell!.blink ? border.withOpacity(blinkOpacity) : border);
                          final baseFill = widget.highlightRows.contains(r)
                              ? Colors.lightBlueAccent.withOpacity(.055)
                              : ((r + c).isEven ? Colors.white.withOpacity(.035) : Colors.black.withOpacity(.10));
                          final fill = cell?.fillColor ?? baseFill;
                          final body = Container(
                            decoration: BoxDecoration(
                              color: fill,
                              border: Border.all(
                                color: cell?.dashed == true ? Colors.white12 : effectiveBorder,
                                width: border == null ? .65 : 2.0,
                              ),
                              boxShadow: cell?.blink == true
                                  ? [BoxShadow(color: effectiveBorder.withOpacity(.75), blurRadius: 5 + 5 * _pulse.value, spreadRadius: .2)]
                                  : null,
                            ),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                if (cell != null) _pieceStack(cell),
                                if (cell?.tag != null)
                                  Positioned(
                                    top: 1.5,
                                    right: 1.5,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                                      decoration: BoxDecoration(
                                        color: (cell!.tagColor ?? border ?? Colors.white).withOpacity(.20),
                                        border: Border.all(color: cell.tagColor ?? border ?? Colors.white, width: .7),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      child: Text(cell.tag!, style: const TextStyle(fontSize: 6.5, fontWeight: FontWeight.w800, height: 1.0)),
                                    ),
                                  ),
                              ],
                            ),
                          );
                          if (cell?.dashed != true || border == null) return body;
                          return Stack(
                            fit: StackFit.expand,
                            children: [
                              body,
                              IgnorePointer(child: CustomPaint(painter: _DashedCellBorderPainter(color: border, strokeWidth: 2.2))),
                            ],
                          );
                        },
                      ),
                    ),
                    if (widget.showZLine)
                      Positioned(
                        left: 0,
                        right: 0,
                        top: constraints.maxHeight * 3 / 7 - 1,
                        child: Row(children: [
                          Expanded(child: Container(height: 2, color: Colors.lightBlueAccent.withOpacity(.8))),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                            color: Colors.black87,
                            child: const Text('Z LINE', style: TextStyle(fontSize: 7, color: Colors.lightBlueAccent, fontWeight: FontWeight.w900)),
                          ),
                          Expanded(child: Container(height: 2, color: Colors.lightBlueAccent.withOpacity(.8))),
                        ]),
                      ),
                    if (widget.threatPairs.isNotEmpty)
                      IgnorePointer(
                        child: AnimatedBuilder(
                          animation: _arc,
                          builder: (context, _) => CustomPaint(
                            painter: _ShotThreatArcPainter(
                              pairs: widget.threatPairs,
                              progress: _arc.value,
                              playerIsWhite: true,
                            ),
                          ),
                        ),
                      ),
                  ],
                );
              }),
            ),
          ),
        ),
        if (widget.caption != null) ...[
          const SizedBox(height: 9),
          Text(widget.caption!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.white60, height: 1.45)),
        ],
      ],
    );
  }
}


class _ManualCrownScoreDisplay extends StatelessWidget {
  final String label;
  final String value;
  const _ManualCrownScoreDisplay({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(.045),
      border: Border.all(color: Colors.white24, width: .7),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, letterSpacing: .7)),
      const SizedBox(width: 5),
      Image.asset('assets/pieces/crown_knight_1_5.webp', width: 28, height: 22, fit: BoxFit.contain),
      const SizedBox(width: 3),
      Text('$value / 3', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
    ]),
  );
}


class _ManualCrownLossExample extends StatelessWidget {
  const _ManualCrownLossExample();
  @override
  Widget build(BuildContext context) => Column(children: [
    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Image.asset('assets/pieces/crown_knight_1_5.webp', width: 58, height: 46, fit: BoxFit.contain),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('+', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
      Image.asset('assets/pieces/crown_knight_1_5.webp', width: 58, height: 46, fit: BoxFit.contain),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('=', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
      const Text('3 / 3', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
    ]),
    const SizedBox(height: 8),
    const Text('獲得した王冠の合計が3に到達すると勝利。', style: TextStyle(fontSize: 12, color: Colors.white60)),
  ]);
}

class _SystemSkillGuide extends StatelessWidget {
  const _SystemSkillGuide();

  Widget _card(String title, String asset, List<Widget> children) => Container(
    width: double.infinity,
    margin: const EdgeInsets.only(bottom: 16),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(.025),
      border: Border.all(color: Colors.white12),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      Center(child: Image.asset(asset, height: 92, fit: BoxFit.contain)),
      const SizedBox(height: 12),
      ...children,
    ]),
  );

  Widget _body(List<_SystemChunk> chunks) => _SystemInline(chunks);

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _card('王 － 連射', 'assets/pieces/white_king.png', [
      _body(const [
        _SystemChunk('射撃を2回連続で行うSKILL。2回の'),
        _SystemChunk('射撃', ruleId: 'ranged'),
        _SystemChunk('が成立する状況でのみ使用できる。1発目で敵を破壊して'),
        _SystemChunk('Lv', ruleId: 'level'),
        _SystemChunk('が上がった場合、その成長後の行動範囲と盤面状況を使って2発目を判定する。各射撃には通常の射撃・'),
        _SystemChunk('拮抗', displayId: 'contested'),
        _SystemChunk('のルールが適用される。'),
      ]),
    ]),
    _card('騎 － 変形', 'assets/pieces/white_knight.png', [
      _body(const [
        _SystemChunk('騎・弐式・参式の3形態を切り替えるSKILL。現在の形態以外の2形態から直接選んで変形でき、変形そのものが1行動となる。蓄積した'),
        _SystemChunk('Lv', ruleId: 'level'),
        _SystemChunk('は変形しても失われない。'),
      ]),
      const SizedBox(height: 14),
      const Text('騎', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      _body(const [
        _SystemChunk('通常形態。'),
        _SystemChunk('Lv / Pu', ruleId: 'level'),
        _SystemChunk('に応じて行動範囲が変化する。'),
      ]),
      const SizedBox(height: 10),
      Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 12, children: [
        _RangeMini('Lv1', _BoardScreenState.lv1MoveOffsets['騎']!),
        _RangeMini('Lv2', _BoardScreenState.lv2MoveOffsets['騎']!),
        _RangeMini('Lv3', _BoardScreenState.lv3MoveOffsets['騎']!),
      ]),
      const SizedBox(height: 18),
      const Text('弐式', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Center(child: Image.asset('assets/pieces/white_knight_2.png', height: 88, fit: BoxFit.contain)),
      const SizedBox(height: 8),
      _body(const [
        _SystemChunk('周囲8マスを行動範囲とする近距離型。行動範囲は固定で、'),
        _SystemChunk('Lv / Pu', ruleId: 'level'),
        _SystemChunk('による範囲拡張を受けない。'),
      ]),
      const SizedBox(height: 10),
      const Center(child: _RangeMini('固定', _BoardScreenState.knightSecondOffsets)),
      const SizedBox(height: 18),
      const Text('参式', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Center(child: Image.asset('assets/pieces/white_knight_3.png', height: 88, fit: BoxFit.contain)),
      const SizedBox(height: 8),
      _body(const [
        _SystemChunk('離れた斜め方向を広く捉える砲撃型。行動範囲は固定で、'),
        _SystemChunk('Lv / Pu', ruleId: 'level'),
        _SystemChunk('による範囲拡張を受けない。'),
      ]),
      const SizedBox(height: 10),
      const Center(child: _RangeMini('固定', _BoardScreenState.knightThirdOffsets)),
    ]),
    _card('帝 － 加速', 'assets/pieces/white_emperor.png', [
      _body(const [
        _SystemChunk('移動を2回連続で行うSKILL。1回目の'),
        _SystemChunk('移動', ruleId: 'move'),
        _SystemChunk('後、着地点で行動範囲を計算し直して2回目を行う。1回目で'),
        _SystemChunk('前線', ruleId: 'frontline'),
        _SystemChunk('に入るなどして'),
        _SystemChunk('Pu', ruleId: 'level'),
        _SystemChunk('が変化した場合、その変化も2回目へ反映される。2回目の移動先がある場合は2回目まで行い、移動先が無い場合だけ1回目で終了する。'),
      ]),
    ]),
  ]);
}

class _SystemSectionBox extends StatelessWidget {
  final String title;
  final Widget child;
  const _SystemSectionBox({required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(.025),
      border: Border.all(color: Colors.white12),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: .4)),
      const SizedBox(height: 12),
      child,
    ]),
  );
}

class SystemDatabaseScreen extends StatelessWidget {
  const SystemDatabaseScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: const Text('DATABASE / SYSTEM')),
    body: ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 12),
      itemCount: 3,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final title = const ['ABOUT', 'RULE', 'DISPLAY'][i];
        final subtitle = const ['このゲームについて', '共通ルール', '盤面表示 / アニメーション'][i];
        return ListTile(
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            _UiSounds.tap();
            if (i == 0) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _SystemAboutScreen()));
            if (i == 1) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _SystemRuleListScreen()));
            if (i == 2) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const _SystemDisplayListScreen()));
          },
        );
      },
    ),
  );
}

class _SystemAboutScreen extends StatelessWidget {
  const _SystemAboutScreen();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: const Text('SYSTEM / ABOUT')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('このゲームについて', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        const Text(_GameGuide.premise, style: TextStyle(fontSize: 16, height: 1.75)),
        const SizedBox(height: 22),
        _SystemSectionBox(
          title: '戦いながら知る',
          child: _SystemInline(const [
            _SystemChunk('SYSTEMでは、対戦に必要な'),
            _SystemChunk('ルール', ruleId: 'basic'),
            _SystemChunk('と盤面の読み方を説明する。駒ごとの特徴や使い方は、DATABASEと戦いの中で確かめていく。'),
          ]),
        ),
        const SizedBox(height: 14),
        _SystemSectionBox(
          title: '鉄の掟',
          child: _SystemInline(const [
            _SystemChunk('対戦では、'),
            _SystemChunk('王冠を3つ獲得すれば勝利', ruleId: 'crown'),
            _SystemChunk('する。これが勝敗の鉄の掟となる。'),
          ]),
        ),
      ],
    ),
  );
}

const _systemRuleItems = <(String, String, String)>[
  ('basic', '基本ルール', '5×7盤面と1ターン1行動'),
  ('flow', 'ゲームの流れ', '対戦開始から勝敗決着まで'),
  ('setup', '対戦開始', 'ユニット選択 / 先攻・後攻 / 配置'),
  ('turn', 'ターンと時間', '15分 / 90秒 / タイムアウト'),
  ('skill', 'SKILL', '王「連射」 / 騎「変形」 / 帝「加速」'),
  ('move', '移動', '空きマスへの移動'),
  ('melee', '格闘', '破壊して相手のマスへ入る'),
  ('ranged', '射撃 / 拮抗', '離れて破壊 / 相互射程'),
  ('merge', '合流', '味方同士を同じマスへ重ねる'),
  ('suppress', '制圧 / 制圧破壊', '敵を破壊せず上に乗る'),
  ('frontline', '前線', '敵陣3列でPuを得る'),
  ('level', 'Lv / Pu', '恒久成長と一時強化'),
  ('soldier', '兵', '状況で変わる行動範囲とストック'),
  ('core', '核 / 復活', '自壊して復活またはLv3'),
  ('crown', '王冠 / 勝敗', '3 / 3で勝利'),
];

const _systemDisplayItems = <(String, String, String)>[
  ('selected', '選択中', '水色の枠と発光'),
  ('actions', '行動候補の色', '移動 / 合流 / 敵対象'),
  ('range', '青・黄・赤 / 点線', 'Lvごとの行動範囲'),
  ('merge', '合流表示', '緑の点滅枠'),
  ('suppress', '制圧表示', '紫の点滅枠'),
  ('threat', '射撃警告', '放物線の黄色い矢印'),
  ('contested', '拮抗表示', '「拮抗」と表示され射撃不可'),
  ('stack', '上 / 下', '重なった駒の情報切替'),
  ('crowns', '王冠表示', 'WHITE / BLACK の 0〜3'),
];

class _SystemRuleListScreen extends StatelessWidget {
  const _SystemRuleListScreen();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: const Text('SYSTEM / RULE')),
    body: ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 12),
      itemCount: _systemRuleItems.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final x = _systemRuleItems[i];
        return ListTile(
          title: Text(x.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(x.$3),
          trailing: const Icon(Icons.chevron_right),
          onTap: _withUiTap(() => _openSystemRule(context, x.$1)),
        );
      },
    ),
  );
}

class _SystemDisplayListScreen extends StatelessWidget {
  const _SystemDisplayListScreen();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: const Text('SYSTEM / DISPLAY')),
    body: ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 12),
      itemCount: _systemDisplayItems.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final x = _systemDisplayItems[i];
        return ListTile(
          title: Text(x.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(x.$3),
          trailing: const Icon(Icons.chevron_right),
          onTap: _withUiTap(() => _openSystemDisplay(context, x.$1)),
        );
      },
    ),
  );
}

String _systemRuleTitle(String id) {
  for (final x in _systemRuleItems) { if (x.$1 == id) return x.$2; }
  return 'RULE';
}

String _systemDisplayTitle(String id) {
  for (final x in _systemDisplayItems) { if (x.$1 == id) return x.$2; }
  return 'DISPLAY';
}

class _SystemRuleDetailScreen extends StatelessWidget {
  final String id;
  const _SystemRuleDetailScreen({required this.id});

  Widget _figure() {
    switch (id) {
      case 'basic':
        return const _ManualBoard(
          cells: {
            1: _ManualCell(assets: ['assets/pieces/black_soldier.png']),
            3: _ManualCell(assets: ['assets/pieces/black_soldier.png']),
            31: _ManualCell(assets: ['assets/pieces/white_soldier.png']),
            33: _ManualCell(assets: ['assets/pieces/white_soldier.png']),
          },
          caption: '盤面は5×7。WHITEは下側、BLACKは上側から戦う。',
        );
      case 'skill':
        return const _SystemSkillGuide();
      case 'move':
        return const _ManualBoard(
          cells: {
            17: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent, fillColor: Color(0x1919B5FE)),
            5: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
            7: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
            9: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
            12: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
            22: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
            27: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
          },
          caption: '騎Lv1の実際の行動範囲。空いている青マスへ移動できる。青い枠はLv1範囲を示す。',
        );
      case 'melee':
        return const _ManualBoard(
          cells: {
            17: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent),
            7: _ManualCell(assets: ['assets/pieces/black_soldier.png'], borderColor: Colors.redAccent, fillColor: Color(0x20FF5252)),
          },
          caption: '敵対象は赤。格闘すると敵を破壊し、そのマスへ移動する。',
        );
      case 'ranged':
        return const _ManualBoard(
          cells: {
            27: _ManualCell(assets: ['assets/pieces/white_scholar.png'], borderColor: Colors.lightBlueAccent),
            17: _ManualCell(assets: ['assets/pieces/black_soldier.png'], borderColor: Colors.redAccent, fillColor: Color(0x20FF5252)),
          },
          caption: '射撃では攻撃側は元のマスに残り、敵の上側だけを破壊する。',
        );
      case 'merge':
        return const _ManualBoard(
          cells: {
            22: _ManualCell(
              assets: ['assets/pieces/white_soldier.png', 'assets/pieces/white_knight.png'],
              borderColor: Colors.greenAccent,
              fillColor: Color(0x143DFF95),
              blink: true,
              tag: '合流',
              tagColor: Colors.greenAccent,
            ),
          },
          caption: '味方2駒が同じマスに重なる。盤面では緑に点滅する。',
        );
      case 'suppress':
        return const _ManualBoard(
          cells: {
            22: _ManualCell(
              assets: ['assets/pieces/black_soldier.png', 'assets/pieces/white_knight.png'],
              borderColor: Colors.purpleAccent,
              fillColor: Color(0x141A0024),
              blink: true,
              tag: '制圧',
              tagColor: Colors.redAccent,
            ),
          },
          caption: '敵を下、制圧側を上に重ねる。枠は紫に点滅する。',
        );
      case 'frontline':
        return const _ManualBoard(
          highlightRows: {0, 1, 2},
          cells: {
            12: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent),
          },
          caption: 'WHITE視点。上側3列が敵陣＝前線。BLACKでは上下が逆になる。',
        );
      case 'level':
        return const _ManualBoard(
          cells: {
            17: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent),
            5: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            7: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            9: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            12: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            22: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            27: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            25: _ManualCell(borderColor: Colors.amberAccent, dashed: true),
            29: _ManualCell(borderColor: Colors.amberAccent, dashed: true),
            15: _ManualCell(borderColor: Colors.redAccent, dashed: true),
            19: _ManualCell(borderColor: Colors.redAccent, dashed: true),
          },
          caption: 'マス内の青＝移動候補。枠色は青＝Lv1、黄＝Lv2、赤＝Lv3。未到達Lvの枠は点線。',
        );
      case 'soldier':
        return const _ManualBoard(
          cells: {
            27: _ManualCell(assets: ['assets/pieces/white_soldier.png'], borderColor: Colors.lightBlueAccent),
            22: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            26: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            28: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            32: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
          },
          caption: '兵はLvを持たず、合流や前線によって行動範囲そのものが変わる。',
        );
      case 'core':
        return const _ManualBoard(
          showZLine: true,
          cells: {
            32: _ManualCell(assets: ['assets/pieces/white_core_2.png'], borderColor: Colors.lightBlueAccent),
            22: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.greenAccent, fillColor: Color(0x183DFF95)),
          },
          caption: '復活先はZ LINEを含む自陣側4列。味方1駒の上なら合流で復活できる。',
        );
      case 'crown':
        return const Padding(
          padding: EdgeInsets.symmetric(vertical: 12),
          child: _ManualCrownLossExample(),
        );
      default:
        return const SizedBox.shrink();
    }
  }

  List<_SystemChunk> _text() {
    switch (id) {
      case 'basic':
        return const [
          _SystemChunk('1対1、5×7の盤面で戦う。先攻はWHITE、後攻はBLACK。通常は1ターンに1行動。勝敗の中心になるのは'),
          _SystemChunk('王冠', ruleId: 'crown'),
          _SystemChunk('で、合計3を獲得した側が勝利する。'),
        ];
      case 'flow':
        return const [
          _SystemChunk('対戦は、まず'),
          _SystemChunk('ユニット選択と先攻・後攻の決定', ruleId: 'setup'),
          _SystemChunk('を行い、その後に駒を配置して戦闘を開始する。先攻＝WHITEからターンが始まり、自分のターンでは通常、'),
          _SystemChunk('移動', ruleId: 'move'),
          _SystemChunk('、'),
          _SystemChunk('格闘', ruleId: 'melee'),
          _SystemChunk('、'),
          _SystemChunk('射撃', ruleId: 'ranged'),
          _SystemChunk('、'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('、'),
          _SystemChunk('制圧', ruleId: 'suppress'),
          _SystemChunk('、'),
          _SystemChunk('SKILL', ruleId: 'skill'),
          _SystemChunk('、'),
          _SystemChunk('核の発動', ruleId: 'core'),
          _SystemChunk('などから1行動を行う。行動すると相手のターンへ移り、WHITEとBLACKが交互に行動する。敵を破壊した大駒は'),
          _SystemChunk('Lv', ruleId: 'level'),
          _SystemChunk('が上がり、敵陣へ進むと'),
          _SystemChunk('前線', ruleId: 'frontline'),
          _SystemChunk('の効果も発生する。これを繰り返し、相手の'),
          _SystemChunk('王冠', ruleId: 'crown'),
          _SystemChunk('を合計3つ獲得すれば勝利となる。'),
        ];
      case 'setup':
        return const [
          _SystemChunk('じゃんけんの勝者が先にユニットを選び、敗者が次に選ぶ。その後、じゃんけん勝者が先攻か後攻を選ぶ。先攻＝WHITE、後攻＝BLACK。配置を確定すると戦闘開始。'),
        ];
      case 'turn':
        return const [
          _SystemChunk('各陣営の総持ち時間は15分。1ターンは90秒。90秒を使い切るとそのターンは終了し、3回目のタイムアウトで敗北する。通常の'),
          _SystemChunk('移動', ruleId: 'move'),
          _SystemChunk('、'),
          _SystemChunk('格闘', ruleId: 'melee'),
          _SystemChunk('、'),
          _SystemChunk('射撃', ruleId: 'ranged'),
          _SystemChunk('、'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('、'),
          _SystemChunk('制圧', ruleId: 'suppress'),
          _SystemChunk('、'),
          _SystemChunk('SKILL', ruleId: 'skill'),
          _SystemChunk('、'),
          _SystemChunk('核の発動', ruleId: 'core'),
          _SystemChunk('など、1つの行動でターンが終わる。'),
        ];
      case 'skill':
        return const [
          _SystemChunk('王・騎・帝は、それぞれ固有のSKILLを持つ。SKILLは通常の行動とは異なる効果を1行動として実行する。王は'),
          _SystemChunk('射撃', ruleId: 'ranged'),
          _SystemChunk('を2回行う「連射」、騎は3形態を切り替える「変形」、帝は'),
          _SystemChunk('移動', ruleId: 'move'),
          _SystemChunk('を2回行う「加速」を使用できる。詳しい挙動と騎の各形態は下に示す。'),
        ];
      case 'move':
        return const [
          _SystemChunk('自軍の駒をタップすると、現在移動できる空きマスが表示される。'),
          _SystemChunk('青マス', displayId: 'actions'),
          _SystemChunk('をタップすると移動し、そのターンは終了する。駒ごとの行動範囲はDATABASE / UNITでも確認できる。'),
        ];
      case 'melee':
        return const [
          _SystemChunk('行動範囲内の敵を選び「格闘」を選ぶと、敵の一番上の駒を破壊し、攻撃した駒は敵がいたマスへ移動する。敵を破壊した大駒は'),
          _SystemChunk('Lv', ruleId: 'level'),
          _SystemChunk('が1上がる。敵が'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('していた場合は上側を破壊し、残った下側を'),
          _SystemChunk('制圧', ruleId: 'suppress'),
          _SystemChunk('する。'),
        ];
      case 'ranged':
        return const [
          _SystemChunk('行動範囲内の敵を選び「射撃」を選ぶと、攻撃側はその場に残ったまま敵の一番上の駒を破壊する。敵を破壊した大駒は'),
          _SystemChunk('Lv', ruleId: 'level'),
          _SystemChunk('が1上がる。射撃能力を持つ駒同士が互いの行動範囲に入っている時は'),
          _SystemChunk('拮抗', displayId: 'contested'),
          _SystemChunk('となり、射撃は選べない。自分が一方的に射撃される位置にいる時は'),
          _SystemChunk('射撃警告', displayId: 'threat'),
          _SystemChunk('が出る。'),
        ];
      case 'merge':
        return const [
          _SystemChunk('味方1駒の上へ移動すると合流できる。1マスに重なれるのは最大2駒。上側の駒は離脱できるが、下側の駒は上に駒がいる間は動けない。合流中は'),
          _SystemChunk('Pu', ruleId: 'level'),
          _SystemChunk('を得て、盤面では'),
          _SystemChunk('緑の点滅枠', displayId: 'merge'),
          _SystemChunk('になる。射撃を受けた場合は上側だけが破壊される。'),
        ];
      case 'suppress':
        return const [
          _SystemChunk('敵を破壊せず、その上へ自軍の駒を乗せる行動。下になった敵は行動できない。制圧中の自軍駒を長押しすると「制圧破壊」を選べ、下の敵だけを破壊する。制圧側がそのマスから離れた時、異なるユニット同士なら下の大駒は鹵獲される。兵は鹵獲されない。盤面では'),
          _SystemChunk('紫の点滅枠', displayId: 'suppress'),
          _SystemChunk('で示される。'),
        ];
      case 'frontline':
        return const [
          _SystemChunk('敵陣側3列へ入った駒は'),
          _SystemChunk('前線', ruleId: 'frontline'),
          _SystemChunk('状態となり、通常は'),
          _SystemChunk('Pu+1', ruleId: 'level'),
          _SystemChunk('。さらに味方の「前線＋'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('」が成立している間、味方大駒は実効Lv3まで最大パンプされる。'),
          _SystemChunk('兵', ruleId: 'soldier'),
          _SystemChunk('も前線用の行動範囲へ変化する。'),
        ];
      case 'level':
        return const [
          _SystemChunk('Lvは大駒が敵を破壊するたびに1上がる恒久成長で、Lv1から最大Lv3まで成長する。一度上がったLvはその対戦中維持される。Puは'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('や'),
          _SystemChunk('前線', ruleId: 'frontline'),
          _SystemChunk('による一時的な強化。LvとPuを合算した実効段階は最大3。駒をタップした時に見える'),
          _SystemChunk('青・黄・赤の枠', displayId: 'range'),
          _SystemChunk('で各段階の違いを確認できる。'),
        ];
      case 'soldier':
        return const [
          _SystemChunk('兵は'),
          _SystemChunk('Lv', ruleId: 'level'),
          _SystemChunk('アップしない。通常は十字1、'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('では十字2、'),
          _SystemChunk('前線', ruleId: 'frontline'),
          _SystemChunk('では周囲3×3へ行動範囲が変化する。KING / KNIGHT / EMPEROR同士の戦いでは、破壊された兵は破壊した側のストックとなり、自陣側4列の空きマスへ1行動で投入できる。'),
        ];
      case 'core':
        return const [
          _SystemChunk('核は、上に別の駒がいない時に自壊して発動できる。発動時は「破壊された大駒を1体復活」または「盤上の大駒を即'),
          _SystemChunk('Lv3', ruleId: 'level'),
          _SystemChunk('」から選ぶ。復活先はZ LINEを含む自陣側4列で、味方1駒の上へ復活するとそのまま'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('する。敵に核を破壊された場合は効果を発動しない。核そのものも'),
          _SystemChunk('王冠', ruleId: 'crown'),
          _SystemChunk('を持つ。'),
        ];
      case 'crown':
        return const [
          _SystemChunk('対戦では、獲得した王冠の合計が3になった側が勝利する。KING / KNIGHT / EMPERORでは、相手の2つの'),
          _SystemChunk('核', ruleId: 'core'),
          _SystemChunk('とリーダーがそれぞれ王冠1.5を持つため、そのうち2つを破壊すれば3に到達する。核の発動によってリーダーが盤上へ'),
          _SystemChunk('復活', ruleId: 'core'),
          _SystemChunk('すれば、その分の獲得王冠は取り消される。また、手番側に合法な行動が1つも無い場合も敗北となる。'),
        ];
      default:
        return const [_SystemChunk('説明準備中。')];
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: Text('RULE / ${_systemRuleTitle(id)}')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(_systemRuleTitle(id), style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        _SystemInline(_text()),
        const SizedBox(height: 24),
        _figure(),
        const SizedBox(height: 28),
        OutlinedButton(
          onPressed: () {
            _UiSounds.tap();
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const SystemDatabaseScreen()),
              (route) => route.isFirst,
            );
          },
          child: const Text('DATABASE / SYSTEMへ戻る'),
        ),
        const SizedBox(height: 10),
        OutlinedButton(
          onPressed: () {
            _UiSounds.tap();
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MainMenuScreen()),
              (route) => route.isFirst,
            );
          },
          child: const Text('メインメニューへ戻る'),
        ),
      ],
    ),
  );
}

class _SystemDisplayDetailScreen extends StatelessWidget {
  final String id;
  const _SystemDisplayDetailScreen({required this.id});

  Widget _figure() {
    switch (id) {
      case 'selected':
        return const _ManualBoard(
          cells: {27: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent, fillColor: Color(0x1919B5FE))},
          caption: '選択中の駒は水色の枠と発光で示される。',
        );
      case 'actions':
        return const _ManualBoard(
          cells: {
            17: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent),
            22: _ManualCell(borderColor: Colors.cyanAccent, fillColor: Color(0x2426C6DA)),
            12: _ManualCell(assets: ['assets/pieces/white_soldier.png'], borderColor: Colors.greenAccent, fillColor: Color(0x203DFF95)),
            7: _ManualCell(assets: ['assets/pieces/black_soldier.png'], borderColor: Colors.redAccent, fillColor: Color(0x20FF5252)),
          },
          caption: 'マス色：青＝移動 / 緑＝合流 / 赤＝敵への行動候補。枠色はLv段階を示す。',
        );
      case 'range':
        return const _ManualBoard(
          cells: {
            17: _ManualCell(assets: ['assets/pieces/white_knight.png'], borderColor: Colors.lightBlueAccent),
            5: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            7: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            9: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            12: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            22: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            27: _ManualCell(borderColor: Colors.lightBlueAccent, fillColor: Color(0x1719B5FE)),
            25: _ManualCell(borderColor: Colors.amberAccent, dashed: true),
            29: _ManualCell(borderColor: Colors.amberAccent, dashed: true),
            15: _ManualCell(borderColor: Colors.redAccent, dashed: true),
            19: _ManualCell(borderColor: Colors.redAccent, dashed: true),
          },
          caption: 'マス内の青＝移動候補。枠色は青＝Lv1 / 黄＝Lv2 / 赤＝Lv3。未到達Lvの枠は点線。',
        );
      case 'merge':
        return const _ManualBoard(
          cells: {
            22: _ManualCell(
              assets: ['assets/pieces/white_soldier.png', 'assets/pieces/white_knight.png'],
              borderColor: Colors.greenAccent,
              fillColor: Color(0x143DFF95),
              blink: true,
              tag: '合流',
              tagColor: Colors.greenAccent,
            ),
          },
          caption: '合流中は緑の枠が点滅し、右上に「合流」と表示される。',
        );
      case 'suppress':
        return const _ManualBoard(
          cells: {
            22: _ManualCell(
              assets: ['assets/pieces/black_soldier.png', 'assets/pieces/white_knight.png'],
              borderColor: Colors.purpleAccent,
              fillColor: Color(0x141A0024),
              blink: true,
              tag: '制圧',
              tagColor: Colors.redAccent,
            ),
          },
          caption: '制圧中は紫の枠が点滅し、右上に「制圧」と表示される。',
        );
      case 'threat':
        return const _ManualBoard(
          cells: {
            7: _ManualCell(assets: ['assets/pieces/black_scholar.png']),
            27: _ManualCell(assets: ['assets/pieces/white_soldier.png']),
          },
          threatPairs: [(7, 27)],
          caption: '自分の手番中、一方的に射撃される駒へ黄色い放物線矢印が走る。',
        );
      case 'contested':
        return Column(children: [
          const _ManualBoard(
            cells: {
              17: _ManualCell(assets: ['assets/pieces/black_scholar.png'], borderColor: Colors.redAccent),
              27: _ManualCell(assets: ['assets/pieces/white_scholar.png'], borderColor: Colors.lightBlueAccent),
            },
          ),
          const SizedBox(height: 12),
          SizedBox(width: 238, child: OutlinedButton(onPressed: null, child: const Text('拮抗', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)))),
          const SizedBox(height: 7),
          const Text('互いの射程内では「射撃」ではなく「拮抗」と表示され、選択できない。', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.white60)),
        ]);
      case 'stack':
        return const _ManualBoard(
          cells: {
            22: _ManualCell(
              assets: ['assets/pieces/white_soldier.png', 'assets/pieces/white_knight.png'],
              borderColor: Colors.greenAccent,
              tag: '合流',
              tagColor: Colors.greenAccent,
            ),
          },
          caption: '重なったマスは再タップすると情報欄の「上：」「下：」を切り替えられる。',
        );
      case 'crowns':
        return const Padding(
          padding: EdgeInsets.symmetric(vertical: 12),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _ManualCrownScoreDisplay(label: 'WHITE', value: '1.5'),
            SizedBox(width: 12),
            _ManualCrownScoreDisplay(label: 'BLACK', value: '0'),
          ]),
        );
      default:
        return const SizedBox.shrink();
    }
  }

  List<_SystemChunk> _text() {
    switch (id) {
      case 'selected':
        return const [_SystemChunk('自軍の駒をタップして操作対象にすると、水色の枠と発光が付く。敵駒を閲覧した時も同じ系統の選択表示が使われる。')];
      case 'actions':
        return const [
          _SystemChunk('駒を選択した時、行動候補はマス内の色で示される。空きマスへの'),
          _SystemChunk('移動', ruleId: 'move'),
          _SystemChunk('は青マス、味方への'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('は緑マス、敵への'),
          _SystemChunk('格闘', ruleId: 'melee'),
          _SystemChunk('・'),
          _SystemChunk('射撃', ruleId: 'ranged'),
          _SystemChunk('・'),
          _SystemChunk('制圧', ruleId: 'suppress'),
          _SystemChunk('候補は赤マスで示される。枠の色は行動種別ではなくLv段階を示す。'),
        ];
      case 'range':
        return const [
          _SystemChunk('行動範囲のLv段階はマスの枠色で示す。青枠＝Lv1、黄枠＝Lv2、赤枠＝Lv3。現在の'),
          _SystemChunk('Lv / Pu', ruleId: 'level'),
          _SystemChunk('ではまだ使えない段階の枠は点線になる。マス内の青・緑・赤はLv色ではなく、それぞれ移動・合流・敵への行動候補を示す。'),
        ];
      case 'merge':
        return const [
          _SystemChunk('味方同士が'),
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('しているマスは、緑の枠がゆっくり点滅し、右上に「合流」と表示される。'),
        ];
      case 'suppress':
        return const [
          _SystemChunk('敵を'),
          _SystemChunk('制圧', ruleId: 'suppress'),
          _SystemChunk('しているマスは、紫の枠がゆっくり点滅し、右上に「制圧」と表示される。合流の緑点滅とは色で見分けられる。'),
        ];
      case 'threat':
        return const [
          _SystemChunk('自分の手番中、敵から一方的に'),
          _SystemChunk('射撃', ruleId: 'ranged'),
          _SystemChunk('される位置にいる自軍駒には、敵からその駒へ黄色い放物線の矢印が走る。互いに射程へ入っていて'),
          _SystemChunk('拮抗', displayId: 'contested'),
          _SystemChunk('している組には、この警告は出ない。'),
        ];
      case 'contested':
        return const [
          _SystemChunk('互いに射撃可能な行動範囲へ入っている時、敵を選択すると「射撃」の代わりに「拮抗」と表示され、ボタンが選択できなくなる。盤面そのものに専用色は付かない。詳しい条件は'),
          _SystemChunk('射撃 / 拮抗', ruleId: 'ranged'),
          _SystemChunk('を参照。'),
        ];
      case 'stack':
        return const [
          _SystemChunk('合流', ruleId: 'merge'),
          _SystemChunk('や'),
          _SystemChunk('制圧', ruleId: 'suppress'),
          _SystemChunk('で2駒が同じマスにいる時、情報欄には「上：」「下：」が付く。同じマスをもう一度タップすると、表示する側を切り替えられる。'),
        ];
      case 'crowns':
        return const [
          _SystemChunk('盤面上部のWHITE / BLACKには、現在獲得している'),
          _SystemChunk('王冠', ruleId: 'crown'),
          _SystemChunk('の合計が0〜3で表示される。3 / 3に到達した側が勝利する。'),
        ];
      default:
        return const [_SystemChunk('説明準備中。')];
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(leading: _easyBackButton(context), title: Text('DISPLAY / ${_systemDisplayTitle(id)}')),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(_systemDisplayTitle(id), style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        _SystemInline(_text()),
        const SizedBox(height: 24),
        _figure(),
        const SizedBox(height: 28),
        OutlinedButton(
          onPressed: () {
            _UiSounds.tap();
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const SystemDatabaseScreen()),
              (route) => route.isFirst,
            );
          },
          child: const Text('DATABASE / SYSTEMへ戻る'),
        ),
        const SizedBox(height: 10),
        OutlinedButton(
          onPressed: () {
            _UiSounds.tap();
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (_) => const MainMenuScreen()),
              (route) => route.isFirst,
            );
          },
          child: const Text('メインメニューへ戻る'),
        ),
      ],
    ),
  );
}


class _UnitDbEntry {
  final String piece, reading, machine, machineReading, description, pieceAsset, pilotAsset, title, pilot, quote;
  final String? externalImage;
  const _UnitDbEntry(this.piece,this.reading,this.machine,this.machineReading,this.description,this.pieceAsset,this.pilotAsset,this.title,this.pilot,this.quote,{this.externalImage});
}

class UnitDatabaseScreen extends StatefulWidget {
  const UnitDatabaseScreen({super.key});
  @override State<UnitDatabaseScreen> createState()=>_UnitDatabaseScreenState();
}
class _UnitDatabaseScreenState extends State<UnitDatabaseScreen> {
  @override void initState(){super.initState();WidgetsBinding.instance.addPostFrameCallback((_)=>_showUnitUnlocks());}
  Future<void> _showUnitUnlocks() async {final notices=await _UnlockInbox.takeUnitNotices();if(!mounted||notices.isEmpty)return;await _showUnlockNotices(context,notices);if(mounted)setState((){});}
  static const core = _UnitDbEntry('核','カク','','','飛空城に備えられた復活兵器。全ての記憶、情報を圧縮した物質だ。','assets/pieces/white_core_2.png','','','','');
  static const soldier = _UnitDbEntry('兵','ヘイ','量産機','','レベルアップしない代わりに状況に応じて行動範囲が変化。','assets/pieces/white_soldier.png','','','騎士団','');
  static const king = <_UnitDbEntry>[
    _UnitDbEntry('王','オウ','立神','タチガミ','KINGユニットのリーダー。SKILL「連射」による爆発力が持ち前。','assets/pieces/white_king.png','assets/pilots/king.webp','反乱軍筆頭','アーキン・バーン','後悔してもいいんだ。'),
    _UnitDbEntry('仕','シ','狼王','ロウオウ','レベルアップで射程を伸ばす。','assets/pieces/white_servant.png','assets/pilots/attendant.webp','反乱軍','レイ・コール','あなたそればっかりね！'),
    _UnitDbEntry('護','ゴ','狼王','ロウオウ','レベルアップで伸びる射程距離はトップクラス。','assets/pieces/white_guard.png','assets/pilots/guard.webp','反乱軍','ジェイク・ペイド','もうヘトヘトだ。'),
    _UnitDbEntry('闘','トウ','狼王','ロウオウ','レベルアップ時は近接と横への攻撃に特化。','assets/pieces/white_fighter.png','assets/pilots/fighter.webp','反乱軍','アーツ・ロイアー','あいつには借りがある。'),
  ];
  static const knight = <_UnitDbEntry>[
    _UnitDbEntry('騎','キ','三俣','ミツマタ','SKILL「変形」により三形態に変化。あらゆる戦況に対応。','assets/pieces/white_knight.png','assets/pilots/knight.webp','皇帝軍四天王筆頭','ブル・キル','時間を稼いでやる。'),
    _UnitDbEntry('博','ハク','弾雨','ダンウ','最大レベル時の前方への攻撃力は作中一、二を争う。','assets/pieces/white_scholar.png','assets/pilots/scholar.webp','皇帝軍四天王','オース・アイン','撤退しろと言うのか？'),
    _UnitDbEntry('将','ショウ','紅龍','コウリュウ','広範囲を飛び回るが小回りは効かない。','assets/pieces/white_general.png','assets/pilots/general.webp','皇帝軍四天王','ファン・オエル','何を遊んでいるのかしら。'),
    _UnitDbEntry('官','カン','刀勢','トウセイ','近接攻撃性能はトップクラス。レベルアップすると横方向の戦いでは無敵に。','assets/pieces/white_officer.png','assets/pilots/officer.webp','皇帝軍四天王','ギル・ターク','その程度か？'),
  ];
  static const goryu = _UnitDbEntry('軍','グン','豪竜','ゴウリュウ','刀勢の変身形態。官よりも射程が長くなった代わりに目前の敵に弱くなった。','assets/pieces/white_goryu.webp','assets/pilots/officer.webp','皇帝軍四天王','ギル・ターク','その程度か？');
  static const emperor = <_UnitDbEntry>[
    _UnitDbEntry('帝','ミカド','帝','ミカド','SKILL「加速」で移動能力は最高レベル。','assets/pieces/white_emperor.png','assets/pilots/emperor.webp','皇帝軍首領','皇帝','謀反を企てる者は消せ。'),
    _UnitDbEntry('砲','ホウ','狩龍','シュリュウ','前方への攻撃に特化。砲撃力はトップクラス。','assets/pieces/white_cannon.png','assets/pilots/cannon.webp','皇帝軍親衛隊','砲','ニガシハシナイ！'),
    _UnitDbEntry('剣','ツルギ','狩龍','シュリュウ','バランスのいい攻撃範囲を持つ。レベルアップすれば狩龍の苦手な横への牽制が可能。','assets/pieces/white_sword.png','assets/pilots/sword.webp','皇帝軍親衛隊','剣','話す義理はないな。'),
    _UnitDbEntry('盾','タテ','狩龍','シュリュウ','レベルアップすれば行動範囲が後方に伸びる。前に出て後ろの敵を狩る。','assets/pieces/white_shield.png','assets/pilots/shield.webp','皇帝軍親衛隊','盾','これは、私の独断。'),
  ];
  static const strasse = <_UnitDbEntry>[
    _UnitDbEntry('槍','ソウ','','','シュトラーセのリーダが変身した姿。広い行動範囲で翻弄。','assets/pieces/white_strasse_spear.png','assets/pilots/strasse_leader.webp','シュトラーセ','リーダ','俺についてこい。'),
    _UnitDbEntry('迅','ジン','','','シュトラーセのミテが変身した姿。レベルアップすると斜めに伸びる行動範囲を持つ。','assets/pieces/white_strasse_swift.png','assets/pilots/strasse_mite.webp','シュトラーセ','ミテ','ちょまてまて！'),
    _UnitDbEntry('進','シン','','','シュトラーセのトラームが変身した姿。行動範囲は前方に広く戻るのが難しい。','assets/pieces/white_strasse_advance.png','assets/pilots/strasse_traum.webp','シュトラーセ','トラーム','はぁ、付き合いきれね。'),
    _UnitDbEntry('亜','ア','','','シュトラーセのマイクが変身した姿。主に自分の周囲をカバーする行動範囲を持つ。','assets/pieces/white_strasse_sub.png','assets/pilots/strasse_mike.webp','シュトラーセ','マイク','待ってくれよー！'),
  ];
  @override Widget build(BuildContext context) {
    final groups = <(String,List<_UnitDbEntry>,String?)>[
      ('KING',[core,soldier,...king],null),
      if (_StoryProgress.knightUnlocked) ('KNIGHT',[core,soldier,...knight, if (_HiddenUnlocks.goryu) goryu],null),
      if (_StoryProgress.emperorUnlocked) ('EMPEROR',[core,soldier,...emperor],null),
      if (_StoryProgress.strasseUnlocked) ('STRASSE',strasse,'SKILL「逃げるが勝ち」で、格闘後に移動したり合流したまま移動することが可能！ただし射撃能力は有していない……。'),
      if (_MasterProgress.masterUnlocked) ('MASTER',const [],null),
    ];
    return Scaffold(appBar:AppBar(leading:_easyBackButton(context),title:const Text('DATABASE / UNIT')),body:ListView.separated(padding:const EdgeInsets.symmetric(vertical:12),itemCount:groups.length,separatorBuilder:(_,__)=>const Divider(height:1),itemBuilder:(c,i){final g=groups[i];return ListTile(title:Text(g.$1,style:const TextStyle(fontWeight:FontWeight.w900,letterSpacing:1.5)),trailing:const Icon(Icons.chevron_right),onTap:(){_UiSounds.tap();Navigator.push(c,MaterialPageRoute(builder:(_)=>g.$1=='MASTER'?const MasterUnitDatabaseScreen():UnitGroupDatabaseScreen(title:g.$1,entries:g.$2,unitNote:g.$3)));});}));
  }
}

class UnitGroupDatabaseScreen extends StatelessWidget {
  final String title; final List<_UnitDbEntry> entries; final String? unitNote;
  const UnitGroupDatabaseScreen({super.key,required this.title,required this.entries,this.unitNote});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(leading:_easyBackButton(context),title:Text('UNIT / $title')),body:ListView(children:[if(unitNote!=null)Padding(padding:const EdgeInsets.all(18),child:Text(unitNote!,style:const TextStyle(height:1.6))),...entries.map((e)=>ListTile(leading:Image.asset(e.pieceAsset,width:52,height:52,fit:BoxFit.contain),title:Text('${e.piece}（${e.reading}）'),subtitle:Text(e.piece=='核' && !_MasterProgress.masterUnlocked?'？？？':(e.machine.isEmpty?e.description:'機体名：${e.machine}${e.machineReading.isEmpty?'':'（${e.machineReading}）'}\n${e.description}'),maxLines:3,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right),onTap:(){_UiSounds.tap();Navigator.push(context,MaterialPageRoute(builder:(_)=>UnitDetailDatabaseScreen(entry:e)));}))]));
}

class _RangeMini extends StatelessWidget {
  final String label; final List<List<int>> offsets;
  const _RangeMini(this.label,this.offsets);
  @override Widget build(BuildContext context){final set=offsets.map((e)=>'${e[0]},${e[1]}').toSet();return Column(children:[Text(label,style:const TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:6),SizedBox(width:105,height:105,child:GridView.builder(physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:5),itemCount:25,itemBuilder:(_,i){final r=i~/5-2,c=i%5-2;final me=r==0&&c==0,hit=set.contains('$r,$c');return Container(margin:const EdgeInsets.all(1),decoration:BoxDecoration(color:me?Colors.white24:hit?Colors.white54:Colors.white10,borderRadius:BorderRadius.circular(2)),child:me?const Center(child:Text('●',style:TextStyle(fontSize:11))):null);}))]);}
}

class _DbFlipPiece extends StatefulWidget { final String whiteAsset, blackAsset; final double height; const _DbFlipPiece(this.whiteAsset,this.blackAsset,{this.height=150}); @override State<_DbFlipPiece> createState()=>_DbFlipPieceState(); }
class _DbFlipPieceState extends State<_DbFlipPiece> with SingleTickerProviderStateMixin { late final AnimationController _flip=AnimationController(vsync:this,duration:const Duration(milliseconds:650)); bool _black=false; @override void dispose(){_flip.dispose();super.dispose();} void _toggle(){if(_flip.isAnimating)return;setState(()=>_black=!_black);_black?_flip.forward():_flip.reverse();} @override Widget build(BuildContext context)=>GestureDetector(onTap:_toggle,child:AnimatedBuilder(animation:_flip,builder:(_,__){final angle=_flip.value*math.pi;final showBlack=angle>math.pi/2;final shownAngle=showBlack?angle-math.pi:angle;return Transform(alignment:Alignment.center,transform:Matrix4.identity()..setEntry(3,2,.0012)..rotateY(shownAngle),child:Image.asset(showBlack?widget.blackAsset:widget.whiteAsset,height:widget.height,fit:BoxFit.contain));})); }

class UnitDetailDatabaseScreen extends StatelessWidget {
  final _UnitDbEntry entry; const UnitDetailDatabaseScreen({super.key,required this.entry});
  String _blackAsset(String white){ if(white.contains('white_goryu'))return white.replaceFirst('white_goryu','black_goryu'); return white.replaceFirst('white_','black_'); }
  List<List<int>> _lv(int lv){if(entry.piece=='兵')return _BoardScreenState.lv1MoveOffsets['兵']!; if(lv==3)return _BoardScreenState.lv3MoveOffsets[entry.piece]??_BoardScreenState.lv2MoveOffsets[entry.piece]??_BoardScreenState.lv1MoveOffsets[entry.piece]??const[];if(lv==2)return _BoardScreenState.lv2MoveOffsets[entry.piece]??_BoardScreenState.lv1MoveOffsets[entry.piece]??const[];return _BoardScreenState.lv1MoveOffsets[entry.piece]??const[];}
  Widget _ranges(){ if(entry.piece=='核')return const SizedBox.shrink(); if(entry.piece=='兵')return Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_RangeMini('通常',_BoardScreenState.lv1MoveOffsets['兵']!),const _RangeMini('合流',_BoardScreenState.mergedSoldierOffsets),const _RangeMini('前線',_BoardScreenState.frontlineSoldierOffsets)]); return Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_RangeMini('Lv1',_lv(1)),_RangeMini('Lv2',_lv(2)),_RangeMini('Lv3',_lv(3))]); }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(leading:_easyBackButton(context),title:Text((entry.machine.isEmpty?entry.pilot:entry.machine).isEmpty ? entry.piece : '${entry.piece} / ${entry.machine.isEmpty?entry.pilot:entry.machine}')),body:ListView(padding:const EdgeInsets.all(18),children:[Center(child:_DbFlipPiece(entry.pieceAsset,_blackAsset(entry.pieceAsset))),const SizedBox(height:12),Text('駒名：${entry.piece}（${entry.reading}）',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),if(entry.machine.isNotEmpty)Text('機体名：${entry.machine}${entry.machineReading.isEmpty?'':'（${entry.machineReading}）'}',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w700)),const SizedBox(height:18),if(entry.piece=='兵')const _KnightsPilotBlock() else if(entry.pilotAsset.isNotEmpty)...[Center(child:Image.asset(entry.pilotAsset,height:180,fit:BoxFit.contain)),const SizedBox(height:12),Text('【${entry.title}】',textAlign:TextAlign.center),Text(entry.pilot,textAlign:TextAlign.center,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),Text('「${entry.quote}」',textAlign:TextAlign.center,style:const TextStyle(fontSize:16))],const SizedBox(height:22),Text(entry.piece=='核' && !_MasterProgress.masterUnlocked?'？？？':entry.description,style:const TextStyle(height:1.6)),if(entry.piece=='騎')...const [SizedBox(height:24),_KnightFormsDatabase()],if(entry.piece!='核')... [const SizedBox(height:24),const Text('行動範囲',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:12),_ranges()] ]));
}

class _KnightsPilotBlock extends StatefulWidget { const _KnightsPilotBlock(); @override State<_KnightsPilotBlock> createState()=>_KnightsPilotBlockState(); }
class _KnightsPilotBlockState extends State<_KnightsPilotBlock>{File? w,b;@override void initState(){super.initState();_load();}Future<void>_load()async{final a=await _AdditionalData.asset('database/knights/white.jpg'),c=await _AdditionalData.asset('database/knights/black.jpg');if(mounted)setState((){w=a;b=c;});}@override Widget build(BuildContext context)=>Column(children:[if(w?.existsSync()??false)Image.file(w!,height:170,fit:BoxFit.contain),const SizedBox(height:8),if(b?.existsSync()??false)Image.file(b!,height:170,fit:BoxFit.contain),const SizedBox(height:10),const Text('騎士団',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900))]);}

class _KnightFormsDatabase extends StatelessWidget { const _KnightFormsDatabase(); @override Widget build(BuildContext context)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('変形形態',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:14),const Text('弐式',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Center(child:_DbFlipPiece('assets/pieces/white_knight_2.png','assets/pieces/black_knight_2.png',height:130)),const Text('三俣の格闘戦専用形態。周囲の敵を切り刻む。'),const SizedBox(height:10),const Center(child:_RangeMini('固定',_BoardScreenState.knightSecondOffsets)),const SizedBox(height:20),const Text('参式',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Center(child:_DbFlipPiece('assets/pieces/white_knight_3.png','assets/pieces/black_knight_3.png',height:130)),const Text('三俣の砲撃戦特化形態。基本形態では対応できない範囲の敵をマルチロックオンする。'),const SizedBox(height:10),const Center(child:_RangeMini('固定',_BoardScreenState.knightThirdOffsets))]); }

class _MasterDbItem {
  final String title, piece, desc, whiteAsset, blackAsset, rangeKey;
  final String? external, pilotAsset, person, personTitle, quote;
  const _MasterDbItem({required this.title,required this.piece,required this.desc,required this.whiteAsset,required this.blackAsset,required this.rangeKey,this.external,this.pilotAsset,this.person,this.personTitle,this.quote});
}

class _MasterKnightFormsDatabase extends StatelessWidget {
  const _MasterKnightFormsDatabase();
  @override Widget build(BuildContext context)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('変形形態',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:14),
    const Text('弐式',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    const Center(child:_DbFlipPiece('assets/pieces/master_knight2_white.png','assets/pieces/master_knight2_black.png',height:130)),
    const Text('三俣の格闘戦専用形態。周囲の敵を切り刻む。'),const SizedBox(height:10),
    const Center(child:_RangeMini('固定',_BoardScreenState.knightSecondOffsets)),const SizedBox(height:20),
    const Text('参式',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),const SizedBox(height:8),
    const Center(child:_DbFlipPiece('assets/pieces/master_knight3_white.png','assets/pieces/master_knight3_black.png',height:130)),
    const Text('三俣の砲撃戦特化形態。基本形態では対応できない範囲の敵をマルチロックオンする。'),const SizedBox(height:10),
    const Center(child:_RangeMini('固定',_BoardScreenState.knightThirdOffsets)),
  ]);
}

class MasterUnitDatabaseScreen extends StatelessWidget {
  const MasterUnitDatabaseScreen({super.key});
  static const _airNote='巨大飛行要塞、飛空城。その巨大さ故に格闘攻撃が通らない。だがその巨大さ故に格闘攻撃を行うことができない……。母艦としての機能を持つ。';

  static const _items=<_MasterDbItem>[
    _MasterDbItem(title:'王',piece:'王（オウ）',desc:'KINGユニットのリーダー。SKILL「連射」による爆発力が持ち前。',whiteAsset:'assets/pieces/master_king_white.png',blackAsset:'assets/pieces/master_king_black.png',rangeKey:'王',pilotAsset:'assets/pilots/king.webp',person:'アーキン・バーン',personTitle:'反乱軍筆頭',quote:'後悔してもいいんだ。'),
    _MasterDbItem(title:'騎',piece:'騎（キ）',desc:'SKILL「変形」により三形態に変化。あらゆる戦況に対応。',whiteAsset:'assets/pieces/master_knight_white.png',blackAsset:'assets/pieces/master_knight_black.png',rangeKey:'騎',pilotAsset:'assets/pilots/knight.webp',person:'ブル・キル',personTitle:'皇帝軍四天王筆頭',quote:'時間を稼いでやる。'),
    _MasterDbItem(title:'帝',piece:'帝（ミカド）',desc:'SKILL「加速」で移動能力は最高レベル。',whiteAsset:'assets/pieces/master_emperor_white.png',blackAsset:'assets/pieces/master_emperor_black.png',rangeKey:'帝',pilotAsset:'assets/pilots/emperor.webp',person:'皇帝',personTitle:'皇帝軍首領',quote:'謀反を企てる者は消せ。'),
    _MasterDbItem(title:'神仕 / 象',piece:'神仕（シンシ）：象',desc:'象。ミライが依代となって生まれた兵器。ミサイルを積んでいる。',whiteAsset:'assets/pieces/master_divine_elephant_white.png',blackAsset:'assets/pieces/master_divine_elephant_black.png',rangeKey:'神仕',external:'database/yorishiro/mirai.jpg',person:'ミライ',personTitle:'最後の兵士',quote:'私がやる……。'),
    _MasterDbItem(title:'神仕 / 獣',piece:'神仕（シンシ）：獣',desc:'獣。アウデが依代となって生まれた兵器。砲塔を積んでいる。',whiteAsset:'assets/pieces/master_divine_beast_white.png',blackAsset:'assets/pieces/master_divine_beast_black.png',rangeKey:'神仕',external:'database/yorishiro/aude.jpg',person:'アウデ',personTitle:'救世主',quote:'あなたが世界を救ったのね！'),
    _MasterDbItem(title:'飛空城',piece:'飛空城（ヒクウジョウ）',desc:'アンナとリーンが依代となって動く要塞。',whiteAsset:'assets/pieces/master_air_white.png',blackAsset:'assets/pieces/master_air_black.png',rangeKey:'飛空城',external:'database/yorishiro/anna_leen.jpg',person:'アンナとリーン',personTitle:'白の実験兵器',quote:'どっちでも同じじゃない。'),
    _MasterDbItem(title:'円盤型飛空城',piece:'円盤型飛空城（エンバンガタヒクウジョウ）',desc:'カーリーが依代となって動く要塞。',whiteAsset:'assets/pieces/master_air_disc_white.png',blackAsset:'assets/pieces/master_air_disc_black.png',rangeKey:'円盤型飛空城',external:'database/yorishiro/carly.jpg',person:'カーリー',personTitle:'約束の門',quote:'終わりなんてないわ。'),
    _MasterDbItem(title:'三角型飛空城',piece:'三角型飛空城（サンカクガタヒクウジョウ）',desc:'ララが依代となって動く要塞。',whiteAsset:'assets/pieces/master_air_triangle_white.png',blackAsset:'assets/pieces/master_air_triangle_black.png',rangeKey:'三角型飛空城',external:'database/yorishiro/lala.jpg',person:'ララ',personTitle:'裏切りの門',quote:'永遠にお別れね。'),
    _MasterDbItem(title:'生命の像',piece:'生命の像（セイメイノゾウ）',desc:'悲しき運命を背負う少女、コードネーム1が依代となって発動した最終兵器。飛空城と連動し、核を超えた復活能力を発揮する。',whiteAsset:'assets/pieces/master_life_white.png',blackAsset:'assets/pieces/master_life_black.png',rangeKey:'生命の像',external:'database/yorishiro/codename1.jpg',person:'コードネーム1',personTitle:'救世主',quote:'あなたは、私だわ。'),
  ];

  List<List<int>> _lv(String key,int lv){if(lv==3)return _BoardScreenState.lv3MoveOffsets[key]??_BoardScreenState.lv2MoveOffsets[key]??_BoardScreenState.lv1MoveOffsets[key]??const[];if(lv==2)return _BoardScreenState.lv2MoveOffsets[key]??_BoardScreenState.lv1MoveOffsets[key]??const[];return _BoardScreenState.lv1MoveOffsets[key]??const[];}
  List<List<int>> _combinedRange(List<List<int>> a,List<List<int>> b){
    final out=<String,List<int>>{for(final o in a)'${o[0]},${o[1]}':o};
    for(final o in b)out['${o[0]},${o[1]}']=o;
    return out.values.toList(growable:false);
  }
  Widget _ranges(_MasterDbItem x){
    if(x.rangeKey=='神仕')return Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_RangeMini('通常',_BoardScreenState.lv1MoveOffsets['兵']!),const _RangeMini('合流',_BoardScreenState.mergedSoldierOffsets),const _RangeMini('前線',_BoardScreenState.frontlineSoldierOffsets)]);
    if(const {'飛空城','円盤型飛空城','三角型飛空城'}.contains(x.rangeKey)){
      final base=_BoardScreenState.lv1MoveOffsets[x.rangeKey]??const <List<int>>[];
      return Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[
        _RangeMini('通常',base),
        _RangeMini('合流',_combinedRange(base,_BoardScreenState.mergedSoldierOffsets)),
        _RangeMini('前線',_combinedRange(base,_BoardScreenState.frontlineSoldierOffsets)),
      ]);
    }
    if(const {'王','騎','帝'}.contains(x.rangeKey))return Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_RangeMini('Lv1',_lv(x.rangeKey,1)),_RangeMini('Lv2',_lv(x.rangeKey,2)),_RangeMini('Lv3',_lv(x.rangeKey,3))]);
    return Center(child:_RangeMini('固定',_BoardScreenState.lv1MoveOffsets[x.rangeKey]??const[]));
  }
  Future<void> _open(BuildContext context,_MasterDbItem x) async {
    File? f;if(x.external!=null)f=await _AdditionalData.asset(x.external!);if(!context.mounted)return;
    Navigator.push(context,MaterialPageRoute(builder:(_)=>Scaffold(appBar:AppBar(leading:_easyBackButton(context),title:Text(x.title)),body:ListView(padding:const EdgeInsets.all(18),children:[
      Center(child:_DbFlipPiece(x.whiteAsset,x.blackAsset)),const SizedBox(height:14),Text(x.piece,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(x.desc,style:const TextStyle(height:1.6)),
      if(x.title=='騎')...const [SizedBox(height:24),_MasterKnightFormsDatabase()],
      if(x.pilotAsset!=null)...[const SizedBox(height:20),Center(child:Image.asset(x.pilotAsset!,height:220,fit:BoxFit.contain))] else if(f?.existsSync()??false)...[const SizedBox(height:20),Center(child:Image.file(f!,height:220,fit:BoxFit.contain))],
      if(x.person!=null)...[const SizedBox(height:12),Text('【${x.personTitle}】',textAlign:TextAlign.center),Text(x.person!,textAlign:TextAlign.center,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),Text('「${x.quote}」',textAlign:TextAlign.center)],
      const SizedBox(height:24),const Text('行動範囲',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:12),_ranges(x),
    ]))));
  }
  void _openKuru(BuildContext context)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Scaffold(
    appBar:AppBar(leading:_easyBackButton(context)),
    body:ListView(
      padding:const EdgeInsets.all(24),
      children:[
        Center(child:Image.asset('assets/pilots/kuru.webp',height:330,fit:BoxFit.contain)),
        const SizedBox(height:18),
        const Text('【最後の騎士】',textAlign:TextAlign.center,style:TextStyle(fontSize:18,fontWeight:FontWeight.w700)),
        const SizedBox(height:6),
        const Text('クル',textAlign:TextAlign.center,style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:2)),
        const SizedBox(height:10),
        const Text('Unknown',textAlign:TextAlign.center,style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:2)),
      ],
    ),
  )));
  @override Widget build(BuildContext context){
    final masters=_items.take(3);final servants=_items.skip(3).take(2);final airs=_items.skip(5).take(3);final life=_items.last;
    Widget tile(_MasterDbItem x)=>ListTile(leading:Image.asset(x.whiteAsset,width:52,height:52,fit:BoxFit.contain),title:Text(x.title),subtitle:Text(x.desc,maxLines:2,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right),onTap:_withUiTap(()=>_open(context,x)));
    return Scaffold(appBar:AppBar(leading:_easyBackButton(context),title:const Text('UNIT / MASTER')),body:ListView(children:[
      ...masters.map(tile),...servants.map(tile),
      Container(
        color:Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.22),
        child:Column(children:[
          const Padding(padding:EdgeInsets.fromLTRB(18,22,18,6),child:Align(alignment:Alignment.centerLeft,child:Text('飛空城',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)))),
          const Padding(padding:EdgeInsets.fromLTRB(18,0,18,10),child:Text(_airNote,style:TextStyle(height:1.6))),
          ...airs.map(tile),
        ]),
      ),
      tile(life),
      if (_HiddenUnlocks.kuru) ListTile(title:const Text('クル'),trailing:const Icon(Icons.chevron_right),onTap:_withUiTap(()=>_openKuru(context))),
    ]));
  }
}

class SoundtrackDatabaseScreen extends StatefulWidget {
  const SoundtrackDatabaseScreen({super.key});
  @override State<SoundtrackDatabaseScreen> createState() => _SoundtrackDatabaseScreenState();
}

class _SoundtrackDatabaseScreenState extends State<SoundtrackDatabaseScreen> {
  final AudioPlayer _player = AudioPlayer();
  String? _playing;
  static const _baseTracks = <(String, String)>[
    ('Dawn After the War', 'audio/1Dawn After the War (Remastered).m4a'),
    ('War Room Protocol', 'audio/2War Room Protocol.mp3'),
    ('Unit Lockdown', 'audio/3Unit Lockdown.m4a'),
    ('Unit Deployment', 'audio/4Unit Deployment.mp3'),
    ('Overdriven Riffs', 'audio/5Overdriven Riffs.m4a'),
    ('Target Lock', 'audio/6Target Lock.m4a'),
    ('Target Lock2', 'audio/7Target Lock2.m4a'),
    ("Commander's Gambit", "audio/8Commander's Gambit.m4a"),
    ('Heavy Metal Strategy', 'audio/9Heavy Metal Strategy.m4a'),
    ('Tactical Velocity', 'audio/10Tactical Velocity.m4a'),
    ('Doubt', 'audio/11Doubt.mp3 （リミックス） (Remastered).m4a'),
    ('Final Tactical Maneuver', 'audio/12Final Tactical Maneuver.m4a'),
    ('Tactical Aftermathematical End', 'audio/13Tactical Aftermathematical End.m4a'),
  ];
  List<(String, String)> get _tracks => [
    ..._baseTracks,
    if (_StoryProgress.isChapter2Unlocked(14)) ('STREET FLOWER', 'audio/STREET FLOWER.mp3'),
  ];
  Future<void> _play(String title, String asset) async {
    await _AppBgm.stop();
    await _player.stop();
    final f = await _AdditionalData.asset(asset);
    await _player.play(DeviceFileSource(f.path), volume: _AudioSettings.bgm);
    if (mounted) setState(() => _playing = title);
  }
  @override void dispose() { _player.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('DATABASE / SOUNDTRACK'), leading: _easyBackButton(context, onPressed: () { _player.stop(); _AppBgm.play('audio/2War Room Protocol.mp3'); Navigator.of(context).pop(); })),
    body: ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 12),
      itemCount: _tracks.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final t = _tracks[i];
        return ListTile(
          title: Text(t.$1),
          trailing: Icon(_playing == t.$1 ? Icons.stop_circle_outlined : Icons.play_circle_outline),
          onTap: () async {
            if (_playing == t.$1) { await _player.stop(); if (mounted) setState(() => _playing = null); }
            else { await _play(t.$1, t.$2); }
          },
        );
      },
    ),
  );
}


class _GoryuUnlockSequence extends StatefulWidget {
  final bool isWhite;
  final bool battleAwakening;
  const _GoryuUnlockSequence({required this.isWhite, this.battleAwakening = false});
  @override
  State<_GoryuUnlockSequence> createState() => _GoryuUnlockSequenceState();
}

class _GoryuUnlockSequenceState extends State<_GoryuUnlockSequence> with TickerProviderStateMixin {
  final AudioPlayer _sfx = AudioPlayer();
  int _phase = 0;
  int _pulse = 0;
  String _typed = '';
  bool _flash = false;
  bool _goryuFlash = false;
  int _mixStep = 0;
  bool _done = false;
  Timer? _timer;
  final String _line = '刀勢……！';

  String get _side => widget.isWhite ? 'white' : 'black';
  String get _officer => 'assets/pieces/${_side}_officer.png';
  String get _goryu => 'assets/pieces/${_side}_goryu.webp';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  Future<void> _play(String asset) async {
    try { await _sfx.play(AssetSource(asset), volume: _AudioSettings.se); } catch (_) {}
  }

  Future<void> _run() async {
    await Future<void>.delayed(const Duration(milliseconds: 650));
    if (!mounted) return;
    setState(() => _phase = 1); // 刀勢
    for (var i = 0; i < 5; i++) {
      if (i == 0) _play('audio/se_goryu_drive.ogg');
      if (!mounted) return;
      setState(() => _pulse++);
      await Future<void>.delayed(const Duration(milliseconds: 420));
    }
    if (!mounted) return;
    setState(() => _phase = 2); // ギル
    _play('audio/se_type.wav');
    for (var i = 1; i <= _line.length; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 105));
      if (!mounted) return;
      setState(() => _typed = _line.substring(0, i));
    }
    await Future<void>.delayed(const Duration(milliseconds: 850));
    if (!mounted) return;
    setState(() { _phase = 3; _pulse = 0; _mixStep = 0; _goryuFlash = false; }); // 変貌
    // 低い駆動音を土台に、刀勢の点滅ごとに軍のシルエットを一瞬だけ混ぜる。
    // 後半ほど軍が画面を占める時間を長くして、刀勢→軍へ侵食していく。
    _play('audio/se_goryu_drive.ogg');
    const officerHold = [300, 280, 250, 220, 180];
    const armyFlash = [110, 150, 200, 260, 340];
    for (var i = 0; i < 5; i++) {
      if (!mounted) return;
      setState(() { _mixStep = i + 1; _pulse++; _goryuFlash = false; });
      await Future<void>.delayed(Duration(milliseconds: officerHold[i]));
      if (!mounted) return;
      // 刀勢の点滅の瞬間だけ軍の輪郭が割り込む。回を追うごとに軍が濃く・長くなる。
      setState(() { _pulse++; _goryuFlash = true; });
      if (i == 2 || i == 4) _play('audio/se_goryu_metal.ogg');
      await Future<void>.delayed(Duration(milliseconds: armyFlash[i]));
    }
    if (!mounted) return;
    setState(() => _goryuFlash = true);
    if (!mounted) return;
    // A short dead-stop before the reveal gives the final impact room to land.
    await Future<void>.delayed(const Duration(milliseconds: 260));
    if (!mounted) return;
    _play('audio/se_goryu_impact.ogg');
    setState(() { _flash = true; _phase = 4; });
    await Future<void>.delayed(const Duration(milliseconds: 180));
    if (!mounted) return;
    setState(() => _flash = false);
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    if (widget.battleAwakening) {
      Navigator.of(context).pop();
      return;
    }
    setState(() => _phase = 5);
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    setState(() => _done = true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _sfx.dispose();
    super.dispose();
  }

  Widget _machineImage(String asset, {double opacity = 1, bool silhouette = false}) {
    Widget image = Image.asset(asset, fit: BoxFit.contain);
    if (silhouette) {
      image = ColorFiltered(
        colorFilter: const ColorFilter.mode(Color(0xFFD9DDE2), BlendMode.srcIn),
        child: image,
      );
    }
    return Opacity(opacity: opacity.clamp(0.0, 1.0), child: image);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final goryuMix = _phase == 3 ? (_mixStep / 5.0).clamp(0.12, 1.0) : 0.0;
    final flicker = _pulse.isEven ? 1.0 : 0.48;
    return Dialog.fullscreen(
      backgroundColor: Colors.black,
      child: Stack(children: [
        Positioned.fill(child: Container(color: Colors.black)),
        if (_phase == 1 || _phase == 3)
          Positioned.fill(child: Opacity(
            opacity: .14,
            child: CustomPaint(painter: _UnlockScanlinePainter()),
          )),
        Center(child: SizedBox(
          width: math.min(size.width * .88, 560),
          height: math.min(size.height * .64, 650),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: _phase == 0 ? const SizedBox.shrink()
              : _phase == 2 ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Image.asset('assets/pilots/officer.webp', height: math.min(size.height * .34, 300)),
                  const SizedBox(height: 22),
                  const Text('ギル・ターク', style: TextStyle(color: Colors.white70, fontSize: 16, letterSpacing: 2)),
                  const SizedBox(height: 10),
                  Text(_typed, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w700)),
                ])
              : _phase == 3 ? Stack(alignment: Alignment.center, children: [
                  // 刀勢が崩れ、豪竜の輪郭が段階的に食い込んでくる。
                  Transform.translate(
                    offset: Offset((_pulse % 3 - 1) * (3.0 + goryuMix * 5.0), ((_pulse + 1) % 3 - 1) * (2.0 + goryuMix * 3.0)),
                    child: Transform.scale(
                      scale: 1.0 + goryuMix * .025,
                      child: _machineImage(_officer, opacity: _goryuFlash ? (1.0 - goryuMix * .72) : 1.0),
                    ),
                  ),
                  if (_goryuFlash) Transform.scale(
                    scale: .88 + goryuMix * .16,
                    child: _machineImage(_goryu, opacity: (.48 + goryuMix * .52)),
                  ),
                  if (_pulse >= 7)
                    Container(
                      width: 210 + goryuMix * 100, height: 210 + goryuMix * 100,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.10 + goryuMix * .22), width: 2.0)),
                    ),
                ])
              : _machineImage(_phase >= 4 ? _goryu : _officer, opacity: _phase == 1 ? flicker : 1),
          ),
        )),
        if (_phase >= 5)
          Positioned(left: 24, right: 24, bottom: 64, child: Column(children: [
            const Text('HIDDEN UNIT UNLOCKED', textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 16, letterSpacing: 3.4, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            const Text('軍', style: TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w900, letterSpacing: 12)),
            const SizedBox(height: 22),
            AnimatedOpacity(opacity: _done ? 1 : 0, duration: const Duration(milliseconds: 350), child:
              TextButton(onPressed: _done ? () => Navigator.of(context).pop() : null,
                child: const Text('CONTINUE', style: TextStyle(letterSpacing: 2.2)))),
          ])),
        if (_flash) Positioned.fill(child: Container(color: Colors.white)),
      ]),
    );
  }
}


class _GoryuBirthFinishSequence extends StatefulWidget {
  final bool isWhite;
  final VoidCallback onWhiteout;
  const _GoryuBirthFinishSequence({required this.isWhite, required this.onWhiteout});
  @override
  State<_GoryuBirthFinishSequence> createState() => _GoryuBirthFinishSequenceState();
}

class _GoryuBirthFinishSequenceState extends State<_GoryuBirthFinishSequence> with SingleTickerProviderStateMixin {
  final AudioPlayer _sfx = AudioPlayer();
  late final AnimationController _light;
  bool _roaring = false;
  String get _asset => 'assets/pieces/${widget.isWhite ? 'white' : 'black'}_goryu.webp';

  @override
  void initState() {
    super.initState();
    _light = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    WidgetsBinding.instance.addPostFrameCallback((_) => _run());
  }

  Future<void> _run() async {
    await Future<void>.delayed(const Duration(milliseconds: 420));
    if (!mounted) return;
    setState(() => _roaring = true);
    try { await _sfx.play(AssetSource('audio/se_goryu_roar.ogg'), volume: _AudioSettings.se); } catch (_) {}
    await Future<void>.delayed(const Duration(milliseconds: 520));
    if (!mounted) return;
    await _light.forward();
    // 白光が盤面を完全に飲み込んだ瞬間から、背後の戦闘画面も白で固定する。
    // ダイアログを閉じても盤面を1フレームも再表示せず、そのままVICTORYへ繋ぐ。
    widget.onWhiteout();
    await Future<void>.delayed(const Duration(milliseconds: 260));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() { _light.dispose(); _sfx.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Dialog.fullscreen(
    backgroundColor: Colors.transparent,
    child: AnimatedBuilder(
      animation: _light,
      builder: (_, __) {
        final t = Curves.easeInCubic.transform(_light.value);
        return Stack(children: [
          Positioned.fill(child: Container(color: Colors.black.withOpacity(.18 * (1 - t)))),
          Center(child: Transform.scale(
            scale: 1.0 + (_roaring ? .035 : 0) + t * .08,
            child: Image.asset(_asset, width: math.min(MediaQuery.sizeOf(context).width * .68, 420)),
          )),
          if (_roaring) Center(child: Container(
            width: 120 + t * MediaQuery.sizeOf(context).longestSide * 2.4,
            height: 120 + t * MediaQuery.sizeOf(context).longestSide * 2.4,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(t.clamp(0.0, 1.0)),
              boxShadow: [BoxShadow(color: Colors.white.withOpacity(.75 * t), blurRadius: 55 + 90 * t, spreadRadius: 25 + 80 * t)],
            ),
          )),
          if (t > .72) Positioned.fill(child: Container(color: Colors.white.withOpacity(((t - .72) / .28).clamp(0.0, 1.0)))),
        ]);
      },
    ),
  );
}

class _UnlockScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = Colors.white;
    for (double y = 0; y < size.height; y += 7) canvas.drawRect(Rect.fromLTWH(0, y, size.width, 1), p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}


// Post-battle navigation is shared by all result screens. The previous match
// routes are removed so replay always starts with a fresh INITIATIVE flow.
void _openPostBattleDestination(BuildContext context, {required BattleMode mode, required bool rematch, bool searchAgain = false}) {
  final navigator = Navigator.of(context);
  if (!rematch && !searchAgain) {
    navigator.pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const MainMenuScreen()),
      (route) => route.isFirst,
    );
    return;
  }
  // Keep MAIN MENU beneath BATTLE, so cancelling a new opponent search
  // and pressing back from BATTLE returns to MAIN MENU instead of TITLE.
  navigator.pushAndRemoveUntil(
    MaterialPageRoute<void>(builder: (_) => const MainMenuScreen()),
    (route) => route.isFirst,
  );
  navigator.push(MaterialPageRoute<void>(builder: (_) => const BattleMenuScreen()));
  final Widget entry;
  if (mode == BattleMode.local) {
    entry = const LocalJankenResultScreen();
  } else if (mode == BattleMode.onlineTest && searchAgain) {
    entry = const OnlineMatchingScreen();
  } else {
    // Replaying the same CPU opponent uses the existing difficulty setting.
    entry = JankenScreen(mode: mode);
  }
  navigator.push(MaterialPageRoute<void>(builder: (_) => entry));
}

// Shared result intro. Keep the actual post-battle UI and its BGM unmounted
// until the intro finishes; online rematch time starts after this callback.
class _ResultSoundAndIntro extends StatefulWidget {
  const _ResultSoundAndIntro({required this.won, required this.child,
    required this.winnerLabel, this.skipIntro = false, this.onIntroFinished,
    this.showWinnerProfile = false, this.cpuWon = false});
  final bool won;
  final bool skipIntro;
  final String winnerLabel;
  final bool showWinnerProfile;
  final bool cpuWon;
  final Widget child;
  final VoidCallback? onIntroFinished;

  @override
  State<_ResultSoundAndIntro> createState() => _ResultSoundAndIntroState();
}

class _ResultSoundAndIntroState extends State<_ResultSoundAndIntro>
    with SingleTickerProviderStateMixin {
  static const Duration _length = Duration(milliseconds: 7632);
  final AudioPlayer _fanfare = AudioPlayer();
  late final AnimationController _animation;
  bool _finished = false;
  _LocalPlayerProfile? _winnerProfile;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(vsync: this, duration: _length);
    if (widget.showWinnerProfile && !widget.cpuWon) {
      _LocalPlayerProfile.load().then((p) {
        if (mounted) setState(() => _winnerProfile = p);
      });
    }
    if (widget.skipIntro) {
      _finished = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) widget.onIntroFinished?.call();
      });
    } else {
      _animation.addStatusListener((status) {
        if (status == AnimationStatus.completed && mounted) {
          setState(() => _finished = true);
          widget.onIntroFinished?.call();
        }
      });
      _animation.forward();
      unawaited(_startSound());
    }
  }

  Future<void> _startSound() async {
    // Both results pause the battle music; play the matching result jingle.
    await _AppBgm.stop();
    if (!mounted) return;
    try {
      await _fanfare.setAudioContext(AudioContext(
        android: const AudioContextAndroid(
          contentType: AndroidContentType.music,
          usageType: AndroidUsageType.game,
          audioFocus: AndroidAudioFocus.none,
        ),
        iOS: AudioContextIOS(
          category: AVAudioSessionCategory.ambient,
          options: const {AVAudioSessionOptions.mixWithOthers},
        ),
      ));
      await _fanfare.setReleaseMode(ReleaseMode.stop);
      if (mounted) {
        await _fanfare.play(AssetSource(
          widget.won ? 'audio/Zaamd_Victory.mp3' : 'audio/Zaamd_Lose.mp3',
        ), volume: _AudioSettings.bgm);
      }
    } catch (_) { /* Audio failure must never block results. */ }
  }

  @override
  void dispose() {
    _animation.dispose();
    unawaited(_fanfare.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Re-create the original result soundtrack after the intro, not before it.
    if (_finished) {
      return _ScreenBgm(
        asset: 'audio/13Tactical Aftermathematical End.m4a',
        child: widget.child,
      );
    }
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, _) {
        final progress = _animation.value;
        final elapsed = progress * 7.632;
        // Explicit, visible motion throughout the seven-second intro.
        // Both outcomes still share the original timer and audio lifecycle.
        double phase(double startAt, double duration) =>
            ((elapsed - startAt) / duration).clamp(0.0, 1.0).toDouble();
        final crownEnter = Curves.easeOutBack.transform(phase(0.10, 1.25));
        final victoryEnter = Curves.easeOutCubic.transform(phase(0.65, 1.30));
        // Two broad shimmer passes, ensuring this is not a frozen title card.
        final shimmerA = phase(1.75, 1.45);
        final shimmerB = phase(4.15, 1.50);
        final shimmer = elapsed < 3.45 ? shimmerA : shimmerB;
        final movingX = -1.2 + 2.4 * shimmer;
        final glow = (0.5 + 0.5 * math.sin(elapsed * 3.1));
        final double loseDrop = Curves.bounceOut.transform(phase(0.05, 1.85));
        final goldText = ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (bounds) => LinearGradient(
            begin: Alignment(movingX - 0.85, -0.2),
            end: Alignment(movingX + 0.85, 0.2),
            colors: const [
              Color(0xff947340), Color(0xffccac65),
              Color(0xfffffff1), Color(0xfff7d991), Color(0xff987344),
            ],
            stops: const [0.0, 0.32, 0.48, 0.60, 1.0],
          ).createShader(bounds),
          child: Text('VICTORY', style: TextStyle(
            color: Colors.white, fontSize: 44,
            fontWeight: FontWeight.w900, letterSpacing: 4,
            shadows: [Shadow(
              color: const Color(0xffd1a656).withOpacity(0.35 + glow * 0.4),
              blurRadius: 12 + glow * 24,
            )],
          )),
        );
        final quoteChoices = _availableProfileQuotes();
        final selectedQuote = quoteChoices
            .where((q) => q.id == _winnerProfile?.quoteId)
            .map((q) => q.line).firstOrNull;
        final winnerName = widget.cpuWon
            ? 'CPU（通信テスト）'
            : (_winnerProfile?.name ?? 'PLAYER');
        final winnerIcon = widget.cpuWon
            ? 'assets/profile/arts.webp'
            : _LocalPlayerProfile.image(_winnerProfile?.icon ?? 'arts');
        if (!widget.won) {
          return ColoredBox(color: const Color(0xff111016), child: Stack(fit: StackFit.expand, children: [
            Center(child: Transform.translate(offset: Offset(0, -MediaQuery.sizeOf(context).height * (1 - loseDrop)),
              child: const Text('LOSE', style: TextStyle(color: Colors.white54, fontSize: 48, fontWeight: FontWeight.w900, letterSpacing: 4)))),
            if (widget.showWinnerProfile) Center(child: Transform.translate(
              offset: const Offset(0, 96),
              child: Opacity(opacity: phase(2.3, 0.7), child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(width: 86, height: 86, child: _LocalPlayerProfile.portrait(winnerIcon)),
                  const SizedBox(width: 12), Flexible(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(winnerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('「${widget.cpuWon ? 'そこだ！！' : (selectedQuote ?? '')}」', maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 15)),
                  ])),
                ]),
              )),
            )),
          ]));
        }
        return ColoredBox(
          color: const Color(0xff111016),
          child: SafeArea(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Opacity(
                    opacity: phase(0.05, 0.65) * (0.52 + 0.32 * glow),
                    child: Container(
                      height: 26,
                      width: 120 + 60 * glow,
                      decoration: BoxDecoration(
                        gradient: RadialGradient(colors: [
                          const Color(0xffffe6a8).withOpacity(0.65),
                          const Color(0xffdfb95c).withOpacity(0.10),
                          Colors.transparent,
                        ]),
                      ),
                    ),
                  ),
                  Opacity(
                    opacity: phase(0.10, 0.75),
                    child: Transform.scale(
                      scale: 0.55 + 0.45 * crownEnter + 0.025 * glow,
                      child: Text('♛', style: TextStyle(
                        fontSize: 68, color: const Color(0xfff1d387),
                        shadows: [Shadow(
                          blurRadius: 12 + glow * 28,
                          color: const Color(0xffe7b95d),
                        )],
                      )),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Opacity(
                    opacity: phase(0.65, 0.65),
                    child: Transform.scale(
                      scale: 0.6 + 0.4 * victoryEnter,
                      child: goldText,
                    ),
                  ),
                  if (widget.showWinnerProfile) ...[
                    const SizedBox(height: 22),
                    Opacity(
                      opacity: phase(2.3, 0.7),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 22),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 86, height: 86,
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: const Color(0xffe5bf72), width: 2),
                              ),
                              child: _LocalPlayerProfile.portrait(winnerIcon),
                            ),
                            const SizedBox(width: 12),
                            Flexible(child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(winnerName, maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                                if (!widget.cpuWon && selectedQuote != null) ...[
                                  const SizedBox(height: 8),
                                  Text('「$selectedQuote」', maxLines: 3, overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 15, color: Colors.white)),
                                ],
                              ],
                            )),
                          ],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class LocalBattleResultScreen extends StatelessWidget {
  final bool winnerIsWhite;
  final bool showCrownVictory;
  const LocalBattleResultScreen({
    super.key,
    required this.winnerIsWhite,
    this.showCrownVictory = true,
  });

  @override
  Widget build(BuildContext context) => Scaffold(
        body: _ResultSoundAndIntro(
          won: true,
          winnerLabel: winnerIsWhite ? 'WHITE WINS' : 'BLACK WINS',
          child: SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('VICTORY', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, letterSpacing: 3)),
                    const SizedBox(height: 12),
                    Text(winnerIsWhite ? 'WHITE' : 'BLACK', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 2.4)),
                    if (showCrownVictory) ...[
                      const SizedBox(height: 14),
                      const Text('♛ × 3', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                    ],
                    const SizedBox(height: 34),
                    FilledButton(onPressed: _withUiTap(() => _openPostBattleDestination(context, mode: BattleMode.local, rematch: true)), child: const Text('再戦')),
                    const SizedBox(height: 12),
                    OutlinedButton(onPressed: _withUiTap(() => _openPostBattleDestination(context, mode: BattleMode.local, rematch: false)), child: const Text('メインメニューへ戻る')),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class BattleResultScreen extends StatefulWidget {
  final bool playerWon;
  final bool showCrownVictory;
  final BattleUnit? playerUnit;
  final BattleMode mode;
  final String? onlineCompletionId;
  final int testRanged, testMelee, testCapture;
  final bool testGoryu;
  final bool normalCompletion;
  const BattleResultScreen({
    super.key,
    required this.playerWon,
    this.playerUnit,
    this.showCrownVictory = true,
    this.mode = BattleMode.cpu,
    this.onlineCompletionId,
    this.testRanged = 0, this.testMelee = 0, this.testCapture = 0, this.testGoryu = false,
    this.normalCompletion = false,
  });

  @override
  State<BattleResultScreen> createState() => _BattleResultScreenState();
}

class _BattleResultScreenState extends State<BattleResultScreen> {
  late final bool _showGoryuVictoryNotice;
  bool _progressHandled = false;
  bool _progressReady = false;
  bool _postBattleSequenceShown = false;
  bool _masterPieceAcquiredThisWin = false;
  bool _masterUnlockedThisWin = false;
  Timer? _rematchTimer;
  int _rematchSecondsLeft = 10;
  bool _onlineRematchDeclined = false;

  @override
  void initState() {
    super.initState();
    _showGoryuVictoryNotice = _HiddenUnlocks.pendingGoryuVictoryNotice;
    _HiddenUnlocks.pendingGoryuVictoryNotice = false;
    if (_HiddenUnlocks.pendingGoryuReveal) {
      _HiddenUnlocks.pendingGoryuReveal = false;
      WidgetsBinding.instance.addPostFrameCallback((_) => _showGoryuReveal());
    }
    if (widget.mode == BattleMode.onlineTest && widget.onlineCompletionId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _recordOnlineBattleProgress());
    }
    if (widget.mode == BattleMode.cpu && widget.normalCompletion) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _recordPracticeProgress());
    } else if (widget.mode != BattleMode.onlineTest) {
      _progressReady = true;
    }
  }

  void _beginRematchTimer() {
    if (!mounted || widget.mode != BattleMode.onlineTest ||
        _onlineRematchDeclined || _rematchTimer != null) return;
    _rematchTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _onlineRematchDeclined || _postBattleSequenceShown) {
        timer.cancel();
        return;
      }
      if (_rematchSecondsLeft <= 1) {
        timer.cancel();
        setState(() { _rematchSecondsLeft = 0; _onlineRematchDeclined = true; });
      } else {
        setState(() => _rematchSecondsLeft--);
      }
    });
  }

  @override
  void dispose() {
    _rematchTimer?.cancel();
    super.dispose();
  }

  Future<void> _recordPracticeProgress() async {
    await _StoryProgress.recordPracticeCompleted();
    _progressReady = true;
  }

  Future<void> _recordOnlineBattleProgress() async {
    final battleId = widget.onlineCompletionId;
    if (battleId == null) { _progressReady = true; return; }
    final chapter2WasActive = _StoryProgress.isChapter2Unlocked(1);
    final chapter1WasComplete = _StoryProgress.isUnlocked(12);
    final newlyCounted = await _RearLineProgress.recordOnlineBattleCompletedOnce(battleId);
    if (!newlyCounted) { _progressReady = true; return; }
    await _CompetitiveProfile.recordTestMatch(widget.playerWon, widget.playerUnit, widget.testRanged, widget.testMelee, widget.testCapture, widget.testGoryu);
    await _StoryProgress.recordNormalOnlineCompleted();
    if (widget.playerWon && widget.playerUnit != null) {
      await _handleProgress(allowChapter2Progress: chapter2WasActive, allowChapter2Start: chapter1WasComplete);
    } else {
      _progressReady = true;
    }
  }

  Future<void> _handleProgress({required bool allowChapter2Progress, required bool allowChapter2Start}) async {
    if (_progressHandled) return; _progressHandled = true;
    final before = _MasterProgress.wins(widget.playerUnit!);
    await _MasterProgress.recordWin(widget.playerUnit!);
    final unlocked = await _StoryProgress.recordOnlineWin(allowChapter2Progress: allowChapter2Progress, allowChapter2Start: allowChapter2Start);
    if (!mounted) return;
    final required = _MasterProgress.souvenirWinsRequired;
    _masterPieceAcquiredThisWin = before < required && _MasterProgress.wins(widget.playerUnit!) == required &&
        (widget.playerUnit == BattleUnit.king || widget.playerUnit == BattleUnit.knight || widget.playerUnit == BattleUnit.emperor);
    _masterUnlockedThisWin = unlocked;
    _progressReady = true;
  }

  Future<void> _exitResult({required bool rematch, bool searchAgain = false}) async {
    if (_postBattleSequenceShown) return;
    _postBattleSequenceShown = true;
    _rematchTimer?.cancel();
    // Never skip an earned unlock or record when leaving the result screen.
    while (((widget.mode == BattleMode.onlineTest && widget.onlineCompletionId != null) || (widget.mode == BattleMode.cpu && widget.normalCompletion)) && !_progressReady && mounted) {
      await Future<void>.delayed(const Duration(milliseconds: 20));
    }
    if (!mounted) return;
    if (_masterUnlockedThisWin) {
      await showDialog<void>(context: context, barrierDismissible: false, builder: (c) => AlertDialog(
        title: const Text('ENDING', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        content: const Text('DATABASE に追加されました。'),
        actions: [FilledButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))],
      ));
    }
    if (!mounted) return;
    _openPostBattleDestination(context, mode: widget.mode, rematch: rematch, searchAgain: searchAgain);
  }

  Future<void> _showGoryuReveal() async {
    if (!mounted) return;
    final isWhite = _HiddenUnlocks.pendingGoryuIsWhite;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black,
      builder: (_) => _GoryuUnlockSequence(isWhite: isWhite),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: _ResultSoundAndIntro(
          won: widget.playerWon,
          showWinnerProfile: widget.mode == BattleMode.onlineTest,
          cpuWon: widget.mode == BattleMode.onlineTest && !widget.playerWon,
          skipIntro: _showGoryuVictoryNotice,
          winnerLabel: widget.playerWon ? 'VICTORY' : 'LOSE',
          onIntroFinished: _beginRematchTimer,
          child: SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(widget.playerWon ? 'VICTORY' : 'LOSE', style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w900, letterSpacing: 3)),
                    if (widget.showCrownVictory) ...[
                      const SizedBox(height: 14),
                      const Text('♛ × 3', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                    ],
                    const SizedBox(height: 34),
                    if (widget.mode == BattleMode.onlineTest) ...[
                      if (!_onlineRematchDeclined) ...[
                        Text('再戦しますか？  $_rematchSecondsLeft', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 16),
                        FilledButton(onPressed: _postBattleSequenceShown ? null : _withUiTap(() => _exitResult(rematch: true)), child: const Text('YES')),
                        const SizedBox(height: 12),
                        OutlinedButton(onPressed: _postBattleSequenceShown ? null : () { _rematchTimer?.cancel(); setState(() => _onlineRematchDeclined = true); }, child: const Text('NO')),
                      ] else ...[
                        FilledButton(onPressed: _postBattleSequenceShown ? null : _withUiTap(() => _exitResult(rematch: false, searchAgain: true)), child: const Text('別の相手を探す')),
                        const SizedBox(height: 12),
                        OutlinedButton(onPressed: _postBattleSequenceShown ? null : _withUiTap(() => _exitResult(rematch: false)), child: const Text('メインメニューへ戻る')),
                      ],
                    ] else ...[
                      FilledButton(onPressed: _postBattleSequenceShown ? null : _withUiTap(() => _exitResult(rematch: true)), child: const Text('再戦')),
                      const SizedBox(height: 12),
                      OutlinedButton(onPressed: _postBattleSequenceShown ? null : _withUiTap(() => _exitResult(rematch: false)), child: const Text('メインメニューへ戻る')),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class Piece {
  final String asset;
  final String label;
  final bool major;
  final bool isWhite;
  final bool originalIsWhite;
  final bool captured;
  final int level;
  final String? pilotId;
  const Piece(
    this.asset,
    this.label, {
    this.major = false,
    required this.isWhite,
    bool? originalIsWhite,
    this.captured = false,
    this.level = 1,
    this.pilotId,
  }) : originalIsWhite = originalIsWhite ?? isWhite;

  Piece copyWith({
    String? asset,
    String? label,
    bool? major,
    bool? isWhite,
    bool? originalIsWhite,
    bool? captured,
    int? level,
    String? pilotId,
    bool clearPilot = false,
  }) {
    return Piece(
      asset ?? this.asset,
      label ?? this.label,
      major: major ?? this.major,
      isWhite: isWhite ?? this.isWhite,
      originalIsWhite: originalIsWhite ?? this.originalIsWhite,
      captured: captured ?? this.captured,
      level: level ?? this.level,
      pilotId: clearPilot ? null : (pilotId ?? this.pilotId),
    );
  }
}

class BoardScreen extends StatefulWidget {
  final Map<int, Piece> initialPieces;
  final bool playerIsWhite;
  final BattleUnit whiteUnit;
  final BattleUnit blackUnit;
  final bool localBattle;
  final bool trainingMode;
  final BattleMode battleMode;
  const BoardScreen({
    super.key,
    required this.initialPieces,
    required this.playerIsWhite,
    required this.whiteUnit,
    required this.blackUnit,
    this.localBattle = false,
    this.trainingMode = false,
    this.battleMode = BattleMode.cpu,
  });

  @override
  State<BoardScreen> createState() => _BoardScreenState();
}

class _BoardScreenState extends State<BoardScreen> with TickerProviderStateMixin {
  // CPU戦はYOU視点を固定。LOCAL BATTLEは並びプレイ前提で、
  // 手番側が常に画面下になるようターンごとに盤面表示だけ180度反転する。
  bool get _viewIsWhite => widget.trainingMode ? true : (widget.localBattle ? whiteTurn : widget.playerIsWhite);
  bool get _humanCanAct => widget.trainingMode ? whiteTurn : (widget.localBattle || whiteTurn == widget.playerIsWhite);

  int? selectedIndex;
  int? inspectedIndex; // view-only range inspection; never grants control
  bool whiteTurn = true;
  bool _noLegalActionFinishScheduled = false;
  Timer? _battleClockTimer;
  int _turnSecondsLeft = 90;
  int _whiteTotalSeconds = 15 * 60;
  int _blackTotalSeconds = 15 * 60;
  int _whiteTurnTimeouts = 0;
  int _blackTurnTimeouts = 0;
  bool _clockTurnWhite = true;
  bool _clockFinished = false;
  bool _cpuTurnScheduled = false;
  late final String _onlineCompletionId;
  int _testRanged = 0, _testMelee = 0, _testCapture = 0;
  bool _testGoryu = false;
  void _testKill(String action, bool side, Piece target) {
    if (side != widget.playerIsWhite || target.isWhite == side) return;
    if (action == "ranged") _testRanged++;
    if (action == "melee") _testMelee++;
  }
  int? _cpuPreviewTarget;
  String? _cpuPreviewAction;
  // 行動後も選択情報だけを短時間残す。操作自体には待機を入れない。
  int? _actionEchoOrigin;
  int? _actionEchoTarget;
  Set<int> _actionEchoMoveTargets = <int>{};
  Set<int> _actionEchoMergeTargets = <int>{};
  Set<int> _actionEchoEnemyTargets = <int>{};
  int _actionEchoGeneration = 0;
  static const Duration _actionEchoDuration = Duration(milliseconds: 650);
  // 駒の移動を「結果の瞬間切替」ではなく、盤上を実際に移動して見せる。
  int? _motionOrigin;
  int? _motionTarget;
  int _motionGeneration = 0;
  static const Duration _pieceMotionDuration = Duration(milliseconds: 720);
  int? _shotOrigin;
  int? _shotTarget;
  int _shotGeneration = 0;
  String? _shotFinalBlowKind;
  static const Duration _shotAnimationDuration = Duration(milliseconds: 420);
  // FINAL BLOWは溜め→収束→極太ビーム→着弾まで、目で追える長さを確保。
  static const Duration _finalBlowAnimationDuration = Duration(milliseconds: 2800);

  // Lv/Pu変化は通常のText再描画ではなく、盤面側の明示イベントとして扱う。
  // 演出中は入力・CPU進行を止め、完了してから次の処理へ進む。
  bool _statChangeBusy = false;
  // 豪竜の決着変貌が始まったら、決着完了まで両者の操作・投了・時計を止める。
  bool _goryuFinisherLocked = false;
  bool _goryuWhiteout = false;
  int? _statChangeIndex;
  String? _statChangePrefix;
  int? _statChangeValue;
  bool _statChangeUp = true;
  int _statChangeGeneration = 0;
  static const Duration _statChangeDuration = Duration(milliseconds: 760);

  Future<void> _showStatChange(int index, String prefix, int value, {required bool up}) async {
    final generation = ++_statChangeGeneration;
    if (!mounted) return;
    setState(() {
      _statChangeBusy = true;
      _statChangeIndex = index;
      _statChangePrefix = prefix;
      _statChangeValue = value;
      _statChangeUp = up;
    });
    await Future<void>.delayed(_statChangeDuration);
    if (!mounted || generation != _statChangeGeneration) return;
    setState(() {
      _statChangeBusy = false;
      _statChangeIndex = null;
      _statChangePrefix = null;
      _statChangeValue = null;
    });
  }

  // 騎の変形：変形先が上空から降下して装着されるように、
  // 同じマス上で「大きい→本来サイズ」に縮小して奥行きを表現する。
  int? _knightTransformIndex;
  Piece? _knightTransformTargetPiece;
  int _knightTransformGeneration = 0;
  bool _knightTransformBusy = false;
  static const Duration _knightTransformDuration = Duration(milliseconds: 680);

  // 技も通常行動と同じ「タイプ音＋台詞 → 盤面上で発動」で統一する。
  String _skillLineFor(Piece piece, {String? knightTarget}) {
    if (_isKuru(piece)) {
      if (_isKnightForm(piece)) {
        return switch (knightTarget) {
          '騎弐式' => '白兵戦と行こうか……。',
          '騎参式' => '弾幕を張る。',
          _ => '頃合だ。',
        };
      }
      return '……。';
    }
    if (piece.label == '王') return 'そこは危ないよ！';
    if (piece.label == '帝') return 'どこを見ている？';
    if (_isKnightForm(piece)) {
      return switch (knightTarget) {
        '騎弐式' => '白兵戦と行こうか……。',
        '騎参式' => '弾幕を張る。',
        _ => '頃合だ。',
      };
    }
    return '';
  }

  Future<void> _showSkillDialogueForIndex(int index, {String? knightTarget}) async {
    final piece = _topPieceAt(index);
    if (piece == null) return;
    final line = _skillLineFor(piece, knightTarget: knightTarget);
    final name = _pilotNameForPiece(piece);
    final asset = _pilotAssetForPiece(piece);
    if (line.isEmpty || name == null || asset == null) return;
    final generation = ++_pilotDialogueGeneration;
    _traceDialogue('P START g$generation skill [$line]');
    setState(() {
      _pilotDialogueBusy = true;
      _pilotDialogueTyping = true;
      _pilotDialogueText = line;
      _pilotDialogueName = name;
      _pilotDialogueAsset = asset;
    });
    _playActionSfx('audio/se_type.wav');
    await Future<void>.delayed(_pilotTypingDuration);
    if (!mounted || generation != _pilotDialogueGeneration) return;
    setState(() => _pilotDialogueTyping = false);
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _pilotDialogueGeneration) return;
    setState(() => _pilotDialogueBusy = false);
    Future<void>.delayed(
      _pilotDialogueVisibleDuration - _pilotTypingDuration - const Duration(milliseconds: 600),
      () {
        if (!mounted || generation != _pilotDialogueGeneration) return;
        setState(() {
          _pilotDialogueTyping = false;
          _pilotDialogueText = null;
          _pilotDialogueName = null;
          _pilotDialogueAsset = null;
        });
      },
    );
  }

  // パイロット台詞。先に高速タイプ表示し、そのまま行動演出中も残す。
  String? _pilotDialogueText;
  String? _pilotDialogueName;
  String? _pilotDialogueAsset;
  int _pilotDialogueGeneration = 0;
  bool _pilotDialogueBusy = false;
  bool _pilotDialogueTyping = false;

  // Temporary on-screen dialogue trace for isolating the double-display bug.
  final List<String> _dialogueTrace = <String>[];
  int _dialogueTraceSeq = 0;
  void _traceDialogue(String event) {
    final line = '${++_dialogueTraceSeq}: $event';
    _dialogueTrace.add(line);
    if (_dialogueTrace.length > 8) _dialogueTrace.removeAt(0);
  }

  // CPU dialogue has its own state. Never share it with the player's overlay.
  String? _cpuPilotDialogueText;
  String? _cpuPilotDialogueName;
  String? _cpuPilotDialogueAsset;
  int _cpuPilotDialogueGeneration = 0;
  bool _cpuPilotDialogueTyping = false;

  static const Duration _pilotTypingDuration = Duration(milliseconds: 430);
  static const Duration _pilotDialogueVisibleDuration = Duration(milliseconds: 2050);

  bool _isKuru(Piece piece) => piece.pilotId == 'kuru';

  String _pilotKeyForPiece(Piece piece) {
    if (_isKuru(piece)) return 'クル';
    return switch (piece.label) {
    '王' => '王',
    '仕' => '仕',
    '護' => '護',
    '闘' => '闘',
    '騎' || '騎弐式' || '騎参式' => '騎',
    '博' => '博',
    '将' => '将',
    '官' => '官',
    '軍' => '軍',
    '帝' => '帝',
    '砲' => '砲',
    '剣' => '剣',
    '盾' => '盾',
    '槍' => '槍',
    '迅' => '迅',
    '進' => '進',
    '亜' => '亜',
    _ => '',
    };
  }

  String? _pilotNameForPiece(Piece piece) => switch (_pilotKeyForPiece(piece)) {
    'クル' => 'クル',
    '王' => 'アーキン・バーン',
    '仕' => 'レイ・コール',
    '護' => 'ジェイク・ペイド',
    '闘' => 'アーツ・ロイアー',
    '騎' => 'ブル・キル',
    '博' => 'オース・アイン',
    '将' => 'ファン・オエル',
    '官' => 'ギル・ターク',
    '軍' => 'ギル・ターク',
    '帝' => '皇帝',
    '砲' => '砲',
    '剣' => '剣',
    '盾' => '盾',
    '槍' => 'リーダ',
    '迅' => 'ミテ',
    '進' => 'トラーム',
    '亜' => 'マイク',
    _ => null,
  };

  String? _pilotAssetForPiece(Piece piece) => switch (_pilotKeyForPiece(piece)) {
    'クル' => 'assets/pilots/kuru.webp',
    '王' => 'assets/pilots/king.webp',
    '仕' => 'assets/pilots/attendant.webp',
    '護' => 'assets/pilots/guard.webp',
    '闘' => 'assets/pilots/fighter.webp',
    '騎' => 'assets/pilots/knight.webp',
    '博' => 'assets/pilots/scholar.webp',
    '将' => 'assets/pilots/general.webp',
    '官' => 'assets/pilots/officer.webp',
    '軍' => 'assets/pilots/officer.webp',
    '帝' => 'assets/pilots/emperor.webp',
    '砲' => 'assets/pilots/cannon.webp',
    '剣' => 'assets/pilots/sword.webp',
    '盾' => 'assets/pilots/shield.webp',
    '槍' => 'assets/pilots/strasse_leader.webp',
    '迅' => 'assets/pilots/strasse_mite.webp',
    '進' => 'assets/pilots/strasse_traum.webp',
    '亜' => 'assets/pilots/strasse_mike.webp',
    _ => null,
  };

  String? _pilotLineFor(Piece piece, String action) {
    final k = _pilotKeyForPiece(piece);
    if (k == 'クル') {
      final knight = piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式';
      if (!knight) return '……。';

      return _profileKuruLines[action] ?? '……。';
    }
    return _profileBattleLines[k]?[action];
  }

  Future<void> _showPilotDialogueForIndex(int index, String action) async {
    final piece = _topPieceAt(index);
    if (piece == null) return;
    final line = _pilotLineFor(piece, action);
    final name = _pilotNameForPiece(piece);
    final asset = _pilotAssetForPiece(piece);
    if (line == null || name == null || asset == null) return;
    final generation = ++_pilotDialogueGeneration;
    _traceDialogue('P START g$generation $action [$line]');
    setState(() {
      _pilotDialogueBusy = true;
      _pilotDialogueTyping = true;
      _pilotDialogueText = line;
      _pilotDialogueName = name;
      _pilotDialogueAsset = asset;
    });
    _playActionSfx('audio/se_type.wav');
    await Future<void>.delayed(_pilotTypingDuration);
    if (!mounted || generation != _pilotDialogueGeneration) return;
    setState(() => _pilotDialogueTyping = false);

    // 文字が打ち終わってから一度しっかり読ませて、機体の行動へ。
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _pilotDialogueGeneration) return;
    _traceDialogue('P ACTION g$generation');
    setState(() => _pilotDialogueBusy = false);

    // 行動アニメ中も表示し、終わったあとにも少し余韻を残す。
    Future<void>.delayed(
      _pilotDialogueVisibleDuration -
          _pilotTypingDuration -
          const Duration(milliseconds: 600),
      () {
      if (!mounted || generation != _pilotDialogueGeneration) return;
      _traceDialogue('P HIDE g$generation');
      setState(() {
        _pilotDialogueTyping = false;
        _pilotDialogueText = null;
        _pilotDialogueName = null;
        _pilotDialogueAsset = null;
      });
    });
  }


  Future<void> _showCpuPilotDialogueForIndex(int index, String action) async {
    final piece = _topPieceAt(index);
    if (piece == null) return;
    final line = _pilotLineFor(piece, action);
    final name = _pilotNameForPiece(piece);
    final asset = _pilotAssetForPiece(piece);
    if (line == null || name == null || asset == null) return;
    final generation = ++_cpuPilotDialogueGeneration;
    _traceDialogue('C START g$generation $action [$line]');
    setState(() {
      // CPU台詞を出す瞬間に旧共通オーバーレイを完全に破棄する。
      // CPU専用表示と旧表示が同じ位置に重なって「2回目」に見える経路を断つ。
      _pilotDialogueGeneration++;
      _pilotDialogueBusy = false;
      _pilotDialogueTyping = false;
      _pilotDialogueText = null;
      _pilotDialogueName = null;
      _pilotDialogueAsset = null;
      _cpuPilotDialogueTyping = true;
      _cpuPilotDialogueText = line;
      _cpuPilotDialogueName = name;
      _cpuPilotDialogueAsset = asset;
    });
    _playActionSfx('audio/se_type.wav');
    await Future<void>.delayed(_pilotTypingDuration);
    if (!mounted || generation != _cpuPilotDialogueGeneration) return;
    setState(() => _cpuPilotDialogueTyping = false);
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _cpuPilotDialogueGeneration) return;
    _traceDialogue('C ACTION g$generation');
    Future<void>.delayed(
      _pilotDialogueVisibleDuration - _pilotTypingDuration - const Duration(milliseconds: 600),
      () {
        if (!mounted || generation != _cpuPilotDialogueGeneration) return;
        _traceDialogue('C HIDE g$generation');
        setState(() {
          _cpuPilotDialogueTyping = false;
          _cpuPilotDialogueText = null;
          _cpuPilotDialogueName = null;
          _cpuPilotDialogueAsset = null;
        });
      },
    );
  }

  void _beginShotAnimation(int from, int to, {String? finalBlowKind}) {
    setState(() {
      _shotOrigin = from;
      _shotTarget = to;
      _shotFinalBlowKind = finalBlowKind;
      _shotGeneration++;
    });
    final generation = _shotGeneration;
    final duration = finalBlowKind == null ? _shotAnimationDuration : _finalBlowAnimationDuration;
    Future<void>.delayed(duration, () {
      if (!mounted || generation != _shotGeneration) return;
      setState(() {
        _shotOrigin = null;
        _shotTarget = null;
        _shotFinalBlowKind = null;
      });
    });
  }

  void _beginPieceMotion(int from, int to) {
    setState(() {
      _motionOrigin = from;
      _motionTarget = to;
      _motionGeneration++;
    });
    final generation = _motionGeneration;
    Future<void>.delayed(_pieceMotionDuration, () {
      if (!mounted || generation != _motionGeneration) return;
      setState(() {
        _motionOrigin = null;
        _motionTarget = null;
      });
    });
  }
  final AudioPlayer _battleBgmPlayer = AudioPlayer();
  final AudioPlayer _actionSfxPlayer = AudioPlayer();
  int? _coreBurstIndex;
  int _coreBurstGeneration = 0;
  static const Duration _coreBurstDuration = Duration(milliseconds: 760);

  // 核の効果は説明ポップアップではなく、盤面上の対象駒そのものに見せる。
  int? _coreEffectIndex;
  Piece? _coreEffectPiece;
  int? _coreEffectOldLevel;
  bool _coreEffectIsRevival = false;
  int _coreEffectGeneration = 0;
  static const Duration _coreLv3EffectDuration = Duration(milliseconds: 1500);
  static const Duration _coreRevivalEffectDuration = Duration(milliseconds: 1500);
  int? _coreLinkFrom;
  int? _coreLinkTo;
  int _coreLinkGeneration = 0;
  int? _pendingRevivalCoreIndex;

  Future<void> _playActionSfx(String asset) async {
    try {
      await _actionSfxPlayer.setAudioContext(
        AudioContext(
          android: const AudioContextAndroid(
            contentType: AndroidContentType.sonification,
            usageType: AndroidUsageType.game,
            audioFocus: AndroidAudioFocus.none,
          ),
          iOS: AudioContextIOS(
            category: AVAudioSessionCategory.ambient,
            options: const {AVAudioSessionOptions.mixWithOthers},
          ),
        ),
      );
      await _actionSfxPlayer.play(AssetSource(asset), volume: _AudioSettings.se);
    } catch (_) {}
  }

  void _beginCoreBurst(int index) {
    setState(() { _coreBurstIndex = index; _coreBurstGeneration++; });
    final g = _coreBurstGeneration;
    _playActionSfx('audio/se_core_charge.wav');
    Future<void>.delayed(const Duration(milliseconds: 470), () {
      if (!mounted || g != _coreBurstGeneration) return;
      _playActionSfx('audio/se_core_burst.wav');
    });
    Future<void>.delayed(_coreBurstDuration, () {
      if (!mounted || g != _coreBurstGeneration) return;
      setState(() => _coreBurstIndex = null);
    });
  }
  bool _showBgmTitle = false;
  String _battleBgmTitle = '';
  final List<(String, String)> _battleBgmPool = <(String, String)>[
    ('Overdriven Riffs', 'audio/5Overdriven Riffs.m4a'),
    ('Target Lock', 'audio/6Target Lock.m4a'),
    ('Target Lock2', 'audio/7Target Lock2.m4a'),
    ("Commander's Gambit", "audio/8Commander's Gambit.m4a"),
    ('Heavy Metal Strategy', 'audio/9Heavy Metal Strategy.m4a'),
    ('Tactical Velocity', 'audio/10Tactical Velocity.m4a'),
    ('Doubt', 'audio/11Doubt.mp3 （リミックス） (Remastered).m4a'),
    ('Final Tactical Maneuver', 'audio/12Final Tactical Maneuver.m4a'),
  ];
  final List<(String, String)> _battleBgmQueue = <(String, String)>[];
  int _bgmTitleGeneration = 0;
  // 帝「加速」：1回目を選んだ後、2回目の移動が可能なら強制する。
  // 現在は同一端末テスト版。対戦相手への移動経路秘匿・カットインは
  // オンライン同期時に2回目の成否だけ送る形で実装する。
  int _accelerationStep = 0; // 0=通常、1=最初の移動、2=2回目の移動
  int _rapidFireStep = 0; // 王「連射」：0=通常、1=1発目、2=2発目
  // シュトラーセ「逃げるが勝ち」
  // 0=通常、1=格闘対象選択、2=格闘後の移動先選択、3=合流した2機の移動先選択
  int _strasseSkillStep = 0;
  // 飛空城シリーズの上に乗った駒へ一時付与されるSKILL「飛空」
  // 0=通常、1=飛空先選択中
  int _flightSkillStep = 0;
  final List<Piece> _whiteDestroyedMajors = <Piece>[];
  final List<Piece> _blackDestroyedMajors = <Piece>[];
  int _whiteSoldierStock = 0;
  int _blackSoldierStock = 0;
  bool _placingStockSoldier = false;
  Set<int> _stockSoldierTargets = <int>{};
  Piece? _pendingRevivalPiece;
  Set<int> _pendingRevivalTargets = <int>{};
  // 生命の像：MASTER復活時は生贄の神仕を盤上から選ぶ。
  Piece? _pendingMasterLifePiece;
  Set<int> _pendingLifeSacrificeTargets = <int>{};
  int? _pendingLifeFirstSacrifice;
  int? _pendingLifeSecondSacrifice;
  final Set<int> lowerInfoCells = <int>{};
  late final AnimationController _mergeBlinkController;
  late final AnimationController _lifeSacrificeMarkerController;
  late final AnimationController _shotThreatController;
  late final AnimationController _turnBannerController;
  bool? _lastRenderedTurn;
  bool _showTurnBanner = false;
  bool _turnBannerWhite = true;

  int _trainingStage = 0;
  String? _trainingText;
  bool _trainingTyping = false;
  bool _trainingCanNext = false;
  int? _trainingTargetCell;
  String? _trainingExpectedAction;
  bool _trainingShowKingPiece = false;
  bool _trainingCrownArrow = false;
  int _trainingDialogueGeneration = 0;
  String? _trainingLastInstruction;
  int? _trainingLastTargetCell;
  String? _trainingLastExpectedAction;
  bool _trainingLastHighlightFrontline = false;
  bool _trainingActionReady = false;
  bool _trainingReviewingInstruction = false;
  bool _trainingHighlightFrontline = false;
  bool _trainingAdvancing = false;
  static const int _trFighterStart = 33;
  static const int _trFighterField = 22;
  static const int _trKingStart = 27;
  static const int _trBlackKingStart = 7;
  static const int _trBlackKingField = 18;
  static const int _trBlackSoldierShot = 13;
  static const int _trBlackServantField = 12;
  static const int _trWhiteServantStart = 31;
  static const int _trRightBlackCore = 4;

  void _trainingSpeak(
    String text, {
    bool next = false,
    int? targetCell,
    String? action,
    bool showKing = false,
    bool crownArrow = false,
    bool highlightFrontline = false,
  }) {
    if (!mounted) return;
    final g = ++_trainingDialogueGeneration;
    final isInstruction = !next && (targetCell != null || action != null);
    setState(() {
      // TRAININGの会話へ入るたび、通常対戦用の一時入力状態を必ず破棄する。
      // 会話中に兵投入モードや緑ハイライトが残ると進行不能になるため、ここで一元的に消す。
      _placingStockSoldier = false;
      _stockSoldierTargets = <int>{};
      _pendingRevivalPiece = null;
      _pendingRevivalTargets = <int>{};
      _rapidFireStep = 0;
      _accelerationStep = 0;
      _strasseSkillStep = 0;
      _flightSkillStep = 0;
      _trainingText = text;
      _trainingCanNext = next;
      _trainingTargetCell = targetCell;
      _trainingExpectedAction = action;
      _trainingShowKingPiece = showKing;
      _trainingCrownArrow = crownArrow;
      _trainingTyping = true;
      // 指示中も盤面は自由に触れる。進行だけ正しい操作に限定する。
      _trainingActionReady = isInstruction;
      _trainingReviewingInstruction = false;
      _trainingHighlightFrontline = highlightFrontline;
      if (isInstruction) {
        _trainingLastInstruction = text;
        _trainingLastTargetCell = targetCell;
        _trainingLastExpectedAction = action;
        _trainingLastHighlightFrontline = highlightFrontline;
      }
    });
    _playActionSfx('audio/se_type.wav');
    Future<void>.delayed(_pilotTypingDuration, () {
      if (!mounted || g != _trainingDialogueGeneration) return;
      setState(() => _trainingTyping = false);
    });
  }

  int? _trainingExpectedSelectedIndex() {
    switch (_trainingStage) {
      case 6:
        return _trFighterStart;
      case 11:
      case 12:
        return _trKingStart;
      case 20:
      case 21:
        return _trFighterField;
      case 27:
        return _trWhiteServantStart;
      case 35:
      case 36:
        return _trFighterField;
      case 45:
      case 46:
        return _trBlackKingField;
      case 50:
      case 51:
        return _trBlackServantField;
      default:
        return null;
    }
  }

  Future<void> _trainingReprimand({required bool listen}) async {
    if (!widget.trainingMode || !mounted) return;

    // 行動メニューで違うコマンドを選んだ場合は、
    // 「指示通りにやれ……。」のあと直前の選択段階へ確実に戻す。
    final wrongActionStage = _trainingStage;
    final wrongAction = !listen && _trainingExpectedAction != null;
    if (wrongAction) {
      switch (wrongActionStage) {
        case 12:
          _trainingStage = 11;
          _trainingLastInstruction = '相手の王を選べ。格闘だ。';
          _trainingLastTargetCell = _trBlackKingField;
          _trainingLastExpectedAction = null;
          selectedIndex = _trKingStart;
          break;
        case 21:
          _trainingStage = 20;
          _trainingLastInstruction = '相手の兵を選べ。射撃だ。';
          _trainingLastTargetCell = _trBlackSoldierShot;
          _trainingLastExpectedAction = null;
          selectedIndex = _trFighterField;
          break;
        case 36:
          _trainingStage = 35;
          _trainingLastInstruction = '相手の闘を選べ。格闘だ。';
          _trainingLastTargetCell = _trBlackServantField;
          _trainingLastExpectedAction = null;
          selectedIndex = _trFighterField;
          break;
        case 40:
          _trainingStage = 39;
          _trainingLastInstruction = 'まずは制圧している敵を長押しして、制圧破壊を選べ。';
          _trainingLastTargetCell = _trBlackServantField;
          _trainingLastExpectedAction = null;
          selectedIndex = null;
          break;
        case 46:
          _trainingStage = 45;
          _trainingLastInstruction = '兵を選べ。格闘だ。';
          _trainingLastTargetCell = _trBlackServantField;
          _trainingLastExpectedAction = null;
          selectedIndex = _trBlackKingField;
          break;
        case 51:
          _trainingStage = 50;
          _trainingLastInstruction = '右側の核を選べ。格闘でも射撃でもいい。';
          _trainingLastTargetCell = _trRightBlackCore;
          _trainingLastExpectedAction = null;
          selectedIndex = _trBlackServantField;
          break;
      }
      _trainingExpectedAction = null;
    }

    final instruction = _trainingLastInstruction;
    final target = _trainingLastTargetCell;
    final action = _trainingLastExpectedAction;
    final highlightFrontline = _trainingLastHighlightFrontline;
    final g = ++_trainingDialogueGeneration;
    setState(() {
      _trainingText = listen ? 'ちゃんと話を聞け……。' : '指示通りにやれ……。';
      _trainingTyping = false;
      _trainingCanNext = false;
      _trainingReviewingInstruction = false;
      if (!wrongAction) {
        selectedIndex = _trainingExpectedSelectedIndex();
      }
      inspectedIndex = null;
      lowerInfoCells.clear();
    });
    await Future<void>.delayed(const Duration(milliseconds: 850));
    if (!mounted || g != _trainingDialogueGeneration || instruction == null) return;
    _trainingSpeak(
      instruction,
      targetCell: target,
      action: action,
      highlightFrontline: highlightFrontline,
    );
  }

  void _trainingInspectPiece(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) {
      setState(() {
        selectedIndex = null;
        inspectedIndex = null;
        lowerInfoCells.clear();
      });
      return;
    }
    setState(() {
      final stack = cells[index];
      final isStacked = stack != null && stack.length > 1;

      // TRAININGでも通常戦と同じタップ挙動にする。
      // 同じ合流駒をもう一度タップした時だけ、情報欄を上↔下で切り替える。
      // 別の駒を選んだ時は前の選択範囲を消し、その駒の情報・行動範囲を表示する。
      if (piece.isWhite == _viewIsWhite) {
        inspectedIndex = null;
        if (selectedIndex == index && isStacked) {
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
        selectedIndex = index;
        lowerInfoCells.clear();
        return;
      }

      selectedIndex = null;
      if (inspectedIndex == index && isStacked) {
        if (lowerInfoCells.contains(index)) {
          lowerInfoCells.remove(index);
        } else {
          lowerInfoCells.add(index);
        }
      } else {
        inspectedIndex = index;
        lowerInfoCells.clear();
      }
    });
  }

  void _trainingBeginAction() {
    if (!widget.trainingMode || _trainingTyping || !mounted) return;
    ++_trainingDialogueGeneration;
    setState(() {
      _trainingText = null;
      _trainingCanNext = false;
      _trainingTyping = false;
      _trainingShowKingPiece = false;
      _trainingActionReady = true;
      _trainingReviewingInstruction = false;
    });
  }

  void _trainingReplayInstruction() {
    final text = _trainingLastInstruction;
    if (!widget.trainingMode || !_trainingActionReady || text == null || !mounted) return;
    ++_trainingDialogueGeneration;
    setState(() {
      _trainingText = text;
      _trainingTyping = false;
      _trainingCanNext = false;
      _trainingReviewingInstruction = true;
    });
  }

  void _trainingCloseReplay() {
    if (!widget.trainingMode || !_trainingReviewingInstruction || !mounted) return;
    ++_trainingDialogueGeneration;
    setState(() {
      _trainingText = null;
      _trainingTyping = false;
      _trainingReviewingInstruction = false;
    });
  }

  void _trainingWaitForAction(String action) {
    ++_trainingDialogueGeneration;
    if (!mounted) return;
    setState(() {
      _trainingText = null;
      _trainingTyping = false;
      _trainingCanNext = false;
      _trainingTargetCell = null;
      _trainingExpectedAction = action;
      _trainingShowKingPiece = false;
      _trainingCrownArrow = false;
      _trainingActionReady = true;
      _trainingReviewingInstruction = false;
    });
  }

  Future<void> _trainingScriptMove(int from, int to, {bool merge = false}) async {
    _beginPieceMotion(from, to);
    setState(() {
      _moveTopPiece(from: from, to: to, merge: merge);
      selectedIndex = null;
    });
    await Future<void>.delayed(_pieceMotionDuration);
  }

  Future<void> _trainingFinish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('training_completed_v2', true);
    await _StoryProgress.recordTrainingCompleted();
    if (!mounted) return;
    await _stopBattleBgm();
    final profileDone = prefs.getBool('player_profile_registered_v1') ?? false;
    if (!mounted) return;
    Navigator.of(context).pushReplacement(_quietTransitionRoute(
      profileDone ? const MainMenuScreen() : const PlayerRegistrationScreen(),
    ));
  }

  Future<void> _trainingNext() async {
    if (!widget.trainingMode || !_trainingCanNext || _trainingTyping || _trainingAdvancing) return;
    if (mounted) {
      setState(() {
        _trainingAdvancing = true;
        _placingStockSoldier = false;
        _stockSoldierTargets = <int>{};
        inspectedIndex = null;
        lowerInfoCells.clear();
      });
    } else {
      _trainingAdvancing = true;
    }
    try {
      switch (_trainingStage) {
      case 0:
        _trainingStage = 1;
        _trainingSpeak('これがZを駒にしたものだ。', next: true, showKing: true);
        break;
      case 1:
        _trainingStage = 2;
        _trainingSpeak('このツァームドの世界を戦って生き抜き、戦場を支配しろ。', next: true);
        break;
      case 2:
        _trainingStage = 3;
        _trainingSpeak('まずはプラクティス。戦い方を少しだけ教えてやる。', next: true);
        break;
      case 3:
        _trainingStage = 4;
        _trainingSpeak('まず闘をタップしてみろ。', targetCell: _trFighterStart);
        break;
      case 5:
        _trainingStage = 6;
        _trainingSpeak('マス内の青は移動候補だ。枠の青・黄・赤はLv1・Lv2・Lv3を示し、点線は今はまだ使えない範囲だ。王の前へ移動してみよう。', targetCell: _trFighterField);
        break;
      case 7:
        _trainingStage = 8;
        await _trainingScriptMove(_trBlackKingStart, _trBlackKingField);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('相手の王がこちらに来たな。', next: true);
        break;
      case 8:
        _trainingStage = 9;
        _trainingSpeak('今、兵が相手の王から撃たれる位置にいる。', next: true);
        break;
      case 9:
        _trainingStage = 10;
        _trainingSpeak('王で相手の王を格闘で倒そう。まず自陣の王をタップしてみよう。', targetCell: _trKingStart);
        break;
      case 13:
        _trainingStage = 14;
        if (mounted) setState(() => whiteTurn = false);
        await Future<void>.delayed(const Duration(milliseconds: 220));
        await _trainingScriptMove(8, _trBlackSoldierShot);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('相手が王の前に兵を出してきたな。', next: true);
        break;
      case 14:
        _trainingStage = 15;
        _trainingSpeak('王が兵の射撃範囲に入っている。', next: true);
        break;
      case 15:
        _trainingStage = 16;
        _trainingSpeak('王をタップしてみよう。', targetCell: _trBlackKingField);
        break;
      case 17:
        _trainingStage = 18;
        _trainingSpeak('だが、王の行動範囲に兵が入っていないようだ。', next: true);
        break;
      case 18:
        _trainingStage = 19;
        _trainingSpeak('では闘で兵に射撃してみよう。', targetCell: _trFighterField);
        break;
      case 22:
        _trainingStage = 23;
        if (mounted) setState(() => whiteTurn = false);
        await Future<void>.delayed(const Duration(milliseconds: 220));
        await _trainingScriptMove(3, _trBlackServantField);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('相手が仕を前に出してきた。', next: true);
        break;
      case 23:
        _trainingStage = 24;
        _trainingSpeak('王で仕を倒すこともできるが王だけで攻め込ませるのは得策ではないな。', next: true);
        break;
      case 24:
        _trainingStage = 901;
        _trainingSpeak('今、こちらの王と相手の仕は拮抗している。', next: true);
        break;
      case 901:
        _trainingStage = 902;
        _trainingSpeak('互いに射撃可能な位置にいる場合、拮抗が発生し、互いに射撃ができなくなる。', next: true);
        break;
      case 902:
        _trainingStage = 25;
        _trainingSpeak('こちらも仕を前に出そう。', targetCell: _trWhiteServantStart);
        break;
      case 26:
        _trainingStage = 27;
        _trainingSpeak('闘をタップして合流してみよう。', targetCell: _trFighterField);
        break;
      case 28:
        _trainingStage = 29;
        _trainingSpeak('合流すると駒は一時的にパワーアップする。これをパンプアップという。行動範囲が増えたな。', next: true);
        break;
      case 29:
        _trainingStage = 30;
        if (mounted) {
          setState(() {
            selectedIndex = _trFighterField;
            inspectedIndex = null;
            lowerInfoCells.remove(_trFighterField);
          });
        }
        _trainingSpeak('合流した駒をもう一度タップしてみよう。同じ駒をタップするたびに、上と下の情報表示を切り替えられる。', targetCell: _trFighterField);
        break;
      case 31:
        _trainingStage = 32;
        if (mounted) {
          setState(() {
            selectedIndex = _trFighterField;
            inspectedIndex = null;
            lowerInfoCells.remove(_trFighterField);
          });
        }
        _trainingSpeak('仕の下部を見てみろ。Lv1/Pu1と表示されているな。Lvの数字＋Puの数字が、今の行動範囲を示すレベルになる。今の仕はLv2相当ということだ。', next: true);
        break;
      case 32:
        _trainingStage = 33;
        if (mounted) setState(() => whiteTurn = false);
        await Future<void>.delayed(const Duration(milliseconds: 220));
        await _trainingScriptMove(1, _trBlackServantField, merge: true);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('おや、相手も仕に闘を合流してきたようだ。', next: true);
        break;
      case 33:
        _trainingStage = 34;
        _trainingSpeak('相手の闘を仕で倒す。格闘で攻めこもう。', targetCell: _trFighterField);
        break;
      case 37:
        _trainingStage = 38;
        if (mounted) setState(() => whiteTurn = false);
        await Future<void>.delayed(const Duration(milliseconds: 220));
        await _trainingScriptMove(6, 7);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('仕が狙われているな。', next: true);
        break;
      case 38:
        _trainingStage = 39;
        _trainingSpeak('まずは制圧している敵を長押しして、制圧破壊を選べ。', targetCell: _trBlackServantField);
        break;
      case 41:
        _trainingStage = 42;
        if (mounted) setState(() => whiteTurn = false);
        await Future<void>.delayed(const Duration(milliseconds: 220));
        await _executeMelee(7, _trBlackServantField, showDialogue: false);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('敵兵が仕を格闘で倒してきた。', next: true);
        break;
      case 42:
        _trainingStage = 43;
        _trainingSpeak('今オレンジに光っている奥の三段を、前線やFrontLine（フロントライン）と呼ぶ。Lv3未満の大駒は、この前線に入ることでPuが1加わる。', next: true, highlightFrontline: true);
        break;
      case 43:
        _trainingStage = 44;
        _trainingSpeak('王で兵に格闘攻撃をしながら、オレンジの前線へ入ってみよう。', targetCell: _trBlackKingField, highlightFrontline: true);
        break;
      case 47:
        _trainingStage = 48;
        if (mounted) setState(() => whiteTurn = false);
        await Future<void>.delayed(const Duration(milliseconds: 220));
        await _trainingScriptMove(5, 0, merge: true);
        if (!mounted) return;
        setState(() => whiteTurn = true);
        _trainingSpeak('相手の兵が核に乗って守ろうとしているが問題ない。', next: true);
        break;
      case 48:
        _trainingStage = 49;
        _trainingSpeak('右側の核を王で攻撃しよう。格闘でも射撃でもいい。', targetCell: _trBlackServantField);
        break;
      case 53:
        _trainingStage = 54;
        _trainingSpeak('ここで学べるのは、戦場に立つための最低限だけだ。\nその先は、戦いの中で自分で確かめろ。', next: true);
        break;
      case 54:
        await _trainingFinish();
        break;
      }
    } finally {
      if (mounted) {
        setState(() => _trainingAdvancing = false);
      } else {
        _trainingAdvancing = false;
      }
    }
  }

  Future<void> _trainingActionCompleted(String action) async {
    if (!widget.trainingMode) return;
    if (_trainingStage == 12 && action == '格闘') {
      _trainingStage = 13;
      if (mounted) setState(() => whiteTurn = true);
      _trainingSpeak('画面上部のWHITE側の王冠を見ろ。1.5になっているな。このWHITEの王冠が3になれば勝利だ。覚えておくんだな。', next: true, crownArrow: true);
    } else if (_trainingStage == 21 && action == '射撃') {
      _trainingStage = 22;
      if (mounted) setState(() => whiteTurn = true);
      _trainingSpeak('射撃は駒が動くことなく駒を倒す。', next: true);
    } else if (_trainingStage == 36 && action == '格闘') {
      _trainingStage = 37;
      if (mounted) setState(() => whiteTurn = true);
      _trainingSpeak('合流した相手に格闘をすると下の駒を制圧する。', next: true);
    } else if (_trainingStage == 40 && action == '制圧破壊') {
      _trainingStage = 41;
      if (mounted) setState(() => whiteTurn = true);
      _trainingSpeak('制圧している敵を破壊した。', next: true);
    } else if (_trainingStage == 46 && action == '格闘') {
      _trainingStage = 47;
      if (mounted) setState(() => whiteTurn = true);
      _trainingSpeak('兵を倒したことで王はLv3になった。LvとPuを合わせた行動範囲の上限はLv3相当だ。今いる場所は前線だが、王はすでにLv3なのでPuは加わらず、行動範囲もこれ以上増えない。', next: true, highlightFrontline: true);
    }
  }

  Future<void> _handleTrainingTap(int index) async {
    if (!widget.trainingMode || _trainingReviewingInstruction) return;

    // 会話本文のタイプ中・「つぎへ」待ち・画面遷移中は盤面を完全ロックする。
    // 指示付き会話はタイプ完了後だけ盤面操作を許可する。
    if (_trainingTyping || _trainingCanNext || _trainingAdvancing) return;

    // 行動指示が出ていない場面では盤面操作を受け付けない。
    if (!_trainingActionReady) return;

    // 指示対象以外の駒は自由に確認できる。行動しようとした時だけ止める。
    if (_trainingTargetCell != null && index != _trainingTargetCell) {
      final tappedPiece = _topPieceAt(index);
      if (tappedPiece != null) {
        _trainingInspectPiece(index);
        return;
      }
      final from = selectedIndex;
      if (from != null &&
          (_moveTargetsFor(from).contains(index) ||
           _mergeTargetsFor(from).contains(index) ||
           _enemyTargetsFor(from).contains(index))) {
        await _trainingReprimand(listen: _trainingTyping);
      }
      return;
    }

    switch (_trainingStage) {
      case 4:
        setState(() { selectedIndex = index; inspectedIndex = null; lowerInfoCells.clear(); });
        _trainingStage = 5;
        _trainingSpeak('駒をタップすると駒の行動範囲が表示されただろう。', next: true);
        break;
      case 6:
        if (selectedIndex != _trFighterStart || !_moveTargetsFor(_trFighterStart).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _beginPieceMotion(_trFighterStart, index);
        setState(() { _moveTopPiece(from: _trFighterStart, to: index, merge: false); selectedIndex = null; whiteTurn = false; });
        await Future<void>.delayed(_pieceMotionDuration);
        if (!mounted) return;
        _trainingStage = 7;
        _trainingSpeak('1行動すると相手にターンが移る。', next: true);
        break;
      case 10:
        setState(() { selectedIndex = index; inspectedIndex = null; });
        _trainingStage = 11;
        _trainingSpeak('相手の王を選べ。格闘だ。', targetCell: _trBlackKingField);
        break;
      case 11:
        if (selectedIndex != _trKingStart || !_enemyTargetsFor(_trKingStart).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _trainingStage = 12;
        _trainingWaitForAction('格闘');
        _showActionMenu(_trKingStart, index);
        break;
      case 16:
        setState(() { selectedIndex = index; inspectedIndex = null; });
        _trainingStage = 17;
        _trainingSpeak('敵を倒した駒はLvが1上がる。さっき王が相手の王を倒したから、王はLv1からLv2になった。Lv2になると、黄色で示された行動範囲が加わる。さらにLv3になると、赤色と黄色で示された行動範囲が加わる。', next: true);
        break;
      case 19:
        setState(() { selectedIndex = index; inspectedIndex = null; });
        _trainingStage = 20;
        _trainingSpeak('相手の兵を選べ。射撃だ。', targetCell: _trBlackSoldierShot);
        break;
      case 20:
        if (selectedIndex != _trFighterField || !_enemyTargetsFor(_trFighterField).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _trainingStage = 21;
        _trainingWaitForAction('射撃');
        _showActionMenu(_trFighterField, index);
        break;
      case 25:
        setState(() { selectedIndex = index; inspectedIndex = null; });
        _trainingStage = 26;
        _trainingSpeak('おっと、仕の行動範囲に味方の闘がいるな。', next: true);
        break;
      case 27:
        if (selectedIndex != _trWhiteServantStart || !_mergeTargetsFor(_trWhiteServantStart).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _beginPieceMotion(_trWhiteServantStart, index);
        setState(() { _moveTopPiece(from: _trWhiteServantStart, to: index, merge: true); selectedIndex = null; whiteTurn = false; });
        await Future<void>.delayed(_pieceMotionDuration);
        if (!mounted) return;
        _trainingStage = 28;
        _trainingSpeak('駒が重なって合流したな。', next: true);
        break;
      case 30:
        _trainingInspectPiece(index);
        _trainingStage = 31;
        _trainingSpeak('上は仕、下は闘だ。合流していても下の駒まで確認できる。', next: true);
        break;
      case 34:
        setState(() { selectedIndex = index; lowerInfoCells.remove(index); });
        _trainingStage = 35;
        _trainingSpeak('相手の闘を選べ。格闘だ。', targetCell: _trBlackServantField);
        break;
      case 35:
        if (selectedIndex != _trFighterField || !_enemyTargetsFor(_trFighterField).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _trainingStage = 36;
        _trainingWaitForAction('格闘');
        _showActionMenu(_trFighterField, index);
        break;
      case 39:
        // 制圧破壊は通常戦と同じく長押しで行う。タップでは進行しない。
        _trainingInspectPiece(index);
        break;
      case 44:
        setState(() { selectedIndex = index; inspectedIndex = null; });
        _trainingStage = 45;
        _trainingSpeak('兵を選べ。格闘だ。', targetCell: _trBlackServantField);
        break;
      case 45:
        if (selectedIndex != _trBlackKingField || !_enemyTargetsFor(_trBlackKingField).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _trainingStage = 46;
        _trainingWaitForAction('格闘');
        _showActionMenu(_trBlackKingField, index);
        break;
      case 49:
        setState(() { selectedIndex = index; inspectedIndex = null; });
        _trainingStage = 50;
        _trainingSpeak('右側の核を選べ。格闘でも射撃でもいい。', targetCell: _trRightBlackCore);
        break;
      case 50:
        if (selectedIndex != _trBlackServantField || !_enemyTargetsFor(_trBlackServantField).contains(index)) {
          await _trainingReprimand(listen: _trainingTyping);
          return;
        }
        _trainingStage = 51;
        _trainingWaitForAction('攻撃');
        _showActionMenu(_trBlackServantField, index);
        break;
    }
  }

  Future<void> _handleTrainingLongPress(int index) async {
    if (!widget.trainingMode || _trainingReviewingInstruction) return;

    if (_trainingStage == 39) {
      if (_trainingTyping && index != _trBlackServantField) {
        await _trainingReprimand(listen: true);
        return;
      }
      if (index != _trBlackServantField) {
        _trainingInspectPiece(index);
        return;
      }
      _trainingStage = 40;
      _trainingWaitForAction('制圧破壊');
      _showSuppressionDestroyMenu(index);
    }
  }

  @override
  void initState() {
    super.initState();
    _onlineCompletionId = '${DateTime.now().microsecondsSinceEpoch}-${identityHashCode(this)}';
    _AppBgm.stop();
    _mergeBlinkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..repeat(reverse: true);
    _lifeSacrificeMarkerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();
    _shotThreatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
    _turnBannerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    );
    _lastRenderedTurn = whiteTurn;
    cells = {
      for (final entry in widget.initialPieces.entries) entry.key: [entry.value],
    };
    _testGoryu = widget.initialPieces.values.any((piece) => piece.isWhite == widget.playerIsWhite && piece.label == "軍");
    // MASTERの中央固定：生命の像の上に通常飛空城が合流した状態で開始。
    if (widget.whiteUnit == BattleUnit.master) {
      cells[32] = [
        const Piece('assets/pieces/master_life_white.png', '生命の像', isWhite: true),
        const Piece('assets/pieces/master_air_white.png', '飛空城', major: true, isWhite: true),
      ];
    }
    if (widget.blackUnit == BattleUnit.master) {
      cells[2] = [
        const Piece('assets/pieces/master_life_black.png', '生命の像', isWhite: false),
        const Piece('assets/pieces/master_air_black.png', '飛空城', major: true, isWhite: false),
      ];
    }
    _whiteBattleUnit = widget.whiteUnit;
    _blackBattleUnit = widget.blackUnit;
    _startBattleBgm();
    _clockTurnWhite = whiteTurn;
    if (!widget.localBattle && !widget.trainingMode) {
      _battleClockTimer = Timer.periodic(const Duration(seconds: 1), (_) => _tickBattleClock());
    }
    if (widget.trainingMode) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _trainingSpeak('ツァームドの世界へようこそ。\nこの世界ではZと呼ばれる兵器で戦争が行われている。', next: true);
      });
    }
  }

  void _tickBattleClock() {
    if (widget.localBattle || widget.trainingMode || !mounted || _clockFinished || _goryuFinisherLocked) return;
    if (_clockTurnWhite != whiteTurn) {
      _clockTurnWhite = whiteTurn;
      _turnSecondsLeft = 90;
    }
    if (whiteTurn) {
      _whiteTotalSeconds = math.max(0, _whiteTotalSeconds - 1);
    } else {
      _blackTotalSeconds = math.max(0, _blackTotalSeconds - 1);
    }
    _turnSecondsLeft = math.max(0, _turnSecondsLeft - 1);
    if ((whiteTurn && _whiteTotalSeconds == 0) || (!whiteTurn && _blackTotalSeconds == 0)) {
      _finishByClock(loserIsWhite: whiteTurn);
      return;
    }
    if (_turnSecondsLeft == 0) {
      final timedOutWhite = whiteTurn;
      if (timedOutWhite) { _whiteTurnTimeouts++; } else { _blackTurnTimeouts++; }
      final count = timedOutWhite ? _whiteTurnTimeouts : _blackTurnTimeouts;
      if (count >= 3) {
        _finishByClock(loserIsWhite: timedOutWhite);
        return;
      }
      setState(() {
        selectedIndex = null;
        _accelerationStep = 0;
        _rapidFireStep = 0;
        _strasseSkillStep = 0;
        _flightSkillStep = 0;
        whiteTurn = !whiteTurn;
        _clockTurnWhite = whiteTurn;
        _turnSecondsLeft = 90;
      });
      return;
    }
    setState(() {});
  }

  void _finishByClock({required bool loserIsWhite}) {
    if (_clockFinished || !mounted) return;
    _clockFinished = true;
    _battleClockTimer?.cancel();
    _stopBattleBgm();
    if (widget.localBattle) {
      Navigator.of(context).pushReplacement(_resultTransitionRoute(
        LocalBattleResultScreen(winnerIsWhite: !loserIsWhite, showCrownVictory: false),
      ));
      return;
    }
    final playerWon = loserIsWhite != widget.playerIsWhite;
    Navigator.of(context).pushReplacement(_resultTransitionRoute(
      BattleResultScreen(playerWon: playerWon, playerUnit: widget.playerIsWhite ? widget.whiteUnit : widget.blackUnit, showCrownVictory: false, mode: widget.battleMode, onlineCompletionId: widget.battleMode == BattleMode.onlineTest ? _onlineCompletionId : null, testRanged: _testRanged, testMelee: _testMelee, testCapture: _testCapture, testGoryu: _testGoryu || cells.values.any((stack) => stack.any((piece) => piece.isWhite == widget.playerIsWhite && piece.label == "軍")), normalCompletion: true),
    ));
  }

  String _clockText(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  Future<void> _startBattleBgm() async {
    _battleBgmPlayer.onPlayerComplete.listen((_) { if (mounted) _playNextBattleBgm(); });
    await _playNextBattleBgm();
  }

  Future<void> _playNextBattleBgm() async {
    if (_battleBgmQueue.isEmpty) {
      _battleBgmQueue.addAll(_battleBgmPool);
      _battleBgmQueue.shuffle(math.Random());
    }
    final next = _battleBgmQueue.removeLast();
    _battleBgmTitle = next.$1;
    try {
      // 曲切替時に前の再生状態を明示的に解除してから再生する。
      // Androidで次曲名だけ更新され音が開始しないケースを防ぐ。
      await _battleBgmPlayer.stop();
      await _battleBgmPlayer.setReleaseMode(ReleaseMode.stop);
      final f = await _AdditionalData.asset(next.$2);
      await _battleBgmPlayer.play(DeviceFileSource(f.path), volume: _AudioSettings.bgm);
    } catch (_) {}
    if (!mounted) return;
    final g = ++_bgmTitleGeneration;
    setState(() => _showBgmTitle = true);
    await Future<void>.delayed(const Duration(seconds: 4));
    if (!mounted || g != _bgmTitleGeneration) return;
    setState(() => _showBgmTitle = false);
  }

  Future<void> _stopBattleBgm() async {
    try {
      await _battleBgmPlayer.stop();
    } catch (_) {}
  }

  @override
  void dispose() {
    _battleClockTimer?.cancel();
    _mergeBlinkController.dispose();
    _lifeSacrificeMarkerController.dispose();
    _shotThreatController.dispose();
    _turnBannerController.dispose();
    _battleBgmPlayer.dispose();
    _actionSfxPlayer.dispose();
    super.dispose();
  }

  late final Map<int, List<Piece>> cells;
  late final BattleUnit _whiteBattleUnit;
  late final BattleUnit _blackBattleUnit;

  // 格闘後などで、敵駒の上に乗って制圧しているマス。
  final Set<int> suppressedCells = <int>{};

  Piece? _topPieceAt(int index) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return null;
    return stack.last;
  }

  bool _isMergedCell(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    return stack.every((piece) => piece.isWhite == stack.first.isWhite);
  }

  bool _isSuppressedCell(int index) => suppressedCells.contains(index);

  BattleUnit _unitFromInitialPieces(bool isWhite) {
    final labels = widget.initialPieces.values
        .where((piece) => piece.isWhite == isWhite)
        .map((piece) => piece.label)
        .toSet();
    if (labels.any((label) => label.startsWith('神仕')) || labels.contains('三角型飛空城') || labels.contains('円盤型飛空城')) return BattleUnit.master;
    if (labels.contains('王')) return BattleUnit.king;
    if (labels.contains('帝')) return BattleUnit.emperor;
    if (labels.any((label) => const {'槍', '迅', '進', '亜'}.contains(label))) return BattleUnit.strasse;
    return BattleUnit.knight;
  }

  BattleUnit _unitForPiece(Piece piece) =>
      piece.originalIsWhite ? _whiteBattleUnit : _blackBattleUnit;

  bool _isLeaderPiece(Piece piece) {
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => piece.label == '王',
      BattleUnit.knight => piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式',
      BattleUnit.emperor => piece.label == '帝',
      BattleUnit.strasse => false,
      BattleUnit.master => piece.label == '王' || piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式' || piece.label == '帝',
    };
  }

  double? _crownValueForPiece(Piece piece) {
    final unit = _unitForPiece(piece);
    if (unit == BattleUnit.strasse && piece.major && !piece.captured) return 1.0;
    if (unit == BattleUnit.master && !piece.captured) {
      if (piece.label == '生命の像') return 3.0;
      if (const {'王','帝','騎','騎弐式','騎参式'}.contains(piece.label)) return 1.0;
    }
    if (piece.label == '核') return 1.5;
    if (_isLeaderPiece(piece) && !piece.captured) return 1.5;
    return null;
  }

  Color _crownColorForPiece(Piece piece) {
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => const Color(0xFFFFD740),
      BattleUnit.knight => const Color(0xFF42A5F5),
      BattleUnit.emperor => const Color(0xFFFF5252),
      BattleUnit.strasse => const Color(0xFFEEEEEE),
      BattleUnit.master => const Color(0xFFE5E4E2),
    };
  }

  String? _crownAssetForPiece(Piece piece) {
    final crownValue = _crownValueForPiece(piece);
    if (_unitForPiece(piece) == BattleUnit.strasse && crownValue == 1.0) {
      return 'assets/pieces/crown_strasse_1.webp';
    }
    if (_unitForPiece(piece) == BattleUnit.master && (crownValue == 1.0 || crownValue == 3.0)) {
      return 'assets/pieces/crown_master_1.png';
    }
    if (crownValue != 1.5) return null;
    return switch (_unitForPiece(piece)) {
      BattleUnit.king => 'assets/pieces/crown_king_1_5.webp',
      BattleUnit.knight => 'assets/pieces/crown_knight_1_5.webp',
      BattleUnit.emperor => 'assets/pieces/crown_emperor_1_5.webp',
      BattleUnit.strasse => null,
      BattleUnit.master => null,
    };
  }

  String _crownValueText(double value) => value == value.roundToDouble()
      ? value.toInt().toString()
      : value.toStringAsFixed(1);

  double _lostCrownPoints(bool isWhite) {
    final unit = isWhite ? _whiteBattleUnit : _blackBattleUnit;
    if (unit == BattleUnit.master) {
      var lifeAlive = false;
      var masterAlive = 0;
      for (final stack in cells.values) {
        for (final piece in stack) {
          if (piece.originalIsWhite != isWhite || piece.captured) continue;
          if (piece.label == '生命の像') lifeAlive = true;
          if (piece.label == '王' || piece.label == '帝' || piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式') masterAlive++;
        }
      }
      if (!lifeAlive) return 3.0;
      return (3 - masterAlive.clamp(0, 3).toInt()).toDouble();
    }
    if (unit == BattleUnit.strasse) {
      var alive = 0;
      for (final stack in cells.values) {
        for (final piece in stack) {
          if (piece.originalIsWhite == isWhite && !piece.captured && const {'槍', '迅', '進', '亜'}.contains(piece.label)) alive++;
        }
      }
      return (4 - alive.clamp(0, 4).toInt()).toDouble();
    }
    var coresAlive = 0;
    var leaderAlive = false;
    for (final stack in cells.values) {
      for (final piece in stack) {
        if (piece.label == '核' && piece.isWhite == isWhite) coresAlive++;
        if (piece.originalIsWhite != isWhite || piece.captured) continue;
        final isLeader = switch (unit) {
          BattleUnit.king => piece.label == '王',
          BattleUnit.knight => piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式',
          BattleUnit.emperor => piece.label == '帝',
          BattleUnit.strasse => false,
          BattleUnit.master => false,
        };
        if (isLeader) leaderAlive = true;
      }
    }
    final missingCores = 2 - coresAlive.clamp(0, 2).toInt();
    final missingLeader = leaderAlive ? 0 : 1;
    return (missingCores + missingLeader) * 1.5;
  }

  bool _sideHasAnyLegalAction(bool isWhite) {
    // 兵ストックから投入できるなら行動あり。
    if (_soldierCaptureEnabled && _soldierStockFor(isWhite) > 0 && _soldierDeploymentTargets(isWhite).isNotEmpty) {
      return true;
    }

    for (var i = 0; i < 35; i++) {
      final stack = cells[i];
      if (stack == null || stack.isEmpty) continue;
      final top = stack.last;
      if (top.isWhite != isWhite) continue;

      // 発動可能な生命の像があれば行動あり。
      if (top.label == '生命の像') {
        if (top.isWhite == whiteTurn && _canUseLifeStatueAt(i)) return true;
        continue;
      }

      // 発動可能な核が1つでもあれば行動あり。
      if (top.label == '核') {
        if (_canActivateCoreAt(i)) return true;
        continue;
      }

      // 制圧中の上側は「制圧破壊」が可能。
      if (_isSuppressedCell(i)) return true;

      // 騎は変形そのものが1行動なので、どの形態でも行動あり。
      if (_isKnightForm(top)) return true;

      // 通常移動・合流・敵への行動のどれかがあれば行動あり。
      if (_moveTargetsFor(i).isNotEmpty ||
          _mergeTargetsFor(i).isNotEmpty ||
          _enemyTargetsFor(i).isNotEmpty) {
        return true;
      }
    }
    return false;
  }

  void _scheduleNoLegalActionFinishIfNeeded() {
    if (widget.trainingMode) return;
    if (_noLegalActionFinishScheduled ||
        _placingStockSoldier ||
        _pendingRevivalPiece != null ||
        _rapidFireStep != 0 ||
        _accelerationStep != 0) {
      return;
    }
    if (_lostCrownPoints(true) >= 3.0 || _lostCrownPoints(false) >= 3.0) return;
    if (_sideHasAnyLegalAction(whiteTurn)) return;

    _noLegalActionFinishScheduled = true;
    final loserIsWhite = whiteTurn;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _stopBattleBgm();
      if (widget.localBattle) {
        Navigator.of(context).pushReplacement(
          _resultTransitionRoute(LocalBattleResultScreen(
            winnerIsWhite: !loserIsWhite,
            showCrownVictory: false,
          )),
        );
        return;
      }
      final playerWon = loserIsWhite != widget.playerIsWhite;
      Navigator.of(context).pushReplacement(
        _resultTransitionRoute(BattleResultScreen(
          playerWon: playerWon,
          playerUnit: widget.playerIsWhite ? widget.whiteUnit : widget.blackUnit,
          showCrownVictory: false,
          mode: widget.battleMode,
          onlineCompletionId: widget.battleMode == BattleMode.onlineTest ? _onlineCompletionId : null, testRanged: _testRanged, testMelee: _testMelee, testCapture: _testCapture, testGoryu: _testGoryu || cells.values.any((stack) => stack.any((piece) => piece.isWhite == widget.playerIsWhite && piece.label == "軍")),
          normalCompletion: true,
        )),
      );
    });
  }

  bool _maybeFinishBattle() {
    final whiteDefeated = _lostCrownPoints(true) >= 3.0;
    final blackDefeated = _lostCrownPoints(false) >= 3.0;
    if (!whiteDefeated && !blackDefeated) return false;

    if (widget.trainingMode) {
      if (blackDefeated && _trainingStage >= 51 && _trainingStage < 53) {
        _trainingStage = 53;
        if (mounted) setState(() => whiteTurn = true);
        _trainingSpeak('これで王冠3つを獲得。ゲームに勝利したという訳だ。', next: true, crownArrow: true);
      }
      return true;
    }

    final winnerIsWhite = blackDefeated && !whiteDefeated;
    _accelerationStep = 0;
    _rapidFireStep = 0;
    selectedIndex = null;
    if (!mounted) return true;
    _stopBattleBgm();
    if (widget.localBattle) {
      Navigator.of(context).pushReplacement(
        _resultTransitionRoute(LocalBattleResultScreen(winnerIsWhite: winnerIsWhite)),
      );
      return true;
    }
    final playerWon = winnerIsWhite == widget.playerIsWhite;
    Navigator.of(context).pushReplacement(
      _resultTransitionRoute(BattleResultScreen(playerWon: playerWon, playerUnit: widget.playerIsWhite ? widget.whiteUnit : widget.blackUnit, mode: widget.battleMode, onlineCompletionId: widget.battleMode == BattleMode.onlineTest ? _onlineCompletionId : null, testRanged: _testRanged, testMelee: _testMelee, testCapture: _testCapture, testGoryu: _testGoryu || cells.values.any((stack) => stack.any((piece) => piece.isWhite == widget.playerIsWhite && piece.label == "軍")), normalCompletion: true)),
    );
    return true;
  }

  // 上方向を「前」とした白側用の相対座標。
  // 2026-09-22確定版：KNIGHT / KING / EMPEROR 全12大駒＋兵系。
  static const Map<String, List<List<int>>> lv1MoveOffsets = {
    '兵': [
      [-1, 0], [1, 0], [0, -1], [0, 1],
    ],
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0],
    ],
    '軍': [
      [-2,-1], [-2,0], [-2,1],
      [-1,-1], [-1,1],
      [1,0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '護': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
    ],
    '帝': [
      [-2, 0],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, 0],
      [2, 0],
    ],
    '槍': [[-2,-1],[-2,0],[-2,1],[1,-2],[1,2]],
    '迅': [[-1,-1],[-1,0],[-1,1],[1,-1],[1,1]],
    '進': [[-2,-2],[-2,-1],[-2,1],[-2,2],[1,0]],
    '亜': [[-1,-1],[-1,0],[-1,1],[1,-1],[1,1]],
    '神仕象': [[-1,0],[1,0],[0,-1],[0,1]],
    '神仕象2': [[-1,0],[1,0],[0,-1],[0,1]],
    '神仕獣': [[-1,0],[1,0],[0,-1],[0,1]],
    '神仕獣2': [[-1,0],[1,0],[0,-1],[0,1]],
    '飛空城': [[-1,0],[0,-1],[0,1],[1,-1],[1,0],[1,1]],
    '三角型飛空城': [[-2,0],[-1,-1],[-1,0],[-1,1],[0,-2],[0,2],[1,0]],
    '円盤型飛空城': [[-2,-1],[-2,0],[-2,1],[-1,0],[0,-1],[0,1],[1,0]],
    '生命の像': <List<int>>[],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv2MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -1], [0, 1],
      [1, 0],
    ],
    '軍': [
      [-2,-1], [-2,0], [-2,1],
      [-1,-1], [-1,1],
      [0,-1], [0,1],
      [1,0],
    ],
    '王': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '槍': [[-2,-1],[-2,0],[-2,1],[1,-2],[1,2],[2,-1],[2,1]],
    '迅': [[-1,-1],[-1,0],[-1,1],[1,-1],[1,1],[2,-2],[2,2]],
    '進': [[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[1,0],[2,0]],
    '亜': [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,1]],
    '核': <List<int>>[],
  };

  static const Map<String, List<List<int>>> lv3MoveOffsets = {
    '騎': [
      [-2, -2], [-2, 0], [-2, 2],
      [-1, 0],
      [0, -2], [0, 2],
      [1, 0],
      [2, -2], [2, 0], [2, 2],
    ],
    '博': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, -1], [1, 1],
    ],
    '将': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -2], [1, 2],
      [2, 0],
    ],
    '官': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, -1], [0, 1], [0, 2],
      [1, 0],
    ],
    '軍': [
      [-2,-1], [-2,0], [-2,1],
      [-1,-1], [-1,1],
      [0,-2], [0,-1], [0,1], [0,2],
      [1,0],
    ],
    '王': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [0, -2], [0, 2],
      [1, 0],
    ],
    '仕': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, -1], [-1, 1], [-1, 2],
      [1, -1], [1, 1],
      [2, 0],
    ],
    '護': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 1],
      [1, -1], [1, 0], [1, 1],
    ],
    '闘': [
      [-2, -1], [-2, 1],
      [-1, -1], [-1, 0], [-1, 1],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
    ],
    '帝': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -2], [0, 2],
      [1, -1], [1, 1],
    ],
    '砲': [
      [-2, -2], [-2, -1], [-2, 0], [-2, 1], [-2, 2],
      [-1, -1], [-1, 0], [-1, 1],
      [1, 0], [2, 0],
    ],
    '剣': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, -2], [-1, 0], [-1, 2],
      [0, -1], [0, 1],
      [1, 0], [2, 0],
    ],
    '盾': [
      [-2, -1], [-2, 0], [-2, 1],
      [-1, 0],
      [0, -2], [0, 2],
      [1, -1], [1, 0], [1, 1],
      [2, 0],
    ],
    '槍': [[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],
    '迅': [[-2,-2],[-2,2],[-1,-1],[-1,0],[-1,1],[1,-1],[1,1],[2,-2],[2,2]],
    '進': [[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[-1,-1],[-1,1],[1,0],[2,0]],
    '亜': [[-1,-2],[-1,-1],[-1,0],[-1,1],[-1,2],[0,-1],[0,1],[1,-1],[1,1]],
    '核': <List<int>>[],
  };

  static const List<List<int>> mergedSoldierOffsets = [
    [-2, 0], [-1, 0],
    [0, -2], [0, -1], [0, 1], [0, 2],
    [1, 0], [2, 0],
  ];

  static const List<List<int>> frontlineSoldierOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  // 騎の変形形態はLv/Puの影響を受けない固定行動範囲。
  static const List<List<int>> knightSecondOffsets = [
    [-1, -1], [-1, 0], [-1, 1],
    [0, -1], [0, 1],
    [1, -1], [1, 0], [1, 1],
  ];

  static const List<List<int>> knightThirdOffsets = [
    [-2, -1], [-2, 1],
    [-1, -2], [-1, -1], [-1, 1], [-1, 2],
    [1, -1], [1, 1],
  ];

  bool _isKnightForm(Piece piece) =>
      piece.label == '騎' || piece.label == '騎弐式' || piece.label == '騎参式';

  bool _isFixedKnightForm(Piece piece) =>
      piece.label == '騎弐式' || piece.label == '騎参式';

  bool _isFrontlineForPiece(int index, Piece piece) {
    final row = index ~/ 5;
    // 白は下側から上へ進軍、黒は上側から下へ進軍。
    // 相手側3列に入ったら前線パンプ +1。
    return piece.isWhite ? row <= 2 : row >= 4;
  }

  bool _hasFrontlineMergeForSide(bool isWhite) {
    for (final entry in cells.entries) {
      final index = entry.key;
      if (!_isMergedCell(index)) continue;
      final top = _topPieceAt(index);
      if (top == null || top.isWhite != isWhite) continue;
      if (_isFrontlineForPiece(index, top)) return true;
    }
    return false;
  }

  int _pumpForPieceAt(int index, Piece piece, {bool? mergedOverride}) {
    if (_isKuru(piece)) return 0;
    final soldierLike = piece.label == '兵' || piece.label.startsWith('神仕') ||
        const {'飛空城','三角型飛空城','円盤型飛空城'}.contains(piece.label);
    if ((!piece.major && !soldierLike) || _isFixedKnightForm(piece) || (!soldierLike && piece.level >= 3)) return 0;

    final roomToLevel3 = soldierLike ? 2 : 3 - piece.level;

    // 味方のどこかで「前線＋合流」が成立している間は、
    // 味方大駒全体を最大（実効Lv3）までパンプする。
    if (_hasFrontlineMergeForSide(piece.isWhite)) return roomToLevel3;

    final merged = mergedOverride ?? _isMergedCell(index);
    var pump = 0;
    if (merged) pump++;
    if (_isFrontlineForPiece(index, piece)) pump++;
    return pump > roomToLevel3 ? roomToLevel3 : pump;
  }

  int _effectiveLevelForPieceAt(int index, Piece piece, {bool? mergedOverride}) {
    if (_isKuru(piece)) return 1;
    if (!piece.major || _isFixedKnightForm(piece)) return piece.level;
    final pump = _pumpForPieceAt(index, piece, mergedOverride: mergedOverride);
    final effective = piece.level + pump;
    return effective > 3 ? 3 : effective;
  }

  List<List<int>> _levelOffsetsFor(String label, int level) {
    if (level >= 3) {
      return lv3MoveOffsets[label] ?? lv2MoveOffsets[label] ?? lv1MoveOffsets[label] ?? const <List<int>>[];
    }
    if (level == 2) {
      return lv2MoveOffsets[label] ?? lv1MoveOffsets[label] ?? const <List<int>>[];
    }
    return lv1MoveOffsets[label] ?? const <List<int>>[];
  }

  List<List<int>> _moveOffsetsFor(int index, Piece piece, {bool? mergedOverride}) {
    if (_isKuru(piece)) {
      final base = piece.label == '騎弐式'
          ? knightSecondOffsets
          : piece.label == '騎参式'
              ? knightThirdOffsets
              : _levelOffsetsFor(piece.label, 1);
      final combined = <String, List<int>>{for (final o in base) '${o[0]},${o[1]}': o};
      // クル共通追加2マス。白基準で2マス前方の左右。黒は下の座標変換で反転する。
      for (final o in const <List<int>>[[-2, -2], [-2, 2]]) {
        combined['${o[0]},${o[1]}'] = o;
      }
      return combined.values.toList(growable: false);
    }
    if (piece.label == '騎弐式') return knightSecondOffsets;
    if (piece.label == '騎参式') return knightThirdOffsets;

    final merged = mergedOverride ?? _isMergedCell(index);
    final frontline = _isFrontlineForPiece(index, piece);

    final isDivineServant = piece.label.startsWith('神仕');
    final isAirCastle = const {'飛空城','三角型飛空城','円盤型飛空城'}.contains(piece.label);
    if (piece.label == '兵' || isDivineServant || isAirCastle) {
      // 兵・神仕・飛空城シリーズはLv成長なし。パンプ効率は兵と同じ。

      // 前線効果（または味方の前線合流による全体パンプ）= 3x3、
      // 合流効果 = 十字2。両方ある場合は効果を合成する。
      final teamMaxPump = _hasFrontlineMergeForSide(piece.isWhite);
      final hasFrontlineEffect = frontline || teamMaxPump;

      final base = lv1MoveOffsets[piece.label] ?? lv1MoveOffsets['兵'] ?? const <List<int>>[];
      if (isAirCastle) {
        final combined = <String, List<int>>{for (final o in base) '${o[0]},${o[1]}': o};
        if (hasFrontlineEffect) {
          for (final o in frontlineSoldierOffsets) combined['${o[0]},${o[1]}'] = o;
        }
        if (merged) {
          for (final o in mergedSoldierOffsets) combined['${o[0]},${o[1]}'] = o;
        }
        return combined.values.toList(growable: false);
      }
      if (hasFrontlineEffect && merged) {
        final combined = <String, List<int>>{};
        for (final offset in frontlineSoldierOffsets) combined['${offset[0]},${offset[1]}'] = offset;
        for (final offset in mergedSoldierOffsets) combined['${offset[0]},${offset[1]}'] = offset;
        return combined.values.toList(growable: false);
      }
      if (hasFrontlineEffect) return frontlineSoldierOffsets;
      if (merged) return mergedSoldierOffsets;
      return base;
    }

    final effectiveLevel = _effectiveLevelForPieceAt(index, piece, mergedOverride: merged);
    return _levelOffsetsFor(piece.label, effectiveLevel);
  }

  Set<int> _actionSquaresFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Set<int> _airCastleInspectionSquaresFor(int index, Piece piece) {
    final offsets = lv1MoveOffsets[piece.label] ?? const <List<int>>[];
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};
    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Set<int> _stageActionSquaresFor(int index, int stage) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};
    // 飛空城シリーズも表示側では他の駒と同じ段階表示経路を通す。
    // Lv成長を持たないため、現在の実行動範囲を1段階目として扱う。
    if (_isAirCastlePiece(piece)) return stage == 1 ? _actionSquaresFor(index) : const <int>{};
    if (!piece.major || _isFixedKnightForm(piece)) return const <int>{};
    // クル搭乗中はLv/Puを完全に捨てるため、将来Lvの黄/赤レンジを表示しない。
    // 現在使える「基礎範囲＋クル共通2マス」だけを1段階目（青）として表示する。
    if (_isKuru(piece)) {
      return stage == 1 ? _actionSquaresFor(index) : const <int>{};
    }
    // 色は「現在のPu」ではなく、その駒本来の1/2/3段階目を常に示す。
    // 前線合流の全体パンプや合流パンプをここへ混ぜると全マスが青になるため、
    // intrinsic offsets を直接使う。
    final offsets = _levelOffsetsFor(piece.label, stage.clamp(1, 3));
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};
    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Set<int> _futureLevelActionSquaresFor(int index, int level) {
    final piece = _topPieceAt(index);
    if (piece == null || !piece.major || _isAirCastlePiece(piece) || _isFixedKnightForm(piece) || piece.level >= level) return const <int>{};
    final future = piece.copyWith(level: level);
    return _actionSquaresForPieceAt(index, future, merged: _isMergedCell(index));
  }

  bool _isStrassePiece(Piece piece) => const {'槍', '迅', '進', '亜'}.contains(piece.label);
  bool _isAirCastlePiece(Piece piece) => const {'飛空城','三角型飛空城','円盤型飛空城'}.contains(piece.label);
  String _displayPieceLabel(Piece piece) => piece.label.startsWith('神仕') ? '神仕' : piece.label;


  Set<int> _enemyTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    return _actionSquaresFor(index).where((target) {
      final targetPiece = _topPieceAt(target);
      return targetPiece != null && targetPiece.isWhite != piece.isWhite;
    }).toSet();
  }

  bool _isContested(int attackerIndex, int targetIndex) {
    final attacker = _topPieceAt(attackerIndex);
    final target = _topPieceAt(targetIndex);
    if (attacker == null || target == null) return false;
    // STRASSEは射撃を持たないため、射撃の拮抗には参加しない。
    if (_isStrassePiece(attacker) || _isStrassePiece(target)) return false;
    return _actionSquaresFor(targetIndex).contains(attackerIndex);
  }

  Set<int> _actionSquaresForPieceAt(int index, Piece piece, {bool merged = false}) {
    final offsets = _moveOffsetsFor(index, piece, mergedOverride: merged);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};
    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      targets.add(nr * 5 + nc);
    }
    return targets;
  }

  Piece _pieceAfterKillLevelUp(Piece piece) {
    if (_isKuru(piece)) return piece;
    if (piece.label.startsWith('神仕') || const {'飛空城','三角型飛空城','円盤型飛空城'}.contains(piece.label)) return piece;
    if (!piece.major || piece.level >= 3) return piece;
    return piece.copyWith(level: piece.level + 1);
  }

  bool get _soldierCaptureEnabled {
    const basics = <BattleUnit>{BattleUnit.king, BattleUnit.knight, BattleUnit.emperor};
    return basics.contains(widget.whiteUnit) && basics.contains(widget.blackUnit);
  }

  void _recordDestroyedPiece(Piece piece) {
    if (piece.label == '兵') {
      if (_soldierCaptureEnabled) {
        // 倒された兵は「倒した側」のストックになる。
        if (piece.isWhite) {
          _blackSoldierStock++;
        } else {
          _whiteSoldierStock++;
        }
      }
      return;
    }
    if (!piece.major && !piece.label.startsWith('神仕')) return;
    // 大駒と神仕は現在の所属や鹵獲状態に関係なく、破壊されたら必ず本来の持ち主へ戻す。
    final originalSideAsset = _capturedAssetForSide(piece.asset, piece.originalIsWhite);
    final returnedPiece = piece.copyWith(
      asset: originalSideAsset,
      isWhite: piece.originalIsWhite,
      captured: false,
    );
    (piece.originalIsWhite ? _whiteDestroyedMajors : _blackDestroyedMajors)
        .add(returnedPiece);
  }

  bool _isLifeStatueReadyAt(int index) {
    final stack = cells[index];
    return stack != null && stack.length == 1 && stack.single.label == '生命の像' &&
        stack.single.isWhite == whiteTurn;
  }

  List<Piece> _destroyedDivineServants(bool isWhite) =>
      _destroyedMajorsFor(isWhite).where((p) => p.label.startsWith('神仕')).toList();

  List<Piece> _destroyedMasterPieces(bool isWhite) => _destroyedMajorsFor(isWhite)
      .where((p) => const {'王','帝','騎','騎弐式','騎参式'}.contains(p.label))
      .toList();

  Set<int> _emptyOwnAirCastles(bool isWhite) {
    final result = <int>{};
    for (final entry in cells.entries) {
      final stack = entry.value;
      if (stack.length != 1) continue;
      final p = stack.single;
      if (_isAirCastlePiece(p) && p.isWhite == isWhite && p.originalIsWhite == isWhite && !p.captured) {
        result.add(entry.key);
      }
    }
    return result;
  }

  // 神仕の復活先：復活直後の神仕が敵射撃と拮抗できる飛空城だけ。
  // 復活した神仕は飛空城と合流状態になるため、合流・前線パンプを含む
  // その場の実際の行動範囲で相互射程を判定する。
  Set<int> _safeAirCastlesForServantRevival(Piece servant) {
    final result = <int>{};
    for (final target in _emptyOwnAirCastles(servant.isWhite)) {
      final servantRange = _actionSquaresForPieceAt(target, servant, merged: true);
      var exposedToOneSidedShot = false;
      for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
        final enemy = _topPieceAt(enemyIndex);
        if (enemy == null || enemy.isWhite == servant.isWhite || enemy.label == '核') continue;
        // STRASSEは射撃を持たない。制圧中など射撃不能な駒も脅威に数えない。
        if (_isStrassePiece(enemy) || _isSuppressedCell(enemyIndex)) continue;
        if (!_actionSquaresFor(enemyIndex).contains(target)) continue;
        // 神仕側も敵を範囲に入れていれば拮抗で射撃不可。
        if (servantRange.contains(enemyIndex)) continue;
        exposedToOneSidedShot = true;
        break;
      }
      if (!exposedToOneSidedShot) result.add(target);
    }
    return result;
  }

  // MASTER復活の生贄候補は「盤上で一番上にいる神仕」。
  // 単独だけでなく、合流・制圧・飛空城の上にいる神仕も選べる。
  // 下側にいる神仕は上の駒を飛び越えて選べない。
  List<MapEntry<int, Piece>> _sacrificableDivineServants(bool isWhite, String kind) {
    final result = <MapEntry<int, Piece>>[];
    for (final entry in cells.entries) {
      final stack = entry.value;
      if (stack.isEmpty) continue;
      final p = stack.last;
      if (p.isWhite == isWhite && p.originalIsWhite == isWhite && !p.captured && p.label.startsWith(kind)) {
        result.add(MapEntry(entry.key, p));
      }
    }
    return result;
  }

  bool _isDivineServantRidingAirCastle(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    final top = stack.last;
    final lower = stack[stack.length - 2];
    return top.label.startsWith('神仕') &&
        _isAirCastlePiece(lower) &&
        top.isWhite == lower.isWhite;
  }

  void _removeLifeSacrificeAt(int index) {
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return;
    final sacrifice = stack.last;
    _recordDestroyedPiece(sacrifice);
    stack.removeLast();
    if (stack.isEmpty) {
      cells.remove(index);
    } else {
      cells[index] = stack;
    }
    // 制圧の上側を生贄にした場合は、下側を残して制圧解除。
    suppressedCells.remove(index);
    lowerInfoCells.remove(index);
  }

  bool _canUseLifeStatueAt(int index) {
    if (!_isLifeStatueReadyAt(index) || _pendingRevivalPiece != null ||
        _rapidFireStep != 0 || _accelerationStep != 0 || _flightSkillStep != 0 || _strasseSkillStep != 0) return false;
    final side = cells[index]!.single.isWhite;
    final emptyAirCastles = _emptyOwnAirCastles(side);
    final canServant = emptyAirCastles.isNotEmpty &&
        _destroyedDivineServants(side).any((p) => _safeAirCastlesForServantRevival(p).isNotEmpty);
    final elephant = _sacrificableDivineServants(side, '神仕象');
    final beast = _sacrificableDivineServants(side, '神仕獣');
    final canFreeAirCastleBySacrifice = <MapEntry<int, Piece>>[...elephant, ...beast]
        .any((e) => _isDivineServantRidingAirCastle(e.key));
    final canMaster = _destroyedMasterPieces(side).isNotEmpty &&
        elephant.isNotEmpty && beast.isNotEmpty &&
        (emptyAirCastles.isNotEmpty || canFreeAirCastleBySacrifice);
    return canServant || canMaster;
  }

  void _startLifeRevival(Piece piece) {
    final targets = _safeAirCastlesForServantRevival(piece);
    if (targets.isEmpty) return;
    setState(() {
      _pendingRevivalCoreIndex = null;
      _pendingRevivalPiece = piece;
      _pendingRevivalTargets = targets;
      selectedIndex = null;
    });
  }

  void _startMasterLifeRevival(Piece piece) {
    final side = piece.isWhite;
    final elephant = _sacrificableDivineServants(side, '神仕象');
    final beast = _sacrificableDivineServants(side, '神仕獣');
    if (elephant.isEmpty || beast.isEmpty) return;

    final hasEmptyAirCastle = _emptyOwnAirCastles(side).isNotEmpty;
    var firstTargets = <int>{
      ...elephant.map((e) => e.key),
      ...beast.map((e) => e.key),
    };
    // 飛空城3機がすべて埋まっている時は、復活場所を必ず作るため
    // 1体目の生贄を「飛空城の上にいる神仕」に限定する。
    if (!hasEmptyAirCastle) {
      firstTargets = firstTargets.where(_isDivineServantRidingAirCastle).toSet();
    }
    if (firstTargets.isEmpty) return;

    setState(() {
      _pendingMasterLifePiece = piece;
      _pendingLifeFirstSacrifice = null;
      _pendingLifeSecondSacrifice = null;
      _pendingLifeSacrificeTargets = firstTargets;
      selectedIndex = null;
    });
  }

  void _handleLifeSacrificeTap(int index) {
    final master = _pendingMasterLifePiece;
    if (master == null) return;

    // 選択済みを再タップしたら解除。2体揃っていなければ決定は出さない。
    if (_pendingLifeFirstSacrifice == index || _pendingLifeSecondSacrifice == index) {
      setState(() {
        if (_pendingLifeSecondSacrifice == index) {
          _pendingLifeSecondSacrifice = null;
        } else {
          _pendingLifeFirstSacrifice = null;
          _pendingLifeSecondSacrifice = null;
        }
        if (_pendingLifeFirstSacrifice == null) {
          final elephant = _sacrificableDivineServants(master.isWhite, '神仕象');
          final beast = _sacrificableDivineServants(master.isWhite, '神仕獣');
          var targets = <int>{...elephant.map((e)=>e.key), ...beast.map((e)=>e.key)};
          if (_emptyOwnAirCastles(master.isWhite).isEmpty) {
            targets = targets.where(_isDivineServantRidingAirCastle).toSet();
          }
          _pendingLifeSacrificeTargets = targets;
        } else {
          final firstPiece = _topPieceAt(_pendingLifeFirstSacrifice!);
          if (firstPiece != null) {
            final wantKind = firstPiece.label.startsWith('神仕象') ? '神仕獣' : '神仕象';
            _pendingLifeSacrificeTargets = _sacrificableDivineServants(master.isWhite, wantKind).map((e)=>e.key).toSet();
          }
        }
      });
      return;
    }

    if (!_pendingLifeSacrificeTargets.contains(index)) return;
    final picked = _topPieceAt(index);
    if (picked == null || !picked.label.startsWith('神仕')) return;

    if (_pendingLifeFirstSacrifice == null) {
      final wantKind = picked.label.startsWith('神仕象') ? '神仕獣' : '神仕象';
      final opposite = _sacrificableDivineServants(master.isWhite, wantKind).map((e) => e.key).toSet();
      if (opposite.isEmpty) return;
      setState(() {
        _pendingLifeFirstSacrifice = index;
        _pendingLifeSecondSacrifice = null;
        _pendingLifeSacrificeTargets = opposite;
      });
      return;
    }

    // 2体目はまだ消さない。両方を紫点滅させ、決定待ちにする。
    setState(() {
      _pendingLifeSecondSacrifice = index;
      _pendingLifeSacrificeTargets = <int>{};
    });
  }

  void _confirmLifeSacrifices() {
    final master = _pendingMasterLifePiece;
    final first = _pendingLifeFirstSacrifice;
    final second = _pendingLifeSecondSacrifice;
    if (master == null || first == null || second == null) return;
    setState(() {
      _removeLifeSacrificeAt(first);
      _removeLifeSacrificeAt(second);
      final targets = _emptyOwnAirCastles(master.isWhite);
      if (targets.isEmpty) return;
      _pendingMasterLifePiece = null;
      _pendingLifeFirstSacrifice = null;
      _pendingLifeSecondSacrifice = null;
      _pendingLifeSacrificeTargets = <int>{};
      _pendingRevivalCoreIndex = null;
      _pendingRevivalPiece = master;
      _pendingRevivalTargets = targets;
      selectedIndex = null;
    });
  }

  void _showLifeReviveCandidates(List<Piece> pieces, {required bool master}) {
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(master ? '復活するMASTERを選択' : '復活する神仕を選択',
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            for (var n = 0; n < pieces.length; n++) ...[
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(sheetContext).pop();
                    master ? _startMasterLifeRevival(pieces[n]) : _startLifeRevival(pieces[n]);
                  },
                  child: Row(children: [
                    SizedBox(width: 44, height: 44, child: Image.asset(pieces[n].asset, fit: BoxFit.contain)),
                    const SizedBox(width: 12),
                    Text(master ? ((pieces[n].label == '騎弐式' || pieces[n].label == '騎参式') ? '騎' : _displayPieceLabel(pieces[n])) : '神仕',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
              const SizedBox(height: 7),
            ],
          ]),
        ),
      ),
    );
  }

  void _showLifeStatueMenu(int index) {
    if (!_isLifeStatueReadyAt(index)) return;
    final side = cells[index]!.single.isWhite;
    final servants = _destroyedDivineServants(side);
    final safeServants = servants.where((p) => _safeAirCastlesForServantRevival(p).isNotEmpty).toList();
    final masters = _destroyedMasterPieces(side);
    final hasAirTarget = _emptyOwnAirCastles(side).isNotEmpty;
    final elephant = _sacrificableDivineServants(side, '神仕象');
    final beast = _sacrificableDivineServants(side, '神仕獣');
    final canFreeAirCastleBySacrifice = <MapEntry<int, Piece>>[...elephant, ...beast]
        .any((e) => _isDivineServantRidingAirCastle(e.key));
    final canMaster = masters.isNotEmpty && elephant.isNotEmpty && beast.isNotEmpty &&
        (hasAirTarget || canFreeAirCastleBySacrifice);
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('生命の像', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: OutlinedButton(
              onPressed: safeServants.isNotEmpty ? () {
                Navigator.of(sheetContext).pop();
                _showLifeReviveCandidates(safeServants, master: false);
              } : null,
              child: Text('神仕を復活  ×${servants.length}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            )),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: OutlinedButton(
              onPressed: canMaster ? () {
                Navigator.of(sheetContext).pop();
                _showLifeReviveCandidates(masters, master: true);
              } : null,
              child: const Text('MASTERを復活', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            )),
          ]),
        ),
      ),
    );
  }

  int _soldierStockFor(bool isWhite) => isWhite ? _whiteSoldierStock : _blackSoldierStock;

  Set<int> _soldierDeploymentTargets(bool isWhite) {
    final result = <int>{};
    for (var i = 0; i < 35; i++) {
      final row = i ~/ 5;
      final inOwnFourRows = isWhite ? row >= 3 : row <= 3;
      if (!inOwnFourRows) continue;
      final stack = cells[i];
      if (stack == null || stack.isEmpty) result.add(i);
    }
    return result;
  }

  void _startStockSoldierDeployment() {
    if (_rapidFireStep != 0 || _accelerationStep != 0 || _pendingRevivalPiece != null) return;
    if (_soldierStockFor(whiteTurn) <= 0) return;
    final targets = _soldierDeploymentTargets(whiteTurn);
    if (targets.isEmpty) return;
    setState(() {
      selectedIndex = null;
      lowerInfoCells.clear();
      _placingStockSoldier = true;
      _stockSoldierTargets = targets;
    });
  }

  void _placeStockSoldier(int index) {
    if (!_placingStockSoldier || !_stockSoldierTargets.contains(index)) return;
    final side = whiteTurn;
    if (_soldierStockFor(side) <= 0) return;
    setState(() {
      final asset = side ? 'assets/pieces/white_soldier.png' : 'assets/pieces/black_soldier.png';
      cells[index] = [Piece(asset, '兵', isWhite: side)];
      if (side) {
        _whiteSoldierStock--;
      } else {
        _blackSoldierStock--;
      }
      _placingStockSoldier = false;
      _stockSoldierTargets = <int>{};
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });
    _maybeFinishBattle();
  }

  List<Piece> _destroyedMajorsFor(bool isWhite) =>
      isWhite ? _whiteDestroyedMajors : _blackDestroyedMajors;

  Set<int> _revivalTargetsFor(bool isWhite) {
    final result = <int>{};
    for (var i = 0; i < 35; i++) {
      final row = i ~/ 5;
      final inOwnFourRows = isWhite ? row >= 3 : row <= 3;
      if (!inOwnFourRows) continue;
      final stack = cells[i];
      if (stack == null || stack.isEmpty) {
        result.add(i);
        continue;
      }
      if (stack.length < 2 && stack.last.isWhite == isWhite) {
        result.add(i);
      }
    }
    return result;
  }

  List<MapEntry<int, Piece>> _lv3Candidates(bool isWhite) {
    final result = <MapEntry<int, Piece>>[];
    for (final entry in cells.entries) {
      final stack = entry.value;
      if (stack.isEmpty) continue;
      for (final piece in stack) {
        if (piece.isWhite == isWhite && piece.major && piece.level < 3 && !_isKuru(piece)) {
          result.add(MapEntry(entry.key, piece));
        }
      }
    }
    return result;
  }

  bool _isLeaderAlive(bool isWhite) {
    for (final stack in cells.values) {
      for (final piece in stack) {
        // A captured enemy crown piece changes current control side (isWhite),
        // but it must not masquerade as this side's original living leader.
        if (piece.originalIsWhite == isWhite && !piece.captured && _isLeaderPiece(piece)) return true;
      }
    }
    return false;
  }

  bool _coreEffectKeepsBattleAlive(Piece core, {Piece? revivedPiece}) {
    var projectedLost = _lostCrownPoints(core.isWhite) + 1.5;
    if (revivedPiece != null &&
        _isLeaderPiece(revivedPiece) &&
        !_isLeaderAlive(core.isWhite)) {
      projectedLost -= 1.5;
    }
    return projectedLost < 3.0;
  }

  List<Piece> _validRevivalPiecesForCore(Piece core) {
    if (_revivalTargetsFor(core.isWhite).isEmpty) return const <Piece>[];
    return _destroyedMajorsFor(core.isWhite)
        .where((piece) => _coreEffectKeepsBattleAlive(core, revivedPiece: piece))
        .toList();
  }

  bool _canActivateCoreAt(int index) {
    if (_accelerationStep != 0 || _rapidFireStep != 0 || _pendingRevivalPiece != null) return false;
    final stack = cells[index];
    if (stack == null || stack.length != 1) return false;
    final core = stack.single;
    if (core.label != '核' || core.isWhite != whiteTurn) return false;
    final canRevive = _validRevivalPiecesForCore(core).isNotEmpty;
    final canLv3 = _coreEffectKeepsBattleAlive(core) && _lv3Candidates(core.isWhite).isNotEmpty;
    return canRevive || canLv3;
  }

  void _consumeCore(int index) {
    _beginCoreBurst(index);
    final stack = cells[index];
    if (stack == null || stack.length != 1 || stack.single.label != '核') return;
    cells.remove(index);
    lowerInfoCells.remove(index);
    selectedIndex = null;
  }

  void _startRevival(int coreIndex, Piece piece) {
    final targets = _revivalTargetsFor(piece.isWhite);
    if (targets.isEmpty) return;
    setState(() {
      _pendingRevivalCoreIndex = coreIndex;
      _consumeCore(coreIndex);
      _pendingRevivalPiece = piece;
      _pendingRevivalTargets = targets;
    });
  }

  Future<void> _placeRevivedPiece(int index) async {
    final piece = _pendingRevivalPiece;
    if (piece == null || !_pendingRevivalTargets.contains(index)) return;
    final revivedPiece =
        (piece.label == '騎弐式' || piece.label == '騎参式')
            ? _knightFormPiece(piece, '騎')
            : piece;
    final coreIndex = _pendingRevivalCoreIndex;
    final generation = ++_coreEffectGeneration;
    setState(() {
      _coreEffectIndex = index;
      _coreEffectPiece = revivedPiece;
      _coreEffectOldLevel = null;
      _coreEffectIsRevival = true;
      _coreLinkFrom = coreIndex;
      _coreLinkTo = index;
      _coreLinkGeneration++;
      selectedIndex = null;
    });

    // 光の輪と輪郭を先に見せ、途中から実体化する。
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      final stack = cells[index];
      if (stack == null || stack.isEmpty) {
        cells[index] = [revivedPiece];
      } else {
        // 既存仕様どおり、味方駒の上への復活＝合流をそのまま維持する。
        stack.add(revivedPiece);
        cells[index] = stack;
      }
      _destroyedMajorsFor(piece.isWhite).remove(piece);
      _pendingRevivalPiece = null;
      _pendingRevivalTargets = <int>{};
      _pendingRevivalCoreIndex = null;
    });
    await Future<void>.delayed(const Duration(milliseconds: 600));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      _coreEffectIndex = null;
      _coreEffectPiece = null;
      _coreEffectIsRevival = false;
      _coreLinkFrom = null;
      _coreLinkTo = null;
      whiteTurn = !whiteTurn;
    });
    _maybeFinishBattle();
  }

  Future<void> _applyInstantLv3(int coreIndex, int targetIndex, Piece targetPiece) async {
    final oldLevel = targetPiece.level;
    final generation = ++_coreEffectGeneration;
    setState(() {
      _consumeCore(coreIndex);
      _coreEffectIndex = targetIndex;
      _coreEffectPiece = targetPiece;
      _coreEffectOldLevel = oldLevel;
      _coreEffectIsRevival = false;
      _coreLinkFrom = coreIndex;
      _coreLinkTo = targetIndex;
      _coreLinkGeneration++;
    });

    // 核から対象へ光が走り、旧Lvが抜けてからLv3へ切り替える。
    await Future<void>.delayed(const Duration(milliseconds: 760));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      final stack = cells[targetIndex];
      if (stack != null) {
        final pos = stack.indexWhere((p) => identical(p, targetPiece));
        if (pos >= 0) stack[pos] = targetPiece.copyWith(level: 3);
        cells[targetIndex] = stack;
      }
    });
    await Future<void>.delayed(const Duration(milliseconds: 740));
    if (!mounted || generation != _coreEffectGeneration) return;
    setState(() {
      _coreEffectIndex = null;
      _coreEffectPiece = null;
      _coreEffectOldLevel = null;
      _coreLinkFrom = null;
      _coreLinkTo = null;
      whiteTurn = !whiteTurn;
    });
    _maybeFinishBattle();
  }

  Future<void> _trainingSpecialActionReprimand() async {
    if (!widget.trainingMode || !mounted) return;

    // 核・スキルの寄り道を止めた後は「最後の指示」ではなく、
    // その瞬間に表示していたTRAINING会話へ戻す。
    // 例：王をタップした直後（stage 17）のLv説明中にSKILLを押しても、
    // stage 16の「王をタップしてみよう。」へ巻き戻さない。
    final restoreText = _trainingText;
    final restoreCanNext = _trainingCanNext;
    final restoreTarget = _trainingTargetCell;
    final restoreAction = _trainingExpectedAction;
    final restoreShowKing = _trainingShowKingPiece;
    final restoreCrownArrow = _trainingCrownArrow;
    final restoreHighlightFrontline = _trainingHighlightFrontline;
    final restoreActionReady = _trainingActionReady;
    final restoreReviewingInstruction = _trainingReviewingInstruction;
    final g = ++_trainingDialogueGeneration;

    setState(() {
      _trainingText = '指示通りにやれ……。';
      _trainingTyping = false;
      _trainingCanNext = false;
      _trainingReviewingInstruction = false;
    });
    await Future<void>.delayed(const Duration(milliseconds: 850));
    if (!mounted || g != _trainingDialogueGeneration) return;

    if (restoreText != null) {
      _trainingSpeak(
        restoreText,
        next: restoreCanNext,
        targetCell: restoreTarget,
        action: restoreAction,
        showKing: restoreShowKing,
        crownArrow: restoreCrownArrow,
        highlightFrontline: restoreHighlightFrontline,
      );
      return;
    }

    // 会話パネルが閉じていた場合も、進行状態だけを元に戻す。
    setState(() {
      _trainingText = null;
      _trainingTyping = false;
      _trainingCanNext = restoreCanNext;
      _trainingTargetCell = restoreTarget;
      _trainingExpectedAction = restoreAction;
      _trainingShowKingPiece = restoreShowKing;
      _trainingCrownArrow = restoreCrownArrow;
      _trainingActionReady = restoreActionReady;
      _trainingReviewingInstruction = restoreReviewingInstruction;
      _trainingHighlightFrontline = restoreHighlightFrontline;
    });
  }

  bool _trainingRejectSpecialAction(BuildContext sheetContext) {
    if (!widget.trainingMode) return false;
    Navigator.of(sheetContext).pop();
    // 核・スキルの寄り道は止めるだけ。
    // 通常の誤操作用 _trainingReprimand() と違い、
    // TRAININGのステージ・選択駒・対象セルは一切巻き戻さない。
    unawaited(_trainingSpecialActionReprimand());
    return true;
  }

  void _showCoreActivationMenu(int index) {
    if (!_canActivateCoreAt(index)) return;
    final core = cells[index]!.single;
    final destroyed = _validRevivalPiecesForCore(core);
    final canRevive = destroyed.isNotEmpty;
    final lv3 = _coreEffectKeepsBattleAlive(core)
        ? _lv3Candidates(core.isWhite)
        : <MapEntry<int, Piece>>[];
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('核発動', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: canRevive ? () {
                    if (_trainingRejectSpecialAction(sheetContext)) return;
                    Navigator.of(sheetContext).pop();
                    _showRevivePieceMenu(index, destroyed);
                  } : null,
                  child: const Text('大駒を復活', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: lv3.isNotEmpty ? () {
                    if (_trainingRejectSpecialAction(sheetContext)) return;
                    Navigator.of(sheetContext).pop();
                    _showLv3TargetMenu(index, lv3);
                  } : null,
                  child: const Text('大駒を即Lv3', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRevivePieceMenu(int coreIndex, List<Piece> pieces) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('復活する大駒を選択', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final piece in pieces) ...[
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _startRevival(coreIndex, piece);
                    },
                    child: Text(
                      '${(piece.label == '騎弐式' || piece.label == '騎参式') ? '騎' : _displayPieceLabel(piece)}  Lv${piece.level}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      ),
    );
  }

  void _showLv3TargetMenu(int coreIndex, List<MapEntry<int, Piece>> targets) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Lv3にする大駒を選択', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              for (final entry in targets) ...[
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      _applyInstantLv3(coreIndex, entry.key, entry.value);
                    },
                    child: Text('${_displayPieceLabel(entry.value)}  Lv${entry.value.level} → Lv3', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                ),
                const SizedBox(height: 6),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Set<int> _legalRangedTargetsFor(
    int attackerIndex, {
    int? afterRemovingTopAt,
    Piece? attackerOverride,
  }) {
    final attacker = attackerOverride ?? _topPieceAt(attackerIndex);
    if (attacker == null || _isStrassePiece(attacker)) return const <int>{};
    final attackerMerged = _isMergedCell(attackerIndex);
    final inRange = _actionSquaresForPieceAt(attackerIndex, attacker, merged: attackerMerged);
    final result = <int>{};
    for (final target in inRange) {
      Piece? targetPiece;
      bool targetMerged = false;
      if (target == afterRemovingTopAt) {
        final stack = cells[target];
        if (stack != null && stack.length >= 2) {
          targetPiece = stack[stack.length - 2];
          targetMerged = false;
        }
      } else {
        targetPiece = _topPieceAt(target);
        targetMerged = _isMergedCell(target);
      }
      if (targetPiece == null || targetPiece.isWhite == attacker.isWhite) continue;
      // STRASSEは射撃を持たないので、相手がSTRASSEなら拮抗しない。
      if (!_isStrassePiece(targetPiece)) {
        final counterRange = _actionSquaresForPieceAt(target, targetPiece, merged: targetMerged);
        if (counterRange.contains(attackerIndex)) continue;
      }
      result.add(target);
    }
    return result;
  }

  Set<int> _rapidFireFirstTargetsFor(int attackerIndex) {
    final attacker = _topPieceAt(attackerIndex);
    if (attacker == null) return const <int>{};
    final current = _legalRangedTargetsFor(attackerIndex);
    final leveledAfterFirst = _pieceAfterKillLevelUp(attacker);
    return current.where((first) =>
      _legalRangedTargetsFor(
        attackerIndex,
        afterRemovingTopAt: first,
        attackerOverride: leveledAfterFirst,
      ).isNotEmpty
    ).toSet();
  }

  bool _canUseRapidFire(int attackerIndex) => _rapidFireFirstTargetsFor(attackerIndex).isNotEmpty;

  bool _wouldActionDefeatEnemyForGoryu(int attackerIndex, int targetIndex, String action) {
    final attacker = _topPieceAt(attackerIndex);
    if (attacker == null) return false;
    final savedCells = <int, List<Piece>>{
      for (final e in cells.entries) e.key: List<Piece>.from(e.value),
    };
    final savedSuppressed = Set<int>.from(suppressedCells);
    final savedWhiteTurn = whiteTurn;
    try {
      final a = cells[attackerIndex];
      final t = cells[targetIndex];
      if (a == null || a.isEmpty || t == null || t.isEmpty) return false;
      if (action == 'ranged') {
        t.removeLast();
        if (t.isEmpty) cells.remove(targetIndex);
        if (savedSuppressed.contains(targetIndex)) suppressedCells.remove(targetIndex);
      } else if (action == 'suppressDestroy') {
        if (t.length < 2) return false;
        t.removeAt(0);
        cells[targetIndex] = t;
        suppressedCells.remove(targetIndex);
      } else if (action == 'melee') {
        final moving = a.removeLast();
        if (a.isEmpty) cells.remove(attackerIndex);
        t.removeLast();
        if (t.isEmpty) {
          cells[targetIndex] = [moving];
        } else {
          t.add(moving);
          cells[targetIndex] = t;
        }
        suppressedCells.remove(targetIndex);
      } else {
        return false;
      }
      final enemyWhite = !attacker.isWhite;
      whiteTurn = enemyWhite;
      return _lostCrownPoints(enemyWhite) >= 3.0 || !_sideHasAnyLegalAction(enemyWhite);
    } finally {
      cells
        ..clear()
        ..addAll({for (final e in savedCells.entries) e.key: List<Piece>.from(e.value)});
      suppressedCells
        ..clear()
        ..addAll(savedSuppressed);
      whiteTurn = savedWhiteTurn;
    }
  }

  Future<bool> _maybeAwakenGoryuBeforeFinisher(int attackerIndex, int targetIndex, String action) async {
    final attacker = _topPieceAt(attackerIndex);
    if (widget.localBattle || widget.battleMode != BattleMode.onlineTest || _HiddenUnlocks.goryu || !_StoryProgress.isChapter2Unlocked(12) || attacker == null || attacker.label != '官' || attacker.level < 3 ||
        attacker.isWhite != widget.playerIsWhite) return false;
    if (!_wouldActionDefeatEnemyForGoryu(attackerIndex, targetIndex, action)) return false;

    // この時点で勝負を決める一撃は成立済み。変貌～攻撃～勝敗確定を一続きの決着処理にする。
    // 演出中に投了や別操作で豪竜初登場を潰せないよう、ここから入力を固定する。
    if (mounted) setState(() => _goryuFinisherLocked = true);

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black,
      builder: (_) => _GoryuUnlockSequence(isWhite: attacker.isWhite, battleAwakening: true),
    );
    if (!mounted) return false;

    final stack = cells[attackerIndex];
    if (stack == null || stack.isEmpty || stack.last.label != '官') return false;
    final side = attacker.isWhite ? 'white' : 'black';
    setState(() {
      stack[stack.length - 1] = stack.last.copyWith(
        asset: 'assets/pieces/${side}_goryu.webp',
        label: '軍',
      );
      cells[attackerIndex] = stack;
    });
    await _HiddenUnlocks.unlockGoryu(isWhite: attacker.isWhite, showPostBattleReveal: false);
    return true;
  }


  Future<void> _executeGoryuBirthFinish(int attackerIndex, int targetIndex, String action) async {
    // 豪竜が誕生した一戦だけは通常攻撃へ戻さない。
    // 通常台詞・通常射撃/格闘SE・FINAL BLOWを飛ばし、咆哮→白光で決着そのものを飲み込む。
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty || targetStack == null || targetStack.isEmpty) return;
    final attackerIsWhite = attackerStack.last.isWhite;

    if (attackerIsWhite == widget.playerIsWhite) _testGoryu = true;
    setState(() {
      if (action == 'ranged') {
        _testKill(action, attackerIsWhite, targetStack.last);
        _recordDestroyedPiece(targetStack.last);
        targetStack.removeLast();
        if (targetStack.isEmpty) cells.remove(targetIndex); else cells[targetIndex] = targetStack;
        suppressedCells.remove(targetIndex);
      } else if (action == 'suppressDestroy') {
        if (targetStack.length >= 2) {
          _recordDestroyedPiece(targetStack.first);
          targetStack.removeAt(0);
          cells[targetIndex] = targetStack;
          suppressedCells.remove(targetIndex);
        }
      } else if (action == 'melee') {
        final targetWasMerged = _isMergedCell(targetIndex);
        final targetWasSuppressed = _isSuppressedCell(targetIndex);
        final moving = attackerStack.removeLast();
        if (attackerStack.isEmpty) cells.remove(attackerIndex);
        _testKill(action, attackerIsWhite, targetStack.last);
        _recordDestroyedPiece(targetStack.last);
        targetStack.removeLast();
        if (targetWasSuppressed && targetStack.isNotEmpty) {
          targetStack.add(moving);
          cells[targetIndex] = targetStack;
          suppressedCells.remove(targetIndex);
        } else if (targetWasMerged && targetStack.isNotEmpty) {
          targetStack.add(moving);
          cells[targetIndex] = targetStack;
          suppressedCells.add(targetIndex);
        } else {
          cells[targetIndex] = [moving];
          suppressedCells.remove(targetIndex);
        }
      }
      lowerInfoCells.clear();
      selectedIndex = null;
    });

    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.transparent,
      builder: (_) => _GoryuBirthFinishSequence(
        isWhite: attackerIsWhite,
        onWhiteout: () { if (mounted) setState(() => _goryuWhiteout = true); },
      ),
    );
    if (!mounted) return;
    _maybeFinishBattle();
  }


  Future<void> _executeMelee(int attackerIndex, int targetIndex, {bool showDialogue = true, bool endTurn = true}) async {
    final goryuAwakened = await _maybeAwakenGoryuBeforeFinisher(attackerIndex, targetIndex, 'melee');
    if (!mounted) return;
    if (goryuAwakened) {
      await _executeGoryuBirthFinish(attackerIndex, targetIndex, 'melee');
      return;
    }
    final attackerPiece = _topPieceAt(attackerIndex);
    final targetPiece = _topPieceAt(targetIndex);
    // 飛空城シリーズそのものは格闘不可・格闘無効。
    // 飛空城の上に別駒が乗っている場合、topはその別駒なので格闘可能。
    if (attackerPiece == null || targetPiece == null ||
        _isAirCastlePiece(attackerPiece) || _isAirCastlePiece(targetPiece)) return;
    if (showDialogue) await _showPilotDialogueForIndex(attackerIndex, 'melee');
    if (!mounted) return;
    _playActionSfx('audio/se_melee.wav');
    _beginPieceMotion(attackerIndex, targetIndex);
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    final targetWasMerged = _isMergedCell(targetIndex);
    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    final levelBefore = attackerStack.last.level;

    setState(() {
      // 攻撃側は現在いるマスから上の駒だけが格闘に出る。
      // 制圧中の上駒が破壊以外で離れるため、先に下の大駒を鹵獲する。
      final attackerWasSuppressing = _isSuppressedCell(attackerIndex);
      final departingAttacker = attackerStack.last;
      if (attackerWasSuppressing) {
        _captureSuppressedLowerPiece(attackerIndex, departingAttacker.isWhite);
      }
      var attacker = attackerStack.removeLast();
      attacker = _pieceAfterKillLevelUp(attacker);
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      }

      // 敵の上の駒を破壊。
      _testKill("melee", attackerPiece.isWhite, targetStack.last);
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();

      if (targetWasSuppressed && targetStack.isNotEmpty) {
        // 制圧中の上側を格闘で破壊。下の駒は絶対に消さない。
        // 格闘した駒はそのマスへ移動するため、残った下の駒の上へ入る。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.remove(targetIndex);
      } else if (targetWasMerged && targetStack.isNotEmpty) {
        // 合流中の敵への格闘：上だけ破壊し、残った下を制圧。
        targetStack.add(attacker);
        cells[targetIndex] = targetStack;
        suppressedCells.add(targetIndex);
      } else {
        // 通常格闘：敵を破壊し、その敵がいたマスへ移動。
        cells[targetIndex] = [attacker];
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
    });

    if (_maybeFinishBattle()) return;
    final movedAttacker = _topPieceAt(targetIndex);
    if (movedAttacker != null && movedAttacker.level > levelBefore) {
      await _showStatChange(targetIndex, 'Lv', movedAttacker.level, up: true);
    }
    if (!mounted) return;
    if (endTurn) setState(() => whiteTurn = !whiteTurn);

  }

  Future<void> _executeRanged(int attackerIndex, int targetIndex, {bool showDialogue = true}) async {
    final goryuAwakened = await _maybeAwakenGoryuBeforeFinisher(attackerIndex, targetIndex, 'ranged');
    if (!mounted) return;
    if (goryuAwakened) {
      await _executeGoryuBirthFinish(attackerIndex, targetIndex, 'ranged');
      return;
    }
    final rangedAttacker = _topPieceAt(attackerIndex);
    if (rangedAttacker == null || _isStrassePiece(rangedAttacker)) return;
    if (showDialogue) await _showPilotDialogueForIndex(attackerIndex, 'ranged');
    if (!mounted) return;
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;

    // FINAL BLOW: 「帝」または「騎」系の射撃そのものが勝敗を確定させる時だけ。
    // 通常射撃や、同勢力の別駒の射撃では発動しない。
    final targetTop = targetStack.last;
    final crownGain = _crownValueForPiece(targetTop) ?? 0.0;
    final winsByCrown = crownGain > 0 &&
        _lostCrownPoints(targetTop.originalIsWhite) + crownGain >= 3.0;

    // FINAL BLOW の行動不能決着判定は、実盤面の targetStack を絶対に変更しない。
    // 射撃後を表す別スタックだけを一時的に cells へ差し替えて確認し、
    // 判定後は元の参照へ戻す。通常の射撃・破壊処理には一切割り込ませない。
    var winsByNoLegalAction = false;
    if (!winsByCrown) {
      final savedWhiteTurn = whiteTurn;
      final savedTargetStackRef = targetStack;
      final savedSuppressed = suppressedCells.contains(targetIndex);
      final simulatedTargetStack = List<Piece>.from(targetStack)..removeLast();
      try {
        if (simulatedTargetStack.isEmpty) {
          cells.remove(targetIndex);
        } else {
          cells[targetIndex] = simulatedTargetStack;
        }
        if (savedSuppressed) suppressedCells.remove(targetIndex);
        whiteTurn = targetTop.isWhite;
        winsByNoLegalAction = !_sideHasAnyLegalAction(targetTop.isWhite);
      } finally {
        cells[targetIndex] = savedTargetStackRef;
        if (savedSuppressed) {
          suppressedCells.add(targetIndex);
        } else {
          suppressedCells.remove(targetIndex);
        }
        whiteTurn = savedWhiteTurn;
      }
    }
    final winsByThisShot = winsByCrown || winsByNoLegalAction;
    String? finalBlowKind;
    if (winsByThisShot) {
      if (rangedAttacker.label == '帝') {
        finalBlowKind = 'emperor';
      } else if (_isKnightForm(rangedAttacker)) {
        finalBlowKind = 'knight';
      }
    }
    if (finalBlowKind != null) {
      _playActionSfx('audio/se_final_blow.wav');
    } else {
      _playActionSfx('audio/se_ranged.wav');
    }
    _beginShotAnimation(attackerIndex, targetIndex, finalBlowKind: finalBlowKind);
    if (finalBlowKind != null) {
      // 極太ビームを最後まで見せてから撃破・RESULTへ進む。
      await Future<void>.delayed(_finalBlowAnimationDuration);
      if (!mounted) return;
    }

    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    final levelBefore = attackerStack.last.level;

    setState(() {
      // 射撃は攻撃側がその場に残り、敵の上の駒だけを破壊する。
      _testKill("ranged", rangedAttacker.isWhite, targetStack.last);
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();
      attackerStack[attackerStack.length - 1] =
          _pieceAfterKillLevelUp(attackerStack.last);

      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        // 合流中・制圧中とも、下の駒は残す。
        cells[targetIndex] = targetStack;
      }

      // 制圧中の上側が射撃で破壊された場合、下の駒は制圧解除。
      if (targetWasSuppressed) {
        suppressedCells.remove(targetIndex);
      }

      lowerInfoCells.clear();
      selectedIndex = null;
    });

    if (_maybeFinishBattle()) return;
    final rangedAttackerAfter = _topPieceAt(attackerIndex);
    if (rangedAttackerAfter != null && rangedAttackerAfter.level > levelBefore) {
      await _showStatChange(attackerIndex, 'Lv', rangedAttackerAfter.level, up: true);
    }
    if (!mounted) return;
    setState(() => whiteTurn = !whiteTurn);

  }

  String _capturedAssetForSide(String asset, bool isWhite) {
    final side = isWhite ? 'white' : 'black';
    final other = isWhite ? 'black' : 'white';
    var result = asset.replaceFirst('pieces/${other}_', 'pieces/${side}_');
    // MASTER素材は master_xxx_white/black.png という末尾側表記。
    result = result.replaceFirst('_$other.png', '_$side.png');
    result = result.replaceFirst('_$other.webp', '_$side.webp');
    return result;
  }

  bool _captureSuppressedLowerPiece(int index, bool captorIsWhite) {
    if (!_isSuppressedCell(index)) return false;
    final stack = cells[index];
    if (stack == null || stack.length < 2) return false;
    final lower = stack.first;

    // 兵は鹵獲されない。大駒だけを幻波で鹵獲する。
    if (!lower.major || lower.label == '兵') {
      suppressedCells.remove(index);
      return false;
    }

    // 同じユニット同士では鹵獲しない。
    // 制圧自体は成立するが、上の駒が離れた時は下の駒を元の所属のまま残す。
    if (widget.whiteUnit == widget.blackUnit) {
      suppressedCells.remove(index);
      return false;
    }

    // 現物の駒をひっくり返すのと同じ表現：
    // 機体はそのまま、鹵獲した側の白枠/黒枠の駒画像へ切り替える。
    if (captorIsWhite == widget.playerIsWhite && lower.isWhite != captorIsWhite) _testCapture++;
    final capturedAsset = _capturedAssetForSide(lower.asset, captorIsWhite);

    stack[0] = lower.copyWith(
      asset: capturedAsset,
      isWhite: captorIsWhite,
      // 本来の持ち主が取り返した場合は鹵獲状態を解除する。
      captured: captorIsWhite != lower.originalIsWhite,
    );
    cells[index] = stack;
    suppressedCells.remove(index);
    return true;
  }

  Future<void> _executeSuppression(int attackerIndex, int targetIndex, {bool showDialogue = true}) async {
    if (showDialogue) await _showPilotDialogueForIndex(attackerIndex, 'suppress');
    if (!mounted) return;
    _playActionSfx('audio/se_suppression.wav');
    _beginPieceMotion(attackerIndex, targetIndex);
    final attackerStack = cells[attackerIndex];
    final targetStack = cells[targetIndex];
    if (attackerStack == null || attackerStack.isEmpty) return;
    if (targetStack == null || targetStack.isEmpty) return;
    if (_isMergedCell(targetIndex) || _isSuppressedCell(targetIndex)) return;

    setState(() {
      // 制圧側は上の駒だけが対象マスへ移動する。
      // 制圧→別制圧も破壊以外で離れるため、元の下駒を先に鹵獲する。
      final attackerWasSuppressing = _isSuppressedCell(attackerIndex);
      final departingAttacker = attackerStack.last;
      if (attackerWasSuppressing) {
        _captureSuppressedLowerPiece(attackerIndex, departingAttacker.isWhite);
      }
      final attacker = attackerStack.removeLast();
      if (attackerStack.isEmpty) {
        cells.remove(attackerIndex);
      }

      // 敵駒は破壊せず下に残し、その上へ攻撃側を重ねる。
      targetStack.add(attacker);
      cells[targetIndex] = targetStack;
      suppressedCells.add(targetIndex);

      lowerInfoCells.clear();
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

  }


  Future<void> _executeSuppressionDestroy(int index, {bool showDialogue = true}) async {
    final goryuAwakened = await _maybeAwakenGoryuBeforeFinisher(index, index, 'suppressDestroy');
    if (!mounted) return;
    if (goryuAwakened) {
      await _executeGoryuBirthFinish(index, index, 'suppressDestroy');
      return;
    }
    if (showDialogue) await _showPilotDialogueForIndex(index, 'suppressDestroy');
    if (!mounted) return;
    _playActionSfx('audio/se_suppress_destroy.wav');
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    setState(() {
      // 制圧破壊：下にいる敵駒だけを破壊し、制圧側の上駒はその場に残る。
      _recordDestroyedPiece(stack.first);
      stack.removeAt(0);
      stack[stack.length - 1] = _pieceAfterKillLevelUp(stack.last);
      cells[index] = stack;
      suppressedCells.remove(index);

      lowerInfoCells.remove(index);
      selectedIndex = null;
      whiteTurn = !whiteTurn;
    });

    if (_maybeFinishBattle()) return;

  }

  void _showSuppressionDestroyMenu(int index) {
    final stack = cells[index];
    if (stack == null || stack.length < 2) return;
    if (!_isSuppressedCell(index)) return;

    final topPiece = stack.last;
    final bottomPiece = stack.first;
    if (topPiece.isWhite != whiteTurn) return;
    if (bottomPiece.isWhite == topPiece.isWhite) return;

    var actionChosen = false;
    final menuFuture = showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'SUPPRESSION  ${bottomPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () async {
                      actionChosen = true;
                      Navigator.of(sheetContext).pop();
                      if (widget.trainingMode) await Future<void>.delayed(const Duration(milliseconds: 360));
                      await _executeSuppressionDestroy(index, showDialogue: !widget.trainingMode);
                      if (mounted) await _trainingActionCompleted('制圧破壊');
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text('制圧破壊', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    menuFuture.whenComplete(() {
      if (widget.trainingMode && !actionChosen && mounted) {
        _trainingCancelActionMenu();
      }
    });
  }

  bool _trainingActionAllowed(String action) {
    if (!widget.trainingMode || _trainingExpectedAction == null) return true;
    if (_trainingExpectedAction == '攻撃') {
      return action == '格闘' || action == '射撃';
    }
    return _trainingExpectedAction == action;
  }

  void _trainingCancelActionMenu() {
    if (!widget.trainingMode || !mounted) return;

    switch (_trainingStage) {
      case 12:
        _trainingStage = 11;
        break;
      case 21:
        _trainingStage = 20;
        break;
      case 36:
        _trainingStage = 35;
        break;
      case 40:
        _trainingStage = 39;
        break;
      case 46:
        _trainingStage = 45;
        break;
      case 51:
        _trainingStage = 50;
        break;
      default:
        return;
    }

    _trainingExpectedAction = null;
    final instruction = _trainingLastInstruction;
    if (instruction == null) return;
    _trainingSpeak(
      instruction,
      targetCell: _trainingLastTargetCell,
      action: _trainingLastExpectedAction,
      highlightFrontline: _trainingLastHighlightFrontline,
    );
  }

  void _showActionMenu(int attackerIndex, int targetIndex) {
    final attacker = _topPieceAt(attackerIndex);
    final targetPiece = _topPieceAt(targetIndex);
    if (attacker == null) return;
    if (targetPiece == null) return;
    final contested = _isContested(attackerIndex, targetIndex);
    final targetMerged = _isMergedCell(targetIndex);
    final targetSuppressed = _isSuppressedCell(targetIndex);
    var actionChosen = false;

    final menuFuture = showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) {
        Widget actionButton(
          String label, {
          bool enabled = true,
          VoidCallback? onPressed,
        }) {
          final effectiveEnabled = enabled;
          return SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: effectiveEnabled
                  ? (onPressed ??
                      () {
                        Navigator.of(sheetContext).pop();
                      })
                  : null,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: effectiveEnabled ? null : Colors.white38,
                    ),
                  ),
                ],
              ),
            ),
          );
        }

        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'TARGET  ${targetPiece.label}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: Colors.white60,
                  ),
                ),
                const SizedBox(height: 14),
                actionButton(
                  '格闘',
                  enabled: !_isAirCastlePiece(attacker) && !_isAirCastlePiece(targetPiece),
                  onPressed: (_isAirCastlePiece(attacker) || _isAirCastlePiece(targetPiece)) ? null : () {
                    actionChosen = true;
                    Navigator.of(sheetContext).pop();
                    () async {
                      if (widget.trainingMode && !_trainingActionAllowed('格闘')) {
                        await _trainingReprimand(listen: false);
                        return;
                      }
                      if (widget.trainingMode) await Future<void>.delayed(const Duration(milliseconds: 180));
                      await _executeMelee(attackerIndex, targetIndex, showDialogue: !widget.trainingMode);
                      if (mounted) await _trainingActionCompleted('格闘');
                    }();
                  },
                ),
                const SizedBox(height: 8),
                actionButton(
                  contested ? '拮抗' : '射撃',
                  enabled: !contested && !_isStrassePiece(attacker),
                  onPressed: (contested || _isStrassePiece(attacker))
                      ? null
                      : () {
                          actionChosen = true;
                          Navigator.of(sheetContext).pop();
                          () async {
                            if (widget.trainingMode && !_trainingActionAllowed('射撃')) {
                              await _trainingReprimand(listen: false);
                              return;
                            }
                            if (widget.trainingMode) await Future<void>.delayed(const Duration(milliseconds: 180));
                            await _executeRanged(attackerIndex, targetIndex, showDialogue: !widget.trainingMode);
                            if (mounted) await _trainingActionCompleted('射撃');
                          }();
                        },
                ),
                const SizedBox(height: 8),
                actionButton(
                  '制圧',
                  enabled: !targetMerged && !targetSuppressed,
                  onPressed: (targetMerged || targetSuppressed)
                      ? null
                      : () {
                          actionChosen = true;
                          Navigator.of(sheetContext).pop();
                          () async {
                            if (widget.trainingMode && !_trainingActionAllowed('制圧')) {
                              await _trainingReprimand(listen: false);
                              return;
                            }
                            if (widget.trainingMode) await Future<void>.delayed(const Duration(milliseconds: 180));
                            await _executeSuppression(attackerIndex, targetIndex, showDialogue: !widget.trainingMode);
                            if (mounted) await _trainingActionCompleted('制圧');
                          }();
                        },
                ),
              ],
            ),
          ),
        );
      },
    );

    menuFuture.whenComplete(() {
      if (widget.trainingMode && !actionChosen && mounted) {
        _trainingCancelActionMenu();
      }
    });
  }

  Set<int> _moveTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      if (cells.containsKey(target)) continue;
      targets.add(target);
    }
    return targets;
  }

  Set<int> _mergeTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null) return const <int>{};

    final offsets = _moveOffsetsFor(index, piece);
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};

    for (final offset in offsets) {
      final dr = piece.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      final targetStack = cells[target];
      if (targetStack == null || targetStack.isEmpty) continue;
      final targetTop = targetStack.last;
      if (targetTop.isWhite != piece.isWhite) continue;
      if (targetStack.length >= 2) continue;
      targets.add(target);
    }
    return targets;
  }

  void _moveTopPiece({required int from, required int to, required bool merge}) {
    _playActionSfx(merge ? 'audio/se_merge.wav' : 'audio/se_move.wav');
    final sourceStack = cells[from];
    if (sourceStack == null || sourceStack.isEmpty) return;
    final wasSuppressed = _isSuppressedCell(from);
    final movingPiece = sourceStack.last;
    // 通常移動/加速で制圧マスから離れる時は、上を外す前に下の大駒を鹵獲する。
    // 先に removeLast() すると制圧判定が消えてしまい、鹵獲も赤点滅解除も失敗する。
    if (wasSuppressed) {
      _captureSuppressedLowerPiece(from, movingPiece.isWhite);
    }
    sourceStack.removeLast();
    if (sourceStack.isEmpty) {
      cells.remove(from);
    }

    lowerInfoCells.remove(from);
    lowerInfoCells.remove(to);

    if (merge) {
      final targetStack = cells[to] ?? <Piece>[];
      targetStack.add(movingPiece);
      cells[to] = targetStack;
    } else {
      cells[to] = [movingPiece];
    }
  }

  Piece _knightFormPiece(Piece current, String formLabel) {
    final side = current.isWhite ? 'white' : 'black';
    final isMasterKnight = _unitForPiece(current) == BattleUnit.master;
    final asset = isMasterKnight
        ? switch (formLabel) {
            '騎弐式' => 'assets/pieces/master_knight2_${side}.png',
            '騎参式' => 'assets/pieces/master_knight3_${side}.png',
            _ => 'assets/pieces/master_knight_${side}.png',
          }
        : switch (formLabel) {
            '騎弐式' => 'assets/pieces/${side}_knight_2.png',
            '騎参式' => 'assets/pieces/${side}_knight_3.png',
            _ => 'assets/pieces/${side}_knight.png',
          };
    return Piece(
      asset,
      formLabel,
      major: true,
      isWhite: current.isWhite,
      originalIsWhite: current.originalIsWhite,
      captured: current.captured,
      level: current.level,
      pilotId: current.pilotId,
    );
  }

  Future<void> _executeKnightTransform(int index, String formLabel) async {
    if (_knightTransformBusy) return;
    final stack = cells[index];
    if (stack == null || stack.isEmpty) return;
    final current = stack.last;
    if (!_isKnightForm(current) || current.isWhite != whiteTurn) return;

    await _showSkillDialogueForIndex(index, knightTarget: formLabel);
    if (!mounted) return;
    final target = _knightFormPiece(current, formLabel);
    final generation = ++_knightTransformGeneration;
    setState(() {
      _knightTransformBusy = true;
      _knightTransformIndex = index;
      _knightTransformTargetPiece = target;
      selectedIndex = null;
      lowerInfoCells.remove(index);
    });
    _playActionSfx('audio/se_transform.wav');

    Future<void>.delayed(_knightTransformDuration, () {
      if (!mounted || generation != _knightTransformGeneration) return;
      final liveStack = cells[index];
      if (liveStack == null || liveStack.isEmpty) return;
      setState(() {
        liveStack[liveStack.length - 1] = target;
        cells[index] = liveStack;
        _knightTransformBusy = false;
        _knightTransformIndex = null;
        _knightTransformTargetPiece = null;
        whiteTurn = !whiteTurn;
      });
    });
  }

  bool _isRidingAirCastle(int index) {
    final stack = cells[index];
    if (stack == null || stack.length != 2) return false;
    final lower = stack.first;
    final upper = stack.last;
    return _isAirCastlePiece(lower) && !_isAirCastlePiece(upper) &&
        lower.isWhite == upper.isWhite;
  }

  Set<int> _flightTargetsFor(int index) {
    if (!_isRidingAirCastle(index)) return const <int>{};
    final stack = cells[index]!;
    final airCastle = stack.first;
    // 飛空は「下の飛空城そのもの」の行動範囲だけを使う。
    // 上駒との合流による移動拡張は飛空SKILLには持ち込まない。
    // SKILL「飛空」専用。通常の移動計算を通すと前線合流の全体Puや
    // 上下合流判定が混ざるため、飛空城の固有（Lv1）範囲を直接使う。
    // これにより上の駒のLv/Pu/種類も、チーム全体Puも一切影響しない。
    final offsets = lv1MoveOffsets[airCastle.label] ?? const <List<int>>[];
    final row = index ~/ 5;
    final col = index % 5;
    final targets = <int>{};
    for (final offset in offsets) {
      final dr = airCastle.isWhite ? offset[0] : -offset[0];
      final nr = row + dr;
      final nc = col + offset[1];
      if (nr < 0 || nr >= 7 || nc < 0 || nc >= 5) continue;
      final target = nr * 5 + nc;
      if (cells.containsKey(target)) continue;
      targets.add(target);
    }
    return targets;
  }

  bool _canUseFlight(int index) {
    final piece = _topPieceAt(index);
    return piece != null && piece.isWhite == whiteTurn &&
        _isRidingAirCastle(index) && _flightTargetsFor(index).isNotEmpty;
  }

  void _startFlight(int index) {
    if (!_canUseFlight(index)) return;
    setState(() {
      selectedIndex = index;
      _flightSkillStep = 1;
    });
  }

  void _showRiderSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.isWhite != whiteTurn || !_canUseFlight(index)) return;
    final isKing = piece.label == '王';
    final isEmperor = piece.label == '帝';
    final isKnight = _isKnightForm(piece);
    final isStrasse = _isStrassePiece(piece);
    final hasNativeSkill = isKing || isEmperor || isKnight || isStrasse;
    if (!hasNativeSkill) {
      _showFlightSkillMenu(index);
      return;
    }
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('SKILL', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
          const SizedBox(height: 14),
          if (isKing) SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: _canUseRapidFire(index) ? () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _showKingSkillMenu(index); } : null,
            child: Text('連射', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: _canUseRapidFire(index) ? null : Colors.white38)),
          )),
          if (isEmperor) SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: _moveTargetsFor(index).isNotEmpty ? () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _showEmperorSkillMenu(index); } : null,
            child: Text('加速', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: _moveTargetsFor(index).isNotEmpty ? null : Colors.white38)),
          )),
          if (isKnight) SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _showKnightTransformMenu(index); },
            child: const Text('変形', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          )),
          if (isStrasse) SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: (_canUseStrasseMeleeMove(index) || _canUseStrasseMergedMove(index))
                ? () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _showStrasseEscapeSkillMenu(index); } : null,
            child: Text('逃げるが勝ち', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700,
                color: (_canUseStrasseMeleeMove(index) || _canUseStrasseMergedMove(index)) ? null : Colors.white38)),
          )),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _startFlight(index); },
            child: const Text('飛空', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          )),
        ]),
      )),
    );
  }

  void _showFlightSkillMenu(int index) {
    if (!_canUseFlight(index)) return;
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('SKILL', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _startFlight(index); },
            child: const Text('飛空', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          )),
        ]),
      )),
    );
  }

  Set<int> _strasseLegalMeleeTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isStrassePiece(piece)) return const <int>{};
    return _enemyTargetsFor(index).where((target) {
      final targetPiece = _topPieceAt(target);
      return targetPiece != null && !_isAirCastlePiece(targetPiece);
    }).toSet();
  }

  // 逃げるが勝ちの移動は「実際に着地できる空きマス」だけ。
  // 核など占有マスは通常の行動範囲色が見えても、SKILL移動先としては青表示しない。
  Set<int> _strasseEscapeMoveTargetsFor(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isStrassePiece(piece)) return const <int>{};
    return _moveTargetsFor(index).where((target) => !cells.containsKey(target)).toSet();
  }

  bool _canUseStrasseMeleeMove(int index) {
    final piece = _topPieceAt(index);
    return piece != null && _isStrassePiece(piece) && piece.isWhite == whiteTurn &&
        _strasseLegalMeleeTargetsFor(index).isNotEmpty;
  }

  bool _canUseStrasseMergedMove(int index) {
    final piece = _topPieceAt(index);
    return piece != null && _isStrassePiece(piece) && piece.isWhite == whiteTurn && _isMergedCell(index) && _moveTargetsFor(index).isNotEmpty;
  }

  void _startStrasseMeleeMove(int index) {
    if (!_canUseStrasseMeleeMove(index)) return;
    setState(() { selectedIndex = index; _strasseSkillStep = 1; });
  }

  void _startStrasseMergedMove(int index) {
    if (!_canUseStrasseMergedMove(index)) return;
    setState(() { selectedIndex = index; _strasseSkillStep = 3; });
  }

  void _moveMergedStrasseStack(int from, int to) {
    final stack = cells[from];
    if (stack == null || stack.length != 2 || cells.containsKey(to)) return;
    _playActionSfx('audio/se_move.wav');
    cells.remove(from);
    cells[to] = stack;
    suppressedCells.remove(from);
  }

  void _showStrasseSkillMenu(int index) {
    final canMeleeMove = _canUseStrasseMeleeMove(index);
    final canMergedMove = _canUseStrasseMergedMove(index);
    if (!canMeleeMove && !canMergedMove) return;
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('SKILL', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _showStrasseEscapeSkillMenu(index); },
            child: const Text('逃げるが勝ち', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          )),
        ]),
      )),
    );
  }

  void _showStrasseEscapeSkillMenu(int index) {
    final canMeleeMove = _canUseStrasseMeleeMove(index);
    final canMergedMove = _canUseStrasseMergedMove(index);
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('逃げるが勝ち', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: canMeleeMove ? () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _startStrasseMeleeMove(index); } : null,
            child: Text('格闘+移動', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canMeleeMove ? null : Colors.white38)),
          )),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: canMergedMove ? () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _startStrasseMergedMove(index); } : null,
            child: Text('合流×移動', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canMergedMove ? null : Colors.white38)),
          )),
        ]),
      )),
    );
  }

  void _showKnightSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isKnightForm(piece) || piece.isWhite != whiteTurn) return;
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('SKILL', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _showKnightTransformMenu(index); },
            child: const Text('変形', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          )),
        ]),
      )),
    );
  }

  void _showKnightTransformMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || !_isKnightForm(piece) || piece.isWhite != whiteTurn) return;
    final forms = <String>['騎', '騎弐式', '騎参式'].where((form) => form != piece.label).toList();
    showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF111418), showDragHandle: true,
      builder: (sheetContext) => SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('変形', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
          const SizedBox(height: 14),
          for (var n = 0; n < forms.length; n++) ...[
            SizedBox(width: double.infinity, child: OutlinedButton(
              onPressed: () { if (_trainingRejectSpecialAction(sheetContext)) return; Navigator.of(sheetContext).pop(); _executeKnightTransform(index, forms[n]); },
              child: Text('${forms[n]}へ変形', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            )),
            if (n != forms.length - 1) const SizedBox(height: 8),
          ],
        ]),
      )),
    );
  }

  Future<void> _startKingRapidFire(int index) async {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '王' || piece.isWhite != whiteTurn) return;
    if (!_canUseRapidFire(index)) return;
    await _showSkillDialogueForIndex(index);
    if (!mounted) return;
    setState(() {
      selectedIndex = index;
      lowerInfoCells.remove(index);
      _rapidFireStep = 1;
    });
  }

  void _showKingSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '王' || piece.isWhite != whiteTurn) return;
    final canRapid = _canUseRapidFire(index);
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  王', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: canRapid ? () {
                    if (_trainingRejectSpecialAction(sheetContext)) return;
                    Navigator.of(sheetContext).pop();
                    _startKingRapidFire(index);
                  } : null,
                  child: Text('連射', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: canRapid ? null : Colors.white38)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _executeRapidFireShot(int attackerIndex, int targetIndex) {
    _playActionSfx('audio/se_ranged.wav');
    _beginShotAnimation(attackerIndex, targetIndex);
    final targetStack = cells[targetIndex];
    if (targetStack == null || targetStack.isEmpty) return;
    final targetWasSuppressed = _isSuppressedCell(targetIndex);
    setState(() {
      _testKill("ranged", _topPieceAt(attackerIndex)?.isWhite ?? !widget.playerIsWhite, targetStack.last);
      _recordDestroyedPiece(targetStack.last);
      targetStack.removeLast();
      final attackerStack = cells[attackerIndex];
      if (attackerStack != null && attackerStack.isNotEmpty) {
        attackerStack[attackerStack.length - 1] =
            _pieceAfterKillLevelUp(attackerStack.last);
        cells[attackerIndex] = attackerStack;
      }
      if (targetStack.isEmpty) {
        cells.remove(targetIndex);
      } else {
        cells[targetIndex] = targetStack;
      }
      if (targetWasSuppressed) suppressedCells.remove(targetIndex);
      lowerInfoCells.clear();

      if (_rapidFireStep == 1) {
        selectedIndex = attackerIndex;
        _rapidFireStep = 2;
      } else {
        selectedIndex = null;
        _rapidFireStep = 0;
        whiteTurn = !whiteTurn;
      }
    });
    _maybeFinishBattle();
  }

  Future<void> _startEmperorAcceleration(int index) async {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '帝' || piece.isWhite != whiteTurn) return;
    if (_moveTargetsFor(index).isEmpty) return;
    await _showSkillDialogueForIndex(index);
    if (!mounted) return;
    setState(() {
      selectedIndex = index;
      lowerInfoCells.remove(index);
      _accelerationStep = 1;
    });
  }

  void _showEmperorSkillMenu(int index) {
    final piece = _topPieceAt(index);
    if (piece == null || piece.label != '帝' || piece.isWhite != whiteTurn) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111418),
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SKILL  帝', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: Colors.white60)),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: _moveTargetsFor(index).isEmpty ? null : () {
                    if (_trainingRejectSpecialAction(sheetContext)) return;
                    Navigator.of(sheetContext).pop();
                    _startEmperorAcceleration(index);
                  },
                  child: const Text('加速', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  double _cpuTargetValue(Piece piece) {
    final crown = _crownValueForPiece(piece) ?? 0;
    if (crown > 0) return 1000 + crown * 500;
    if (piece.major) return 180 + piece.level * 35;
    return piece.label == '兵' ? 45 : 25;
  }

  double _cpuAdvanceValue(int index, bool isWhite) {
    final row = index ~/ 5;
    return isWhite ? (6 - row).toDouble() : row.toDouble();
  }

  List<(int, int)> _shotThreatPairsForHumanTurn() {
    // 警告は操作中の人間側だけ。ローカル対戦では現在手番側を基準にする。
    if (!_humanCanAct) return const <(int, int)>[];
    final humanSideIsWhite = whiteTurn;
    final pairs = <(int, int)>[];
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == humanSideIsWhite || enemy.label == '核') continue;
      // STRASSEには射撃がないので、射撃警告の攻撃側にはならない。
      if (_isStrassePiece(enemy)) continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      for (final targetIndex in enemyRange) {
        final mine = _topPieceAt(targetIndex);
        if (mine == null || mine.isWhite != humanSideIsWhite) continue;
        // STRASSEは射撃を持たないため、射撃の拮抗には参加しない。
        if (!_isStrassePiece(mine) && _actionSquaresFor(targetIndex).contains(enemyIndex)) continue;
        pairs.add((enemyIndex, targetIndex));
      }
    }
    return pairs;
  }

  // CPUの最優先思想：
  // 1) 勝てる手は他の損得より常に上。
  // 2) 相手の行動範囲に入らず、こちらの行動範囲に相手を入れる。
  // 3) 既に一方的に範囲へ入れられている味方を、タダで取らせない。
  // 合流・前線・核・Lv・スキルは、それ自体ではなく上記を実現する手段として評価する。
  bool _cpuEnemyCanActOn(int index, bool cpuIsWhite, {int? ignoreEnemyAt}) {
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      if (enemyIndex == ignoreEnemyAt) continue;
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == cpuIsWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      if (_actionSquaresFor(enemyIndex).contains(index)) return true;
    }
    return false;
  }

  int _cpuOneSidedThreatCountAgainst(bool sideIsWhite) {
    var count = 0;
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == sideIsWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      for (final target in _actionSquaresFor(enemyIndex)) {
        final ally = _topPieceAt(target);
        if (ally == null || ally.isWhite != sideIsWhite) continue;
        // 相互範囲なら射撃は拮抗。一方的に入れられている駒だけを危険として数える。
        if (!_actionSquaresFor(target).contains(enemyIndex)) count++;
      }
    }
    return count;
  }

  double _cpuInfluenceScoreAt(int index, Piece piece, {required bool mergedAtIndex}) {
    final range = _actionSquaresForPieceAt(index, piece, merged: mergedAtIndex);
    var score = 0.0;
    for (final targetIndex in range) {
      final enemy = _topPieceAt(targetIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite) continue;
      final crown = _crownValueForPiece(enemy) ?? 0;
      score += 180 + _cpuTargetValue(enemy) * .8 + (crown > 0 ? 900 + crown * 350 : 0);
    }
    return score;
  }

  Set<int> _cpuImmediateLossThreatEnemies(bool cpuIsWhite) {
    final result = <int>{};
    final alreadyLost = _lostCrownPoints(cpuIsWhite);
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == cpuIsWhite || enemy.label == '核' || _isSuppressedCell(enemyIndex)) continue;
      for (final targetIndex in _actionSquaresFor(enemyIndex)) {
        final mine = _topPieceAt(targetIndex);
        if (mine == null || mine.isWhite != cpuIsWhite) continue;
        final crown = _crownValueForPiece(mine) ?? 0;
        if (crown > 0 && alreadyLost + crown >= 3.0) {
          result.add(enemyIndex);
          break;
        }
      }
    }
    return result;
  }

  bool _cpuCrownPieceEscapesImmediateLoss(int from, int to, Piece piece) {
    if ((_crownValueForPiece(piece) ?? 0) <= 0) return false;
    final threats = _cpuImmediateLossThreatEnemies(piece.isWhite);
    if (threats.isEmpty) return false;
    final wasThreatened = threats.any((enemyIndex) => _actionSquaresFor(enemyIndex).contains(from));
    if (!wasThreatened) return false;
    final stillThreatened = threats.any((enemyIndex) => _actionSquaresFor(enemyIndex).contains(to));
    return !stillThreatened;
  }

  Set<int> _cpuEnemiesThreateningCrowns(bool cpuIsWhite) {
    final result = <int>{};
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == cpuIsWhite || enemy.label == '核' || _isSuppressedCell(enemyIndex)) continue;
      final range = _actionSquaresFor(enemyIndex);
      for (final targetIndex in range) {
        final mine = _topPieceAt(targetIndex);
        if (mine == null || mine.isWhite != cpuIsWhite) continue;
        if ((_crownValueForPiece(mine) ?? 0) > 0) {
          result.add(enemyIndex);
          break;
        }
      }
    }
    return result;
  }

  bool _cpuMoveHasPurpose(int from, int to, Piece piece, {required bool mergedAtTo}) {
    // 将棋と同じく「前へ出る」だけでは価値を与えない。
    // まず「次手でタダ取りされない」を通し、その上で利き・退避・防御目的を見る。
    if (_CpuDifficultyState.current != CpuDifficulty.easy &&
        _cpuEnemyCanTakePieceAt(to, piece, mergedAtIndex: mergedAtTo)) {
      return false;
    }
    final beforeInfluence = _cpuInfluenceScoreAt(from, piece, mergedAtIndex: _isMergedCell(from));
    final afterInfluence = _cpuInfluenceScoreAt(to, piece, mergedAtIndex: mergedAtTo);
    if (afterInfluence > beforeInfluence + 1) return true;

    if (_cpuCrownPieceEscapesImmediateLoss(from, to, piece)) return true;

    final wasThreatened = _cpuEnemyCanActOn(from, piece.isWhite);
    final willBeThreatened = _cpuEnemyCanActOn(to, piece.isWhite);
    if (wasThreatened && !willBeThreatened) return true;

    final urgentEnemies = _cpuEnemiesThreateningCrowns(piece.isWhite);
    if (urgentEnemies.isNotEmpty) {
      final afterRange = _actionSquaresForPieceAt(to, piece, merged: mergedAtTo);
      if (urgentEnemies.any(afterRange.contains)) return true;
    }
    return false;
  }

  double _cpuPositionScore(int from, int to, Piece piece, {required bool mergedAtTo}) {
    final myRange = _actionSquaresForPieceAt(to, piece, merged: mergedAtTo);
    var score = 0.0;
    var enemyCanHitMe = false;

    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      final iCanHit = myRange.contains(enemyIndex);
      final enemyCanHit = enemyRange.contains(to);

      if (iCanHit && !enemyCanHit) {
        // 理想形。一方的にこちらの行動範囲へ入れる。
        score += 520 + _cpuTargetValue(enemy) * 1.15;
      } else if (iCanHit && enemyCanHit) {
        // 拮抗は一方的な射撃より下。ただし相手の射撃を止める価値はある。
        score += 75;
      }
      if (enemyCanHit) enemyCanHitMe = true;
    }

    if (enemyCanHitMe) {
      // 相手の範囲へ自分から入る手は原則大幅減点。王冠持ちはさらに重い。
      final crown = _crownValueForPiece(piece) ?? 0;
      score -= crown > 0 ? 2600 : (420 + _cpuTargetValue(piece) * 1.35);
    } else {
      score += 160; // 「相手に入れられない」状態そのものを評価。
    }

    // NORMAL/HARDは、次手で一方的に射撃破壊されるマスへ自分から出る手を強く嫌う。
    // HARDは特に厳しくし、兵投入や通常移動の自滅を抑える。
    if (_CpuDifficultyState.current != CpuDifficulty.easy &&
        _cpuEnemyHasFreeRangedShotOn(to, piece, mergedAtIndex: mergedAtTo)) {
      score -= _CpuDifficultyState.current == CpuDifficulty.hard ? 9000 : 5200;
    }

    // 危険な味方を一方的射撃から救うため、脅威の敵へ射程を重ねる価値。
    // ただしこれは「一方的にこちらから入れる」より低い。
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite || enemy.label == '核') continue;
      if (!myRange.contains(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      var enemyHasFreeShot = false;
      for (final allyIndex in enemyRange) {
        if (allyIndex == from) continue;
        final ally = _topPieceAt(allyIndex);
        if (ally == null || ally.isWhite != piece.isWhite) continue;
        if (!_actionSquaresFor(allyIndex).contains(enemyIndex)) {
          enemyHasFreeShot = true;
          break;
        }
      }
      if (enemyHasFreeShot) score += 190;
    }

    // 次手で敗北する王手級の危機では、王冠駒の退避を通常の位置取りより圧倒的に優先する。
    if (_cpuCrownPieceEscapesImmediateLoss(from, to, piece)) {
      score += _CpuDifficultyState.current == CpuDifficulty.hard ? 120000 : 80000;
    }

    // HARD/NORMALは「次手でその駒自体を取られる位置」を最重要の損として扱う。
    if (_CpuDifficultyState.current != CpuDifficulty.easy) {
      score -= _cpuSafetyPenaltyAt(to, piece, mergedAtIndex: mergedAtTo);
    }

    // 核・リーダーへ圧を掛けている敵へ利きを作る手を高評価する。
    final urgentEnemies = _cpuEnemiesThreateningCrowns(piece.isWhite);
    for (final enemyIndex in urgentEnemies) {
      if (myRange.contains(enemyIndex)) {
        score += _CpuDifficultyState.current == CpuDifficulty.hard ? 2400 : 1500;
      }
    }
    return score;
  }

  bool _cpuEnemyHasFreeRangedShotOn(
    int index,
    Piece piece, {
    required bool mergedAtIndex,
    int? ignoreEnemyAt,
  }) {
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      if (enemyIndex == ignoreEnemyAt) continue;
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite || enemy.label == '核' || _isStrassePiece(enemy)) continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      final enemyRange = _actionSquaresFor(enemyIndex);
      if (!enemyRange.contains(index)) continue;
      // こちらから相手へ射撃拮抗できる位置なら「ノーリスク射撃」ではない。
      final myRange = _actionSquaresForPieceAt(index, piece, merged: mergedAtIndex);
      if (!myRange.contains(enemyIndex)) return true;
    }
    return false;
  }

  // 「タダで駒をやる」手を避けるための、次手の即時被取り判定。
  // 行動範囲に入っただけで一律危険とはせず、格闘可能か／一方的な射撃かを実際の駒種で見る。
  bool _cpuEnemyCanTakePieceAt(
    int index,
    Piece piece, {
    required bool mergedAtIndex,
    int? ignoreEnemyAt,
  }) {
    for (var enemyIndex = 0; enemyIndex < 35; enemyIndex++) {
      if (enemyIndex == ignoreEnemyAt) continue;
      final enemy = _topPieceAt(enemyIndex);
      if (enemy == null || enemy.isWhite == piece.isWhite || enemy.label == '核') continue;
      if (_isSuppressedCell(enemyIndex)) continue;
      if (!_actionSquaresFor(enemyIndex).contains(index)) continue;

      // 格闘が成立するなら、相手の次手でそのまま取られる。
      if (!_isAirCastlePiece(enemy) && !_isAirCastlePiece(piece)) return true;

      // 格闘不可でも、STRASSE以外は射撃可能。こちらから射撃拮抗できないなら一方的に取られる。
      if (!_isStrassePiece(enemy)) {
        if (_isStrassePiece(piece)) return true;
        final myRange = _actionSquaresForPieceAt(index, piece, merged: mergedAtIndex);
        if (!myRange.contains(enemyIndex)) return true;
      }
    }
    return false;
  }

  double _cpuSafetyPenaltyAt(int index, Piece piece, {required bool mergedAtIndex}) {
    if (!_cpuEnemyCanTakePieceAt(index, piece, mergedAtIndex: mergedAtIndex)) return 0;
    final crown = _crownValueForPiece(piece) ?? 0;
    final base = 5000.0 + _cpuTargetValue(piece) * 3.0;
    return crown > 0 ? base + 12000.0 + crown * 4000.0 : base;
  }


  // HARDは「この手の直後、相手の最善の1手で何を失うか」まで見る。
  // 盤面を一時的に仮更新して相手の即時反撃を評価し、必ず元へ戻す。
  double _cpuHardReplyPenaltyAfter(bool cpuIsWhite, void Function() applyHypothetical) {
    if (_CpuDifficultyState.current != CpuDifficulty.hard) return 0.0;
    final savedCells = <int, List<Piece>>{
      for (final entry in cells.entries) entry.key: List<Piece>.from(entry.value),
    };
    final savedSuppressed = Set<int>.from(suppressedCells);
    try {
      applyHypothetical();
      var worst = 0.0;
      var extra = 0.0;
      for (var enemyFrom = 0; enemyFrom < 35; enemyFrom++) {
        final enemy = _topPieceAt(enemyFrom);
        if (enemy == null || enemy.isWhite == cpuIsWhite || enemy.label == '核') continue;
        if (_isSuppressedCell(enemyFrom)) continue;
        for (final targetIndex in _enemyTargetsFor(enemyFrom)) {
          final mine = _topPieceAt(targetIndex);
          if (mine == null || mine.isWhite != cpuIsWhite) continue;
          final contested = _isContested(enemyFrom, targetIndex);
          final canShoot = !contested && !_isStrassePiece(enemy);
          final canMelee = !_isAirCastlePiece(enemy) && !_isAirCastlePiece(mine);
          if (!canShoot && !canMelee) continue;
          final crown = _crownValueForPiece(mine) ?? 0.0;
          var loss = 2200.0 + _cpuTargetValue(mine) * 4.0;
          if (crown > 0) loss += 12000.0 + crown * 5000.0;
          if (crown > 0 && _lostCrownPoints(cpuIsWhite) + crown >= 3.0) {
            loss += 500000.0;
          }
          if (loss > worst) worst = loss;
          extra += loss * 0.08;
        }
      }
      return worst + extra;
    } finally {
      cells
        ..clear()
        ..addAll(savedCells);
      suppressedCells
        ..clear()
        ..addAll(savedSuppressed);
    }
  }

  void _cpuSimMoveTop(int from, int to, {required bool merge}) {
    final fromStack = cells[from];
    if (fromStack == null || fromStack.isEmpty) return;
    final moving = fromStack.removeLast();
    if (fromStack.isEmpty) cells.remove(from);
    if (merge) {
      final toStack = cells[to];
      if (toStack == null || toStack.isEmpty) {
        cells[to] = [moving];
      } else {
        toStack.add(moving);
      }
    } else {
      cells[to] = [moving];
    }
    suppressedCells.remove(from);
    suppressedCells.remove(to);
  }

  void _cpuSimRemoveTop(int index) {
    final st = cells[index];
    if (st == null || st.isEmpty) return;
    st.removeLast();
    if (st.isEmpty) {
      cells.remove(index);
      suppressedCells.remove(index);
    } else if (suppressedCells.contains(index)) {
      // 上駒が消えた時点で制圧状態は解除。
      suppressedCells.remove(index);
    }
  }

  void _cpuSimMelee(int from, int to) {
    final fromStack = cells[from];
    final targetStack = cells[to];
    if (fromStack == null || fromStack.isEmpty || targetStack == null || targetStack.isEmpty) return;
    final targetWasMerged = targetStack.length >= 2 && !suppressedCells.contains(to);
    final targetWasSuppressed = suppressedCells.contains(to);
    var moving = fromStack.removeLast();
    moving = _pieceAfterKillLevelUp(moving);
    if (fromStack.isEmpty) cells.remove(from);
    targetStack.removeLast();
    if (targetStack.isEmpty) {
      cells[to] = [moving];
      suppressedCells.remove(to);
    } else {
      targetStack.add(moving);
      cells[to] = targetStack;
      if (targetWasMerged) {
        suppressedCells.add(to);
      } else if (targetWasSuppressed) {
        suppressedCells.remove(to);
      }
    }
    suppressedCells.remove(from);
  }

  void _cpuSimSuppress(int from, int to) {
    final fromStack = cells[from];
    final targetStack = cells[to];
    if (fromStack == null || fromStack.isEmpty || targetStack == null || targetStack.isEmpty) return;
    final moving = fromStack.removeLast();
    if (fromStack.isEmpty) cells.remove(from);
    targetStack.add(moving);
    cells[to] = targetStack;
    suppressedCells.add(to);
    suppressedCells.remove(from);
  }

  void _cpuSimTransform(int index, Piece transformed) {
    final st = cells[index];
    if (st == null || st.isEmpty) return;
    st[st.length - 1] = transformed;
  }

  Set<int> _cpuSecondMoveTargets(int originalFrom, int firstTo, Piece piece) {
    final squares = _actionSquaresForPieceAt(firstTo, piece, merged: false);
    return squares.where((target) => target == originalFrom || !cells.containsKey(target)).toSet();
  }

  bool _cpuCaptureWouldWin(Piece target, bool cpuIsWhite) {
    final crown = _crownValueForPiece(target) ?? 0;
    if (crown <= 0) return false;
    return _lostCrownPoints(!cpuIsWhite) + crown >= 3.0;
  }

  void _scheduleCpuTurnIfNeeded() {
    if (widget.localBattle || widget.trainingMode) return;
    final cpuIsWhite = !widget.playerIsWhite;
    if (_pilotDialogueBusy || _knightTransformBusy || _statChangeBusy || _cpuTurnScheduled || whiteTurn != cpuIsWhite) return;
    if (_placingStockSoldier || _pendingRevivalPiece != null ||
        _rapidFireStep != 0 || _accelerationStep != 0 || _strasseSkillStep != 0) return;
    if (_lostCrownPoints(true) >= 3.0 || _lostCrownPoints(false) >= 3.0) return;

    _cpuTurnScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future<void>.delayed(Duration(milliseconds: switch (_CpuDifficultyState.current) { CpuDifficulty.easy => 280, CpuDifficulty.normal => 220, CpuDifficulty.hard => 160 }), () async {
        if (!mounted) return;
        if (whiteTurn != cpuIsWhite) {
          _cpuTurnScheduled = false;
          return;
        }
        await _runCpuTurn(cpuIsWhite);
        if (mounted) _cpuTurnScheduled = false;
      });
    });
  }

  Future<void> _runCpuTurn(bool cpuIsWhite) async {
    final cpuLevel = _CpuDifficultyState.current;
    // Build #422のHARD相当をNORMAL基準へ。HARDはさらに安全性と取り切りを強化。
    final tacticalBonus = switch (cpuLevel) { CpuDifficulty.easy => 0.0, CpuDifficulty.normal => 220.0, CpuDifficulty.hard => 420.0 };
    final cautionBonus = switch (cpuLevel) { CpuDifficulty.easy => 0.0, CpuDifficulty.normal => 300.0, CpuDifficulty.hard => 650.0 };
    int? bestSuppressionDestroy;
    double bestSuppressionDestroyScore = -1e18;
    for (final index in suppressedCells) {
      final stack = cells[index];
      if (stack == null || stack.length < 2) continue;
      final top = stack.last;
      final bottom = stack.first;
      if (top.isWhite != cpuIsWhite || bottom.isWhite == cpuIsWhite) continue;
      final wins = _cpuCaptureWouldWin(bottom, cpuIsWhite);
      var score = (wins ? 1000000.0 : 650.0) + _cpuTargetValue(bottom);
      if (!wins) {
        score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () {
          final st = cells[index];
          if (st != null && st.length >= 2) {
            st.removeAt(0);
            cells[index] = st;
            suppressedCells.remove(index);
          }
        });
      }
      if (score > bestSuppressionDestroyScore) {
        bestSuppressionDestroyScore = score;
        bestSuppressionDestroy = index;
      }
    }

    String? bestKind;
    int? bestFrom;
    int? bestTo;
    Piece? bestRevivalPiece;
    Piece? bestLv3Piece;
    String? bestKnightForm;
    int? bestRapidSecond;
    int? bestAccelerationSecond;
    int? bestStrasseEscape;
    double bestScore = -1e18;
    // 評価条件が厳しすぎてもCPUターンを停止させないための合法手フォールバック。
    String? fallbackKind;
    int? fallbackFrom;
    int? fallbackTo;
    double fallbackScore = -1e18;

    // 勝利条件は最優先。制圧破壊で勝てるなら即採用。
    if (bestSuppressionDestroy != null && bestSuppressionDestroyScore >= 1000000) {
      bestKind = 'suppressionDestroy';
      bestFrom = bestSuppressionDestroy;
      bestTo = bestSuppressionDestroy;
      bestScore = bestSuppressionDestroyScore;
    }

    // 核は「使えるから使う」を廃止。復活は盤面へ戦力を戻す価値だけ評価し、
    // 即Lv3は位置関係を改善する根拠がない限り低評価にする。
    for (var coreIndex = 0; coreIndex < 35; coreIndex++) {
      final stack = cells[coreIndex];
      if (stack == null || stack.length != 1) continue;
      final core = stack.single;
      if (core.label != '核' || core.isWhite != cpuIsWhite) continue;

      final revivalPieces = _validRevivalPiecesForCore(core);
      if (revivalPieces.isNotEmpty) {
        for (final piece in revivalPieces) {
          for (final to in _revivalTargetsFor(cpuIsWhite)) {
            final merged = cells[to]?.isNotEmpty == true;
            final positional = _cpuPositionScore(coreIndex, to, piece, mergedAtTo: merged);
            var score = 170 + _cpuTargetValue(piece) * .45 + positional;
            score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () {
              cells.remove(coreIndex);
              final st = cells[to];
              if (st == null || st.isEmpty) { cells[to] = [piece]; } else { st.add(piece); }
            });
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'coreRevive';
              bestFrom = coreIndex;
              bestTo = to;
              bestRevivalPiece = piece;
            }
          }
        }
      }

      if (_coreEffectKeepsBattleAlive(core)) {
        for (final target in _lv3Candidates(cpuIsWhite)) {
          // Lv3化そのものにはほぼ点を与えない。開幕即自壊を防ぐためではなく、
          // 「行動範囲の優位を作れる時だけ」選ばれるよう現在位置で比較する。
          final before = _cpuPositionScore(target.key, target.key, target.value, mergedAtTo: _isMergedCell(target.key));
          final lv3Piece = target.value.copyWith(level: 3);
          final after = _cpuPositionScore(target.key, target.key, lv3Piece, mergedAtTo: _isMergedCell(target.key));
          var score = (after - before) - 260; // 核という択を消費するコスト。
          score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () {
            cells.remove(coreIndex);
            final st = cells[target.key];
            if (st != null && st.isNotEmpty) st[st.length - 1] = lv3Piece;
          });
          if (score > bestScore) {
            bestScore = score;
            bestKind = 'coreLv3';
            bestFrom = coreIndex;
            bestTo = target.key;
            bestLv3Piece = target.value;
          }
        }
      }
    }

    // 兵投入も「置けるから」ではなく、置いた位置の行動範囲関係で評価。
    if (_soldierStockFor(cpuIsWhite) > 0) {
      final soldierAsset = cpuIsWhite ? 'assets/pieces/white_soldier.png' : 'assets/pieces/black_soldier.png';
      final soldier = Piece(soldierAsset, '兵', isWhite: cpuIsWhite);
      final urgentCrownThreat = _cpuEnemiesThreateningCrowns(cpuIsWhite).isNotEmpty || _cpuImmediateLossThreatEnemies(cpuIsWhite).isNotEmpty;
      for (final to in _soldierDeploymentTargets(cpuIsWhite)) {
        if (cpuLevel != CpuDifficulty.easy && urgentCrownThreat) continue;
        if (cpuLevel != CpuDifficulty.easy &&
            _cpuEnemyCanTakePieceAt(to, soldier, mergedAtIndex: false)) {
          continue;
        }
        if (cpuLevel != CpuDifficulty.easy &&
            _cpuInfluenceScoreAt(to, soldier, mergedAtIndex: false) <= 0) {
          continue;
        }
        var score = 25 + _cpuPositionScore(to, to, soldier, mergedAtTo: false);
        score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { cells[to] = [soldier]; });
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'soldier';
          bestFrom = null;
          bestTo = to;
        }
      }
    }

    for (var from = 0; from < 35; from++) {
      final piece = _topPieceAt(from);
      if (piece == null || piece.isWhite != cpuIsWhite || piece.label == '核') continue;
      if (_isSuppressedCell(from)) continue;

      // 王の連射は射撃するなら撃ち得。2発成立する時は通常射撃より優先候補にする。
      if (piece.label == '王' && _canUseRapidFire(from)) {
        for (final first in _rapidFireFirstTargetsFor(from)) {
          final firstTarget = _topPieceAt(first);
          if (firstTarget == null) continue;
          final leveled = _pieceAfterKillLevelUp(piece);
          final seconds = _legalRangedTargetsFor(from, afterRemovingTopAt: first, attackerOverride: leveled);
          for (final second in seconds) {
            Piece? secondTarget;
            final st = cells[second];
            if (second == first && st != null && st.length >= 2) {
              secondTarget = st[st.length - 2];
            } else {
              secondTarget = _topPieceAt(second);
            }
            if (secondTarget == null) continue;
            final firstCrown = _crownValueForPiece(firstTarget) ?? 0;
            final secondCrown = _crownValueForPiece(secondTarget) ?? 0;
            final crownGain = firstCrown + secondCrown;
            final wins = _lostCrownPoints(!cpuIsWhite) + crownGain >= 3.0;
            // 連射が2発とも成立するなら、通常射撃1発より明確に価値が高い。
            // HARDで安全性評価を強めても、撃ち得の連射まで埋もれないようにする。
            final rapidBase = switch (cpuLevel) {
              CpuDifficulty.easy => 900.0,
              CpuDifficulty.normal => 2450.0,
              CpuDifficulty.hard => 3200.0,
            };
            final crownPressure = (firstCrown + secondCrown) *
                (cpuLevel == CpuDifficulty.hard ? 900.0 : 600.0);
            var score = (wins ? 1000000.0 : rapidBase) +
                _cpuTargetValue(firstTarget) +
                _cpuTargetValue(secondTarget) +
                crownPressure;
            if (!wins) {
              score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () {
                _cpuSimRemoveTop(first);
                _cpuSimRemoveTop(second);
              });
            }
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'rapidFire';
              bestFrom = from;
              bestTo = first;
              bestRapidSecond = second;
            }
          }
        }
      }

      // 敵への行動。勝てる手 > 一方的な射撃 > 必要な格闘/制圧。
      for (final to in _enemyTargetsFor(from)) {
        final target = _topPieceAt(to);
        if (target == null) continue;
        final value = _cpuTargetValue(target);
        final contested = _isContested(from, to);
        final wins = _cpuCaptureWouldWin(target, cpuIsWhite);

        final targetCrown = _crownValueForPiece(target) ?? 0;
        final immediateThreatEnemies = _cpuImmediateLossThreatEnemies(cpuIsWhite);
        final mustStopThreatBonus = immediateThreatEnemies.contains(to)
            ? (cpuLevel == CpuDifficulty.hard ? 180000.0 : (cpuLevel == CpuDifficulty.normal ? 120000.0 : 0.0))
            : 0.0;
        final hardCriticalTargetBonus = switch (cpuLevel) {
          CpuDifficulty.easy => 0.0,
          CpuDifficulty.normal => target.label == '核' ? 1500.0 : (targetCrown > 0 ? 900.0 : 0.0),
          CpuDifficulty.hard => target.label == '核' ? 2100.0 : (targetCrown > 0 ? 1300.0 : 0.0),
        };

        if (!contested && !_isStrassePiece(piece)) {
          final rangedBase = switch (cpuLevel) {
            CpuDifficulty.easy => 760.0,
            CpuDifficulty.normal => 1250.0,
            CpuDifficulty.hard => 1650.0,
          };
          var rangedScore = (wins ? 1000000.0 : rangedBase) + value + hardCriticalTargetBonus + mustStopThreatBonus;
          if (!wins) {
            rangedScore -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimRemoveTop(to); });
          }
          if (rangedScore > bestScore) {
            bestScore = rangedScore;
            bestKind = 'ranged'; bestFrom = from; bestTo = to;
          }
        }

        // 格闘後は攻撃側が敵マスへ入る。HARDは安全に取れる駒を強く優先し、
        // 反撃される格闘は大きく減点してプレミへの咎めと自駒の安全を両立する。
        if (!_isAirCastlePiece(piece) && !_isAirCastlePiece(target)) {
          final dangerAfterMelee = _cpuEnemyCanActOn(to, cpuIsWhite, ignoreEnemyAt: to);
          final meleeBase = switch (cpuLevel) {
            CpuDifficulty.easy => 250.0,
            CpuDifficulty.normal => dangerAfterMelee ? 300.0 : 1450.0,
            CpuDifficulty.hard => dangerAfterMelee ? 120.0 : 1850.0,
          };
          var meleeScore = (wins ? 1000000.0 : meleeBase) + value + hardCriticalTargetBonus + mustStopThreatBonus;
          if (!wins && dangerAfterMelee) {
            final crown = _crownValueForPiece(piece) ?? 0;
            meleeScore -= crown > 0
                ? 3200 + cautionBonus
                : ((switch (cpuLevel) { CpuDifficulty.easy => 500.0, CpuDifficulty.normal => 900.0, CpuDifficulty.hard => 1350.0 }) +
                    cautionBonus + _cpuTargetValue(piece) * 1.4);
          }
          if (!wins) {
            meleeScore -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimMelee(from, to); });
          }
          if (meleeScore > bestScore) {
            bestScore = meleeScore;
            bestKind = 'melee'; bestFrom = from; bestTo = to;
          }
        }

        if (!_isMergedCell(to) && !_isSuppressedCell(to) && target.major) {
          // 制圧は即勝利ではないので、射撃より下。王冠への圧力は評価する。
          var suppressionScore = 120 + value * .45 + ((_crownValueForPiece(target) ?? 0) > 0 ? 260 : 0) + mustStopThreatBonus;
          suppressionScore -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimSuppress(from, to); });
          if (suppressionScore > bestScore) {
            bestScore = suppressionScore;
            bestKind = 'suppress'; bestFrom = from; bestTo = to;
          }
        }
      }

      // 帝「加速」：使えるから使うのではなく、通常1歩より明確に有利になる時だけ使う。
      // 最終地点が次手でタダ取りされる加速は候補から除外する。
      if (piece.label == '帝' && cpuLevel != CpuDifficulty.easy) {
        double bestSingleMoveScore = -1e18;
        for (final one in _moveTargetsFor(from)) {
          if (!_cpuMoveHasPurpose(from, one, piece, mergedAtTo: false)) continue;
          final oneScore = _cpuPositionScore(from, one, piece, mergedAtTo: false);
          if (oneScore > bestSingleMoveScore) bestSingleMoveScore = oneScore;
        }
        for (final first in _moveTargetsFor(from)) {
          for (final second in _cpuSecondMoveTargets(from, first, piece)) {
            if (second == first || second == from) continue;
            if (_cpuEnemyCanTakePieceAt(second, piece, mergedAtIndex: false)) continue;
            if (!_cpuMoveHasPurpose(from, second, piece, mergedAtTo: false)) continue;
            final positional = _cpuPositionScore(from, second, piece, mergedAtTo: false);
            // 加速は「普通に1歩動くより、はっきり得な時」だけ。開幕の無意味な突進を防ぐ。
            final requiredGain = cpuLevel == CpuDifficulty.hard ? 420.0 : 650.0;
            if (bestSingleMoveScore > -1e17 && positional < bestSingleMoveScore + requiredGain) continue;
            var score = positional - 60.0; // スキルを切る小さな機会費用。
            score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimMoveTop(from, second, merge: false); });
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'acceleration';
              bestFrom = from;
              bestTo = first;
              bestAccelerationSecond = second;
            }
          }
        }
      }

      // STRASSE「逃げるが勝ち」：格闘で取ってから安全地帯へ離脱する手を高評価。
      if (_isStrassePiece(piece) && cpuLevel != CpuDifficulty.easy) {
        for (final meleeTo in _strasseLegalMeleeTargetsFor(from)) {
          final target = _topPieceAt(meleeTo);
          if (target == null || _isAirCastlePiece(target)) continue;
          final afterKill = _pieceAfterKillLevelUp(piece);
          final targetWasMerged = _isMergedCell(meleeTo);
          final escapeSquares = _actionSquaresForPieceAt(meleeTo, afterKill, merged: targetWasMerged);
          final escapes = escapeSquares.where((targetIndex) => targetIndex == from || !cells.containsKey(targetIndex)).toSet();
          for (final escape in escapes) {
            if (_cpuEnemyCanTakePieceAt(escape, afterKill, mergedAtIndex: false, ignoreEnemyAt: meleeTo)) continue;
            final positional = _cpuPositionScore(meleeTo, escape, afterKill, mergedAtTo: false);
            final wins = _cpuCaptureWouldWin(target, cpuIsWhite);
            // SKILL使用そのものには点を足さない。「取って安全に逃げられる」結果だけを評価する。
            var score = (wins ? 1000000.0 : 1500.0) + _cpuTargetValue(target) + positional;
            if (!wins) {
              score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () {
                _cpuSimMelee(from, meleeTo);
                _cpuSimMoveTop(meleeTo, escape, merge: false);
              });
            }
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'strasseMeleeMove';
              bestFrom = from;
              bestTo = meleeTo;
              bestStrasseEscape = escape;
            }
          }
        }
        if (_canUseStrasseMergedMove(from)) {
          for (final to in _moveTargetsFor(from)) {
            if (_cpuEnemyCanTakePieceAt(to, piece, mergedAtIndex: true)) continue;
            if (!_cpuMoveHasPurpose(from, to, piece, mergedAtTo: true)) continue;
            final positional = _cpuPositionScore(from, to, piece, mergedAtTo: true);
            var score = positional - 40.0;
            score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () {
              final st = cells.remove(from);
              if (st != null) cells[to] = st;
              suppressedCells.remove(from);
              suppressedCells.remove(to);
            });
            if (score > bestScore) {
              bestScore = score;
              bestKind = 'strasseMergedMove';
              bestFrom = from;
              bestTo = to;
              bestStrasseEscape = null;
            }
          }
        }
      }

      // 移動と合流は同じ「位置を作る手」として評価。合流自体にはボーナスを与えない。
      for (final to in _moveTargetsFor(from)) {
        final rawScore = _cpuPositionScore(from, to, piece, mergedAtTo: false);
        // NORMAL/HARDのフォールバックも安全な手だけ。
        // 「目的のある手」が無いだけで、タダ取りされるマスへ突っ込む退化を防ぐ。
        final fallbackSafe = cpuLevel == CpuDifficulty.easy ||
            !_cpuEnemyCanTakePieceAt(to, piece, mergedAtIndex: false);
        if (fallbackSafe) {
          var candidateFallback = rawScore;
          candidateFallback -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimMoveTop(from, to, merge: false); });
          if (candidateFallback > fallbackScore) {
            fallbackScore = candidateFallback; fallbackKind = 'move'; fallbackFrom = from; fallbackTo = to;
          }
        }
        if (cpuLevel != CpuDifficulty.easy && !_cpuMoveHasPurpose(from, to, piece, mergedAtTo: false)) continue;
        var score = rawScore;
        score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimMoveTop(from, to, merge: false); });
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'move'; bestFrom = from; bestTo = to;
        }
      }
      for (final to in _mergeTargetsFor(from)) {
        final rawScore = _cpuPositionScore(from, to, piece, mergedAtTo: true);
        final fallbackSafe = cpuLevel == CpuDifficulty.easy ||
            !_cpuEnemyCanTakePieceAt(to, piece, mergedAtIndex: true);
        if (fallbackSafe) {
          var candidateFallback = rawScore;
          candidateFallback -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimMoveTop(from, to, merge: true); });
          if (candidateFallback > fallbackScore) {
            fallbackScore = candidateFallback; fallbackKind = 'merge'; fallbackFrom = from; fallbackTo = to;
          }
        }
        if (cpuLevel != CpuDifficulty.easy && !_cpuMoveHasPurpose(from, to, piece, mergedAtTo: true)) continue;
        var score = rawScore;
        score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimMoveTop(from, to, merge: true); });
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'merge'; bestFrom = from; bestTo = to;
        }
      }

      // 変形も「できるから」ではなく、今いる位置で行動範囲関係が改善する時だけ。
      if (_isKnightForm(piece)) {
        final nextForm = switch (piece.label) {
          '騎' => '騎弐式',
          '騎弐式' => '騎参式',
          _ => '騎',
        };
        final transformed = _knightFormPiece(piece, nextForm);
        final before = _cpuPositionScore(from, from, piece, mergedAtTo: _isMergedCell(from));
        final after = _cpuPositionScore(from, from, transformed, mergedAtTo: _isMergedCell(from));
        var score = after - before - 10;
        score -= _cpuHardReplyPenaltyAfter(cpuIsWhite, () { _cpuSimTransform(from, transformed); });
        if (score > bestScore) {
          bestScore = score;
          bestKind = 'knightTransform';
          bestFrom = from;
          bestTo = from;
          bestKnightForm = nextForm;
        }
      }
    }

    // 制圧破壊が勝利手でなくても、他にそれ以上の手が無ければ比較対象にする。
    if (bestSuppressionDestroy != null && bestSuppressionDestroyScore > bestScore) {
      bestScore = bestSuppressionDestroyScore;
      bestKind = 'suppressionDestroy';
      bestFrom = bestSuppressionDestroy;
      bestTo = bestSuppressionDestroy;
    }

    if ((bestKind == null || bestTo == null) && fallbackKind != null && fallbackTo != null) {
      bestKind = fallbackKind;
      bestFrom = fallbackFrom;
      bestTo = fallbackTo;
      bestScore = fallbackScore;
    }
    if (bestKind == null || bestTo == null) {
      _scheduleNoLegalActionFinishIfNeeded();
      return;
    }

    final actionName = switch (bestKind) {
      'soldier' => '兵を投入',
      'coreRevive' => '核発動・復活',
      'coreLv3' => '核発動・Lv3',
      'rapidFire' => '連射',
      'acceleration' => '加速',
      'strasseMeleeMove' => '逃げるが勝ち',
      'strasseMergedMove' => '逃げるが勝ち',
      'suppressionDestroy' => '制圧破壊',
      'melee' => '格闘',
      'ranged' => '射撃',
      'suppress' => '制圧',
      'merge' => '合流',
      'move' => '移動',
      'knightTransform' => '変形',
      _ => '行動',
    };
    // 相手の行動が確定したら観戦用の敵駒確認を閉じ、以後は行動演出を最優先する。
    if (mounted) setState(() { selectedIndex = null; lowerInfoCells.clear(); });
    _showActionEcho(bestFrom, bestTo, actionLabel: '${widget.battleMode == BattleMode.onlineTest ? 'OPPONENT' : 'CPU'}：$actionName');

    // CPU通常行動の台詞はここで一度だけ出す。
    // 実行関数側ではCPU台詞を再発火させない。
    final cpuDialogueAction = switch (bestKind) {
      'suppressionDestroy' => 'suppressDestroy',
      'melee' => 'melee',
      'ranged' => 'ranged',
      'suppress' => 'suppress',
      'merge' => 'merge',
      'move' => 'move',
      _ => null,
    };
    if (cpuDialogueAction != null && bestFrom != null) {
      await _showCpuPilotDialogueForIndex(bestFrom!, cpuDialogueAction);
      if (!mounted) return;
    }

    switch (bestKind) {
      case 'suppressionDestroy':
        await _executeSuppressionDestroy(bestTo!, showDialogue: false);
        break;
      case 'soldier':
        setState(() {
          final asset = cpuIsWhite ? 'assets/pieces/white_soldier.png' : 'assets/pieces/black_soldier.png';
          cells[bestTo!] = [Piece(asset, '兵', isWhite: cpuIsWhite)];
          if (cpuIsWhite) { _whiteSoldierStock--; } else { _blackSoldierStock--; }
          selectedIndex = null;
          whiteTurn = !whiteTurn;
        });
        if (_maybeFinishBattle()) return;
        break;
      case 'coreRevive':
        final revived = bestRevivalPiece;
        if (bestFrom == null || revived == null) return;
        setState(() {
          _pendingRevivalCoreIndex = bestFrom;
          _consumeCore(bestFrom!);
          _pendingRevivalPiece = revived;
          _pendingRevivalTargets = <int>{bestTo!};
        });
        await _placeRevivedPiece(bestTo!);
        break;
      case 'coreLv3':
        final targetPiece = bestLv3Piece;
        if (bestFrom == null || targetPiece == null) return;
        await _applyInstantLv3(bestFrom!, bestTo!, targetPiece);
        break;
      case 'rapidFire':
        final second = bestRapidSecond;
        if (bestFrom == null || second == null) return;
        await _showSkillDialogueForIndex(bestFrom!);
        if (!mounted) return;
        setState(() { selectedIndex = bestFrom; _rapidFireStep = 1; });
        _executeRapidFireShot(bestFrom!, bestTo!);
        if (_maybeFinishBattle()) return;
        await Future<void>.delayed(const Duration(milliseconds: 500));
        if (!mounted) return;
        if (_legalRangedTargetsFor(bestFrom!).contains(second)) {
          _executeRapidFireShot(bestFrom!, second);
        } else {
          // 1発目のLvアップ等で予定した2発目が不成立なら、その時点の合法対象から撃つ。
          final legal = _legalRangedTargetsFor(bestFrom!);
          if (legal.isNotEmpty) {
            final fallback = legal.reduce((a, b) => _cpuTargetValue(_topPieceAt(a)!) >= _cpuTargetValue(_topPieceAt(b)!) ? a : b);
            _executeRapidFireShot(bestFrom!, fallback);
          } else {
            setState(() { _rapidFireStep = 0; selectedIndex = null; whiteTurn = !whiteTurn; });
          }
        }
        break;
      case 'acceleration':
        final second = bestAccelerationSecond;
        if (bestFrom == null || second == null) return;
        await _showSkillDialogueForIndex(bestFrom!);
        if (!mounted) return;
        final first = bestTo!;
        _beginPieceMotion(bestFrom!, first);
        setState(() { _moveTopPiece(from: bestFrom!, to: first, merge: false); selectedIndex = first; });
        await Future<void>.delayed(_pieceMotionDuration);
        if (!mounted || _maybeFinishBattle()) return;
        _beginPieceMotion(first, second);
        setState(() { _moveTopPiece(from: first, to: second, merge: false); selectedIndex = null; whiteTurn = !whiteTurn; });
        if (_maybeFinishBattle()) return;
        break;
      case 'strasseMeleeMove':
        final plannedEscape = bestStrasseEscape;
        if (bestFrom == null || plannedEscape == null) return;
        await _showSkillDialogueForIndex(bestFrom!);
        if (!mounted) return;
        await _executeMelee(bestFrom!, bestTo, endTurn: false, showDialogue: false);
        if (!mounted || _maybeFinishBattle()) return;
        // 格闘後は盤面が変わるため、事前計算した逃走先を盲信しない。
        // 実際の合法逃走先を再取得し、無ければその場で必ずターンを終了する。
        final legalEscapes = _strasseEscapeMoveTargetsFor(bestTo!);
        if (legalEscapes.isEmpty) {
          setState(() { selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn; });
          break;
        }
        int escape = legalEscapes.contains(plannedEscape) ? plannedEscape : legalEscapes.first;
        double escapeScore = -1e18;
        final moved = _topPieceAt(bestTo!);
        if (moved != null) {
          for (final candidate in legalEscapes) {
            final score = _cpuPositionScore(bestTo!, candidate, moved, mergedAtTo: false);
            if (score > escapeScore) { escapeScore = score; escape = candidate; }
          }
        }
        _beginPieceMotion(bestTo!, escape);
        setState(() {
          _moveTopPiece(from: bestTo!, to: escape, merge: false);
          selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn;
        });
        if (_maybeFinishBattle()) return;
        break;
      case 'strasseMergedMove':
        if (bestFrom == null) return;
        await _showSkillDialogueForIndex(bestFrom!);
        if (!mounted) return;
        _beginPieceMotion(bestFrom!, bestTo!);
        setState(() { _moveMergedStrasseStack(bestFrom!, bestTo!); selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn; });
        if (_maybeFinishBattle()) return;
        break;
      case 'melee': await _executeMelee(bestFrom!, bestTo, showDialogue: false); break;
      case 'ranged': await _executeRanged(bestFrom!, bestTo, showDialogue: false); break;
      case 'suppress': await _executeSuppression(bestFrom!, bestTo, showDialogue: false); break;
      case 'merge':
        final cpuMovingPiece = _topPieceAt(bestFrom!);
        final pumpBefore = cpuMovingPiece == null ? 0 : _pumpForPieceAt(bestFrom!, cpuMovingPiece, mergedOverride: _isMergedCell(bestFrom!));
        _beginPieceMotion(bestFrom!, bestTo!);
        setState(() { _moveTopPiece(from: bestFrom!, to: bestTo!, merge: true); selectedIndex = null; });
        if (_maybeFinishBattle()) return;
        final cpuMovedPiece = _topPieceAt(bestTo!);
        final pumpAfter = cpuMovedPiece == null ? 0 : _pumpForPieceAt(bestTo!, cpuMovedPiece, mergedOverride: _isMergedCell(bestTo!));
        if (pumpAfter != pumpBefore) {
          await _showStatChange(bestTo!, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
        }
        if (!mounted) return;
        setState(() => whiteTurn = !whiteTurn);
        break;
      case 'move':
        final cpuMovingPiece = _topPieceAt(bestFrom!);
        final pumpBefore = cpuMovingPiece == null ? 0 : _pumpForPieceAt(bestFrom!, cpuMovingPiece, mergedOverride: _isMergedCell(bestFrom!));
        _beginPieceMotion(bestFrom!, bestTo!);
        setState(() { _moveTopPiece(from: bestFrom!, to: bestTo!, merge: false); selectedIndex = null; });
        if (_maybeFinishBattle()) return;
        final cpuMovedPiece = _topPieceAt(bestTo!);
        final pumpAfter = cpuMovedPiece == null ? 0 : _pumpForPieceAt(bestTo!, cpuMovedPiece, mergedOverride: _isMergedCell(bestTo!));
        if (pumpAfter != pumpBefore) {
          await _showStatChange(bestTo!, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
        }
        if (!mounted) return;
        setState(() => whiteTurn = !whiteTurn);
        break;
      case 'knightTransform':
        final form = bestKnightForm;
        if (bestFrom == null || form == null) return;
        await _executeKnightTransform(bestFrom!, form);
        if (_maybeFinishBattle()) return;
        break;
    }
    if (mounted) {
      setState(() { selectedIndex = null; });
    }
  }

  void _showActionEcho(int? origin, int? target, {String? actionLabel}) {
    final generation = ++_actionEchoGeneration;
    final move = origin == null ? <int>{} : _moveTargetsFor(origin);
    final merge = origin == null ? <int>{} : _mergeTargetsFor(origin);
    final enemy = origin == null ? <int>{} : _enemyTargetsFor(origin);
    setState(() {
      _actionEchoOrigin = origin;
      _actionEchoTarget = target;
      _actionEchoMoveTargets = Set<int>.from(move);
      _actionEchoMergeTargets = Set<int>.from(merge);
      _actionEchoEnemyTargets = Set<int>.from(enemy);
      _cpuPreviewTarget = target;
      _cpuPreviewAction = actionLabel;
    });
    Future<void>.delayed(_actionEchoDuration, () {
      if (!mounted || generation != _actionEchoGeneration) return;
      setState(() {
        _actionEchoOrigin = null;
        _actionEchoTarget = null;
        _actionEchoMoveTargets.clear();
        _actionEchoMergeTargets.clear();
        _actionEchoEnemyTargets.clear();
        _cpuPreviewTarget = null;
        _cpuPreviewAction = null;
      });
    });
  }

  void _handleTap(int index) async {
    if (widget.trainingMode) { await _handleTrainingTap(index); return; }
    // 相手手番中は操作はできないが、敵駒の情報・行動範囲だけ確認できる。
    // CPU/オンラインの実行演出が始まる時点で選択状態は強制解除する。
    if (!widget.localBattle && whiteTurn != widget.playerIsWhite) {
      if (_goryuFinisherLocked || _pilotDialogueBusy || _statChangeBusy || _motionOrigin != null || _shotOrigin != null) return;
      final inspected = _topPieceAt(index);
      if (inspected == null || inspected.isWhite != whiteTurn) {
        setState(() { selectedIndex = null; lowerInfoCells.clear(); });
        return;
      }
      setState(() {
        selectedIndex = null;
        if (inspectedIndex == index && (cells[index]?.length ?? 0) > 1) {
          if (lowerInfoCells.contains(index)) { lowerInfoCells.remove(index); } else { lowerInfoCells.add(index); }
        } else {
          inspectedIndex = index;
          lowerInfoCells.remove(index);
        }
      });
      return;
    }
    if (_goryuFinisherLocked || _pilotDialogueBusy || _statChangeBusy) return;

    if (_placingStockSoldier) {
      if (_stockSoldierTargets.contains(index)) _placeStockSoldier(index);
      return;
    }
    if (_pendingMasterLifePiece != null) {
      _handleLifeSacrificeTap(index);
      return;
    }
    if (_pendingRevivalPiece != null) {
      if (_pendingRevivalTargets.contains(index)) _placeRevivedPiece(index);
      return;
    }

    // SKILL「飛空」発動中：下の飛空城の行動範囲で上下2駒を一緒に移動。
    if (_flightSkillStep == 1) {
      final from = selectedIndex;
      if (from == null || !_flightTargetsFor(from).contains(index)) return;
      await _showPilotDialogueForIndex(from, 'move');
      if (!mounted) return;
      _beginPieceMotion(from, index);
      setState(() {
        final stack = cells.remove(from);
        if (stack != null) cells[index] = stack;
        suppressedCells.remove(from);
        selectedIndex = null;
        _flightSkillStep = 0;
        whiteTurn = !whiteTurn;
      });
      _maybeFinishBattle();
      return;
    }

    // シュトラーセ「逃げるが勝ち」発動中。
    if (_strasseSkillStep == 1) {
      final from = selectedIndex;
      if (from == null || !_strasseLegalMeleeTargetsFor(from).contains(index)) return;
      final skillTarget = _topPieceAt(index);
      if (skillTarget == null || _isAirCastlePiece(skillTarget)) return;
      await _executeMelee(from, index, endTurn: false);
      if (!mounted || _maybeFinishBattle()) return;
      if (_strasseEscapeMoveTargetsFor(index).isEmpty) {
        setState(() { selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn; });
      } else {
        setState(() { selectedIndex = index; _strasseSkillStep = 2; });
      }
      return;
    }
    if (_strasseSkillStep == 2) {
      final from = selectedIndex;
      if (from == null || !_strasseEscapeMoveTargetsFor(from).contains(index)) return;
      await _showPilotDialogueForIndex(from, 'move');
      if (!mounted) return;
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn;
      });
      _maybeFinishBattle();
      return;
    }
    if (_strasseSkillStep == 3) {
      final from = selectedIndex;
      if (from == null || !_moveTargetsFor(from).contains(index)) return;
      await _showPilotDialogueForIndex(from, 'mergedMove');
      if (!mounted) return;
      _beginPieceMotion(from, index);
      setState(() {
        _moveMergedStrasseStack(from, index);
        selectedIndex = null; _strasseSkillStep = 0; whiteTurn = !whiteTurn;
      });
      _maybeFinishBattle();
      return;
    }

    // 連射発動後は、合法な射撃対象以外の操作を受け付けない。
    if (_rapidFireStep != 0) {
      final attackerIndex = selectedIndex;
      if (attackerIndex == null) return;
      final legalTargets = _rapidFireStep == 1
          ? _rapidFireFirstTargetsFor(attackerIndex)
          : _legalRangedTargetsFor(attackerIndex);
      if (!legalTargets.contains(index)) return;
      _showActionEcho(selectedIndex, index);
      _executeRapidFireShot(attackerIndex, index);
      return;
    }

    // 加速発動後は帝の移動先以外の操作を受け付けない。
    if (_accelerationStep != 0) {
      final from = selectedIndex;
      if (from == null || !_moveTargetsFor(from).contains(index)) return;
      final wasFirstMove = _accelerationStep == 1;
      _showActionEcho(selectedIndex, index);
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        if (wasFirstMove && _moveTargetsFor(index).isNotEmpty) {
          selectedIndex = index;
          _accelerationStep = 2;
        } else {
          // 2回目が不可能なら通常移動と同じ結果でターン終了。
          selectedIndex = null;
          _accelerationStep = 0;
          whiteTurn = !whiteTurn;
        }
      });
      if (_maybeFinishBattle()) return;
      return;
    }
    final piece = _topPieceAt(index);
    final moveTargets = selectedIndex == null ? const <int>{} : _moveTargetsFor(selectedIndex!);
    final mergeTargets = selectedIndex == null ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final enemyTargets = selectedIndex == null ? const <int>{} : _enemyTargetsFor(selectedIndex!);
    final isCurrentSidePiece = piece != null &&
        piece.isWhite == whiteTurn;

    if (selectedIndex != null && enemyTargets.contains(index)) {
      _showActionEcho(selectedIndex, index);
      _showActionMenu(selectedIndex!, index);
      return;
    }

    if (selectedIndex != null && moveTargets.contains(index)) {
      final from = selectedIndex!;
      _showActionEcho(selectedIndex, index);
      await _showPilotDialogueForIndex(from, 'move');
      if (!mounted) return;
      final movingPiece = _topPieceAt(from);
      final pumpBefore = movingPiece == null ? 0 : _pumpForPieceAt(from, movingPiece, mergedOverride: _isMergedCell(from));
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: false);
        selectedIndex = null;
      });
      if (_maybeFinishBattle()) return;
      final movedPiece = _topPieceAt(index);
      final pumpAfter = movedPiece == null ? 0 : _pumpForPieceAt(index, movedPiece, mergedOverride: _isMergedCell(index));
      if (pumpAfter != pumpBefore) {
        await _showStatChange(index, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
      }
      if (!mounted) return;
      setState(() => whiteTurn = !whiteTurn);
      return;
    }

    if (selectedIndex != null && mergeTargets.contains(index)) {
      final from = selectedIndex!;
      _showActionEcho(selectedIndex, index);
      await _showPilotDialogueForIndex(from, 'merge');
      if (!mounted) return;
      final mergingPiece = _topPieceAt(from);
      final pumpBefore = mergingPiece == null ? 0 : _pumpForPieceAt(from, mergingPiece, mergedOverride: _isMergedCell(from));
      _beginPieceMotion(from, index);
      setState(() {
        _moveTopPiece(from: from, to: index, merge: true);
        selectedIndex = null;
      });
      if (_maybeFinishBattle()) return;
      final mergedPiece = _topPieceAt(index);
      final pumpAfter = mergedPiece == null ? 0 : _pumpForPieceAt(index, mergedPiece, mergedOverride: _isMergedCell(index));
      if (pumpAfter != pumpBefore) {
        await _showStatChange(index, 'Pu', pumpAfter, up: pumpAfter > pumpBefore);
      }
      if (!mounted) return;
      setState(() => whiteTurn = !whiteTurn);
      return;
    }

    // 自分の手番でも敵駒は閲覧できる。操作選択とは完全に分離する。
    if (piece != null && !isCurrentSidePiece) {
      setState(() {
        selectedIndex = null;
        if (inspectedIndex == index && (cells[index]?.length ?? 0) > 1) {
          if (lowerInfoCells.contains(index)) { lowerInfoCells.remove(index); } else { lowerInfoCells.add(index); }
        } else {
          inspectedIndex = index;
          lowerInfoCells.remove(index);
        }
      });
      return;
    }

    setState(() {

      if (isCurrentSidePiece) {
        inspectedIndex = null;
        final stack = cells[index];
        final isStacked = stack != null && stack.length > 1;
        if (selectedIndex == index && isStacked) {
          // 重なり中の同じマスをもう一度タップすると、情報欄だけ上↔下を切り替える。
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
        selectedIndex = selectedIndex == index ? null : index;
        lowerInfoCells.remove(index);
        return;
      }

      // 未選択時なら、敵の重なりマスも情報だけ確認できる。
      if (selectedIndex == null && piece != null) {
        final stack = cells[index];
        if (stack != null && stack.length > 1) {
          if (lowerInfoCells.contains(index)) {
            lowerInfoCells.remove(index);
          } else {
            lowerInfoCells.add(index);
          }
          return;
        }
      }

      if (piece == null) {
        selectedIndex = null;
        inspectedIndex = null;
      }
    });
    // 制圧から離れた瞬間に下のリーダーを鹵獲する場合があるため、
    // 通常移動/合流の直後も必ず王冠勝敗を再判定する。
    _maybeFinishBattle();
  }

  Future<void> _confirmTrainingSkip() async {
    if (!widget.trainingMode || _goryuFinisherLocked) return;
    final skip = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('TRAINING SKIP'),
        content: const Text('TRAININGをクリア済みとしてスキップしますか？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('NO')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('YES')),
        ],
      ),
    );
    if (skip != true || !mounted) return;
    setState(() {
      _placingStockSoldier = false;
      _stockSoldierTargets = <int>{};
      selectedIndex = null;
      inspectedIndex = null;
      lowerInfoCells.clear();
      _trainingText = null;
      _trainingCanNext = false;
      _trainingTyping = false;
      _trainingActionReady = false;
    });
    await _trainingFinish();
  }

  Future<void> _confirmSurrender() async {
    if (widget.trainingMode) { await _confirmTrainingSkip(); return; }
    if (_goryuFinisherLocked) return;
    final surrender = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('投了'),
        content: const Text('この対戦を投了しますか？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('戻る')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('投了する')),
        ],
      ),
    );
    if (surrender != true || !mounted) return;
    if (widget.trainingMode) {
      await _trainingFinish();
      return;
    }
    await _stopBattleBgm();
    if (!mounted) return;
    if (widget.localBattle) {
      Navigator.of(context).pushReplacement(
        _resultTransitionRoute(LocalBattleResultScreen(winnerIsWhite: !whiteTurn, showCrownVictory: false)),
      );
    } else {
      Navigator.of(context).pushReplacement(
        _resultTransitionRoute(BattleResultScreen(playerWon: false, showCrownVictory: false, mode: widget.battleMode)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    _scheduleNoLegalActionFinishIfNeeded();
    _scheduleCpuTurnIfNeeded();
    if (!widget.trainingMode && _lastRenderedTurn != null && _lastRenderedTurn != whiteTurn) {
      _lastRenderedTurn = whiteTurn;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        setState(() { _turnBannerWhite = whiteTurn; _showTurnBanner = true; });
        _turnBannerController.forward(from: 0).whenComplete(() {
          if (mounted) setState(() => _showTurnBanner = false);
        });
      });
    }
    final liveMoveTargets = selectedIndex == null
        ? const <int>{}
        : (_flightSkillStep == 1
            ? _flightTargetsFor(selectedIndex!)
            : (_strasseSkillStep == 1
                ? const <int>{}
                : (_strasseSkillStep == 2
                    ? _strasseEscapeMoveTargetsFor(selectedIndex!)
                    : (_rapidFireStep != 0 ? const <int>{} : _moveTargetsFor(selectedIndex!)))));
    final moveTargets = <int>{...liveMoveTargets, ..._actionEchoMoveTargets};
    final liveMergeTargets = (_flightSkillStep != 0 || _strasseSkillStep != 0 || _accelerationStep != 0 || _rapidFireStep != 0 || selectedIndex == null) ? const <int>{} : _mergeTargetsFor(selectedIndex!);
    final mergeTargets = <int>{...liveMergeTargets, ..._actionEchoMergeTargets};
    final liveEnemyTargets = _rapidFireStep != 0 && selectedIndex != null
        ? (_rapidFireStep == 1 ? _rapidFireFirstTargetsFor(selectedIndex!) : _legalRangedTargetsFor(selectedIndex!))
        : (_flightSkillStep != 0 || _accelerationStep != 0 || selectedIndex == null || _strasseSkillStep == 2 || _strasseSkillStep == 3
            ? const <int>{}
            : (_strasseSkillStep == 1 ? _strasseLegalMeleeTargetsFor(selectedIndex!) : _enemyTargetsFor(selectedIndex!)));
    final enemyTargets = <int>{...liveEnemyTargets, ..._actionEchoEnemyTargets};
    final selectedPiece = selectedIndex == null ? null : _topPieceAt(selectedIndex!);
    final canUseCore = selectedIndex != null && _canActivateCoreAt(selectedIndex!);
    final canUseLifeStatue = selectedIndex != null && _canUseLifeStatueAt(selectedIndex!);
    final canShowKingSkill = _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null && selectedPiece.label == '王' && selectedPiece.isWhite == whiteTurn;
    final canUseKingSkill = canShowKingSkill && _canUseRapidFire(selectedIndex!);
    final canUseEmperorSkill = _accelerationStep == 0 && _rapidFireStep == 0 &&
        selectedIndex != null &&
        selectedPiece != null &&
        selectedPiece.label == '帝' &&
        selectedPiece.isWhite == whiteTurn;
    final canUseKnightSkill = _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null &&
        _isKnightForm(selectedPiece) &&
        selectedPiece.isWhite == whiteTurn;
    final canUseStrasseSkill = _strasseSkillStep == 0 && _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null && _isStrassePiece(selectedPiece) && selectedPiece.isWhite == whiteTurn &&
        (_canUseStrasseMeleeMove(selectedIndex!) || _canUseStrasseMergedMove(selectedIndex!));
    final canUseFlightSkill = _flightSkillStep == 0 && _strasseSkillStep == 0 &&
        _accelerationStep == 0 && _rapidFireStep == 0 && selectedIndex != null &&
        selectedPiece != null && selectedPiece.isWhite == whiteTurn && _canUseFlight(selectedIndex!);
    final inspectSource = inspectedIndex ?? selectedIndex;
    final inspectPiece = inspectSource == null ? null : _topPieceAt(inspectSource);
    final inspectIsAirCastle = inspectPiece != null && _isAirCastlePiece(inspectPiece);
    final inspectIsSimplePiece = inspectPiece != null && !inspectPiece.major && !inspectIsAirCastle;
    final inspectStage1All = (inspectSource == null || _flightSkillStep == 1)
        ? const <int>{}
        : (inspectIsSimplePiece ? _actionSquaresFor(inspectSource) : _stageActionSquaresFor(inspectSource, 1));
    final inspectStage2All = (inspectSource == null || inspectIsSimplePiece || _flightSkillStep == 1)
        ? const <int>{}
        : _stageActionSquaresFor(inspectSource, 2);
    final inspectStage3All = (inspectSource == null || inspectIsSimplePiece || _flightSkillStep == 1)
        ? const <int>{}
        : _stageActionSquaresFor(inspectSource, 3);
    final inspectStage1Squares = inspectStage1All;
    final inspectStage2Squares = inspectStage2All.difference(inspectStage1All);
    final inspectStage3Squares = inspectStage3All.difference(inspectStage2All);
    final inspectEffectiveStage = (inspectSource == null || inspectPiece == null)
        ? 0
        : (inspectIsSimplePiece ? 1 : _effectiveLevelForPieceAt(inspectSource, inspectPiece, mergedOverride: _isMergedCell(inspectSource)).clamp(1, 3));
    final whiteCapturedCrowns = _lostCrownPoints(false);
    final blackCapturedCrowns = _lostCrownPoints(true);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) { if (!didPop) { _confirmSurrender(); } },
      child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leadingWidth: widget.trainingMode ? 72 : 0,
        leading: widget.trainingMode
            ? TextButton(
                onPressed: _goryuFinisherLocked ? null : _confirmTrainingSkip,
                child: const Text('スキップ', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800, fontSize: 12)),
              )
            : null,
        title: widget.trainingMode
            ? const SizedBox.shrink()
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!widget.localBattle)
                    Text('WHITE ${_clockText(_whiteTotalSeconds)}   BLACK ${_clockText(_blackTotalSeconds)}   TURN $_turnSecondsLeft',
                    style: const TextStyle(fontSize: 10, color: Colors.white70)),
                ],
              ),
        actions: [
          if (!widget.trainingMode) TextButton(
            onPressed: _goryuFinisherLocked ? null : _confirmSurrender,
            child: const Text('投了', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 6),
              child: SizedBox(
                height: 26,
                child: Center(
                  child: Text(
                _placingStockSoldier
                    ? '兵の投入位置を選択'
                    : (_pendingRevivalPiece != null
                    ? '復活位置を選択'
                    : (_rapidFireStep != 0
                        ? '連射  SHOT $_rapidFireStep / 2'
                        : (_accelerationStep == 0 ? (whiteTurn ? 'WHITE TURN' : 'BLACK TURN') : '加速  MOVE $_accelerationStep / 2'))),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.8,
                ),
                  ),
                ),
              ),
            ),
            if (inspectSource != null && (inspectStage2Squares.isNotEmpty || inspectStage3Squares.isNotEmpty))
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  '枠色：青＝Lv1   黄＝Lv2   赤＝Lv3   点線＝現在未使用',
                  style: const TextStyle(fontSize: 9, color: Colors.white70),
                ),
              ),
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(clipBehavior: Clip.none, children: [
                    CrownScoreDisplay(label: 'WHITE', value: _crownValueText(whiteCapturedCrowns)),
                  ]),
                  const SizedBox(width: 8),
                  CrownScoreDisplay(label: 'BLACK', value: _crownValueText(blackCapturedCrowns)),
                ],
              ),
            ),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 5 / 7,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5,
              childAspectRatio: 1,
            ),
            itemCount: 35,
            itemBuilder: (_, visualIndex) {
              // YOU は常に画面下側。YOU が黒/金なら盤面表示だけ180度反転する。
              final i = _viewIsWhite ? visualIndex : 34 - visualIndex;
              final r = visualIndex ~/ 5, c = visualIndex % 5;
              final cellStack = cells[i];
              final piece = _topPieceAt(i);
              final basePiece = (cellStack != null && cellStack.length > 1) ? cellStack.first : null;
              final isSelected = selectedIndex == i || inspectedIndex == i || _actionEchoOrigin == i;
              final isCpuPreviewTarget = _cpuPreviewTarget == i;
              final isMoveTarget = moveTargets.contains(i);
              final isMergeTarget = mergeTargets.contains(i);
              final isEnemyTarget = enemyTargets.contains(i);
              final isInspectStage1 = inspectStage1Squares.contains(i);
              final isInspectStage2 = inspectStage2Squares.contains(i);
              final isInspectStage3 = inspectStage3Squares.contains(i);
              final inspectCellStage = isInspectStage3 ? 3 : (isInspectStage2 ? 2 : (isInspectStage1 ? 1 : 0));
              final isInspectFuture = inspectCellStage > inspectEffectiveStage;
              final isInspectRangeCell = inspectCellStage > 0;
              final inspectTargetPiece = _topPieceAt(i);
              // マス内の色は「今なにができるか」、枠色は「何Lvの範囲か」に完全分離する。
              // 点線の未到達Lvは「将来の範囲」なので、面発光は絶対に付けない。
              // 敵駒を閲覧している時だけ、現在Lvで実際に使える範囲の候補種別を面色で示す。
              final deriveInspectAction = inspectSource != null && inspectedIndex != null && !isInspectFuture;
              final inspectMoveCandidate = deriveInspectAction && isInspectRangeCell && inspectTargetPiece == null;
              final inspectMergeCandidate = deriveInspectAction && isInspectRangeCell && inspectTargetPiece != null &&
                  inspectPiece != null && inspectTargetPiece.isWhite == inspectPiece.isWhite &&
                  (cells[i]?.length ?? 0) < 2;
              final inspectEnemyCandidate = deriveInspectAction && isInspectRangeCell && inspectTargetPiece != null &&
                  inspectPiece != null && inspectTargetPiece.isWhite != inspectPiece.isWhite;
              final showMoveCandidate = isMoveTarget || inspectMoveCandidate;
              final showMergeCandidate = isMergeTarget || inspectMergeCandidate;
              final showEnemyCandidate = isEnemyTarget || inspectEnemyCandidate;
              final inspectRangeBorderColor = isInspectStage3
                  ? Colors.redAccent
                  : (isInspectStage2 ? Colors.amberAccent : (isInspectStage1 ? Colors.lightBlueAccent : null));
              final isMergedCell = _isMergedCell(i);
              final isSuppressedCell = _isSuppressedCell(i);
              final isStackedCell = cellStack != null && cellStack.length > 1;
              final showingLowerInfo = isStackedCell && lowerInfoCells.contains(i);
              final infoPiece = showingLowerInfo ? cellStack!.first : piece;
              final infoPump = infoPiece == null
                  ? 0
                  : _pumpForPieceAt(
                      i,
                      infoPiece,
                      // 合流中の下段駒は「合流によるPu」を受けない。
                      // 表示切替時にマス全体の合流状態を流用すると、下段までPu1と誤表示されるため分離する。
                      mergedOverride: showingLowerInfo ? false : isMergedCell,
                    );
              final showInfoPu = infoPiece != null &&
                  !_isKuru(infoPiece) &&
                  infoPiece.major &&
                  !_isAirCastlePiece(infoPiece) &&
                  infoPiece.level < 3 &&
                  !_isFixedKnightForm(infoPiece);

              final isRevivalTarget = _pendingRevivalTargets.contains(i);
              final isStockSoldierTarget = _stockSoldierTargets.contains(i);
              final isLifeSacrificeTarget = _pendingLifeSacrificeTargets.contains(i);
              final isLifeSacrificeSelected = _pendingLifeFirstSacrifice == i || _pendingLifeSecondSacrifice == i;

              Color borderColor;
              double borderWidth;
              List<BoxShadow>? glow;
              Color fillColor;

              if (isCpuPreviewTarget) {
                borderColor = Colors.amberAccent;
                borderWidth = 3.2;
                glow = const [
                  BoxShadow(color: Colors.amberAccent, blurRadius: 13, spreadRadius: 1.5),
                ];
                fillColor = Colors.amberAccent.withOpacity(.22);
              } else if (isLifeSacrificeSelected) {
                borderColor = Colors.purpleAccent;
                borderWidth = 3.2;
                glow = const [
                  BoxShadow(color: Colors.purpleAccent, blurRadius: 12, spreadRadius: 1.5),
                ];
                fillColor = Colors.purpleAccent.withOpacity(.10);
              } else if (isRevivalTarget || isStockSoldierTarget) {
                borderColor = Colors.greenAccent;
                borderWidth = 3.0;
                glow = const [
                  BoxShadow(color: Colors.greenAccent, blurRadius: 10, spreadRadius: 1),
                ];
                fillColor = Colors.greenAccent.withOpacity(.20);
              } else if (isSelected) {
                borderColor = Colors.lightBlueAccent;
                borderWidth = 2.4;
                glow = const [
                  BoxShadow(
                    color: Colors.lightBlueAccent,
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ];
                fillColor = Colors.lightBlueAccent.withOpacity(.12);
              } else if (showEnemyCandidate) {
                // 行動種別はマス内の色、Lv段階は枠色で表示する。
                borderColor = inspectRangeBorderColor ?? Colors.redAccent;
                borderWidth = inspectRangeBorderColor != null ? 2.2 : 2.2;
                glow = const [
                  BoxShadow(color: Colors.redAccent, blurRadius: 8, spreadRadius: .6),
                ];
                fillColor = Colors.redAccent.withOpacity(.20);
              } else if (showMergeCandidate) {
                borderColor = inspectRangeBorderColor ?? Colors.greenAccent;
                borderWidth = 2.2;
                glow = const [
                  BoxShadow(color: Colors.greenAccent, blurRadius: 8, spreadRadius: .6),
                ];
                fillColor = Colors.greenAccent.withOpacity(.20);
              } else if (showMoveCandidate) {
                borderColor = inspectRangeBorderColor ?? Colors.lightBlueAccent;
                borderWidth = 2.2;
                glow = const [
                  BoxShadow(color: Colors.cyanAccent, blurRadius: 8, spreadRadius: .6),
                ];
                fillColor = Colors.cyanAccent.withOpacity(.22);
              } else if (inspectRangeBorderColor != null) {
                // 占有などで現在の行動候補にならない範囲も、Lv枠だけは確認できる。
                borderColor = inspectRangeBorderColor;
                borderWidth = 2.0;
                glow = null;
                fillColor = (r + c).isEven ? Colors.white10 : Colors.black12;
              } else if (isSuppressedCell) {
                borderColor = Colors.purpleAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.purpleAccent.withOpacity(.04);
              } else if (isMergedCell) {
                borderColor = Colors.greenAccent;
                borderWidth = 2.2;
                glow = null;
                fillColor = Colors.greenAccent.withOpacity(.04);
              } else {
                borderColor = Colors.white38;
                borderWidth = .7;
                glow = null;
                fillColor = (r + c).isEven ? Colors.white10 : Colors.black12;
              }

              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _handleTap(i),
                onLongPress: () {
                  if (widget.trainingMode) {
                    _handleTrainingLongPress(i);
                    return;
                  }
                  final top = _topPieceAt(i);
                  if (_accelerationStep == 0 && _rapidFireStep == 0 && top != null &&
                      top.isWhite == whiteTurn &&
                      _isSuppressedCell(i)) {
                    _showSuppressionDestroyMenu(i);
                  }
                },
                child: AnimatedBuilder(
                  animation: _mergeBlinkController,
                  builder: (context, child) {
                    final blink = 0.25 + (_mergeBlinkController.value * 0.75);
                    final showSuppressionBlink = isSuppressedCell && !isLifeSacrificeSelected && !isSelected && !showMergeCandidate && !showEnemyCandidate;
                    final showMergeBlink = isMergedCell && !isLifeSacrificeSelected && !isSelected && !showMergeCandidate && !showEnemyCandidate;
                    final blinkColor = showSuppressionBlink ? Colors.purpleAccent : Colors.greenAccent;
                    final showStateBlink = showSuppressionBlink || showMergeBlink;
                    final effectiveBorderColor = isLifeSacrificeSelected
                        ? Colors.purpleAccent.withOpacity(blink)
                        : showStateBlink ? blinkColor.withOpacity(blink) : borderColor;
                    final effectiveBorderWidth = isLifeSacrificeSelected ? 3.2 : (showStateBlink ? 2.2 : borderWidth);
                    final effectiveGlow = isLifeSacrificeSelected
                        ? [BoxShadow(color: Colors.purpleAccent.withOpacity(blink * .9), blurRadius: 5 + 8 * _mergeBlinkController.value, spreadRadius: .4)]
                        : showStateBlink ? [
                            BoxShadow(
                              color: blinkColor.withOpacity(blink * 0.85),
                              blurRadius: 4 + (7 * _mergeBlinkController.value),
                              spreadRadius: .2 + (.8 * _mergeBlinkController.value),
                            ),
                          ]
                        : glow;

                    final cell = AnimatedContainer(
                      duration: const Duration(milliseconds: 90),
                      decoration: BoxDecoration(
                        border: Border.all(color: isInspectFuture ? Colors.transparent : effectiveBorderColor, width: effectiveBorderWidth),
                        boxShadow: effectiveGlow,
                        color: fillColor,
                      ),
                  child: piece == null
                      ? null
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            if (basePiece != null)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(8, 6, 10, 22),
                                child: Opacity(
                                  opacity: 0.55,
                                  child: Transform.translate(
                                    offset: const Offset(-6, -4),
                                    child: Transform.rotate(
                                      angle: basePiece.isWhite == _viewIsWhite ? 0 : 3.141592653589793,
                                      child: basePiece.asset.isEmpty
                                          ? Center(child: Text(_displayPieceLabel(basePiece), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)))
                                          : Image.asset(basePiece.asset, fit: BoxFit.contain),
                                    ),
                                  ),
                                ),
                              ),
                            LayoutBuilder(
                              builder: (context, pieceConstraints) {
                                final movingHere = _motionTarget == i && _motionOrigin != null;
                                final origin = _motionOrigin;
                                if (!movingHere || origin == null) {
                                  return Padding(
                                    padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                    child: Transform.rotate(
                                      angle: piece.isWhite == _viewIsWhite ? 0 : 3.141592653589793,
                                      child: piece.asset.isEmpty
                                          ? Center(child: Text(piece.label.startsWith('神仕') ? '神仕' : piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))
                                          : Image.asset(piece.asset, fit: BoxFit.contain),
                                    ),
                                  );
                                }
                                final originVisual = _viewIsWhite ? origin : 34 - origin;
                                final targetVisual = _viewIsWhite ? i : 34 - i;
                                final fromRow = originVisual ~/ 5;
                                final fromCol = originVisual % 5;
                                final toRow = targetVisual ~/ 5;
                                final toCol = targetVisual % 5;
                                final dx = (fromCol - toCol) * pieceConstraints.maxWidth;
                                final dy = (fromRow - toRow) * pieceConstraints.maxHeight;
                                return TweenAnimationBuilder<double>(
                                  key: ValueKey('piece-motion-$_motionGeneration-$i'),
                                  tween: Tween<double>(begin: 0, end: 1),
                                  duration: _pieceMotionDuration,
                                  curve: Curves.easeInOutCubic,
                                  builder: (context, t, child) {
                                    final lift = -10.0 * math.sin(math.pi * t);
                                    final scale = 1.0 + (0.08 * math.sin(math.pi * t));
                                    return Transform.translate(
                                      offset: Offset(dx * (1 - t), dy * (1 - t) + lift),
                                      child: Transform.scale(scale: scale, child: child),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                    child: Transform.rotate(
                                      angle: piece.isWhite == _viewIsWhite ? 0 : 3.141592653589793,
                                      child: piece.asset.isEmpty
                                          ? Center(child: Text(piece.label.startsWith('神仕') ? '神仕' : piece.label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)))
                                          : Image.asset(piece.asset, fit: BoxFit.contain),
                                    ),
                                  ),
                                );
                              },
                            ),
                            if (_knightTransformIndex == i && _knightTransformTargetPiece != null)
                              TweenAnimationBuilder<double>(
                                key: ValueKey('knight-transform-$_knightTransformGeneration-$i'),
                                tween: Tween<double>(begin: 0, end: 1),
                                duration: _knightTransformDuration,
                                curve: Curves.easeInCubic,
                                builder: (context, t, child) {
                                  // 真上視点なので、巨大な像が急速に本来サイズへ縮むことで
                                  // 「上空から盤面へ降下」してくる奥行きを作る。
                                  final scale = 2.75 - (1.75 * t);
                                  final flash = math.exp(-math.pow((t - .92) / .075, 2));
                                  return Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Transform.scale(
                                        scale: scale,
                                        child: Opacity(
                                          opacity: (0.58 + .42 * t).clamp(0.0, 1.0),
                                          child: child,
                                        ),
                                      ),
                                      if (flash > .02)
                                        IgnorePointer(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white.withOpacity((flash * .62).clamp(0.0, .62)),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.white.withOpacity((flash * .85).clamp(0.0, .85)),
                                                  blurRadius: 18 * flash,
                                                  spreadRadius: 5 * flash,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                    ],
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                  child: Transform.rotate(
                                    angle: _knightTransformTargetPiece!.isWhite == _viewIsWhite
                                        ? 0
                                        : 3.141592653589793,
                                    child: _knightTransformTargetPiece!.asset.isEmpty
                                        ? Center(
                                            child: Text(
                                              _knightTransformTargetPiece!.label,
                                              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                                            ),
                                          )
                                        : Image.asset(_knightTransformTargetPiece!.asset, fit: BoxFit.contain),
                                  ),
                                ),
                              ),
                            if (isLifeSacrificeTarget)
                              Center(
                                child: IgnorePointer(
                                  child: AnimatedBuilder(
                                    animation: _lifeSacrificeMarkerController,
                                    builder: (context, child) => Transform(
                                      alignment: Alignment.center,
                                      transform: Matrix4.identity()
                                        ..setEntry(3, 2, 0.0025)
                                        // Tilt the marker first, then rotate around that tilted local axis.
                                        ..rotateZ(math.pi / 7)
                                        ..rotateY(_lifeSacrificeMarkerController.value * math.pi * 2),
                                      child: child,
                                    ),
                                    child: const CustomPaint(
                                      size: Size(34, 34),
                                      painter: _LifeSacrificeCrossPainter(),
                                    ),
                                  ),
                                ),
                              ),
                            if (isMergedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.greenAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.greenAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '合流',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            if (isSuppressedCell)
                              Positioned(
                                top: 2,
                                right: 2,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Colors.redAccent.withOpacity(.20),
                                    border: Border.all(color: Colors.redAccent, width: .8),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    '制圧',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      height: 1.0,
                                    ),
                                  ),
                                ),
                              ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
                                color: Colors.black54,
                                child: FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      if (infoPiece != null && _crownValueForPiece(infoPiece) != null) ...[
                                        if (_crownAssetForPiece(infoPiece) != null)
                                          SizedBox(
                                            width: 20,
                                            height: 15,
                                            child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Image.asset(
                                                  _crownAssetForPiece(infoPiece)!,
                                                  width: 20,
                                                  height: 15,
                                                  fit: BoxFit.contain,
                                                ),
                                                Positioned(
                                                  left: 5.2,
                                                  right: 5.2,
                                                  bottom: 1.7,
                                                  child: Container(
                                                    height: 5.6,
                                                    alignment: Alignment.center,
                                                    decoration: BoxDecoration(
                                                      color: const Color(0xFF111318).withOpacity(.96),
                                                      borderRadius: BorderRadius.circular(1.2),
                                                    ),
                                                    child: Text(
                                                      _crownValueText(_crownValueForPiece(infoPiece)!),
                                                      maxLines: 1,
                                                      textAlign: TextAlign.center,
                                                      style: const TextStyle(color: Colors.white, fontSize: 6.2, fontWeight: FontWeight.w900, height: .82, letterSpacing: -.35),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          )
                                        else
                                          SizedBox(
                                            width: 18,
                                            height: 15,
                                            child: FittedBox(
                                              child: CrownBadge(
                                                color: _crownColorForPiece(infoPiece),
                                                value: _crownValueText(_crownValueForPiece(infoPiece)!),
                                                darkCrown: _unitForPiece(infoPiece) == BattleUnit.strasse,
                                              ),
                                            ),
                                          ),
                                        const SizedBox(width: 2),
                                      ],
                                      if (infoPiece != null)
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              '${isStackedCell ? (showingLowerInfo ? '下：' : '上：') : ''}${_displayPieceLabel(infoPiece)}${infoPiece.major ? '  ' : ''}',
                                              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, height: 1.0),
                                            ),
                                            if (infoPiece.major && !_isAirCastlePiece(infoPiece) && !_isKuru(infoPiece))
                                              _DeltaStatText(
                                                prefix: 'Lv',
                                                value: infoPiece.level,
                                                strong: true,
                                                color: infoPiece.level >= 3 ? Colors.redAccent : (infoPiece.level == 2 ? Colors.lightBlueAccent : Colors.white),
                                              ),
                                            if (showInfoPu) const Text('/', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, height: 1.0)),
                                            if (showInfoPu)
                                              _DeltaStatText(
                                                prefix: 'Pu',
                                                value: infoPump,
                                                strong: false,
                                                color: infoPump >= 2 ? Colors.redAccent : (infoPump == 1 ? Colors.lightBlueAccent : Colors.white),
                                              ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            if (_coreEffectIndex == i && _coreEffectPiece != null)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: TweenAnimationBuilder<double>(
                                    key: ValueKey('core-effect-$_coreEffectGeneration-$i'),
                                    tween: Tween<double>(begin: 0, end: 1),
                                    duration: _coreEffectIsRevival ? _coreRevivalEffectDuration : _coreLv3EffectDuration,
                                    curve: Curves.easeInOut,
                                    builder: (context, t, _) {
                                      if (_coreEffectIsRevival) {
                                        final materialize = ((t - .18) / .48).clamp(0.0, 1.0);
                                        final fadeOut = t < .78 ? 1.0 : ((1.0 - t) / .22).clamp(0.0, 1.0);
                                        final pulse = .5 + .5 * math.sin(t * math.pi * 8).abs();
                                        return Stack(
                                          fit: StackFit.expand,
                                          children: [
                                            Center(
                                              child: Container(
                                                width: 54 + 16 * t,
                                                height: 18 + 8 * t,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(50),
                                                  border: Border.all(color: Colors.lightBlueAccent.withOpacity(.9 * fadeOut), width: 2),
                                                  boxShadow: [BoxShadow(color: Colors.lightBlueAccent.withOpacity(.65 * fadeOut), blurRadius: 14 + 10 * pulse, spreadRadius: 2)],
                                                ),
                                              ),
                                            ),
                                            Transform.scale(
                                              scale: .82 + .18 * materialize,
                                              child: Opacity(
                                                opacity: (materialize * fadeOut).clamp(0.0, 1.0),
                                                child: Padding(
                                                  padding: const EdgeInsets.fromLTRB(2, 2, 2, 16),
                                                  child: Transform.rotate(
                                                    angle: _coreEffectPiece!.isWhite == _viewIsWhite ? 0 : math.pi,
                                                    child: Image.asset(_coreEffectPiece!.asset, fit: BoxFit.contain),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            if (t > .72)
                                              Container(color: Colors.white.withOpacity((.34 * (1.0 - ((t - .72) / .28).clamp(0.0, 1.0))).clamp(0.0, .34))),
                                          ],
                                        );
                                      }
                                      final pulse = math.sin(t * math.pi * 6).abs();
                                      final lift = t < .52 ? -34.0 * (t / .52) : -34.0;
                                      final oldOpacity = t < .52 ? 1.0 - (t / .52) : 0.0;
                                      final newT = ((t - .48) / .34).clamp(0.0, 1.0);
                                      final newY = -34.0 * (1.0 - newT);
                                      final glowFade = t < .84 ? 1.0 : ((1.0 - t) / .16).clamp(0.0, 1.0);
                                      return Stack(
                                        fit: StackFit.expand,
                                        children: [
                                          Transform.scale(
                                            scale: 1.0 + .10 * math.sin(math.pi * t),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.white.withOpacity((.10 + .13 * pulse) * glowFade),
                                                boxShadow: [BoxShadow(color: Colors.lightBlueAccent.withOpacity(.75 * glowFade), blurRadius: 22 + 10 * pulse, spreadRadius: 4)],
                                              ),
                                            ),
                                          ),
                                          if (_coreEffectOldLevel != null && oldOpacity > 0)
                                            Transform.translate(
                                              offset: Offset(0, lift),
                                              child: Opacity(
                                                opacity: oldOpacity.clamp(0.0, 1.0),
                                                child: Center(child: Text('Lv$_coreEffectOldLevel', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.lightBlueAccent, blurRadius: 14), Shadow(color: Colors.black, blurRadius: 4)]))),
                                              ),
                                            ),
                                          if (newT > 0)
                                            Transform.translate(
                                              offset: Offset(0, newY),
                                              child: Transform.scale(
                                                scale: 1.45 - .45 * newT,
                                                child: Opacity(
                                                  opacity: newT,
                                                  child: const Center(child: Text('Lv3', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.lightBlueAccent, blurRadius: 16), Shadow(color: Colors.black, blurRadius: 5)]))),
                                                ),
                                              ),
                                            ),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                              ),
                            if (_statChangeBusy && _statChangeIndex == i && _statChangeValue != null)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: TweenAnimationBuilder<double>(
                                    key: ValueKey('stat-${_statChangeGeneration}-$i'),
                                    tween: Tween<double>(begin: 0, end: 1),
                                    duration: _statChangeDuration,
                                    curve: Curves.easeOutCubic,
                                    builder: (context, t, _) {
                                      final y = _statChangeUp ? (-38.0 * t) : (-38.0 * (1.0 - t));
                                      final opacity = _statChangeUp ? (t < .80 ? 1.0 : ((1.0 - t) / .20).clamp(0.0, 1.0)) : 1.0;
                                      final scale = _statChangeUp ? 1.0 : (1.75 - .75 * t);
                                      return Transform.translate(
                                        offset: Offset(0, y),
                                        child: Transform.scale(
                                          scale: scale,
                                          child: Opacity(
                                            opacity: opacity,
                                            child: Center(
                                              child: Text(
                                                '${_statChangePrefix}${_statChangeValue}',
                                                style: const TextStyle(
                                                  color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900,
                                                  shadows: [Shadow(color: Colors.black, blurRadius: 5, offset: Offset(0, 2)), Shadow(color: Colors.lightBlueAccent, blurRadius: 12)],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                          ],
                        ),
                    );
                    final trainingCell = (widget.trainingMode && _trainingHighlightFrontline && i < 15)
                        ? Stack(
                            fit: StackFit.expand,
                            children: [
                              cell,
                              IgnorePointer(
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.orangeAccent.withOpacity(.10),
                                    border: Border.all(color: Colors.orangeAccent.withOpacity(.95), width: 1.5),
                                    boxShadow: [BoxShadow(color: Colors.orangeAccent.withOpacity(.28), blurRadius: 5)],
                                  ),
                                ),
                              ),
                            ],
                          )
                        : cell;
                    if (!isInspectFuture) return trainingCell;
                    return Stack(
                      fit: StackFit.expand,
                      children: [
                        trainingCell,
                        IgnorePointer(
                          child: CustomPaint(
                            painter: _DashedCellBorderPainter(color: borderColor, strokeWidth: 2.4),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              );
                    },
                  ),
                      if (_coreLinkFrom != null && _coreLinkTo != null)
                        IgnorePointer(
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('core-link-$_coreLinkGeneration'),
                            tween: Tween<double>(begin: 0, end: 1),
                            duration: const Duration(milliseconds: 520),
                            builder: (context, t, _) => CustomPaint(
                              painter: _CoreLinkPainter(
                                fromIndex: _coreLinkFrom!,
                                toIndex: _coreLinkTo!,
                                progress: t,
                                playerIsWhite: _viewIsWhite,
                              ),
                            ),
                          ),
                        ),
                      if (_coreBurstIndex != null)
                        IgnorePointer(
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('core-burst-$_coreBurstGeneration'),
                            tween: Tween<double>(begin: 0, end: 1),
                            duration: _coreBurstDuration,
                            builder: (context, t, _) => CustomPaint(
                              painter: _CoreBurstPainter(
                                index: _coreBurstIndex!,
                                progress: t,
                                playerIsWhite: _viewIsWhite,
                              ),
                            ),
                          ),
                        ),
                      if (_humanCanAct)
                        IgnorePointer(
                          child: AnimatedBuilder(
                            animation: _shotThreatController,
                            builder: (context, _) {
                              final pairs = _shotThreatPairsForHumanTurn();
                              if (pairs.isEmpty) return const SizedBox.shrink();
                              return CustomPaint(
                                painter: _ShotThreatArcPainter(
                                  pairs: pairs,
                                  progress: _shotThreatController.value,
                                  playerIsWhite: _viewIsWhite,
                                ),
                              );
                            },
                          ),
                        ),
                      if (_shotOrigin != null && _shotTarget != null)
                        IgnorePointer(
                          child: TweenAnimationBuilder<double>(
                            key: ValueKey('shot-$_shotGeneration'),
                            tween: Tween<double>(begin: 0, end: 1),
                            duration: _shotFinalBlowKind == null ? _shotAnimationDuration : _finalBlowAnimationDuration,
                            curve: Curves.easeOutCubic,
                            builder: (context, t, _) => CustomPaint(
                              painter: _ShotBeamPainter(
                                originIndex: _shotOrigin!,
                                targetIndex: _shotTarget!,
                                progress: t,
                                playerIsWhite: _viewIsWhite,
                                finalBlowKind: _shotFinalBlowKind,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            // 盤面位置を完全固定するため、下部操作欄は常に同じ高さを確保する。
            // SKILL/核/兵投入の表示が消えても、この領域自体は縮めない。
            SizedBox(
              height: 112,
              child: Column(
                children: [
                  SizedBox(
                    height: 52,
                    child: (!widget.trainingMode &&
                            _soldierCaptureEnabled &&
                            !_placingStockSoldier &&
                            _pendingRevivalPiece == null &&
                            _rapidFireStep == 0 &&
                            _accelerationStep == 0)
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(12, 6, 12, 2),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    '兵ストック  ×${_soldierStockFor(whiteTurn)}',
                                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                                  ),
                                ),
                                FilledButton.tonal(
                                  onPressed: _soldierStockFor(whiteTurn) > 0 &&
                                          _soldierDeploymentTargets(whiteTurn).isNotEmpty
                                      ? _startStockSoldierDeployment
                                      : null,
                                  child: const Text('兵を投入', style: TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ],
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                  SizedBox(
                    height: 60,
                    child: (_pendingMasterLifePiece != null && _pendingLifeFirstSacrifice != null && _pendingLifeSecondSacrifice != null)
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                            child: SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonal(
                                onPressed: _confirmLifeSacrifices,
                                child: const Text('決定', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.6)),
                              ),
                            ),
                          )
                        : canUseLifeStatue
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                            child: SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonal(
                                onPressed: () => _showLifeStatueMenu(selectedIndex!),
                                child: const Text('生命の像', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
                              ),
                            ),
                          )
                        : canUseCore
                        ? Padding(
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                            child: SizedBox(
                              width: double.infinity,
                              child: FilledButton.tonal(
                                onPressed: () => _showCoreActivationMenu(selectedIndex!),
                                child: const Text(
                                  '核発動',
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 1.6),
                                ),
                              ),
                            ),
                          )
                        : (canUseFlightSkill || canUseKnightSkill || canUseEmperorSkill || canShowKingSkill || canUseStrasseSkill)
                            ? Padding(
                                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                                child: SizedBox(
                                  width: double.infinity,
                                  child: FilledButton.tonal(
                                    onPressed: canUseFlightSkill
                                        ? () => _showRiderSkillMenu(selectedIndex!)
                                        : canShowKingSkill
                                            ? (canUseKingSkill ? () => _showKingSkillMenu(selectedIndex!) : null)
                                            : () => canUseStrasseSkill
                                                ? _showStrasseSkillMenu(selectedIndex!)
                                                : canUseKnightSkill
                                                    ? _showKnightSkillMenu(selectedIndex!)
                                                    : _showEmperorSkillMenu(selectedIndex!),
                                    child: Text(
                                      'SKILL',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 1.6,
                                        color: !canUseFlightSkill && canShowKingSkill && !canUseKingSkill ? Colors.white38 : null,
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ],
            ),
            if (_showBgmTitle)
              Positioned(
                right: 12,
                bottom: 8,
                child: IgnorePointer(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(.42), borderRadius: BorderRadius.circular(4)),
                    child: Text(_battleBgmTitle, style: const TextStyle(fontSize: 11, color: Colors.white70, letterSpacing: .3)),
                  ),
                ),
              ),
            if (_showTurnBanner)
              Positioned.fill(
                child: IgnorePointer(
                  child: AnimatedBuilder(
                    animation: _turnBannerController,
                    builder: (context, _) {
                      final t = _turnBannerController.value;
                      final width = MediaQuery.of(context).size.width;
                      // 約3秒で「入る → 中央で読ませる → 抜ける」。
                      // 0.00-0.32: 右から中央へ / 0.32-0.68: 中央保持 / 0.68-1.00: 左へ。
                      final double x;
                      if (t < .32) {
                        final enter = Curves.easeOutCubic.transform(t / .32);
                        x = width * (1.15 * (1.0 - enter));
                      } else if (t <= .68) {
                        x = 0;
                      } else {
                        final exit = Curves.easeInCubic.transform((t - .68) / .32);
                        x = -width * 1.15 * exit;
                      }
                      final edgeFade = t < .10
                          ? (t / .10)
                          : (t > .90 ? ((1.0 - t) / .10) : 1.0);
                      final hold = edgeFade.clamp(0.0, 1.0);
                      return Align(
                        alignment: const Alignment(0, -0.72),
                        child: Transform.translate(
                          offset: Offset(x, 0),
                          child: Opacity(
                            opacity: hold.clamp(0.0, 1.0),
                            child: Container(
                              width: width * .78,
                              height: 54,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.transparent, Colors.white.withOpacity(.10), Colors.white.withOpacity(.16), Colors.white.withOpacity(.10), Colors.transparent],
                                ),
                                border: const Border.symmetric(horizontal: BorderSide(color: Colors.white24, width: .7)),
                              ),
                              child: Text(
                                _turnBannerWhite ? 'WHITE TURN' : 'BLACK TURN',
                                style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 4.0, shadows: [Shadow(color: Colors.black, blurRadius: 8)]),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            if (_cpuPreviewAction != null)
              Positioned(
                top: 54,
                left: 0,
                right: 0,
                child: IgnorePointer(
                  child: Center(
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 160),
                      opacity: _cpuPreviewAction == null ? 0 : 1,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.78),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white24),
                        ),
                        child: Text(
                          _cpuPreviewAction!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .6,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            if (_cpuPilotDialogueText != null && _cpuPilotDialogueAsset != null)
              Positioned(
                left: 10, right: 10, bottom: 14,
                child: IgnorePointer(
                  child: _StablePilotTypewriter(
                    key: ValueKey('cpu-pilot-dialogue-$_cpuPilotDialogueGeneration'),
                    text: _cpuPilotDialogueText!,
                    duration: _pilotTypingDuration,
                    completed: !_cpuPilotDialogueTyping,
                    childBuilder: (context, shown) {
                      return Container(
                        height: 112,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.88),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white24),
                          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
                        ),
                        child: Row(children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.horizontal(left: Radius.circular(7)),
                            child: SizedBox(width: 104, height: 112, child: Image.asset(_cpuPilotDialogueAsset!, fit: BoxFit.cover)),
                          ),
                          Expanded(child: Padding(
                            padding: const EdgeInsets.fromLTRB(13, 10, 12, 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(_cpuPilotDialogueName ?? '', style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .7)),
                                const SizedBox(height: 5),
                                Text(shown, maxLines: 2, overflow: TextOverflow.clip, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, height: 1.2)),
                              ],
                            ),
                          )),
                        ]),
                      );
                    },
                  ),
                ),
              ),
            // CPU専用台詞が生きている間は旧共通台詞を絶対に描画しない。
            if (!widget.trainingMode && _cpuPilotDialogueText == null &&
                _pilotDialogueText != null && _pilotDialogueAsset != null)
              Positioned(
                left: 10,
                right: 10,
                bottom: 14,
                child: IgnorePointer(
                  child: _StablePilotTypewriter(
                    key: ValueKey('pilot-dialogue-$_pilotDialogueGeneration'),
                    text: _pilotDialogueText!,
                    duration: _pilotTypingDuration,
                    completed: !_pilotDialogueTyping,
                    childBuilder: (context, shown) {
                      return Container(
                        height: 112,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.88),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white24),
                          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.horizontal(left: Radius.circular(7)),
                              child: SizedBox(
                                width: 104,
                                height: 112,
                                child: Image.asset(_pilotDialogueAsset!, fit: BoxFit.cover),
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(13, 10, 12, 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      _pilotDialogueName ?? '',
                                      style: const TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .7),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      shown,
                                      maxLines: 2,
                                      overflow: TextOverflow.clip,
                                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, height: 1.2),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            if (widget.trainingMode && _trainingShowKingPiece)
              Positioned.fill(
                child: IgnorePointer(
                  child: Center(
                    child: Transform.translate(
                      offset: const Offset(0, -80),
                      child: Image.asset('assets/pieces/white_king.png', height: 190, fit: BoxFit.contain),
                    ),
                  ),
                ),
              ),
            if (widget.trainingMode && _trainingText != null)
              Positioned(
                left: 10,
                right: 10,
                bottom: 14,
                child: Container(
                  height: 112,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(.90),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.white24),
                    boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 12)],
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(13, 8, 8, 7),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('ブル', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .7)),
                              const SizedBox(height: 4),
                              Expanded(
                                child: _StablePilotTypewriter(
                                  key: ValueKey('training-dialogue-$_trainingDialogueGeneration'),
                                  text: _trainingText!,
                                  duration: _pilotTypingDuration,
                                  completed: !_trainingTyping,
                                  childBuilder: (context, shown) => Scrollbar(
                                    child: SingleChildScrollView(
                                      physics: const ClampingScrollPhysics(),
                                      child: Padding(
                                        padding: EdgeInsets.only(right: _trainingCanNext ? 58 : 4),
                                        child: Text(
                                          shown,
                                          style: const TextStyle(color: Colors.white, fontSize: 15.5, fontWeight: FontWeight.w800, height: 1.20),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.horizontal(right: Radius.circular(7)),
                        child: SizedBox(
                          width: 104,
                          height: 112,
                          child: Image.asset('assets/pilots/knight.webp', fit: BoxFit.cover),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (widget.trainingMode && _trainingCanNext && _trainingText != null)
              Positioned(
                right: 116,
                bottom: 18,
                child: TextButton(
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    backgroundColor: Colors.black.withOpacity(.70),
                  ),
                  onPressed: (_trainingTyping || _trainingAdvancing) ? null : _trainingNext,
                  child: const Text('つぎへ  ▶', style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            if (_goryuWhiteout)
              const Positioned.fill(
                child: IgnorePointer(child: ColoredBox(color: Colors.white)),
              ),
          ],
        ),
      ),
    ));
  }
}


class _DeltaStatText extends StatelessWidget {
  const _DeltaStatText({
    required this.prefix,
    required this.value,
    required this.strong,
    required this.color,
  });

  final String prefix;
  final int value;
  final bool strong;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Text(
      '$prefix$value',
      style: TextStyle(
        color: color,
        fontSize: 10,
        fontWeight: value >= 1 ? FontWeight.w900 : FontWeight.w700,
        height: 1.0,
      ),
    );
  }
}



class _DashedCellBorderPainter extends CustomPainter {
  const _DashedCellBorderPainter({required this.color, this.strokeWidth = 2.4});
  final Color color;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;
    final rect = Rect.fromLTWH(strokeWidth / 2, strokeWidth / 2, size.width - strokeWidth, size.height - strokeWidth);
    final path = Path()..addRect(rect);
    for (final metric in path.computeMetrics()) {
      double d = 0;
      const dash = 7.0, gap = 4.0;
      while (d < metric.length) {
        canvas.drawPath(metric.extractPath(d, (d + dash).clamp(0, metric.length)), paint);
        d += dash + gap;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedCellBorderPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.strokeWidth != strokeWidth;
}

class _LifeSacrificeCrossPainter extends CustomPainter {
  const _LifeSacrificeCrossPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height * 0.38;
    final blade = Paint()
      ..color = const Color(0xFFF2F2F4)
      ..style = PaintingStyle.fill;
    final edge = Paint()
      ..color = const Color(0xFF8E939D)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.7;

    // Asymmetric slender cross: short upper arm, clearly longer lower arm,
    // and compact horizontal arms. Marker logic is intentionally untouched.
    final cross = Path()
      ..moveTo(cx, 1.5)
      ..lineTo(cx + 2.0, cy - 3.0)
      ..lineTo(cx + 2.0, cy - 1.5)
      ..lineTo(cx + 7.0, cy - 1.5)
      ..lineTo(cx + 10.5, cy)
      ..lineTo(cx + 7.0, cy + 1.5)
      ..lineTo(cx + 2.0, cy + 1.5)
      ..lineTo(cx + 2.0, size.height - 3.0)
      ..lineTo(cx, size.height - 0.5)
      ..lineTo(cx - 2.0, size.height - 3.0)
      ..lineTo(cx - 2.0, cy + 1.5)
      ..lineTo(cx - 7.0, cy + 1.5)
      ..lineTo(cx - 10.5, cy)
      ..lineTo(cx - 7.0, cy - 1.5)
      ..lineTo(cx - 2.0, cy - 1.5)
      ..lineTo(cx - 2.0, cy - 3.0)
      ..close();

    canvas.drawPath(cross, blade);
    canvas.drawPath(cross, edge);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
