class Room {
  final String code;
  final String hostId;
  final String hostName;
  final String? guestId;
  final String? guestName;
  final bool hostReady;
  final bool guestReady;
  final String status;

  const Room({
    required this.code,
    required this.hostId,
    required this.hostName,
    this.guestId,
    this.guestName,
    required this.hostReady,
    required this.guestReady,
    required this.status,
  });

  bool get bothReady => guestId != null && hostReady && guestReady;

  factory Room.fromMap(String code, Map<String, dynamic> map) {
    return Room(
      code: code,
      hostId: map['hostId'] as String,
      hostName: map['hostName'] as String? ?? 'HOST',
      guestId: map['guestId'] as String?,
      guestName: map['guestName'] as String?,
      hostReady: map['hostReady'] as bool? ?? false,
      guestReady: map['guestReady'] as bool? ?? false,
      status: map['status'] as String? ?? 'lobby',
    );
  }
}
