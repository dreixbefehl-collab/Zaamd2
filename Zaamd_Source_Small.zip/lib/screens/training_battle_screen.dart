import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

enum Side { white, black }
enum ActionMode { move, melee, shoot, control, controlDestroy, merge, skill }
enum StackState { none, merged, controlled }

class Piece {
  Piece({required this.id,required this.name,required this.side,required this.row,required this.col,this.level=1,this.pu=0,this.large=false,this.core=false,this.leader=false});
  final String id,name; final Side side; int row,col,level,pu; final bool large,core,leader;
  bool destroyed=false; String? underId; StackState stackState=StackState.none;
}

class TrainingBattleScreen extends StatefulWidget {
  const TrainingBattleScreen({super.key,this.tutorialMode=false});
  final bool tutorialMode;
  @override State<TrainingBattleScreen> createState()=>_TrainingBattleScreenState();
}

class _TrainingBattleScreenState extends State<TrainingBattleScreen>{
  final List<Piece> pieces=[]; final List<String> log=[];
  Side turn=Side.white; Piece? selected; ActionMode? mode; bool finished=false;
  int whiteKills=0,blackKills=0; int whiteTime=900,blackTime=900; int turnTime=90; int whiteTimeouts=0,blackTimeouts=0; Timer? timer;
  String tutorialText='駒を選択してください';

  @override void initState(){super.initState();_reset();timer=Timer.periodic(const Duration(seconds:1),(_)=>_tick());}
  @override void dispose(){timer?.cancel();super.dispose();}

  void _reset(){
    pieces..clear()..addAll([
      Piece(id:'wcore1',name:'核',side:Side.white,row:6,col:0,core:true),Piece(id:'wcore2',name:'核',side:Side.white,row:6,col:4,core:true),
      Piece(id:'ws1',name:'兵',side:Side.white,row:5,col:0),Piece(id:'ws2',name:'兵',side:Side.white,row:5,col:1),Piece(id:'ws3',name:'兵',side:Side.white,row:5,col:3),Piece(id:'ws4',name:'兵',side:Side.white,row:5,col:4),
      Piece(id:'w1',name:'王',side:Side.white,row:6,col:1,large:true,leader:true),Piece(id:'w2',name:'仕',side:Side.white,row:6,col:2,large:true),Piece(id:'w3',name:'護',side:Side.white,row:5,col:2,large:true),Piece(id:'w4',name:'闘',side:Side.white,row:6,col:3,large:true),
      Piece(id:'bcore1',name:'核',side:Side.black,row:0,col:0,core:true),Piece(id:'bcore2',name:'核',side:Side.black,row:0,col:4,core:true),
      Piece(id:'bs1',name:'兵',side:Side.black,row:1,col:0),Piece(id:'bs2',name:'兵',side:Side.black,row:1,col:1),Piece(id:'bs3',name:'兵',side:Side.black,row:1,col:3),Piece(id:'bs4',name:'兵',side:Side.black,row:1,col:4),
      Piece(id:'b1',name:'帝',side:Side.black,row:0,col:1,large:true,leader:true),Piece(id:'b2',name:'砲',side:Side.black,row:0,col:2,large:true),Piece(id:'b3',name:'剣',side:Side.black,row:1,col:2,large:true),Piece(id:'b4',name:'盾',side:Side.black,row:0,col:3,large:true),
    ]);
    turn=Side.white;selected=null;mode=null;finished=false;whiteKills=0;blackKills=0;whiteTime=900;blackTime=900;turnTime=90;whiteTimeouts=0;blackTimeouts=0;log..clear()..add('TRAINING BATTLE START');tutorialText='駒を選択してください';
  }

  void _tick(){ if(!mounted||finished||widget.tutorialMode)return; setState((){if(turn==Side.white){whiteTime=max(0,whiteTime-1);}else{blackTime=max(0,blackTime-1);}turnTime--;
    if((turn==Side.white?whiteTime:blackTime)<=0){_declare(turn==Side.white?Side.black:Side.white,'持ち時間切れ');return;}
    if(turnTime<=0){if(turn==Side.white)whiteTimeouts++;else blackTimeouts++; final n=turn==Side.white?whiteTimeouts:blackTimeouts; if(n>=3){_declare(turn==Side.white?Side.black:Side.white,'90秒超過3回');}else{_record('90秒超過：強制パス ($n/3)');_finishAction();}}
  });}

  List<Piece> _at(int r,int c)=>pieces.where((p)=>!p.destroyed&&p.row==r&&p.col==c).toList();
  Piece? _topAt(int r,int c){final a=_at(r,c);if(a.isEmpty)return null;for(final p in a){if(p.underId!=null)return p;}return a.last;}
  Piece? _byId(String? id)=>id==null?null:pieces.cast<Piece?>().firstWhere((p)=>p?.id==id,orElse:()=>null);
  bool _front(Side s,int r)=>s==Side.white?r<=2:r>=4;

  Set<Point<int>> _range(Piece p,{bool merge=false}){
    if(p.core||p.stackState==StackState.controlled&&p.underId==null)return{};
    if(p.name=='兵'){final d=merge?2:((_front(p.side,p.row)||p.pu>0)?2:1);final o=<Point<int>>{};for(int i=1;i<=d;i++){_add(o,p,-i,0);_add(o,p,i,0);_add(o,p,0,-i);_add(o,p,0,i);}return o;}
    int lv=min(3,p.level+((_front(p.side,p.row)||p.pu>0)?1:0));
    final o=<Point<int>>{};for(final q in _offsets(p.name,lv)){_add(o,p,q.x,q.y);} if(merge){for(final q in List<Point<int>>.from(o)){for(final d in const [Point(-1,0),Point(1,0),Point(0,-1),Point(0,1)]){final r=q.x+d.x,c=q.y+d.y;if(r>=0&&r<7&&c>=0&&c<5)o.add(Point(r,c));}}} return o;
  }
  void _add(Set<Point<int>> out,Piece p,int dr,int dc){final rr=p.side==Side.white?dr:-dr,cc=p.side==Side.white?dc:-dc,r=p.row+rr,c=p.col+cc;if(r>=0&&r<7&&c>=0&&c<5)out.add(Point(r,c));}

  List<Point<int>> _offsets(String n,int l){
    const D={
      '王':[[[-2,-1],[-2,0],[-2,1],[0,-2],[0,2],[1,0]],[[-2,-1],[-2,0],[-2,1],[-1,-1],[-1,1],[0,-2],[0,2],[1,0]],[[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[-1,-1],[-1,1],[0,-2],[0,2],[1,0]]],
      '仕':[[[-2,-1],[-2,1],[-1,-1],[-1,1],[1,-1],[1,1]],[[-2,-1],[-2,0],[-2,1],[-1,-1],[-1,1],[1,-1],[1,1],[2,0]],[[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,-1],[-1,1],[-1,2],[1,-1],[1,1],[2,0]]],
      '護':[[[-2,-1],[-2,1],[-1,-1],[-1,1],[1,-1],[1,1]],[[-2,-1],[-2,0],[-2,1],[-1,-1],[-1,1],[1,-1],[1,0],[1,1]],[[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[-1,-1],[-1,1],[1,-1],[1,0],[1,1]]],
      '闘':[[[-2,-1],[-2,1],[-1,-1],[-1,1],[1,-1],[1,1]],[[-2,-1],[-2,1],[-1,-1],[-1,0],[-1,1],[1,-1],[1,0],[1,1]],[[-2,-1],[-2,1],[-1,-1],[-1,0],[-1,1],[0,-2],[0,2],[1,-1],[1,0],[1,1]]],
      '騎':[[[-2,-2],[-2,0],[-2,2],[-1,0],[1,0],[2,0]],[[-2,-2],[-2,0],[-2,2],[-1,0],[1,0],[2,-2],[2,0],[2,2]],[[-2,-2],[-2,0],[-2,2],[-1,0],[0,-2],[0,2],[1,0],[2,-2],[2,0],[2,2]]],
      '博':[[[-2,-1],[-2,0],[-2,1],[-1,0],[1,-1],[1,1]],[[-2,-1],[-2,0],[-2,1],[-1,-1],[-1,0],[-1,1],[1,-1],[1,1]],[[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[-1,-1],[-1,0],[-1,1],[1,-1],[1,1]]],
      '将':[[[-2,-1],[-2,0],[-2,1],[0,-2],[0,2],[1,0]],[[-2,-1],[-2,0],[-2,1],[-1,-1],[-1,1],[0,-2],[0,2],[1,0]],[[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,-1],[-1,1],[-1,2],[0,-2],[0,2],[1,0]]],
      '官':[[[-2,-1],[-2,1],[-1,-1],[-1,0],[-1,1],[1,0]],[[-2,-1],[-2,1],[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,0]],[[-2,-1],[-2,1],[-1,-1],[-1,0],[-1,1],[0,-2],[0,-1],[0,1],[0,2],[1,0]]],
      '帝':[[[-2,0],[-1,-2],[-1,0],[-1,2],[1,-1],[1,1]],[[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,0],[-1,2],[1,-1],[1,1]],[[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,0],[-1,2],[0,-2],[0,2],[1,-1],[1,1]]],
      '砲':[[[-2,-1],[-2,0],[-2,1],[-1,0],[1,0],[2,0]],[[-2,-1],[-2,0],[-2,1],[-1,-1],[-1,0],[-1,1],[1,0],[2,0]],[[-2,-2],[-2,-1],[-2,0],[-2,1],[-2,2],[-1,-1],[-1,0],[-1,1],[1,0],[2,0]]],
      '剣':[[[-2,-1],[-2,0],[-2,1],[-1,0],[1,0],[2,0]],[[-2,-1],[-2,0],[-2,1],[-1,0],[0,-1],[0,1],[1,0],[2,0]],[[-2,-1],[-2,0],[-2,1],[-1,-2],[-1,0],[-1,2],[0,-1],[0,1],[1,0],[2,0]]],
      '盾':[[[-2,-1],[-2,0],[-2,1],[-1,0],[1,0],[2,0]],[[-2,-1],[-2,0],[-2,1],[-1,0],[1,-1],[1,0],[1,1],[2,0]],[[-2,-1],[-2,0],[-2,1],[-1,0],[0,-2],[0,2],[1,-1],[1,0],[1,1],[2,0]]]
    };
    final arr=D[n]; if(arr==null)return const[]; return (arr[l.clamp(1,3)-1] as List).map<Point<int>>((e)=>Point<int>(e[0] as int,e[1] as int)).toList();
  }

  bool _legal(int r,int c){if(selected==null||mode==null)return false;final a=selected!;switch(mode!){case ActionMode.skill:return r==a.row&&c==a.col;case ActionMode.controlDestroy:return _at(r,c).any((p)=>p.side!=a.side&&p.underId!=null&&p.stackState==StackState.controlled);case ActionMode.merge:return _range(a,merge:true).contains(Point(r,c));default:return _range(a).contains(Point(r,c));}}

  void _tap(int r,int c){if(finished)return;final target=_topAt(r,c);
    if(selected==null||mode==null){if(target!=null&&target.side==turn&&!target.core&&!(target.stackState==StackState.controlled&&target.underId==null)){setState((){selected=target;mode=null;tutorialText='行動を選択';});}return;}
    if(!_legal(r,c))return;final a=selected!;
    switch(mode!){
      case ActionMode.move: if(target==null){a.row=r;a.col=c;_record('${a.name} 移動');_done();} break;
      case ActionMode.melee: if(target!=null&&target.side!=a.side){_melee(a,target,r,c);} break;
      case ActionMode.shoot: if(target!=null&&target.side!=a.side){if(_range(target).contains(Point(a.row,a.col))){_record('射撃拮抗：${a.name} ⇄ ${target.name}');return;}_destroyTop(target,a,'射撃');_done();} break;
      case ActionMode.control: if(target!=null&&target.side!=a.side&&target.underId==null){a.row=r;a.col=c;a.underId=target.id;a.stackState=StackState.controlled;_record('${a.name} 制圧 → ${target.name}');_done();} break;
      case ActionMode.controlDestroy: if(target!=null&&target.side!=a.side&&target.stackState==StackState.controlled){_destroyTop(target,a,'制圧破壊');_done();} break;
      case ActionMode.merge: if(target!=null&&target.side==a.side&&target.id!=a.id&&target.underId==null){a.row=r;a.col=c;a.underId=target.id;a.stackState=StackState.merged;_record('${a.name} 合流 → ${target.name}');_done();} break;
      case ActionMode.skill: a.level=min(3,a.level+1);a.pu=min(3,a.pu+1);_record('${a.name} 技 / Lv${a.level} Pu${a.pu}');_done(); break;
    }
  }

  void _melee(Piece a,Piece target,int r,int c){
    if(target.underId!=null){final lower=_byId(target.underId);_destroyOnly(target,a,'格闘'); if(lower!=null){lower.stackState=StackState.controlled;lower.underId=null;}_record('下駒は制圧状態');_done();return;}
    _destroyOnly(target,a,'格闘');a.row=r;a.col=c;_done();
  }
  void _destroyTop(Piece target,Piece a,String verb){_destroyOnly(target,a,verb);}
  void _destroyOnly(Piece v,Piece a,String verb){v.destroyed=true;if(a.side==Side.white)whiteKills++;else blackKills++;if(v.large)a.level=min(3,a.level+1);_record('${a.name} $verb → ${v.name}破壊');_checkVictory();}
  void _checkVictory(){int loss(Side s)=>pieces.where((p)=>p.side==s&&p.destroyed&&(p.core||p.leader)).length;final wl=loss(Side.white),bl=loss(Side.black);if(wl>=2)_declare(Side.black,'核/リーダー2喪失');else if(bl>=2)_declare(Side.white,'核/リーダー2喪失');}
  void _declare(Side winner,String why){finished=true;_record('- 𝕧𝕚𝕔𝕥𝕠𝕣𝕪!! - ${winner==Side.white?'WHITE':'BLACK'} / $why');}
  void _record(String s){log.insert(0,s);if(log.length>5)log.removeLast();}
  void _done(){selected=null;mode=null;turn=turn==Side.white?Side.black:Side.white;turnTime=90;tutorialText='${turn==Side.white?'WHITE':'BLACK'} TURN';}

  String _clock(int s)=>'${(s~/60).toString().padLeft(2,'0')}:${(s%60).toString().padLeft(2,'0')}';
  Color _zone(int r)=>r==3?const Color(0xFF33383C):r==2?const Color(0xFF243B4A):r==4?const Color(0xFF4A2A2A):const Color(0xFF10161A);

  @override Widget build(BuildContext context){final white=turn==Side.white;return Scaffold(
    appBar:AppBar(title:Text(widget.tutorialMode?'TUTORIAL':'PRACTICE / OFFLINE CORE'),actions:[IconButton(onPressed:()=>setState(_reset),icon:const Icon(Icons.restart_alt))]),
    body:SafeArea(child:Column(children:[
      _status(Side.black,!white,blackKills,blackTime,blackTimeouts),
      if(widget.tutorialMode)Container(width:double.infinity,padding:const EdgeInsets.all(8),color:Colors.white10,child:Text(tutorialText,textAlign:TextAlign.center)),
      Expanded(child:Padding(padding:const EdgeInsets.all(8),child:AspectRatio(aspectRatio:5/7,child:LayoutBuilder(builder:(context,c){final cw=c.maxWidth/5,ch=c.maxHeight/7;return Stack(children:[
        Column(children:List.generate(7,(r)=>Expanded(child:Row(children:List.generate(5,(col){final legal=_legal(r,col);return Expanded(child:GestureDetector(onTap:()=>setState(()=>_tap(r,col)),child:Container(decoration:BoxDecoration(color:legal?Colors.white.withValues(alpha:.13):_zone(r),border:Border.all(color:Colors.white12)),child:Stack(children:[if(r==3&&col==2)const Center(child:Text('Z',style:TextStyle(fontSize:28,color:Colors.white24,fontWeight:FontWeight.bold))),if((r==2||r==4)&&col==2)Center(child:Text('FRONT LINE',style:TextStyle(fontSize:8,color:r==2?Colors.lightBlueAccent.withValues(alpha:.55):Colors.redAccent.withValues(alpha:.55))))]))));}))))),
        ...pieces.where((p)=>!p.destroyed).map((p){final same=_at(p.row,p.col),idx=same.indexOf(p),isSel=selected?.id==p.id;return Positioned(left:p.col*cw+3,top:p.row*ch+3-idx*5,width:cw-6,height:ch-6,child:IgnorePointer(child:Container(decoration:BoxDecoration(color:p.side==Side.white?const Color(0xFFBAC5CC):const Color(0xFFC9A857),borderRadius:BorderRadius.circular(7),border:Border.all(color:p.stackState==StackState.controlled?Colors.redAccent:p.stackState==StackState.merged?Colors.greenAccent:isSel?Colors.cyanAccent:Colors.black54,width:isSel?3:2),boxShadow:const [BoxShadow(color:Colors.black54,blurRadius:5)]),child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Text(p.name,style:const TextStyle(color:Colors.black,fontSize:18,fontWeight:FontWeight.w900)),if(!p.core)Text('Lv${p.level}  Pu${p.pu}',style:const TextStyle(color:Colors.black87,fontSize:9,fontWeight:FontWeight.bold))])))));}).toList(),
      ]);})))),
      _actionBar(),
      Container(height:72,width:double.infinity,padding:const EdgeInsets.symmetric(horizontal:10,vertical:5),color:Colors.black26,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:log.map((e)=>Text(e,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11,color:Colors.white60))).toList())),
      _status(Side.white,white,whiteKills,whiteTime,whiteTimeouts),
      if(finished)Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:FilledButton(onPressed:()=>setState(_reset),child:const Text('再戦'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:()=>Navigator.pop(context),child:const Text('メニューへ')))])),
    ])),
  );}

  Widget _status(Side s,bool active,int kills,int time,int tos)=>Container(width:double.infinity,padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:active?(s==Side.white?Colors.blueGrey.withValues(alpha:.38):Colors.brown.withValues(alpha:.38)):Colors.black26,border:Border(bottom:BorderSide(color:active?Colors.white54:Colors.transparent,width:2))),child:Row(children:[Text(s==Side.white?'WHITE / SILVER':'BLACK / GOLD',style:TextStyle(fontWeight:FontWeight.bold,color:active?Colors.white:Colors.white54)),const Spacer(),Text('K $kills   ${widget.tutorialMode?'--:--':_clock(time)}   ${widget.tutorialMode?'':'90s $turnTime  TO $tos/3'}',style:const TextStyle(fontSize:12))]));

  Widget _actionBar(){final p=selected;final disabled=p==null||p.side!=turn||finished;Widget b(String t,ActionMode m)=>Expanded(child:Padding(padding:const EdgeInsets.all(2),child:OutlinedButton(onPressed:disabled?null:()=>setState(()=>mode=m),style:OutlinedButton.styleFrom(backgroundColor:mode==m?Colors.white12:null,padding:const EdgeInsets.symmetric(vertical:8,horizontal:2)),child:Text(t,style:const TextStyle(fontSize:11)))));return Container(color:const Color(0xFF090D10),padding:const EdgeInsets.symmetric(horizontal:4,vertical:4),child:Column(children:[if(p!=null)Padding(padding:const EdgeInsets.only(bottom:3),child:Text('${p.name}  Lv${p.level}  Pu${p.pu}',style:const TextStyle(fontSize:12,color:Colors.white70))),Row(children:[b('移動',ActionMode.move),b('格闘',ActionMode.melee),b('射撃',ActionMode.shoot),b('制圧',ActionMode.control),b('合流',ActionMode.merge),b('技',ActionMode.skill)]),Row(children:[b('制圧破壊',ActionMode.controlDestroy),Expanded(child:Padding(padding:const EdgeInsets.all(2),child:OutlinedButton(onPressed:p==null?null:()=>setState((){selected=null;mode=null;}),child:const Text('戻る',style:TextStyle(fontSize:11))))),Expanded(flex:4,child:Text(p==null?'駒をタップ':mode==null?'行動を選択':'対象セルをタップ',textAlign:TextAlign.center,style:const TextStyle(fontSize:11,color:Colors.white54)))]) ]));}
}
