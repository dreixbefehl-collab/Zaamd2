import 'package:flutter/material.dart';
import '../services/bgm_service.dart';
import 'battle_entry_screen.dart';
import 'training_hub_screen.dart';
import 'database_screen.dart';
import 'record_screen.dart';
import 'option_screen.dart';
import 'watch_screen.dart';

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});
  @override State<MainMenuScreen> createState()=>_MainMenuScreenState();
}
class _MainMenuScreenState extends State<MainMenuScreen>{
  @override void initState(){super.initState();WidgetsBinding.instance.addPostFrameCallback((_){BgmService.instance.playLoop('audio/war_room_protocol.mp3',fadeIn:const Duration(milliseconds:850));});}
  void _go(Widget w)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>w));
  @override Widget build(BuildContext context)=>Scaffold(body:Container(
    decoration:const BoxDecoration(gradient:LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF05090D),Color(0xFF0E171D),Color(0xFF050708)])),
    child:SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(24,20,18,18),child:Column(children:[
      Row(children:[const Text('Z_Armed',style:TextStyle(fontSize:18,letterSpacing:2.8)),const Spacer(),IconButton(onPressed:(){},icon:const Icon(Icons.notifications_none_rounded))]),
      const Spacer(flex:2),
      _item('BATTLE',()=>_go(const BattleEntryScreen())),
      _item('WATCH',()=>_go(const WatchScreen())),
      _item('TRAINING',()=>_go(const TrainingHubScreen())),
      _item('DATABASE',()=>_go(const DatabaseScreen())),
      _item('RECORD',()=>_go(const RecordScreen())),
      _item('OPTION',()=>_go(const OptionScreen())),
      const Spacer(flex:3),
      const Align(alignment:Alignment.centerRight,child:Text('INTEGRATED BUILD v1.0',style:TextStyle(fontSize:10,letterSpacing:1.8,color:Colors.white30)))
    ]))),
  ));
  Widget _item(String s,VoidCallback f)=>InkWell(onTap:f,child:Padding(padding:const EdgeInsets.symmetric(vertical:11),child:Center(child:Text(s,style:const TextStyle(fontSize:23,letterSpacing:5,color:Colors.white70)))));
}
